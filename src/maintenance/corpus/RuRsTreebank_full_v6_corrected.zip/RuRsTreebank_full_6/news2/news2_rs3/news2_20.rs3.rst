<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="296" relname="preparation">Успех проекта «Турецкий поток» принесет пользу и выгоду целому ряду стран Юго-Восточной Европы</segment>
		<segment id="2" parent="294" relname="span">Афины заинтересованы в расширении энергетического сотрудничества с Москвой и строительстве на своей территории газопровода в рамках проекта "Турецкий поток".</segment>
		<segment id="3" parent="2" relname="attribution">Об этом заявил премьер-министр Греции Алексис Ципрас (Alexis Tsipras) во время встречи с президентом России Владимиром Путиным (Vladimir Putin) в минувшую среду, 8 апреля.</segment>
		<segment id="4" parent="479" relname="attribution">По его мнению,</segment>
		<segment id="5" parent="292" relname="joint">проект позволит привлечь дополнительные инвестиции в экономику Греции,</segment>
		<segment id="6" parent="292" relname="joint">стабилизировать обстановку в регионе</segment>
		<segment id="7" parent="293" relname="span">и создать хороший повод</segment>
		<segment id="8" parent="7" relname="purpose">для потенциального улучшения отношений с Анкарой.</segment>
		<segment id="9" parent="297" relname="span">Как ожидается, на границе Турции и Греции будет построен газовый хаб,</segment>
		<segment id="10" parent="9" relname="elaboration">вместимость которого составит 50 млрд. кубометров.</segment>
		<segment id="11" parent="297" relname="elaboration">Оттуда нитку можно протянуть на север Греции, а уже затем и к европейским потребителям: на территорию Македонии, Сербии, Венгрии и потом Австрии.</segment>
		<segment id="12" parent="300" relname="attribution">Днем ранее, 7 апреля, главы МИД Турции и четырех балканских стран - Греции, Сербии, Македонии и Венгрии - по итогам переговоров в Будапеште заявили,</segment>
		<segment id="13" parent="299" relname="joint">что поддерживают идею диверсификации поставок природного газа</segment>
		<segment id="14" parent="299" relname="joint">и готовы присоединиться к "Турецкому потоку".</segment>
		<segment id="15" parent="302" relname="joint">Также они подписали декларацию об энергосотрудничестве.</segment>
		<segment id="16" parent="482" relname="attribution">В конце марта о важной роли "Турецкого потока" напомнил президент Турции Реджеп Тайип Эрдоган (Recep Tayyip Erdogan) после встречи в Киеве с главой Украины Петром Порошенко (Petro Poroshenko).</segment>
		<segment id="17" parent="18" relname="attribution">Он подчеркнул,</segment>
		<segment id="18" parent="482" relname="span">что считает приемлемым предложение России о строительстве нового газопровода после отказа от "Южного потока".</segment>
		<segment id="19" parent="481" relname="same-unit">Это,</segment>
		<segment id="20" parent="21" relname="attribution">по мнению президента Турции,</segment>
		<segment id="21" parent="480" relname="span">позволит диверсифицировать источники газоснабжения.</segment>
		<segment id="22" parent="310" relname="preparation">Планы по строительству газопровода вызвали пристальное внимание турецких СМИ.</segment>
		<segment id="23" parent="24" relname="attribution">Как пишут издания,</segment>
		<segment id="24" parent="485" relname="span">решение Реджепа Тайипа Эрдогана может трансформировать страну из транзитера в ведущего поставщика "голубого топлива" в Европу,</segment>
		<segment id="25" parent="305" relname="joint">что значительно укрепит позиции Анкары</segment>
		<segment id="26" parent="305" relname="joint">и принесет стране дополнительную прибыль.</segment>
		<segment id="27" parent="306" relname="attribution">При этом, как заявил министр энергетики и природных ресурсов Турции Танер Йылдыз (Taner Yildiz),</segment>
		<segment id="28" parent="306" relname="span">"Турецкий поток" не является конкурентом строящегося газопровода "TANAP",</segment>
		<segment id="29" parent="28" relname="cause">поскольку поставки будут идти параллельно.</segment>
		<segment id="30" parent="31" relname="attribution">Вместе с тем он признал,</segment>
		<segment id="31" parent="573" relname="span">что "голубое топливо" из Азербайджана будет стоить дороже российского,</segment>
		<segment id="32" parent="308" relname="contrast">однако сравнительно низкая цена энергоносителей из РФ сделает весь газ более доступным для населения.</segment>
		<segment id="33" parent="486" relname="attribution">Вместе c тем некоторые международные эксперты высказывают опасения,</segment>
		<segment id="34" parent="486" relname="span">что инициатива Москвы и Анкары рискует встретить очередное сопротивление со стороны западных политиков,</segment>
		<segment id="35" parent="34" relname="cause">из-за действий которых фактически и было принято решение о закрытии "Южного потока".</segment>
		<segment id="36" parent="560" relname="span">Так, например, двухдневный визит премьер-министра Греции Алексиса Ципраса в Москву уже вызвал критику представителей Евросоюза,</segment>
		<segment id="37" parent="315" relname="joint">которые недовольны тем, что Афины пытаются вести самостоятельную политику</segment>
		<segment id="38" parent="316" relname="span">и стремятся к сближению с Россией</segment>
		<segment id="39" parent="38" relname="purpose">с целью решения своих внутренних экономических проблем.</segment>
		<segment id="40" parent="491" relname="same-unit">Кроме того,</segment>
		<segment id="41" parent="42" relname="attribution">в СМИ появляются сообщения,</segment>
		<segment id="42" parent="489" relname="span">что Евросоюз и США могут прибегнуть к дестабилизации политической ситуации в тех странах, которые намерены участвовать в реализации "Турецкого потока".</segment>
		<segment id="43" parent="317" relname="span">В качестве примера приводится попытка неудавшегося государственного переворота в Македонии,</segment>
		<segment id="44" parent="43" relname="elaboration">которая была пресечена правоохранительными органами в конце января.</segment>
		<segment id="45" parent="325" relname="joint">Альтернативным вариантом, как пишут зарубежные издания, может стать нагнетание напряженности в самой Турции,</segment>
		<segment id="46" parent="326" relname="contrast">при этом не исключено, что разменной монетой в этой игре окажется часть 75-миллионого населения страны - крымские татары, которых насчитывается около 100 тыс. человек.</segment>
		<segment id="47" parent="318" relname="span">Однако численность жителей,</segment>
		<segment id="48" parent="47" relname="background">предки которых в разное время иммигрировали из Крыма в Турцию,</segment>
		<segment id="49" parent="319" relname="same-unit">оценивается не менее чем в 5 млн. человек.</segment>
		<segment id="50" parent="323" relname="span">Именно они могут сыграть решающую роль в приостановке реализации масштабного газового проекта.</segment>
		<segment id="51" parent="321" relname="span">Для этого всего лишь следует развернуть массированную информационную кампанию о притеснениях крымских татар и о несоблюдении их прав в Крыму,</segment>
		<segment id="52" parent="51" relname="condition">подключив к этому общественные организации и СМИ.</segment>
		<segment id="53" parent="494" relname="attribution">Как отмечает турецкий обозреватель Мехмет Кубат (Mehmet Kubat),</segment>
		<segment id="54" parent="55" relname="attribution">в социальных сетях в последнее время уже появляются сообщения о том,</segment>
		<segment id="55" parent="494" relname="span">что крымским татарам в Турции следует проявлять большую инициативу и организованность для достижения результата.</segment>
		<segment id="56" parent="495" relname="attribution">По его словам,</segment>
		<segment id="57" parent="58" relname="attribution">некоторые пользователи открыто призывают</segment>
		<segment id="58" parent="495" relname="span">блокировать строительство объектов газопровода "Турецкий поток".</segment>
		<segment id="59" parent="60" relname="attribution">При этом журналист отмечает,</segment>
		<segment id="60" parent="496" relname="span">что технология манипулирования людьми через Twitter и Facebook является давно отработанной.</segment>
		<segment id="61" parent="497" relname="attribution">Он напоминает,</segment>
		<segment id="62" parent="497" relname="span">что ее применял Госдепартамент США в Египте, Ливии, Сирии, Украине и других странах</segment>
		<segment id="63" parent="62" relname="purpose">для дестабилизации обстановки.</segment>
		<segment id="64" parent="65" relname="attribution">В свою очередь заведующий отделом Ближнего Востока немецкого Общества защиты угнетенных народов Камаль Сидо (Kamal Sido) указал</segment>
		<segment id="65" parent="502" relname="span">на ряд других проблем, которые могут встать на пути у проекта в Турции.</segment>
		<segment id="66" parent="330" relname="span">"Мы знаем, что курдский вопрос еще не решен.</segment>
		<segment id="67" parent="327" relname="contrast">Между Рабочей партией Курдистана, [лидером партии] Абдуллой Оджаланом (Abdullah Ocalan) и турецким правительством идут переговоры,</segment>
		<segment id="68" parent="327" relname="contrast">но пока окончательного решения нет.</segment>
		<segment id="69" parent="328" relname="span">Это, конечно, будет оказывать негативное влияние на тему газопровода до тех пор,</segment>
		<segment id="70" parent="69" relname="condition">пока эти проблемы не будут разрешены",</segment>
		<segment id="71" parent="503" relname="attribution">- пояснил он.</segment>
		<segment id="72" parent="73" relname="attribution">Эксперт добавил,</segment>
		<segment id="73" parent="504" relname="span">что отдельные вопросы, требующие диалога, существуют и в отношениях с другими национальными меньшинствами в Турции.</segment>
		<segment id="74" parent="506" relname="same-unit">Кроме того,</segment>
		<segment id="75" parent="76" relname="attribution">по его словам,</segment>
		<segment id="76" parent="505" relname="span">некоторые крымские татары,</segment>
		<segment id="77" parent="507" relname="background">которые находились на Украине в момент вхождения Крыма в состав России,</segment>
		<segment id="78" parent="333" relname="same-unit">не имеют сейчас возможности вернуться назад,</segment>
		<segment id="79" parent="334" relname="joint">и правозащитные организации работают в этом направлении.</segment>
		<segment id="80" parent="81" relname="attribution">Экономист, профессор кафедры экономики и менеджмента университета Кырыккале Харун Озтюрклер (Harun Ozturkler) предположил,</segment>
		<segment id="81" parent="337" relname="span">что строительство газопровода "Турецкий поток" вряд ли будет сопровождаться масштабными народными волнениями.</segment>
		<segment id="82" parent="338" relname="contrast">"Я не политолог,</segment>
		<segment id="83" parent="84" relname="attribution">но считаю,</segment>
		<segment id="84" parent="574" relname="span">что никто не сможет разжечь подобные протесты.</segment>
		<segment id="85" parent="339" relname="joint">Даже самые крупные акции были скромными по численности</segment>
		<segment id="86" parent="339" relname="joint">и не длились более нескольких дней",</segment>
		<segment id="87" parent="509" relname="attribution">- пояснил он.</segment>
		<segment id="88" parent="563" relname="condition">Говоря о значимости "Турецкого потока",</segment>
		<segment id="89" parent="90" relname="attribution">эксперт назвал</segment>
		<segment id="90" parent="563" relname="span">его новым этапом стратегических отношений между Европой, Россией и Турцией,</segment>
		<segment id="91" parent="92" relname="attribution">выразив надежду,</segment>
		<segment id="92" parent="576" relname="span">что в будущем это решение может изменить географию европейского рынка энергоносителей.</segment>
		<segment id="93" parent="570" relname="span">"Украинский кризис продолжается.</segment>
		<segment id="94" parent="342" relname="joint">На этом фоне политическая и экономическая значимость проекта заключается в том, что он может сделать Украину менее важной для Евросоюза</segment>
		<segment id="95" parent="345" relname="span">и дать России преимущество на политической арене в диалоге с Западом и США",</segment>
		<segment id="96" parent="344" relname="attribution">- подчеркнул экономист,</segment>
		<segment id="97" parent="98" relname="attribution">добавив,</segment>
		<segment id="98" parent="577" relname="span">что на сегодняшний день у Европы по-прежнему нет полноценной альтернативы российским поставкам газа.</segment>
		<segment id="99" parent="100" relname="attribution">По его мнению,</segment>
		<segment id="100" parent="514" relname="span">наибольшую выгоду от строительства "Турецкого потока" извлечет Греция.</segment>
		<segment id="101" parent="347" relname="span">"Турецкий поток" поможет разрушенной экономике Афин через инвестиции и новые рабочие места",</segment>
		<segment id="102" parent="101" relname="attribution">- пояснил Харун Озтюрклер.</segment>
		<segment id="103" parent="349" relname="same-unit">В то же время</segment>
		<segment id="104" parent="564" relname="attribution">он обратил внимание на то,</segment>
		<segment id="105" parent="349" relname="same-unit">что для Турции совместный с Россией проект может стать очень прибыльным, особенно в сочетании</segment>
		<segment id="106" parent="348" relname="span">с газопроводом "TANAP",</segment>
		<segment id="107" parent="106" relname="attribution">о строительстве которого официально было заявлено в марте 2015 года.</segment>
		<segment id="108" parent="350" relname="span">"Не думаю, что эти проекты могут заменить друг друга,</segment>
		<segment id="109" parent="108" relname="cause">так как они соревнуются за поставки газа в ЕС.</segment>
		<segment id="110" parent="111" relname="condition">Если смотреть на ситуацию с позиции Анкары,</segment>
		<segment id="111" parent="351" relname="span">российский проект и газопровод "TANAP" позволят Турции подняться от транзитера до рынка энергоносителей",</segment>
		<segment id="112" parent="352" relname="attribution">- сказал экономист.</segment>
		<segment id="113" parent="565" relname="condition">Говоря о противниках "Турецкого потока",</segment>
		<segment id="114" parent="115" relname="attribution">он предположил,</segment>
		<segment id="115" parent="565" relname="span">что его запуск может помешать планам Соединенных Штатов и ряда государств Ближнего Востока.</segment>
		<segment id="116" parent="357" relname="span">"Этот проект не сочетается с экономическими и политическими интересами Ирана, Курдистана и США.</segment>
		<segment id="117" parent="356" relname="span">Он сделает альтернативные поставки природного газа из Ирана и Северного Ирака менее конкурентоспособными",</segment>
		<segment id="118" parent="357" relname="attribution">- пояснил эксперт,</segment>
		<segment id="119" parent="120" relname="attribution">отметив,</segment>
		<segment id="120" parent="578" relname="span">что официальный Тегеран может в будущем оказать определенное влияние на ход событий.</segment>
		<segment id="121" parent="359" relname="span">Также, с его точки зрения, ход переговоров может измениться</segment>
		<segment id="122" parent="121" relname="cause">под влиянием Тель-Авива или из-за нестабильности отношений между Афинами и Анкарой.</segment>
		<segment id="123" parent="361" relname="span">"Израиль может повлиять на Грецию,</segment>
		<segment id="124" parent="123" relname="condition">воспользовавшись энергетическими договорами с Южным Кипром.</segment>
		<segment id="125" parent="362" relname="span">Более того, могут возникнуть проблемы в отношениях Турции и Греции.</segment>
		<segment id="126" parent="363" relname="span">Обе стороны хотят построить у себя хаб</segment>
		<segment id="127" parent="126" relname="purpose">для продажи газа,</segment>
		<segment id="128" parent="360" relname="contrast">а не просто выступать в роли транзитера",</segment>
		<segment id="129" parent="520" relname="attribution">- заметил экономист.</segment>
		<segment id="130" parent="131" relname="attribution">Он напомнил также,</segment>
		<segment id="131" parent="521" relname="span">что переговоры о деталях строительства "Турецкого потока" проходят на фоне широкомасштабного противостояния мировых держав.</segment>
		<segment id="132" parent="367" relname="joint">"Самыми крупными соперниками Запада являются Россия и Китай,</segment>
		<segment id="133" parent="367" relname="joint">и Украина стала очередным полем битвы.</segment>
		<segment id="134" parent="135" relname="evaluation">Неудивительно, что</segment>
		<segment id="135" parent="571" relname="span">все ищут способы помешать друг другу.</segment>
		<segment id="136" parent="579" relname="attribution">Но я считаю, что</segment>
		<segment id="137" parent="138" relname="cause">из-за спроса на энергоносители и рынки сбыта</segment>
		<segment id="138" parent="368" relname="span">в долгосрочной перспективе ЕС больше зависит от России, нежели наоборот.</segment>
		<segment id="139" parent="368" relname="cause">Недавние энергетические соглашения России с Китаем и Шанхаем только подтверждают мои слова", -</segment>
		<segment id="140" parent="374" relname="attribution">подчеркнул Харун Озтюрклер.</segment>
		<segment id="141" parent="142" relname="attribution">В продолжение этой темы научный сотрудник Группы по исследованию энергетической политики Кембриджского университета, директор Форума по энергетической политике Чи Конг Чонг (Chi Kong Chyong) обратил внимание на то,</segment>
		<segment id="142" parent="376" relname="span">что полностью построенный газопровод из России в Турцию представляет значительную угрозу для политического и экономического положения Украины.</segment>
		<segment id="143" parent="525" relname="attribution">"Представители политической элиты и общественности полагают,</segment>
		<segment id="144" parent="377" relname="joint">что полностью построенный "Турецкий поток" - все четыре нитки - может подорвать позиции Украины как самого крупного транзитера российского газа в Европе</segment>
		<segment id="145" parent="377" relname="joint">и оставить Киев практически без средств экономического влияния на Москву",</segment>
		<segment id="146" parent="378" relname="attribution">- пояснил эксперт в интервью ИА "PenzaNews".</segment>
		<segment id="147" parent="527" relname="same-unit">Однако Евросоюз,</segment>
		<segment id="148" parent="149" relname="attribution">по его словам,</segment>
		<segment id="149" parent="526" relname="span">только выиграет от одновременных поставок газа из России и Азербайджана.</segment>
		<segment id="150" parent="385" relname="span">"Вопрос о сосуществовании "Турецкого потока" и "TANAP" не стоит, по крайней мере,</segment>
		<segment id="151" parent="150" relname="attribution">с точки зрения Европы.</segment>
		<segment id="152" parent="153" relname="condition">Чем больше конкуренция между поставщиками,</segment>
		<segment id="153" parent="382" relname="span">тем лучше для потребителя",</segment>
		<segment id="154" parent="529" relname="attribution">- сказал аналитик.</segment>
		<segment id="155" parent="383" relname="attribution">При этом Чи Конг Чонг добавил,</segment>
		<segment id="156" parent="383" relname="span">что страны-транзитеры по отдельности также не останутся в проигрыше,</segment>
		<segment id="157" parent="156" relname="cause">поскольку обеспечат себе прямой доступ к энергоносителям, дополнительную прибыль и возможность укрепить свои позиции в контактах как с Москвой, так и Брюсселем.</segment>
		<segment id="158" parent="388" relname="attribution">По мнению исследователя в области энергетики,</segment>
		<segment id="159" parent="160" relname="condition">если юридические и технические тонкости будут соблюдены,</segment>
		<segment id="160" parent="388" relname="span">ЕС никоим образом не сможет вмешаться в ход проекта.</segment>
		<segment id="161" parent="582" relname="same-unit">"Если</segment>
		<segment id="162" parent="163" relname="attribution">"Газпром" докажет,</segment>
		<segment id="163" parent="581" relname="span">что может построить "Турецкий поток" с минимальными затратами, на эталонном уровне строительства подводного участка и с соблюдением законодательства,</segment>
		<segment id="164" parent="583" relname="condition">разрешив вопросы, связанные с конкуренцией, закупками и транспарентностью,</segment>
		<segment id="165" parent="390" relname="span">тогда этот проект сможет остановить только Турция",</segment>
		<segment id="166" parent="390" relname="attribution">- уточнил он.</segment>
		<segment id="167" parent="168" relname="attribution">Также Чи Конг Чонг выразил уверенность</segment>
		<segment id="168" parent="393" relname="span">в том, что с коммерческой и практической точки зрения новый проект гораздо лучше закрытого "Южного потока".</segment>
		<segment id="169" parent="566" relname="joint">"Турция представляет собой один из самых быстро растущих рынков газа,</segment>
		<segment id="170" parent="171" relname="cause">а поскольку "Газпром" уже инвестировал в регион значительные средства,</segment>
		<segment id="171" parent="391" relname="span">строительство, по меньшей мере, двух первых ниток "Турецкого потока" является вполне разумным шагом.</segment>
		<segment id="172" parent="398" relname="joint">Первая нитка заменит нынешний путь поставок из России в Турцию через Украину,</segment>
		<segment id="173" parent="394" relname="span">а вторая нитка позволит "Газпрому" предоставить Анкаре больше газа,</segment>
		<segment id="174" parent="173" relname="purpose">чтобы удовлетворить дополнительный спрос.</segment>
		<segment id="175" parent="395" relname="span">Иначе говоря, первые две нитки "Турецкого потока" будет легко построить,</segment>
		<segment id="176" parent="175" relname="cause">поскольку деньги уже были затрачены,</segment>
		<segment id="177" parent="396" relname="joint">а это позволит "Газпрому" расширить проект</segment>
		<segment id="178" parent="397" relname="span">и проложить еще две нитки</segment>
		<segment id="179" parent="178" relname="purpose">для поставок в Европу,</segment>
		<segment id="180" parent="397" relname="condition">если политическая обстановка в ЕС будет подходящей",</segment>
		<segment id="181" parent="532" relname="attribution">- сказал собеседник агентства.</segment>
		<segment id="182" parent="403" relname="attribution">В то же время известный эксперт по энергетической политике, председатель комитета по энергетике оппозиционной Республиканской народной партии Турции Некдет Памир (Necdet Pamir) напомнил,</segment>
		<segment id="183" parent="403" relname="span">что представители Соединенных Штатов и Евросоюза развернули масштабную кампанию против России</segment>
		<segment id="184" parent="183" relname="purpose">с целью оказания на нее давления.</segment>
		<segment id="185" parent="534" relname="attribution">При этом он подчеркнул,</segment>
		<segment id="186" parent="534" relname="span">что оппоненты Москвы прибегают как к экономическим санкциям, так и к спекуляции на сырьевом рынке</segment>
		<segment id="187" parent="186" relname="condition">при поддержке Саудовской Аравии.</segment>
		<segment id="188" parent="407" relname="span">"Американцы и саудиты хотят одной пулей убить нескольких зайцев:</segment>
		<segment id="189" parent="406" relname="span">[Америка хочет] ограничить нефтегазовую прибыль России, Ирана и даже Венесуэлы,</segment>
		<segment id="190" parent="189" relname="condition">одновременно уменьшив расходы США на импорт нефти.</segment>
		<segment id="191" parent="405" relname="joint">В свою очередь Саудовская Аравия стремится расширить влияние в регионе в ходе противостояния с РФ и Ираном,</segment>
		<segment id="192" parent="405" relname="joint">а также забрать себе часть российского рынка сбыта нефти",</segment>
		<segment id="193" parent="409" relname="attribution">- пояснил Некдет Памир.</segment>
		<segment id="194" parent="411" relname="attribution">По его мнению,</segment>
		<segment id="195" parent="196" relname="condition">в нынешних экономических условиях</segment>
		<segment id="196" parent="411" relname="span">газовый проект может оказаться слишком дорогим,</segment>
		<segment id="197" parent="412" relname="span">особенно если учесть тот факт,</segment>
		<segment id="198" parent="197" relname="elaboration">что проложить трубопровод через Турцию и Грецию в Европу является нелегкой задачей.</segment>
		<segment id="199" parent="414" relname="attribution">Некдет Памир добавил,</segment>
		<segment id="200" parent="414" relname="span">что успех "Турецкого потока" во многом зависит от того,</segment>
		<segment id="201" parent="413" relname="joint">смогут ли Россия и Евросоюз прийти к консенсусу</segment>
		<segment id="202" parent="413" relname="joint">и будет ли Брюссель готов покупать российский газ у другого поставщика.</segment>
		<segment id="203" parent="423" relname="span">"Неважно, пойдет ли он через Болгарию или через Турцию.</segment>
		<segment id="204" parent="205" relname="condition">Если газ пойдет в Турцию,</segment>
		<segment id="205" parent="418" relname="span">то затем его нужно будет направить в Европу.</segment>
		<segment id="206" parent="207" relname="condition">Если европейские страны откажутся покупать российский газ,</segment>
		<segment id="207" parent="419" relname="span">то этот грандиозный по стоимости проект ни к чему не приведет",</segment>
		<segment id="208" parent="421" relname="attribution">- констатировал он,</segment>
		<segment id="209" parent="420" relname="span">не исключив также и возможного возврата к проекту "Южный поток"</segment>
		<segment id="210" parent="209" relname="condition">при нормализации отношений между Москвой и Брюсселем.</segment>
		<segment id="211" parent="540" relname="attribution">В то же время он усомнился в том,</segment>
		<segment id="212" parent="540" relname="span">что Турция сможет извлечь выгоду из совместного проекта</segment>
		<segment id="213" parent="212" relname="condition">при тех условиях, которые известны только на данный момент.</segment>
		<segment id="214" parent="544" relname="same-unit">В частности,</segment>
		<segment id="215" parent="542" relname="attribution">по мнению эксперта,</segment>
		<segment id="216" parent="542" relname="span">остаются нерешенным вопросы цены на газ, реэкспорта, а также строительства соответствующей инфраструктуры</segment>
		<segment id="217" parent="216" relname="purpose">для хранения газа.</segment>
		<segment id="218" parent="219" relname="attribution">При этом он напомнил,</segment>
		<segment id="219" parent="545" relname="span">что на сегодняшний день Турция уже импортирует из России 59% потребляемых объемов природного газа, 32% угля и 8% нефти.</segment>
		<segment id="220" parent="221" relname="attribution">Отвечая на вопрос о том,</segment>
		<segment id="221" parent="586" relname="span">как "Турецкий поток" будет сочетаться с азербайджанским газопроводом "TANAP",</segment>
		<segment id="222" parent="425" relname="attribution">Некдет Памир подчеркнул,</segment>
		<segment id="223" parent="425" relname="span">что эти проекты в будущем могут оказаться в ситуации,</segment>
		<segment id="224" parent="223" relname="elaboration">когда один из поставщиков рискует остаться без покупателя.</segment>
		<segment id="225" parent="435" relname="span">"Евросоюз стремится не только к диверсификации поставщиков, но и к снижению объемов потребления и увеличению доли возобновляемых источников энергии.</segment>
		<segment id="226" parent="225" relname="evaluation">Для обоих проектов может не хватить места",</segment>
		<segment id="227" parent="435" relname="attribution">- пояснил он.</segment>
		<segment id="228" parent="434" relname="span">Однако представитель Республиканской народной партии Турции затруднился провести конкретное сравнение между "Турецким потоком" и "TANAP".</segment>
		<segment id="229" parent="550" relname="attribution">Он отметил,</segment>
		<segment id="230" parent="430" relname="contrast">что поставки из Москвы выгодны с точки зрения объемов,</segment>
		<segment id="231" parent="430" relname="contrast">но противоречат энергетической политике Брюсселя,</segment>
		<segment id="232" parent="431" relname="contrast">тогда как поставки из Азербайджана соответствуют этим задачам,</segment>
		<segment id="233" parent="432" relname="span">но теряют в привлекательности</segment>
		<segment id="234" parent="233" relname="cause">из-за высоких расходов на транспортировку и малых объемов.</segment>
		<segment id="235" parent="236" relname="attribution">По словам Некдета Памира,</segment>
		<segment id="236" parent="439" relname="span">сразу после введения в эксплуатацию азербайджанский газопровод будет поставлять в Европу лишь 10 млрд. кубометров "голубого топлива" в год,</segment>
		<segment id="237" parent="595" relname="same-unit">в то время как Россия,</segment>
		<segment id="238" parent="239" relname="attribution">согласно данным на 2013 год,</segment>
		<segment id="239" parent="596" relname="span">уже поставляла в страны ЕС и Турцию свыше 160 млрд. кубометров газа ежегодно.</segment>
		<segment id="240" parent="444" relname="attribution">В свою очередь старший научный сотрудник, глава научно-исследовательской программы по вопросам природного газа Оксфордского института энергетических исследований Джонатан Стерн (Jonathan Stern) предположил,</segment>
		<segment id="241" parent="443" relname="joint">что "Турецкий поток" и "TANAP" будут беспрепятственно сосуществовать,</segment>
		<segment id="242" parent="243" relname="condition">а при благоприятном развитии событий</segment>
		<segment id="243" parent="442" relname="span">могут быть оба подключены к проектируемому Трансадриатическому газопроводу ("TAP") на границе Турции и Греции.</segment>
		<segment id="244" parent="245" relname="attribution">При этом эксперт подчеркнул,</segment>
		<segment id="245" parent="551" relname="span">что о проекте до сих пор известно очень мало.</segment>
		<segment id="246" parent="447" relname="evaluation">"Я ожидал, что работы начнутся гораздо быстрее.</segment>
		<segment id="247" parent="447" relname="span">Мы еще ничего не знаем о "Турецком потоке", кроме намерений "Газпрома".</segment>
		<segment id="248" parent="446" relname="joint">Мы не знаем, дало ли турецкое правительство окончательное согласие;</segment>
		<segment id="249" parent="446" relname="joint">началась ли разведка морского дна;</segment>
		<segment id="250" parent="446" relname="joint">когда будут прокладывать трубы и так далее",</segment>
		<segment id="251" parent="448" relname="attribution">- уточнил он.</segment>
		<segment id="252" parent="253" relname="attribution">В то же время Джонатан Стерн выразил уверенность в том,</segment>
		<segment id="253" parent="449" relname="span">что ни Украина, ни Евросоюз не смогут помешать планам России и Турции.</segment>
		<segment id="254" parent="452" relname="joint">"Ни Киев, ни Брюссель [в проекте] не участвуют.</segment>
		<segment id="255" parent="451" relname="span">Евросоюз может поставить только одно условие:</segment>
		<segment id="256" parent="255" relname="elaboration">газ, который будет поступать в страны Европы, должен соответствовать по условиям и качеству европейскому законодательству. И не более того", - констатировал аналитик.</segment>
		<segment id="257" parent="258" relname="attribution">Он отметил также,</segment>
		<segment id="258" parent="554" relname="span">что сейчас пока сложно говорить о том, как именно будет развиваться ситуация с ответвлением "Турецкого потока" на Балканском полуострове.</segment>
		<segment id="259" parent="456" relname="span">"Очень многое зависит от того, будут ли продлены транспортные контракты "Газпрома" в этих странах",</segment>
		<segment id="260" parent="259" relname="attribution">- сказал эксперт,</segment>
		<segment id="261" parent="587" relname="attribution">добавив,</segment>
		<segment id="262" parent="454" relname="same-unit">что отдельные государства</segment>
		<segment id="263" parent="264" relname="condition">при определенных обстоятельствах</segment>
		<segment id="264" parent="453" relname="span">могут отказаться от участия в строительстве "Балканского потока"</segment>
		<segment id="265" parent="455" relname="joint">и продолжить получать газ через Украину.</segment>
		<segment id="266" parent="267" relname="attribution">Вместе с тем исследователь турецкого Фонда политических, экономических и социальных исследований Салихе Кая (Salihe Kaya) выразила абсолютную уверенность в том,</segment>
		<segment id="267" parent="459" relname="span">что "Турецкий поток" предоставит балканским государствам прекрасную возможность поднять экономику и промышленность.</segment>
		<segment id="268" parent="460" relname="span">"Отношения между Турцией и Грецией пойдут в гору.</segment>
		<segment id="269" parent="268" relname="cause">Помимо Греции, проект будет выгодным для Македонии, Боснии и Герцеговины, Сербии, Албании и Черногории",</segment>
		<segment id="270" parent="460" relname="attribution">- пояснила эксперт.</segment>
		<segment id="271" parent="557" relname="attribution">По ее мнению,</segment>
		<segment id="272" parent="557" relname="span">Анкара имела все предпосылки</segment>
		<segment id="273" parent="272" relname="purpose">для запуска крупномасштабного энергетического проекта совместно с Москвой.</segment>
		<segment id="274" parent="462" relname="joint">"Турция расположена в прекрасной точке между Балканами, Ближним Востоком и Кавказом.</segment>
		<segment id="275" parent="464" relname="joint">Кроме того, Россия и Турция успешно развивают конструктивные отношения по ряду политических вопросов,</segment>
		<segment id="276" parent="463" relname="span">а их экономическое сотрудничество не ограничивается энергетикой и выходом к Черному морю",</segment>
		<segment id="277" parent="276" relname="attribution">- сказала исследователь,</segment>
		<segment id="278" parent="279" relname="attribution">добавив,</segment>
		<segment id="279" parent="589" relname="span">что и "Турецкий поток", и "TANAP" отвечают многополярным геополитическим и экономическим интересам страны.</segment>
		<segment id="280" parent="281" relname="attribution">В то же время она предположила,</segment>
		<segment id="281" parent="591" relname="span">что строительство нового газопровода вряд ли будет сопровождаться какими-либо акциями протеста.</segment>
		<segment id="282" parent="465" relname="span">"На мой взгляд, сейчас никаких предпосылок для негативного развития ситуации нет,</segment>
		<segment id="283" parent="282" relname="cause">поскольку проект вызвал положительную реакцию со стороны турецкого правительства и общественности",</segment>
		<segment id="284" parent="465" relname="attribution">- отметила Салихе Кая.</segment>
		<segment id="285" parent="593" relname="attribution">В заключение представитель Фонда политических, экономических и социальных исследований добавила,</segment>
		<segment id="286" parent="469" relname="joint">что расширение энергосотрудничества с Москвой позволит Анкаре воспользоваться стратегическим преимуществом в регионе</segment>
		<segment id="287" parent="469" relname="joint">и сделает страну более привлекательной для инвестиций.</segment>
		<segment id="288" parent="470" relname="contrast">"У проекта есть и преимущества, и недостатки.</segment>
		<segment id="289" parent="470" relname="contrast">Однако в долгосрочной перспективе он позволит Турции стать энергетическим хабом с правом устанавливать свои цены на природный газ.</segment>
		<segment id="290" parent="471" relname="evaluation">Это очень перспективный проект для будущего Турции",</segment>
		<segment id="291" parent="472" relname="attribution">- подытожила Салихе Кая.</segment>
		<group id="292" type="multinuc" parent="479" relname="span"/>
		<group id="293" type="span" parent="292" relname="joint"/>
		<group id="294" type="span" parent="295" relname="span"/>
		<group id="295" type="span" parent="303" relname="span"/>
		<group id="296" type="span" parent="304" relname="span"/>
		<group id="297" type="span" parent="298" relname="span"/>
		<group id="298" type="span" parent="295" relname="elaboration"/>
		<group id="299" type="multinuc" parent="300" relname="span"/>
		<group id="300" type="span" parent="301" relname="span"/>
		<group id="301" type="span" parent="302" relname="joint"/>
		<group id="302" type="multinuc" parent="314" relname="sequence"/>
		<group id="303" type="span" parent="296" relname="span"/>
		<group id="304" type="span" />
		<group id="305" type="multinuc" parent="309" relname="span"/>
		<group id="306" type="span" parent="307" relname="span"/>
		<group id="307" type="span" parent="313" relname="joint"/>
		<group id="308" type="multinuc" parent="313" relname="joint"/>
		<group id="309" type="span" parent="310" relname="span"/>
		<group id="310" type="span" parent="311" relname="span"/>
		<group id="311" type="span" parent="312" relname="joint"/>
		<group id="312" type="multinuc" />
		<group id="313" type="multinuc" parent="312" relname="joint"/>
		<group id="314" type="multinuc" />
		<group id="315" type="multinuc" parent="36" relname="elaboration"/>
		<group id="316" type="span" parent="315" relname="joint"/>
		<group id="317" type="span" parent="490" relname="elaboration"/>
		<group id="318" type="span" parent="319" relname="same-unit"/>
		<group id="319" type="multinuc" parent="322" relname="span"/>
		<group id="320" type="span" parent="326" relname="contrast"/>
		<group id="321" type="span" parent="324" relname="span"/>
		<group id="322" type="span" parent="320" relname="span"/>
		<group id="323" type="span" parent="322" relname="elaboration"/>
		<group id="324" type="span" parent="50" relname="purpose"/>
		<group id="325" type="multinuc" />
		<group id="326" type="multinuc" parent="325" relname="joint"/>
		<group id="327" type="multinuc" parent="66" relname="elaboration"/>
		<group id="328" type="span" parent="503" relname="span"/>
		<group id="329" type="span" parent="331" relname="span"/>
		<group id="330" type="span" parent="328" relname="cause"/>
		<group id="331" type="span" parent="336" relname="span"/>
		<group id="332" type="span" parent="333" relname="same-unit"/>
		<group id="333" type="multinuc" parent="334" relname="joint"/>
		<group id="334" type="multinuc" parent="335" relname="joint"/>
		<group id="335" type="multinuc" parent="331" relname="elaboration"/>
		<group id="336" type="span" />
		<group id="337" type="span" parent="341" relname="span"/>
		<group id="338" type="multinuc" parent="509" relname="span"/>
		<group id="339" type="multinuc" parent="574" relname="cause"/>
		<group id="341" type="span" parent="512" relname="preparation"/>
		<group id="342" type="multinuc" parent="343" relname="span"/>
		<group id="343" type="span" parent="344" relname="span"/>
		<group id="344" type="span" parent="346" relname="span"/>
		<group id="345" type="span" parent="342" relname="joint"/>
		<group id="346" type="span" parent="93" relname="elaboration"/>
		<group id="347" type="span" parent="514" relname="elaboration"/>
		<group id="348" type="span" parent="349" relname="same-unit"/>
		<group id="349" type="multinuc" parent="564" relname="span"/>
		<group id="350" type="span" parent="352" relname="span"/>
		<group id="351" type="span" parent="350" relname="elaboration"/>
		<group id="352" type="span" parent="516" relname="span"/>
		<group id="353" type="multinuc" parent="358" relname="comparison"/>
		<group id="354" type="span" parent="353" relname="comparison"/>
		<group id="355" type="span" parent="354" relname="span"/>
		<group id="356" type="span" parent="116" relname="cause"/>
		<group id="357" type="span" parent="518" relname="span"/>
		<group id="358" type="multinuc" />
		<group id="359" type="span" parent="365" relname="preparation"/>
		<group id="360" type="multinuc" parent="125" relname="elaboration"/>
		<group id="361" type="span" parent="364" relname="joint"/>
		<group id="362" type="span" parent="364" relname="joint"/>
		<group id="363" type="span" parent="360" relname="contrast"/>
		<group id="364" type="multinuc" parent="520" relname="span"/>
		<group id="365" type="span" parent="366" relname="span"/>
		<group id="366" type="span" />
		<group id="367" type="multinuc" parent="571" relname="cause"/>
		<group id="368" type="span" parent="579" relname="span"/>
		<group id="372" type="multinuc" parent="374" relname="span"/>
		<group id="374" type="span" parent="375" relname="span"/>
		<group id="375" type="span" parent="522" relname="span"/>
		<group id="376" type="span" parent="380" relname="span"/>
		<group id="377" type="multinuc" parent="525" relname="span"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="376" relname="elaboration"/>
		<group id="380" type="span" parent="381" relname="contrast"/>
		<group id="381" type="multinuc" />
		<group id="382" type="span" parent="385" relname="elaboration"/>
		<group id="383" type="span" parent="384" relname="span"/>
		<group id="384" type="span" parent="387" relname="joint"/>
		<group id="385" type="span" parent="529" relname="span"/>
		<group id="386" type="span" parent="387" relname="joint"/>
		<group id="387" type="multinuc" parent="381" relname="contrast"/>
		<group id="388" type="span" parent="523" relname="span"/>
		<group id="390" type="span" parent="585" relname="span"/>
		<group id="391" type="span" parent="568" relname="span"/>
		<group id="393" type="span" parent="567" relname="preparation"/>
		<group id="394" type="span" parent="398" relname="joint"/>
		<group id="395" type="span" parent="532" relname="span"/>
		<group id="396" type="multinuc" parent="531" relname="span"/>
		<group id="397" type="span" parent="401" relname="span"/>
		<group id="398" type="multinuc" parent="399" relname="restatement"/>
		<group id="399" type="multinuc" parent="391" relname="elaboration"/>
		<group id="401" type="span" parent="396" relname="joint"/>
		<group id="403" type="span" parent="404" relname="span"/>
		<group id="404" type="span" parent="536" relname="joint"/>
		<group id="405" type="multinuc" parent="408" relname="comparison"/>
		<group id="406" type="span" parent="188" relname="elaboration"/>
		<group id="407" type="span" parent="408" relname="comparison"/>
		<group id="408" type="multinuc" parent="409" relname="span"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" parent="416" relname="span"/>
		<group id="411" type="span" parent="537" relname="span"/>
		<group id="412" type="span" parent="537" relname="cause"/>
		<group id="413" type="multinuc" parent="200" relname="condition"/>
		<group id="414" type="span" parent="415" relname="span"/>
		<group id="415" type="span" parent="424" relname="preparation"/>
		<group id="416" type="span" parent="417" relname="span"/>
		<group id="417" type="span" />
		<group id="418" type="span" parent="422" relname="joint"/>
		<group id="419" type="span" parent="421" relname="span"/>
		<group id="420" type="span" parent="419" relname="condition"/>
		<group id="421" type="span" parent="539" relname="span"/>
		<group id="422" type="multinuc" parent="203" relname="elaboration"/>
		<group id="423" type="span" parent="424" relname="span"/>
		<group id="424" type="span" parent="428" relname="span"/>
		<group id="425" type="span" parent="426" relname="span"/>
		<group id="426" type="span" parent="427" relname="span"/>
		<group id="427" type="span" parent="429" relname="span"/>
		<group id="428" type="span" />
		<group id="429" type="span" parent="436" relname="span"/>
		<group id="430" type="multinuc" parent="550" relname="span"/>
		<group id="431" type="multinuc" parent="433" relname="comparison"/>
		<group id="432" type="span" parent="431" relname="contrast"/>
		<group id="433" type="multinuc" parent="441" relname="span"/>
		<group id="434" type="span" parent="437" relname="contrast"/>
		<group id="435" type="span" parent="548" relname="span"/>
		<group id="436" type="span" parent="437" relname="contrast"/>
		<group id="437" type="multinuc" />
		<group id="438" type="multinuc" parent="441" relname="elaboration"/>
		<group id="439" type="span" parent="438" relname="comparison"/>
		<group id="440" type="span" parent="228" relname="elaboration"/>
		<group id="441" type="span" parent="440" relname="span"/>
		<group id="442" type="span" parent="443" relname="joint"/>
		<group id="443" type="multinuc" parent="444" relname="span"/>
		<group id="444" type="span" parent="445" relname="span"/>
		<group id="445" type="span" parent="450" relname="joint"/>
		<group id="446" type="multinuc" parent="247" relname="elaboration"/>
		<group id="447" type="span" parent="448" relname="span"/>
		<group id="448" type="span" parent="556" relname="span"/>
		<group id="449" type="span" parent="457" relname="span"/>
		<group id="450" type="multinuc" />
		<group id="451" type="span" parent="452" relname="joint"/>
		<group id="452" type="multinuc" parent="449" relname="elaboration"/>
		<group id="453" type="span" parent="454" relname="same-unit"/>
		<group id="454" type="multinuc" parent="455" relname="joint"/>
		<group id="455" type="multinuc" parent="587" relname="span"/>
		<group id="456" type="span" parent="553" relname="span"/>
		<group id="457" type="span" parent="458" relname="joint"/>
		<group id="458" type="multinuc" />
		<group id="459" type="span" parent="461" relname="span"/>
		<group id="460" type="span" parent="594" relname="span"/>
		<group id="461" type="span" parent="476" relname="preparation"/>
		<group id="462" type="multinuc" parent="558" relname="elaboration"/>
		<group id="463" type="span" parent="590" relname="span"/>
		<group id="464" type="multinuc" parent="462" relname="joint"/>
		<group id="465" type="span" parent="466" relname="span"/>
		<group id="466" type="span" parent="591" relname="elaboration"/>
		<group id="468" type="multinuc" parent="476" relname="span"/>
		<group id="469" type="multinuc" parent="593" relname="span"/>
		<group id="470" type="multinuc" parent="471" relname="span"/>
		<group id="471" type="span" parent="472" relname="span"/>
		<group id="472" type="span" parent="473" relname="span"/>
		<group id="473" type="span" parent="474" relname="elaboration"/>
		<group id="474" type="span" parent="475" relname="span"/>
		<group id="475" type="span" />
		<group id="476" type="span" parent="477" relname="span"/>
		<group id="477" type="span" />
		<group id="478" type="span" parent="294" relname="purpose"/>
		<group id="479" type="span" parent="478" relname="span"/>
		<group id="480" type="span" parent="481" relname="same-unit"/>
		<group id="481" type="multinuc" parent="483" relname="purpose"/>
		<group id="482" type="span" parent="483" relname="span"/>
		<group id="483" type="span" parent="484" relname="span"/>
		<group id="484" type="span" parent="314" relname="sequence"/>
		<group id="485" type="span" parent="309" relname="cause"/>
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" parent="488" relname="span"/>
		<group id="488" type="span" parent="493" relname="joint"/>
		<group id="489" type="span" parent="491" relname="same-unit"/>
		<group id="490" type="span" parent="492" relname="span"/>
		<group id="491" type="multinuc" parent="490" relname="span"/>
		<group id="492" type="span" parent="493" relname="joint"/>
		<group id="493" type="multinuc" />
		<group id="494" type="span" parent="562" relname="span"/>
		<group id="495" type="span" parent="561" relname="span"/>
		<group id="496" type="span" parent="500" relname="span"/>
		<group id="497" type="span" parent="498" relname="span"/>
		<group id="498" type="span" parent="496" relname="background"/>
		<group id="499" type="multinuc" parent="562" relname="elaboration"/>
		<group id="500" type="span" parent="499" relname="joint"/>
		<group id="501" type="span" parent="321" relname="evaluation"/>
		<group id="502" type="span" parent="329" relname="preparation"/>
		<group id="503" type="span" parent="329" relname="span"/>
		<group id="504" type="span" parent="335" relname="joint"/>
		<group id="505" type="span" parent="506" relname="same-unit"/>
		<group id="506" type="multinuc" parent="507" relname="span"/>
		<group id="507" type="span" parent="332" relname="span"/>
		<group id="508" type="span" parent="337" relname="evaluation"/>
		<group id="509" type="span" parent="508" relname="span"/>
		<group id="510" type="span" parent="511" relname="span"/>
		<group id="511" type="span" parent="512" relname="span"/>
		<group id="512" type="span" parent="513" relname="span"/>
		<group id="513" type="span" />
		<group id="514" type="span" parent="515" relname="span"/>
		<group id="515" type="span" parent="353" relname="comparison"/>
		<group id="516" type="span" parent="355" relname="elaboration"/>
		<group id="517" type="span" parent="519" relname="span"/>
		<group id="518" type="span" parent="517" relname="elaboration"/>
		<group id="519" type="span" parent="358" relname="comparison"/>
		<group id="520" type="span" parent="365" relname="span"/>
		<group id="521" type="span" parent="375" relname="preparation"/>
		<group id="522" type="span" />
		<group id="523" type="span" parent="524" relname="span"/>
		<group id="524" type="span" />
		<group id="525" type="span" parent="378" relname="span"/>
		<group id="526" type="span" parent="527" relname="same-unit"/>
		<group id="527" type="multinuc" parent="528" relname="span"/>
		<group id="528" type="span" parent="386" relname="span"/>
		<group id="529" type="span" parent="530" relname="span"/>
		<group id="530" type="span" parent="528" relname="elaboration"/>
		<group id="531" type="span" parent="395" relname="purpose"/>
		<group id="532" type="span" parent="533" relname="span"/>
		<group id="533" type="span" parent="399" relname="restatement"/>
		<group id="534" type="span" parent="535" relname="span"/>
		<group id="535" type="span" parent="536" relname="joint"/>
		<group id="536" type="multinuc" parent="416" relname="preparation"/>
		<group id="537" type="span" parent="538" relname="span"/>
		<group id="538" type="span" parent="410" relname="evaluation"/>
		<group id="539" type="span" parent="422" relname="joint"/>
		<group id="540" type="span" parent="541" relname="span"/>
		<group id="541" type="span" parent="546" relname="span"/>
		<group id="542" type="span" parent="543" relname="span"/>
		<group id="543" type="span" parent="544" relname="same-unit"/>
		<group id="544" type="multinuc" parent="541" relname="elaboration"/>
		<group id="545" type="span" parent="546" relname="background"/>
		<group id="546" type="span" parent="547" relname="span"/>
		<group id="547" type="span" parent="423" relname="evaluation"/>
		<group id="548" type="span" parent="429" relname="elaboration"/>
		<group id="549" type="span" parent="433" relname="comparison"/>
		<group id="550" type="span" parent="549" relname="span"/>
		<group id="551" type="span" parent="552" relname="span"/>
		<group id="552" type="span" parent="450" relname="joint"/>
		<group id="553" type="span" parent="554" relname="elaboration"/>
		<group id="554" type="span" parent="555" relname="span"/>
		<group id="555" type="span" parent="458" relname="joint"/>
		<group id="556" type="span" parent="551" relname="elaboration"/>
		<group id="557" type="span" parent="558" relname="span"/>
		<group id="558" type="span" parent="559" relname="span"/>
		<group id="559" type="span" parent="468" relname="joint"/>
		<group id="560" type="span" parent="487" relname="elaboration"/>
		<group id="561" type="span" parent="499" relname="joint"/>
		<group id="562" type="span" parent="501" relname="span"/>
		<group id="563" type="span" parent="510" relname="span"/>
		<group id="564" type="span" parent="355" relname="span"/>
		<group id="565" type="span" parent="517" relname="span"/>
		<group id="566" type="multinuc" parent="567" relname="span"/>
		<group id="567" type="span" parent="569" relname="span"/>
		<group id="568" type="span" parent="566" relname="joint"/>
		<group id="569" type="span" />
		<group id="570" type="span" parent="511" relname="elaboration"/>
		<group id="571" type="span" parent="572" relname="span"/>
		<group id="572" type="span" parent="372" relname="contrast"/>
		<group id="573" type="span" parent="308" relname="contrast"/>
		<group id="574" type="span" parent="575" relname="span"/>
		<group id="575" type="span" parent="338" relname="contrast"/>
		<group id="576" type="span" parent="510" relname="elaboration"/>
		<group id="577" type="span" parent="95" relname="background"/>
		<group id="578" type="span" parent="117" relname="elaboration"/>
		<group id="579" type="span" parent="580" relname="span"/>
		<group id="580" type="span" parent="372" relname="contrast"/>
		<group id="581" type="span" parent="582" relname="same-unit"/>
		<group id="582" type="multinuc" parent="583" relname="span"/>
		<group id="583" type="span" parent="584" relname="span"/>
		<group id="584" type="span" parent="165" relname="condition"/>
		<group id="585" type="span" parent="523" relname="elaboration"/>
		<group id="586" type="span" parent="427" relname="solutionhood"/>
		<group id="587" type="span" parent="588" relname="span"/>
		<group id="588" type="span" parent="456" relname="condition"/>
		<group id="589" type="span" parent="463" relname="elaboration"/>
		<group id="590" type="span" parent="464" relname="joint"/>
		<group id="591" type="span" parent="592" relname="span"/>
		<group id="592" type="span" parent="468" relname="joint"/>
		<group id="593" type="span" parent="474" relname="span"/>
		<group id="594" type="span" parent="459" relname="elaboration"/>
		<group id="595" type="multinuc" parent="438" relname="comparison"/>
		<group id="596" type="span" parent="595" relname="same-unit"/>
	</body>
</rst>