<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="56" relname="preparation">Новость: В Аликовском районе открылся бизнес-инкубатор для предпринимателей</segment>
		<segment id="2" parent="56" relname="span">19 сентября Глава Чувашии Михаил Игнатьев посетил Аликовский район,</segment>
		<segment id="3" parent="55" relname="joint">где принял участие в открытии районного бизнес-инкубатора «Меркурий»</segment>
		<segment id="4" parent="55" relname="joint">и провел «круглый стол» по вопросам развития малого и среднего предпринимательства.</segment>
		<segment id="5" parent="57" relname="attribution">Выступая на открытии бизнес-инкубатора, Михаил Игнатьев отметил,</segment>
		<segment id="6" parent="57" relname="span">что здесь созданы комфортные условия</segment>
		<segment id="7" parent="6" relname="purpose">для самореализации начинающих предпринимателей.</segment>
		<segment id="8" parent="63" relname="joint">«Только в это здание государством вложено почти 38 млн рублей.</segment>
		<segment id="9" parent="59" relname="joint">Общая же сумма государственной помощи, направляемой на развитие малого и среднего бизнеса Чувашии, в 2012 году составит 523 млн рублей,</segment>
		<segment id="10" parent="59" relname="joint">и с каждым годом эта поддержка будет увеличиваться.</segment>
		<segment id="11" parent="61" relname="span">Все это делается с одной единственной целью</segment>
		<segment id="12" parent="60" relname="joint">- чтобы в сельских районах создавались высокотехнологичные рабочие места</segment>
		<segment id="13" parent="60" relname="joint">и повышался уровень заработной платы жителей республики.</segment>
		<segment id="14" parent="62" relname="span">Тем самым в Чувашии активно выполняется задача по созданию условий</segment>
		<segment id="15" parent="14" relname="purpose">для динамичного развития малого и среднего предпринимательства, поставленная Президентом России Владимиром Владимировичем Путиным»,</segment>
		<segment id="16" parent="65" relname="attribution">- отметил Михаил Игнатьев.</segment>
		<segment id="17" parent="67" relname="span">В здании бизнес-инкубатора Аликовского района разместятся офисы 35 предпринимателей,</segment>
		<segment id="18" parent="17" relname="attribution">которые в течение трех лет смогут работать на льготных условиях.</segment>
		<segment id="19" parent="83" relname="span">В настоящее время заявки поданы от 19 человек.</segment>
		<segment id="20" parent="82" relname="sequence">В первый год они будут платить не более 40% от ставки арендной платы, во второй – не более 60%.</segment>
		<segment id="21" parent="68" relname="restatement">Начиная с 2006 года, в Чувашии открылись</segment>
		<segment id="22" parent="68" relname="restatement">и успешно функционируют еще 5 бизнес-инкубаторов – в Чебоксарах, Новочебоксарске, а также в Шемуршинском, Красноармейском и Моргаушском районах.</segment>
		<segment id="23" parent="82" relname="sequence">В планах – создание аналогичных инкубаторов в Батыревском и Мариинско-Посадском районах.</segment>
		<segment id="24" parent="88" relname="attribution">В новом здании Михаил Игнатьев провел заседание «круглого стола» по вопросам развития малого и среднего бизнеса.</segment>
		<segment id="25" parent="70" relname="preparation">«Средние и малые предприятия нуждаются в помощи, особенно на начальных этапах своей деятельности.</segment>
		<segment id="26" parent="70" relname="span">Эту проблему призваны решить бизнес-инкубаторы,</segment>
		<segment id="27" parent="69" relname="joint">где предпринимателям могут помочь с составлением бизнес-плана,</segment>
		<segment id="28" parent="69" relname="joint">предоставить юридический адрес, помещение под офис,</segment>
		<segment id="29" parent="69" relname="joint">обеспечить оргтехникой,</segment>
		<segment id="30" parent="69" relname="joint">дать консультации по различным финансовым и юридическим вопросам,</segment>
		<segment id="31" parent="69" relname="joint">оказать другие услуги»,</segment>
		<segment id="32" parent="71" relname="attribution">-  сказал Глава республики.</segment>
		<segment id="33" parent="34" relname="attribution">Он также отметил,</segment>
		<segment id="34" parent="73" relname="span">что по итогам сплошного федерального статистического наблюдения, которое прошло в 2011 году, в Чувашии в расчете на 1 тыс. человек населения осуществляют деятельность 32 индивидуальных предпринимателя.</segment>
		<segment id="35" parent="74" relname="joint">Это больше, чем в среднем по России,</segment>
		<segment id="36" parent="74" relname="joint">и является лучшим показателем среди регионов Приволжского федерального округа.</segment>
		<segment id="37" parent="86" relname="joint">В будущем основные акценты предполагается сделать на вовлечении активной и инициативной молодежи в предпринимательскую деятельность, расширении государственной поддержки инноваций, лизинга, энергосбережения, народных промыслов, создания частных детских садов.</segment>
		<segment id="38" parent="39" relname="attribution">Президент Торгово-промышленной палаты Чувашии Игорь Кустарин рассказал</segment>
		<segment id="39" parent="97" relname="span">о проблемах малого и среднего предпринимательства.</segment>
		<segment id="40" parent="90" relname="span">К таковым он отнес отсутствие свободного доступа к имущественным и финансовым ресурсам, нехватку квалифицированных кадров.</segment>
		<segment id="41" parent="42" relname="purpose">Для снятия острых вопросов бизнес-сообществу и органам власти</segment>
		<segment id="42" parent="75" relname="span">необходимо выработать совместные решения.</segment>
		<segment id="43" parent="44" relname="attribution">По мнению Игоря Кустарина,</segment>
		<segment id="44" parent="99" relname="span">в связи с тем, что в последние годы наблюдается тенденция по сокращению персонала на крупных предприятиях,</segment>
		<segment id="45" parent="46" relname="cause">люди «уходят в самозанятость»,</segment>
		<segment id="46" parent="76" relname="span">поэтому приоритетом государственной политики страны должна стать радикальная помощь в развитии малого и среднего бизнеса.</segment>
		<segment id="47" parent="48" relname="condition">При обсуждении системы функционирования бизнес-инкубаторов в Чувашии</segment>
		<segment id="48" parent="78" relname="span">поступило предложение рассмотреть вопрос о создании и развитии в республике транспортно-логистических центров.</segment>
		<segment id="49" parent="95" relname="span">Также в ходе заседания была рассмотрена ситуация с малым и средним предпринимательством в Аликовском районе.</segment>
		<segment id="50" parent="79" relname="span">Здесь по состоянию на 1 сентября действуют 585 субъектов малого и среднего предпринимательства,</segment>
		<segment id="51" parent="50" relname="elaboration">которые охватывают практически все виды экономической деятельности.</segment>
		<segment id="52" parent="93" relname="joint">Наибольшее количество сосредоточено на предприятиях сельского хозяйства (40,6%), строительства (12,7%), торговли и общественного питания (8,6%), переработки плодов, овощей и ягод, производства строительных материалов и тепловой энергии (34,6%) и др.</segment>
		<segment id="53" parent="93" relname="joint">Оборот розничного товарооборота в целом по району за январь-август 2012 года составил 356,73 млн рублей, общественного питания – 30 млн рублей.</segment>
		<segment id="54" parent="93" relname="joint">В общем объеме на долю субъектов малого предпринимательства приходится 15,5% розничной торговли и 9% оборота общественного питания.</segment>
		<group id="55" type="multinuc" parent="2" relname="elaboration"/>
		<group id="56" type="span" parent="80" relname="span"/>
		<group id="57" type="span" parent="58" relname="span"/>
		<group id="58" type="span" parent="66" relname="attribution"/>
		<group id="59" type="multinuc" parent="63" relname="joint"/>
		<group id="60" type="multinuc" parent="11" relname="purpose"/>
		<group id="61" type="span" parent="64" relname="span"/>
		<group id="62" type="span" parent="65" relname="span"/>
		<group id="63" type="multinuc" parent="61" relname="cause"/>
		<group id="64" type="span" parent="62" relname="cause"/>
		<group id="65" type="span" parent="66" relname="span"/>
		<group id="66" type="span" parent="81" relname="span"/>
		<group id="67" type="span" parent="83" relname="preparation"/>
		<group id="68" type="multinuc" parent="82" relname="sequence"/>
		<group id="69" type="multinuc" parent="26" relname="elaboration"/>
		<group id="70" type="span" parent="71" relname="span"/>
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" parent="87" relname="joint"/>
		<group id="73" type="span" parent="85" relname="span"/>
		<group id="74" type="multinuc" parent="73" relname="evaluation"/>
		<group id="75" type="span" parent="40" relname="evaluation"/>
		<group id="76" type="span" parent="77" relname="span"/>
		<group id="77" type="span" parent="92" relname="joint"/>
		<group id="78" type="span" parent="96" relname="joint"/>
		<group id="79" type="span" parent="94" relname="span"/>
		<group id="80" type="span" />
		<group id="81" type="span" />
		<group id="82" type="multinuc" parent="19" relname="elaboration"/>
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" />
		<group id="85" type="span" parent="86" relname="joint"/>
		<group id="86" type="multinuc" parent="87" relname="joint"/>
		<group id="87" type="multinuc" parent="88" relname="span"/>
		<group id="88" type="span" parent="89" relname="span"/>
		<group id="89" type="span" />
		<group id="90" type="span" parent="97" relname="elaboration"/>
		<group id="92" type="multinuc" />
		<group id="93" type="multinuc" parent="79" relname="evidence"/>
		<group id="94" type="span" parent="49" relname="elaboration"/>
		<group id="95" type="span" parent="96" relname="joint"/>
		<group id="96" type="multinuc" />
		<group id="97" type="span" parent="98" relname="span"/>
		<group id="98" type="span" parent="92" relname="joint"/>
		<group id="99" type="span" parent="76" relname="cause"/>
	</body>
</rst>