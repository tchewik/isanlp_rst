<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="463" relname="preparation">Программа АНБ США по перехвату данных в сети продолжает вызывать тревогу — эксперты</segment>
		<segment id="2" parent="441" relname="span">Агентство национальной безопасности (АНБ) США в течение более десяти лет вело слежку за коммуникациями крупных бизнесменов и высокопоставленных политиков Франции и Германии.</segment>
		<segment id="3" parent="2" relname="attribution">Об этом говорится в документах, опубликованных на сайте организации WikiLeaks 29 июня и 1 июля 2015 года.</segment>
		<segment id="4" parent="474" relname="attribution">Согласно этим материалам,</segment>
		<segment id="5" parent="234" relname="joint">американские спецслужбы организовали автоматический сбор телефонных разговоров целого ряда интересующих их лиц.</segment>
		<segment id="6" parent="231" relname="span">Кроме того, они формировали базу сведений экономического и политического характера,</segment>
		<segment id="7" parent="6" relname="cause">получив данные о крупных французских контрактах на суммы свыше 200 млн. долларов и о сути переговоров канцлера ФРГ Ангелы Меркель (Angela Merkel) с ее личным помощником.</segment>
		<segment id="8" parent="232" relname="span">При этом отдельные документы находились в открытом доступе для всех участников разведывательной системы "Пять глаз" (Five Eyes),</segment>
		<segment id="9" parent="8" relname="elaboration">в которую входят США, Великобритания, Канада, Австралия и Новая Зеландия.</segment>
		<segment id="10" parent="239" relname="span">Обнародованные секретные сведения всколыхнули европейское политическое сообщество.</segment>
		<segment id="11" parent="238" relname="joint">Так, президент Франции Франсуа Олланд (Francois Hollande) назвал сложившуюся ситуацию недопустимой,</segment>
		<segment id="12" parent="237" relname="span">а руководитель ведомства канцлера Германии Петер Альтмайер (Peter Altmaier) вызвал посла США Джона Эмерсона (John Emerson)</segment>
		<segment id="13" parent="12" relname="purpose">для консультаций.</segment>
		<segment id="14" parent="245" relname="span">Новые публикации WikiLeaks также спровоцировали оживленную реакцию журналистов.</segment>
		<segment id="15" parent="240" relname="attribution">В частности, корреспондент журнала Time Саймон Шустер (Simon Shuster) считает,</segment>
		<segment id="16" parent="240" relname="span">что события последних недель очень похожи на скандал 2013 года вокруг прослушивания одного из телефонов Ангелы Меркель,</segment>
		<segment id="17" parent="16" relname="elaboration">следствие по которому было прекращено Генеральной прокуратурой Германии в июне 2015 года.</segment>
		<segment id="18" parent="19" relname="cause">"Как показала эта ситуация,</segment>
		<segment id="19" parent="242" relname="span">такие скандалы не приводят к разрыву отношений</segment>
		<segment id="20" parent="242" relname="cause">- хотя бы потому, что в Европе полагаются на США не только в сфере торговли, но и в вопросах безопасности и обмена разведданными",</segment>
		<segment id="21" parent="243" relname="attribution">- пишет он.</segment>
		<segment id="22" parent="248" relname="span">Кроме того, обнародованные документы вновь привлекли внимание общества к программе массового негласного наблюдения за пользователями сети Интернет,</segment>
		<segment id="23" parent="22" relname="elaboration">которая стала широко известна после публикации бывшим сотрудником АНБ Эдвардом Сноуденом (Edward Snowden) некоторых засекреченных материалов в июне 2013 года.</segment>
		<segment id="24" parent="250" relname="attribution">В ходе видеомоста, организованного правозащитной организацией Amnesty International в начале июня, он напомнил,</segment>
		<segment id="25" parent="250" relname="span">что лидеры разведгруппы "Пяти глаз" и ряда других стран ввели меры неконтролируемого сбора данных под предлогом защиты от терроризма,</segment>
		<segment id="26" parent="249" relname="span">используя все возможные методы,</segment>
		<segment id="27" parent="26" relname="purpose">чтобы избежать тщательной проверки.</segment>
		<segment id="28" parent="256" relname="span">"Программа слежки [в США] была многократно признана неправомерной.</segment>
		<segment id="29" parent="477" relname="attribution">Согласно постановлениям американских судов,</segment>
		<segment id="30" parent="254" relname="joint">массовое наблюдение являлось противозаконным</segment>
		<segment id="31" parent="254" relname="joint">и нарушающим основные конституционные права граждан с первых же дней.</segment>
		<segment id="32" parent="253" relname="joint">В Белом доме провели закрытый анализ программы АНБ</segment>
		<segment id="33" parent="34" relname="attribution">и пришли к выводу,</segment>
		<segment id="34" parent="252" relname="span">что негласная всеобъемлющая слежка не помогла предотвратить ни одного теракта",</segment>
		<segment id="35" parent="256" relname="attribution">- подчеркнул бывший сотрудник американских спецслужб, ставший героем фильма "Citizenfour. Правда Сноудена".</segment>
		<segment id="36" parent="261" relname="attribution">По мнению представителя Пиратской партии Швеции Антона Норденфюра (Anton Nordenfur),</segment>
		<segment id="37" parent="261" relname="span">нынешнее положение дел осложняется тем,</segment>
		<segment id="38" parent="37" relname="cause">что Вашингтон уже извлек урок из ситуации с бывшим сотрудником АНБ США.</segment>
		<segment id="39" parent="262" relname="joint">"Вероятнее всего, Соединенные Штаты [&hellip;] станут действовать более жестко по отношению к таким информаторам</segment>
		<segment id="40" parent="262" relname="joint">и тщательнее следить за содержимым документов, которые могут стать доступны общественности",</segment>
		<segment id="41" parent="455" relname="attribution">- сказал в интервью ИА "PenzaNews" политик,</segment>
		<segment id="42" parent="266" relname="same-unit">добавив, что Эдвард Сноуден, сейчас проживающий в России,</segment>
		<segment id="43" parent="264" relname="condition">при неудачном стечении обстоятельств</segment>
		<segment id="44" parent="263" relname="joint">мог оказаться в тюрьме Гуантанамо</segment>
		<segment id="45" parent="263" relname="joint">или даже лишиться жизни.</segment>
		<segment id="46" parent="47" relname="attribution">Он предположил также,</segment>
		<segment id="47" parent="272" relname="span">что от недавних утечек WikiLeaks стоит ожидать лишь краткосрочного эффекта.</segment>
		<segment id="48" parent="273" relname="span">"Однако США, скорее всего, продолжат шпионить за главами государств, только иными способами и более успешно,</segment>
		<segment id="49" parent="48" relname="purpose">чтобы избежать раскрытия. [&hellip;]</segment>
		<segment id="50" parent="275" relname="joint">Даже если бы сейчас начался масштабный народный протест,</segment>
		<segment id="51" parent="52" relname="attribution">даже если бы власти выступили с заявлением,</segment>
		<segment id="52" parent="274" relname="span">что полностью сворачивают все программы,</segment>
		<segment id="53" parent="54" relname="attribution">я очень сильно сомневаюсь,</segment>
		<segment id="54" parent="276" relname="span">что все бы на самом деле закончилось",</segment>
		<segment id="55" parent="277" relname="attribution">- отметил собеседник агентства.</segment>
		<segment id="56" parent="282" relname="span">С точки зрения Антона Норденфюра,</segment>
		<segment id="57" parent="287" relname="span">публикации, свидетельствующие о неправомерных действиях американских спецслужб против своих же союзников, нанесли ущерб в первую очередь самому Вашингтону.</segment>
		<segment id="58" parent="443" relname="attribution">По его словам,</segment>
		<segment id="59" parent="443" relname="span">это вызвано тем,</segment>
		<segment id="60" parent="59" relname="cause">что миллионы людей по всему миру стали иначе относиться к вопросу защиты коммуникаций, который важен как для простых граждан, так и для политиков и бизнесменов, стремящихся сохранить втайне информацию о своей личной жизни, профессиональной и коммерческой деятельности.</segment>
		<segment id="61" parent="62" relname="attribution">"В [недавнем] интервью премьер-министр Швеции [Стефан Левен (Stefan Lofwen)] упомянул о том,</segment>
		<segment id="62" parent="283" relname="span">что больше не доверяет телефонным разговорам.</segment>
		<segment id="63" parent="284" relname="span">По моему мнению, это, к сожалению, хороший знак:</segment>
		<segment id="64" parent="63" relname="elaboration">значит, люди ждут новых утечек в будущем",</segment>
		<segment id="65" parent="285" relname="attribution">- констатировал функционер Пиратской партии Швеции.</segment>
		<segment id="66" parent="67" relname="attribution">В свою очередь эксперт по вопросу защиты персональных данных при администрации бывших президентов США Джорджа Буша-младшего (George Bush Jr.) и Билла Клинтона (Bill Clinton), профессор юриспруденции и этики Технологического института Джорджии Питер Свайр (Peter Swire) заявил,</segment>
		<segment id="67" parent="290" relname="span">что решение Эдварда Сноудена обнародовать секретные документы оказало значительное влияние на ход истории.</segment>
		<segment id="68" parent="291" relname="span">"По моему личному мнению, действия Сноудена привели к позитивным последствиям</segment>
		<segment id="69" parent="68" relname="elaboration">- в частности, из-за него общество сейчас обсуждает столь важный вопрос защиты данных.</segment>
		<segment id="70" parent="294" relname="span">Однако имели место и негативные последствия.</segment>
		<segment id="71" parent="292" relname="joint">Северная Корея и другие тоталитарные режимы узнали о возможностях американских разведслужб,</segment>
		<segment id="72" parent="293" relname="span">а некоторые из раскрытых документов были насколько подробными,</segment>
		<segment id="73" parent="72" relname="cause">что побудили государства, представляющие опасность, провести ряд внутренних реформ",</segment>
		<segment id="74" parent="75" relname="attribution">- подчеркнул он,</segment>
		<segment id="75" parent="457" relname="span">добавив, что действия бывшего сотрудника АНБ США с точки зрения закона являются преступными.</segment>
		<segment id="76" parent="77" relname="attribution">В то же время он отметил,</segment>
		<segment id="77" parent="300" relname="span">что именно эти утечки документов стали причиной пристального изучения программы массового сбора данных о пользователях сети американскими разведывательными службами.</segment>
		<segment id="78" parent="307" relname="span">"Я был одним из членов комиссии президента США Барака Обамы (Barack Obama) по пересмотру технологий сбора разведданных (Review Group on Intelligence and Communications Technologies).</segment>
		<segment id="79" parent="301" relname="span">В августе 2013 года он сформировал группу из пяти человек, включая меня,</segment>
		<segment id="80" parent="79" relname="purpose">чтобы изучить программу АНБ. [&hellip;]</segment>
		<segment id="81" parent="305" relname="joint">Наша экспертная комиссия рекомендовала ввести дополнительные меры защиты персональных данных, в том числе касательно статьи 702 закона о внешней разведке США",</segment>
		<segment id="82" parent="459" relname="attribution">- напомнил Питер Свайр,</segment>
		<segment id="83" parent="458" relname="span">добавив, что американская система массового слежения PRISM,</segment>
		<segment id="84" parent="83" relname="elaboration">запущенная АНБ в 2007 году,</segment>
		<segment id="85" parent="304" relname="same-unit">действует именно на основании положений этой статьи.</segment>
		<segment id="86" parent="310" relname="attribution">Он также обратил внимание,</segment>
		<segment id="87" parent="310" relname="span">что одним из самых заметных последствий этих утечек на сегодняшний день стал принятый 3 июня 2015 года "Акт о свободе США" (USA Freedom Act),</segment>
		<segment id="88" parent="87" relname="elaboration">призванный ограничить права американских спецслужб на сбор и хранение данных о телефонных переговорах.</segment>
		<segment id="89" parent="312" relname="joint">"Этот акт стал самой крупной разведывательной реформой за последние 40 лет, направленной на защиту личных данных пользователей,</segment>
		<segment id="90" parent="312" relname="joint">и первым подобным законом после событий 11 сентября 2001 года",</segment>
		<segment id="91" parent="313" relname="attribution">- подчеркнул Питер Свайр.</segment>
		<segment id="92" parent="317" relname="span">Схожего мнения придерживается и старший юрист правозащитной организации "Electronic Privacy Information Center" Алан Батлер (Alan Butler),</segment>
		<segment id="93" parent="92" relname="elaboration">который назвал принятый документ "эпохальным законом".</segment>
		<segment id="94" parent="95" relname="attribution">"Мы считаем,</segment>
		<segment id="95" parent="466" relname="span">что это крайне значительный шаг в верном направлении.</segment>
		<segment id="96" parent="318" relname="span">Конгресс и президент США поступили верно,</segment>
		<segment id="97" parent="96" relname="cause">одобрив и подписав этот закон",</segment>
		<segment id="98" parent="467" relname="attribution">- сказал он.</segment>
		<segment id="99" parent="321" relname="restatement">С точки зрения правозащитника, введение дополнительных мер по надзору за действиями спецслужб</segment>
		<segment id="100" parent="321" relname="restatement">и расширение требований к прозрачности таких программ</segment>
		<segment id="101" parent="322" relname="span">позволит пресечь случаи,</segment>
		<segment id="102" parent="322" relname="elaboration">когда меры негласного наблюдения вводятся втайне от общественного контроля,</segment>
		<segment id="103" parent="324" relname="contrast">однако важная проблема защиты людей, проживающих в других странах, по-прежнему остается неразрешенной.</segment>
		<segment id="104" parent="329" relname="span">"Несомненно, это сложный юридический вопрос.</segment>
		<segment id="105" parent="328" relname="joint">В настоящее время многие организации выступают за распространение этих прав и на неграждан США.</segment>
		<segment id="106" parent="107" relname="attribution">Более того, в 2014 году американский президент выступил с заявлением о том,</segment>
		<segment id="107" parent="326" relname="span">что намерен восстановить эти права",</segment>
		<segment id="108" parent="109" relname="attribution">- напомнил эксперт,</segment>
		<segment id="109" parent="461" relname="span">добавив, что общественная работа в этом направлении продолжается.</segment>
		<segment id="110" parent="111" relname="attribution">В свою очередь консультант по вопросам технологий и прав человека Amnesty International Джошуа Франко (Joshua Franco) подчеркнул,</segment>
		<segment id="111" parent="332" relname="span">что не считает "Акт о свободе США" полноценной реформой американской системы массового негласного наблюдения.</segment>
		<segment id="112" parent="334" relname="joint">"Еще очень многое предстоит сделать.</segment>
		<segment id="113" parent="334" relname="joint">Целый ряд американских программ по сбору данных санкционирован положениями других законов.</segment>
		<segment id="114" parent="334" relname="joint">Наверняка мы еще очень многого не знаем.</segment>
		<segment id="115" parent="333" relname="contrast">По моему мнению, это знаковая и важная политическая победа,</segment>
		<segment id="116" parent="333" relname="contrast">но она показывает, что далеко не все вопросы закрыты",</segment>
		<segment id="117" parent="336" relname="attribution">- сказал эксперт.</segment>
		<segment id="118" parent="340" relname="attribution">Он отметил,</segment>
		<segment id="119" parent="338" relname="joint">что информация, обнародованная Эдвардом Сноуденом и рядом других источников, спровоцировала сдвиги в обществе и политике,</segment>
		<segment id="120" parent="339" relname="span">а также дала правозащитникам возможность оспорить законность программ негласного наблюдения в Интернете в судебном порядке,</segment>
		<segment id="121" parent="120" relname="condition">при этом во многих странах мира по-прежнему заметно движение в обратную сторону.</segment>
		<segment id="122" parent="123" relname="attribution">"Власти Великобритании обещают</segment>
		<segment id="123" parent="471" relname="span">расширить полномочия спецслужб,</segment>
		<segment id="124" parent="125" relname="attribution">а чиновники в Вашингтоне и Лондоне заявляют,</segment>
		<segment id="125" parent="343" relname="span">что технологии шифрования препятствуют контртерроризму и работе сил правопорядка.</segment>
		<segment id="126" parent="345" relname="cause">Все эти тенденции могут негативно сказаться на защищенности личной информации в сети и соблюдении иных прав человека.</segment>
		<segment id="127" parent="347" relname="joint">Более того, сама Франция уже взяла на вооружение новый закон о массовом отслеживании коммуникаций",</segment>
		<segment id="128" parent="348" relname="attribution">- сказал сотрудник Amnesty International.</segment>
		<segment id="129" parent="449" relname="same-unit">В связи с этим,</segment>
		<segment id="130" parent="446" relname="attribution">по его мнению,</segment>
		<segment id="131" parent="351" relname="joint">международному сообществу необходимо как можно усерднее добиваться введения юридических гарантий защиты персональных данных пользователей от негласного наблюдения,</segment>
		<segment id="132" parent="351" relname="joint">а также проводить работу с корпорациями, которые контролируют доступ к информации и отвечают за ноу-хау, доступные конечным потребителям.</segment>
		<segment id="133" parent="352" relname="attribution">Джошуа Франко напомнил,</segment>
		<segment id="134" parent="352" relname="span">что Интернет не имеет зримых границ,</segment>
		<segment id="135" parent="134" relname="cause">поэтому перехват коммуникаций в одном государстве неминуемо ставит под угрозу права всех пользователей всемирной сети.</segment>
		<segment id="136" parent="451" relname="same-unit">При этом,</segment>
		<segment id="137" parent="138" relname="attribution">по его словам,</segment>
		<segment id="138" parent="450" relname="span">все больше стран стремятся заполучить технологии, которые бы позволили им собирать максимум информации о своих гражданах.</segment>
		<segment id="139" parent="140" relname="attribution">В свою очередь президент швейцарской Ассоциации за надлежащее управление Интернетом Ричард Хилл (Richard Hill) высказал мнение,</segment>
		<segment id="140" parent="355" relname="span">что скандал с прослушиванием высокопоставленных лиц Франции приведет к переговорам за закрытыми дверями.</segment>
		<segment id="141" parent="358" relname="same-unit">"Например, в истории с Ангелой Меркель [в 2013 году],</segment>
		<segment id="142" parent="356" relname="evaluation">как думаю не только я,</segment>
		<segment id="143" parent="356" relname="span">Вашингтон согласился передавать Берлину больше информации,</segment>
		<segment id="144" parent="143" relname="condition">если расследование прекратится.</segment>
		<segment id="145" parent="359" relname="contrast">На мой взгляд, страны, которые попали под негласное наблюдение, хотят присоединиться к клубу "Пяти глаз",</segment>
		<segment id="146" parent="359" relname="contrast">а не остановить слежку",</segment>
		<segment id="147" parent="361" relname="attribution">- предположил правозащитник.</segment>
		<segment id="148" parent="453" relname="attribution">С его точки зрения,</segment>
		<segment id="149" parent="453" relname="span">в действиях американской разведки можно усмотреть продолжение так называемой "доктрины Вулфовица",</segment>
		<segment id="150" parent="364" relname="span">названной в честь бывшего заместителя министра обороны США Пола Вулфовица (Paul Wolfowitz),</segment>
		<segment id="151" parent="150" relname="elaboration">который озвучил ее в начале 90-х годов ХХ века.</segment>
		<segment id="152" parent="478" relname="attribution">"Согласно этой стратегии,</segment>
		<segment id="153" parent="478" relname="span">после окончания холодной войны Соединенные Штаты должны были приложить все усилия,</segment>
		<segment id="154" parent="153" relname="purpose">чтобы не позволить другой стране сравниться с Вашингтоном по военной и политической мощи.</segment>
		<segment id="155" parent="367" relname="span">С тех пор политика США была направлена на то,</segment>
		<segment id="156" parent="155" relname="purpose">чтобы не дать соперникам поравняться с Вашингтоном в силе - в том числе, конечно же, и с помощью слежки",</segment>
		<segment id="157" parent="368" relname="attribution">- пояснил президент Ассоциации за надлежащее управление Интернетом.</segment>
		<segment id="158" parent="159" relname="attribution">Он отметил,</segment>
		<segment id="159" parent="371" relname="span">что наилучшим средством борьбы с массовым негласным наблюдением в конечном итоге будут не скандалы подобного уровня, а постоянное и неослабевающее давление общественности и СМИ на политиков и разведслужбы, которые продвигают свои интересы, прикрываясь угрозой терроризма.</segment>
		<segment id="160" parent="380" relname="span">"Попросту глупо утверждать, что мы сможем сократить число этих атак с помощью массовой слежки.</segment>
		<segment id="161" parent="374" relname="span">Я всегда привожу такую аналогию:</segment>
		<segment id="162" parent="372" relname="attribution">неужели вы думаете,</segment>
		<segment id="163" parent="164" relname="condition">что если всех будут прослушивать,</segment>
		<segment id="164" parent="372" relname="span">от этого станут реже грабить банки?</segment>
		<segment id="165" parent="374" relname="solutionhood">Нет, конечно же.</segment>
		<segment id="166" parent="167" relname="attribution">Так почему вы считаете,</segment>
		<segment id="167" parent="376" relname="span">что перехват сообщений через Интернет позволит пресечь обособленные атаки?</segment>
		<segment id="168" parent="377" relname="joint">То есть у программы неизбирательного сбора данных совершенно нелепый посыл,</segment>
		<segment id="169" parent="377" relname="joint">и об этом обязательно нужно говорить",</segment>
		<segment id="170" parent="380" relname="attribution">- подчеркнул Ричард Хилл.</segment>
		<segment id="171" parent="172" relname="attribution">Эксперт в сфере информационных технологий, сооснователь и технический руководитель IT-консультационной компании "Gendo" Арьен Кампхейс (Arjen Kamphuis) также выразил уверенность,</segment>
		<segment id="172" parent="383" relname="span">что программа по слежению за пользователями в сети никоим образом не связана с борьбой против терроризма,</segment>
		<segment id="173" parent="383" relname="cause">поскольку Агентство национальной безопасности не имеет к этой задаче никакого отношения.</segment>
		<segment id="174" parent="385" relname="span">"Это работа Федерального бюро расследований (ФБР) - и иногда Центрального разведывательного управления (ЦРУ),</segment>
		<segment id="175" parent="174" relname="concession">хотя в ЦРУ чаще всего заняты финансированием, вооружением, подготовкой и командованием самими террористами, как в Афганистане в 1978-1999 годах.</segment>
		<segment id="176" parent="386" relname="joint">Задачей АНБ после окончания холодной войны стало ведение промышленного шпионажа и подрывной политической деятельности",</segment>
		<segment id="177" parent="387" relname="attribution">- пояснил он.</segment>
		<segment id="178" parent="392" relname="attribution">Арьен Кампхейс отметил,</segment>
		<segment id="179" parent="390" relname="joint">что разведывательные органы США и Великобритании сейчас живут по своим правилам</segment>
		<segment id="180" parent="390" relname="joint">и действуют вне любых законов и юрисдикций,</segment>
		<segment id="181" parent="391" relname="joint">и никто не решится усмирить их деятельность.</segment>
		<segment id="182" parent="394" relname="joint">"Я работал с информаторами из разведслужб, начиная с 2007 года,</segment>
		<segment id="183" parent="394" relname="joint">и сотрудничаю с WikiLeaks с 2008 года. [&hellip;]</segment>
		<segment id="184" parent="395" relname="joint">Эти спецслужбы знают о частной жизни политиков все</segment>
		<segment id="185" parent="396" relname="span">и могут "выпустить наружу" ровно столько сведений,</segment>
		<segment id="186" parent="185" relname="purpose">чтобы мгновенно прервать политическую карьеру любого",</segment>
		<segment id="187" parent="398" relname="attribution">- подчеркнул эксперт.</segment>
		<segment id="188" parent="189" relname="attribution">Он добавил,</segment>
		<segment id="189" parent="401" relname="span">что американские власти не боятся применять силу в любых возможных ситуациях, даже в отношении тех стран, которые сотрудничают с Белым домом.</segment>
		<segment id="190" parent="403" relname="span">"Союзников нет:</segment>
		<segment id="191" parent="190" relname="elaboration">есть США и мелкие государства, которые могут только улыбаться в лицо крокодилу и надеяться, что сегодня их не съедят.</segment>
		<segment id="192" parent="402" relname="contrast">Франция и Германия как более крупные нации как-то сопротивляются,</segment>
		<segment id="193" parent="402" relname="contrast">но в конечном итоге и они предпочитают не тревожить зверя",</segment>
		<segment id="194" parent="404" relname="attribution">- сказал Арьен Кампхейс.</segment>
		<segment id="195" parent="196" relname="attribution">По его словам,</segment>
		<segment id="196" parent="452" relname="span">за два года, которые прошли с момента публикации первых документов Эдвардом Сноуденом, Берлин так и не предпринял никаких конкретных шагов.</segment>
		<segment id="197" parent="409" relname="attribution">При этом аналитик отметил,</segment>
		<segment id="198" parent="407" relname="comparison">что общественность обратила внимание на действия американских спецслужб на 15-20 лет позже,</segment>
		<segment id="199" parent="407" relname="comparison">чем следовало бы,</segment>
		<segment id="200" parent="408" relname="concession">хотя уже в конце 1990-х годов в СМИ стали появляться подобные предупреждения.</segment>
		<segment id="201" parent="202" relname="attribution">"Было ли оправдано решение [Эдварда Сноудена] рассказать семи с лишним миллиардам людей о том,</segment>
		<segment id="202" parent="412" relname="span">что держава, которая ведет необъявленные войны и несет ответственность за массовые убийства в двух десятках стран, нарушает их неотъемлемые права на тайну частной жизни каждую секунду каждого дня?</segment>
		<segment id="203" parent="472" relname="span">Да,</segment>
		<segment id="204" parent="203" relname="attribution">как я считаю",</segment>
		<segment id="205" parent="413" relname="attribution">- заключил сооснователь и технический руководитель IT-компании "Gendo".</segment>
		<segment id="206" parent="207" relname="attribution">Он предположил,</segment>
		<segment id="207" parent="416" relname="span">что политику США за последние несколько лет можно сравнить с действиями Советского Союза на грани распада,</segment>
		<segment id="208" parent="209" relname="attribution">и высказал мнение,</segment>
		<segment id="209" parent="415" relname="span">что Соединенные Штаты как единое государство исчезнет уже через 5-20 лет.</segment>
		<segment id="210" parent="419" relname="joint">"Как и СССР, в свои последние дни США начнут вести себя непредсказуемо.</segment>
		<segment id="211" parent="418" relname="span">В тот момент, когда империя Соединенных Штатов начнет уходить в небытие,</segment>
		<segment id="212" parent="211" relname="evaluation">лучше всего будет держаться от нее на почтительном расстоянии",</segment>
		<segment id="213" parent="420" relname="attribution">- заметил Арьен Кампхейс.</segment>
		<segment id="214" parent="215" relname="attribution">Кроме того, он указал на тот факт,</segment>
		<segment id="215" parent="440" relname="span">что большинство стран сейчас находятся в большой зависимости от американских технологий, в том числе в компьютерной и IT-индустрии,</segment>
		<segment id="216" parent="424" relname="joint">и призвал мировые державы заняться созданием</segment>
		<segment id="217" parent="424" relname="joint">и развитием собственных разработок.</segment>
		<segment id="218" parent="427" relname="span">"Франции, Германии и другим странам стоит начать вплотную работать с Россией, Бразилией, Индией и даже Китаем и Ираном над созданием альтернативных технологий,</segment>
		<segment id="219" parent="426" relname="span">чтобы больше не полагаться на слепую веру в чью-то незаинтересованность,</segment>
		<segment id="220" parent="219" relname="elaboration">как сейчас все вынуждены надеяться на США.</segment>
		<segment id="221" parent="222" relname="evaluation">Очевидно, что</segment>
		<segment id="222" parent="465" relname="span">доверять во всем одной крупной державе просто-напросто нельзя.</segment>
		<segment id="223" parent="430" relname="span">Нам необходим многополярный мир и открытые децентрализованные технологии,</segment>
		<segment id="224" parent="429" relname="span">защищенные от несанкционированного вмешательства,</segment>
		<segment id="225" parent="428" relname="span">которые нужно сделать обязательными в образовательных учреждениях,</segment>
		<segment id="226" parent="225" relname="purpose">чтобы они стали для людей привычными.</segment>
		<segment id="227" parent="432" relname="joint">Это позволит сэкономить 1-2% валового национального продукта, которые сейчас идут на закупку американских технологий,</segment>
		<segment id="228" parent="432" relname="joint">и использовать вырученные средства на инновационное развитие, новые проекты и обучение профессионалов",</segment>
		<segment id="229" parent="436" relname="attribution">- подытожил эксперт.</segment>
		<group id="231" type="span" parent="473" relname="span"/>
		<group id="232" type="span" parent="231" relname="elaboration"/>
		<group id="234" type="multinuc" parent="474" relname="span"/>
		<group id="237" type="span" parent="238" relname="joint"/>
		<group id="238" type="multinuc" parent="10" relname="evidence"/>
		<group id="239" type="span" parent="247" relname="joint"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" parent="14" relname="evidence"/>
		<group id="242" type="span" parent="243" relname="span"/>
		<group id="243" type="span" parent="244" relname="span"/>
		<group id="244" type="span" parent="246" relname="joint"/>
		<group id="245" type="span" parent="246" relname="joint"/>
		<group id="246" type="multinuc" parent="247" relname="joint"/>
		<group id="247" type="multinuc" />
		<group id="248" type="span" parent="259" relname="preparation"/>
		<group id="249" type="span" parent="25" relname="cause"/>
		<group id="250" type="span" parent="251" relname="span"/>
		<group id="251" type="span" parent="258" relname="joint"/>
		<group id="252" type="span" parent="253" relname="joint"/>
		<group id="253" type="multinuc" parent="255" relname="joint"/>
		<group id="254" type="multinuc" parent="477" relname="span"/>
		<group id="255" type="multinuc" parent="28" relname="elaboration"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" parent="258" relname="joint"/>
		<group id="258" type="multinuc" parent="259" relname="span"/>
		<group id="259" type="span" parent="260" relname="span"/>
		<group id="260" type="span" />
		<group id="261" type="span" parent="270" relname="span"/>
		<group id="262" type="multinuc" parent="267" relname="span"/>
		<group id="263" type="multinuc" parent="264" relname="span"/>
		<group id="264" type="span" parent="265" relname="span"/>
		<group id="265" type="span" parent="266" relname="same-unit"/>
		<group id="266" type="multinuc" parent="455" relname="span"/>
		<group id="267" type="span" parent="268" relname="span"/>
		<group id="268" type="span" parent="271" relname="joint"/>
		<group id="270" type="span" parent="271" relname="joint"/>
		<group id="271" type="multinuc" />
		<group id="272" type="span" parent="280" relname="joint"/>
		<group id="273" type="span" parent="279" relname="span"/>
		<group id="274" type="span" parent="275" relname="joint"/>
		<group id="275" type="multinuc" parent="276" relname="condition"/>
		<group id="276" type="span" parent="277" relname="span"/>
		<group id="277" type="span" parent="278" relname="span"/>
		<group id="278" type="span" parent="273" relname="evaluation"/>
		<group id="279" type="span" parent="280" relname="joint"/>
		<group id="280" type="multinuc" />
		<group id="282" type="span" parent="57" relname="attribution"/>
		<group id="283" type="span" parent="285" relname="span"/>
		<group id="284" type="span" parent="283" relname="evaluation"/>
		<group id="285" type="span" parent="286" relname="span"/>
		<group id="286" type="span" parent="289" relname="joint"/>
		<group id="287" type="span" parent="444" relname="preparation"/>
		<group id="289" type="multinuc" />
		<group id="290" type="span" parent="299" relname="joint"/>
		<group id="291" type="span" parent="295" relname="contrast"/>
		<group id="292" type="multinuc" parent="70" relname="evidence"/>
		<group id="293" type="span" parent="292" relname="joint"/>
		<group id="294" type="span" parent="295" relname="contrast"/>
		<group id="295" type="multinuc" parent="297" relname="span"/>
		<group id="297" type="span" parent="298" relname="span"/>
		<group id="298" type="span" parent="299" relname="joint"/>
		<group id="299" type="multinuc" />
		<group id="300" type="span" parent="309" relname="joint"/>
		<group id="301" type="span" parent="305" relname="joint"/>
		<group id="304" type="multinuc" parent="459" relname="span"/>
		<group id="305" type="multinuc" parent="306" relname="span"/>
		<group id="306" type="span" parent="78" relname="elaboration"/>
		<group id="307" type="span" parent="308" relname="span"/>
		<group id="308" type="span" parent="309" relname="joint"/>
		<group id="309" type="multinuc" parent="316" relname="joint"/>
		<group id="310" type="span" parent="311" relname="span"/>
		<group id="311" type="span" parent="315" relname="joint"/>
		<group id="312" type="multinuc" parent="313" relname="span"/>
		<group id="313" type="span" parent="314" relname="span"/>
		<group id="314" type="span" parent="315" relname="joint"/>
		<group id="315" type="multinuc" />
		<group id="316" type="multinuc" />
		<group id="317" type="span" parent="325" relname="joint"/>
		<group id="318" type="span" parent="466" relname="evaluation"/>
		<group id="321" type="multinuc" parent="101" relname="cause"/>
		<group id="322" type="span" parent="323" relname="span"/>
		<group id="323" type="span" parent="324" relname="contrast"/>
		<group id="324" type="multinuc" parent="331" relname="joint"/>
		<group id="325" type="multinuc" />
		<group id="326" type="span" parent="328" relname="joint"/>
		<group id="328" type="multinuc" parent="104" relname="elaboration"/>
		<group id="329" type="span" parent="330" relname="span"/>
		<group id="330" type="span" parent="331" relname="joint"/>
		<group id="331" type="multinuc" />
		<group id="332" type="span" parent="342" relname="joint"/>
		<group id="333" type="multinuc" parent="335" relname="evaluation"/>
		<group id="334" type="multinuc" parent="335" relname="span"/>
		<group id="335" type="span" parent="336" relname="span"/>
		<group id="336" type="span" parent="337" relname="span"/>
		<group id="337" type="span" parent="342" relname="joint"/>
		<group id="338" type="multinuc" parent="340" relname="span"/>
		<group id="339" type="span" parent="338" relname="joint"/>
		<group id="340" type="span" parent="341" relname="span"/>
		<group id="341" type="span" parent="350" relname="joint"/>
		<group id="342" type="multinuc" />
		<group id="343" type="span" parent="344" relname="contrast"/>
		<group id="344" type="multinuc" parent="345" relname="span"/>
		<group id="345" type="span" parent="346" relname="span"/>
		<group id="346" type="span" parent="347" relname="joint"/>
		<group id="347" type="multinuc" parent="348" relname="span"/>
		<group id="348" type="span" parent="349" relname="span"/>
		<group id="349" type="span" parent="350" relname="joint"/>
		<group id="350" type="multinuc" />
		<group id="351" type="multinuc" parent="446" relname="span"/>
		<group id="352" type="span" parent="353" relname="span"/>
		<group id="353" type="span" parent="354" relname="joint"/>
		<group id="354" type="multinuc" />
		<group id="355" type="span" parent="363" relname="joint"/>
		<group id="356" type="span" parent="357" relname="span"/>
		<group id="357" type="span" parent="358" relname="same-unit"/>
		<group id="358" type="multinuc" parent="360" relname="joint"/>
		<group id="359" type="multinuc" parent="360" relname="joint"/>
		<group id="360" type="multinuc" parent="361" relname="span"/>
		<group id="361" type="span" parent="362" relname="span"/>
		<group id="362" type="span" parent="363" relname="joint"/>
		<group id="363" type="multinuc" />
		<group id="364" type="span" parent="149" relname="elaboration"/>
		<group id="367" type="span" parent="368" relname="span"/>
		<group id="368" type="span" parent="369" relname="span"/>
		<group id="369" type="span" parent="480" relname="span"/>
		<group id="370" type="multinuc" />
		<group id="371" type="span" parent="382" relname="joint"/>
		<group id="372" type="span" parent="373" relname="span"/>
		<group id="373" type="span" parent="161" relname="elaboration"/>
		<group id="374" type="span" parent="375" relname="span"/>
		<group id="375" type="span" parent="378" relname="joint"/>
		<group id="376" type="span" parent="378" relname="joint"/>
		<group id="377" type="multinuc" parent="379" relname="restatement"/>
		<group id="378" type="multinuc" parent="379" relname="restatement"/>
		<group id="379" type="multinuc" parent="160" relname="elaboration"/>
		<group id="380" type="span" parent="381" relname="span"/>
		<group id="381" type="span" parent="382" relname="joint"/>
		<group id="382" type="multinuc" />
		<group id="383" type="span" parent="384" relname="span"/>
		<group id="384" type="span" parent="389" relname="joint"/>
		<group id="385" type="span" parent="386" relname="joint"/>
		<group id="386" type="multinuc" parent="387" relname="span"/>
		<group id="387" type="span" parent="388" relname="span"/>
		<group id="388" type="span" parent="389" relname="joint"/>
		<group id="389" type="multinuc" />
		<group id="390" type="multinuc" parent="391" relname="joint"/>
		<group id="391" type="multinuc" parent="392" relname="span"/>
		<group id="392" type="span" parent="393" relname="span"/>
		<group id="393" type="span" parent="400" relname="joint"/>
		<group id="394" type="multinuc" parent="397" relname="span"/>
		<group id="395" type="multinuc" parent="397" relname="elaboration"/>
		<group id="396" type="span" parent="395" relname="joint"/>
		<group id="397" type="span" parent="398" relname="span"/>
		<group id="398" type="span" parent="399" relname="span"/>
		<group id="399" type="span" parent="400" relname="joint"/>
		<group id="400" type="multinuc" />
		<group id="401" type="span" parent="406" relname="joint"/>
		<group id="402" type="multinuc" parent="403" relname="elaboration"/>
		<group id="403" type="span" parent="404" relname="span"/>
		<group id="404" type="span" parent="405" relname="span"/>
		<group id="405" type="span" parent="406" relname="joint"/>
		<group id="406" type="multinuc" />
		<group id="407" type="multinuc" parent="408" relname="span"/>
		<group id="408" type="span" parent="409" relname="span"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" parent="411" relname="joint"/>
		<group id="411" type="multinuc" />
		<group id="412" type="span" parent="413" relname="span"/>
		<group id="413" type="span" parent="414" relname="span"/>
		<group id="414" type="span" parent="411" relname="joint"/>
		<group id="415" type="span" parent="417" relname="joint"/>
		<group id="416" type="span" parent="417" relname="joint"/>
		<group id="417" type="multinuc" parent="422" relname="joint"/>
		<group id="418" type="span" parent="419" relname="joint"/>
		<group id="419" type="multinuc" parent="420" relname="span"/>
		<group id="420" type="span" parent="421" relname="span"/>
		<group id="421" type="span" parent="422" relname="joint"/>
		<group id="422" type="multinuc" />
		<group id="424" type="multinuc" parent="425" relname="joint"/>
		<group id="425" type="multinuc" parent="438" relname="joint"/>
		<group id="426" type="span" parent="218" relname="purpose"/>
		<group id="427" type="span" parent="431" relname="span"/>
		<group id="428" type="span" parent="224" relname="purpose"/>
		<group id="429" type="span" parent="223" relname="purpose"/>
		<group id="430" type="span" parent="433" relname="cause"/>
		<group id="431" type="span" parent="435" relname="joint"/>
		<group id="432" type="multinuc" parent="433" relname="span"/>
		<group id="433" type="span" parent="434" relname="span"/>
		<group id="434" type="span" parent="435" relname="joint"/>
		<group id="435" type="multinuc" parent="436" relname="span"/>
		<group id="436" type="span" parent="437" relname="span"/>
		<group id="437" type="span" parent="438" relname="joint"/>
		<group id="438" type="multinuc" />
		<group id="440" type="span" parent="425" relname="joint"/>
		<group id="441" type="span" parent="462" relname="joint"/>
		<group id="443" type="span" parent="444" relname="span"/>
		<group id="444" type="span" parent="445" relname="span"/>
		<group id="445" type="span" parent="289" relname="joint"/>
		<group id="446" type="span" parent="447" relname="span"/>
		<group id="447" type="span" parent="449" relname="same-unit"/>
		<group id="448" type="span" parent="354" relname="joint"/>
		<group id="449" type="multinuc" parent="448" relname="span"/>
		<group id="450" type="span" parent="451" relname="same-unit"/>
		<group id="451" type="multinuc" parent="354" relname="joint"/>
		<group id="452" type="span" parent="411" relname="joint"/>
		<group id="453" type="span" parent="454" relname="span"/>
		<group id="454" type="span" parent="370" relname="joint"/>
		<group id="455" type="span" parent="456" relname="span"/>
		<group id="456" type="span" parent="267" relname="attribution"/>
		<group id="457" type="span" parent="297" relname="attribution"/>
		<group id="458" type="span" parent="304" relname="same-unit"/>
		<group id="459" type="span" parent="460" relname="span"/>
		<group id="460" type="span" parent="307" relname="attribution"/>
		<group id="461" type="span" parent="329" relname="attribution"/>
		<group id="462" type="multinuc" parent="463" relname="span"/>
		<group id="463" type="span" parent="464" relname="span"/>
		<group id="464" type="span" />
		<group id="465" type="span" parent="427" relname="evaluation"/>
		<group id="466" type="span" parent="467" relname="span"/>
		<group id="467" type="span" parent="468" relname="span"/>
		<group id="468" type="span" parent="325" relname="joint"/>
		<group id="471" type="span" parent="344" relname="contrast"/>
		<group id="472" type="span" parent="412" relname="solutionhood"/>
		<group id="473" type="span" parent="234" relname="joint"/>
		<group id="474" type="span" parent="475" relname="span"/>
		<group id="475" type="span" parent="462" relname="joint"/>
		<group id="476" type="span" parent="255" relname="joint"/>
		<group id="477" type="span" parent="476" relname="span"/>
		<group id="478" type="span" parent="479" relname="span"/>
		<group id="479" type="span" parent="369" relname="cause"/>
		<group id="480" type="span" parent="370" relname="joint"/>
	</body>
</rst>