<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="236" relname="preparation">Итоги саммитов ШОС и БРИКС в Уфе указывают на формирование нового мирового порядка</segment>
		<segment id="2" parent="226" relname="span">Лидеры стран Азии, Африки и Латинской Америки приняли участие в XIV саммите Шанхайской организации сотрудничества (ШОС) и VII саммите группы БРИКС,</segment>
		<segment id="3" parent="2" relname="elaboration">которые прошли в Уфе под председательством Российской Федерации 8-10 июля 2015 года.</segment>
		<segment id="4" parent="227" relname="joint">Главным итогом заседаний глав стран БРИКС стал запуск двух финансовых институтов - Нового банка развития (НБР) и Пула условных валютных резервов - с совокупным капиталом в 200 млрд. долларов,</segment>
		<segment id="5" parent="228" relname="span">а также принятие Стратегии экономического партнерства до 2020 года,</segment>
		<segment id="6" parent="5" relname="elaboration">направленной на расширение многостороннего делового сотрудничества в сфере энергетики, добычи сырья, агрокультуры и инфраструктуры.</segment>
		<segment id="7" parent="426" relname="attribution">В свою очередь лидеры государств ШОС в ходе совместной встречи подписали постановление о расширении организации,</segment>
		<segment id="8" parent="229" relname="joint">согласно которому Индия и Пакистан получают статус полноправных членов,</segment>
		<segment id="9" parent="229" relname="joint">Белоруссия становится страной-наблюдателем, а Армения, Азербайджан, Камбоджа и Непал - партнерами по диалогу.</segment>
		<segment id="10" parent="233" relname="joint">Кроме того, участники саммита Шанхайской организации сотрудничества поддержали инициативу Китая по созданию проекта в рамках экономического пояса "Шелковый путь"</segment>
		<segment id="11" parent="231" relname="span">и утвердили стратегию развития до 2025 года,</segment>
		<segment id="12" parent="230" relname="joint">в которой, в частности, поставили задачу разработать Конвенцию по борьбе с экстремизмом,</segment>
		<segment id="13" parent="230" relname="joint">создать новые транспортные коридоры,</segment>
		<segment id="14" parent="233" relname="joint">а также выступили за реформирование Совета безопасности ООН.</segment>
		<segment id="15" parent="239" relname="span">В ходе саммитов в России прошли совместные встречи премьер-министра Индии Нарендры Моди (Narendra Modi) и его пакистанского коллеги Наваза Шарифа (Nawaz Sharif),</segment>
		<segment id="16" parent="409" relname="attribution">по итогам которых стороны выразили намерение</segment>
		<segment id="17" parent="238" relname="joint">сотрудничать ради искоренения угрозы терроризма в Южной Азии</segment>
		<segment id="18" parent="238" relname="joint">и налаживать контакты в различных сферах.</segment>
		<segment id="19" parent="242" relname="span">Помимо этого, мероприятия посетил президент Ирана Хасан Роухани (Hassan Rouhani),</segment>
		<segment id="20" parent="240" relname="attribution">который в ходе своего выступления выразил уверенность,</segment>
		<segment id="21" parent="240" relname="span">что отмена западных санкций в отношении Тегерана откроет новые возможности</segment>
		<segment id="22" parent="21" relname="purpose">для многостороннего сотрудничества в регионе.</segment>
		<segment id="23" parent="247" relname="span">Мировые лидеры и высокопоставленные должностные лица положительно оценили результаты своей трехдневной работы в Уфе.</segment>
		<segment id="24" parent="243" relname="attribution">Так, премьер-министр Пакистана Наваз Шариф заявил,</segment>
		<segment id="25" parent="26" relname="purpose">что вступление его страны в ШОС поможет</segment>
		<segment id="26" parent="243" relname="span">установлению мира в Афганистане,</segment>
		<segment id="27" parent="28" relname="attribution">а директор департамента международного экономического сотрудничества МИД Китая Чжан Цзюнь (Zhang Jun) отметил,</segment>
		<segment id="28" parent="244" relname="span">что в ходе встреч были достигнуты важные договоренности в сфере инвестиций, торговли и индустрии.</segment>
		<segment id="29" parent="250" relname="span">Прошедшие в России саммиты вызвали живой и неподдельный интерес у журналистов не только Азии, но и Европы, которые сделали акцент на уникальности и значимости событий.</segment>
		<segment id="30" parent="31" relname="attribution">В частности, обозреватель немецкой телерадиокомпании Deutsche Welle Франк Зирен (Frank Sieren) предположил,</segment>
		<segment id="31" parent="249" relname="span">что Бразилия, Россия, Индия, Китая и Южная Африка к концу XXI века могут обойти страны "Большой восьмерки" по экономическому потенциалу.</segment>
		<segment id="32" parent="251" relname="span">"Подобный глобальный саммит прошел в этом регионе впервые.</segment>
		<segment id="33" parent="32" relname="cause">Нам, жителям Запада, придется привыкнуть к тому, что для БРИКС важны совершенно иные регионы",</segment>
		<segment id="34" parent="251" relname="attribution">- подчеркнул он.</segment>
		<segment id="35" parent="254" relname="attribution">В то же время его коллега, бразильский журналист-международник, обозреватель ряда новостных изданий Пепе Эскобар (Pepe Escobar) в интервью ИА "PenzaNews" отметил,</segment>
		<segment id="36" parent="254" relname="span">что американские СМИ предсказуемо и незаслуженно обошли своим вниманием саммиты в России,</segment>
		<segment id="37" parent="36" relname="concession">несмотря на их значимость не только для азиатской, но и всей международной политики и экономики.</segment>
		<segment id="38" parent="39" relname="cause">"В Уфе Индия и Пакистан окончательно договорились о полноценном вступлении [в Шанхайскую организацию сотрудничества].</segment>
		<segment id="39" parent="256" relname="span">ШОС стала "Большой восьмеркой",</segment>
		<segment id="40" parent="257" relname="span">а после присоединения Ирана в начале 2016 года,</segment>
		<segment id="41" parent="40" relname="elaboration">когда закончатся санкции,</segment>
		<segment id="42" parent="259" relname="span">будет "Большой девяткой",</segment>
		<segment id="43" parent="260" relname="attribution">- сказал собеседник агентства.</segment>
		<segment id="44" parent="264" relname="joint">По его мнению, среди заявлений, сделанных 8-10 июля, стоит обратить особое внимание на договоренности между Нарендрой Моди и главой КНР Си Цзиньпином (Xi Jinping) по урегулированию имеющихся пограничных споров, а также на многочисленные соглашения по укреплению взаимного сотрудничества в таких сферах, как энергетика и инфраструктура.</segment>
		<segment id="45" parent="263" relname="span">"В основе новой "большой игры" в Евразии преимущественно будет лежать торговая и коммерческая интеграция на основе сложной сети автомагистралей, скоростных железных дорог, портов, аэропортов, трубопроводов и оптоволоконных кабелей",</segment>
		<segment id="46" parent="45" relname="attribution">- пояснил обозреватель.</segment>
		<segment id="47" parent="48" relname="attribution">Вместе с тем он подчеркнул,</segment>
		<segment id="48" parent="265" relname="span">что встречи в Уфе проходили на фоне растущей геополитической напряженности со стороны США.</segment>
		<segment id="49" parent="50" relname="attribution">Кроме того, журналист напомнил,</segment>
		<segment id="50" parent="266" relname="span">что в недавно обнародованной национальной военной стратегии Америки на 2015 год Россия, Китай и Иран были включены в список стран, представляющих наибольшую угрозу для безопасности Соединенных Штатов.</segment>
		<segment id="51" parent="269" relname="restatement">"[Они] названы "ревизионистскими государствами".</segment>
		<segment id="52" parent="268" relname="restatement">Иначе говоря, эти страны открыто отказываются принимать то, что в Пентагоне называют международной безопасностью и стабильностью</segment>
		<segment id="53" parent="268" relname="restatement">- то есть неравные условия игры в глобализированную, непродуктивную, полную ограничений и раскрученную на всю катушку рулетку капитализма",</segment>
		<segment id="54" parent="270" relname="attribution">- сказал Пепе Эскобар.</segment>
		<segment id="55" parent="279" relname="joint">С его точки зрения, в данном контексте успешно прошедшие в России саммиты ШОС и БРИКС можно расценивать как серьезный удар по планам США, который демонстрирует глубину стратегического мышления Москвы и Пекина.</segment>
		<segment id="56" parent="273" relname="joint">"В Уфе [президент России] Владимир Путин (Vladimir Putin) сказал [председателю КНР] Си Цзиньпину,</segment>
		<segment id="57" parent="273" relname="joint">цитирую:</segment>
		<segment id="58" parent="59" relname="cause">"Объединяя усилия,</segment>
		<segment id="59" parent="274" relname="span">мы, безусловно, преодолеем все стоящие перед нами проблемы".</segment>
		<segment id="60" parent="61" relname="cause">Под "усилиями" стоит понимать новый "Шелковый путь", Евразийский экономический союз, БРИКС, ШОС, Азиатский банк инфраструктурных инвестиций (АБИИ), Новый банк развития, валютные свопы, отказ от использования доллара США в торговле и так далее.</segment>
		<segment id="61" parent="275" relname="span">Ни один последователь идей Хэлфорда Маккиндера (Halford Mackinder) с этим не сможет бороться",</segment>
		<segment id="62" parent="277" relname="attribution">- констатировал Пепе Эскобар.</segment>
		<segment id="63" parent="64" relname="attribution">Он также предположил,</segment>
		<segment id="64" parent="280" relname="span">что в ближайшее время страны региона начнут активные переговоры с Ираном о выходе к морским торговым путям и строительстве экономически важной инфраструктуры в рамках многочисленных проектов.</segment>
		<segment id="65" parent="281" relname="span">"Все это отлично сочетается с членством Ирана в ШОС,</segment>
		<segment id="66" parent="65" relname="elaboration">которое само по себе логически вытекает из целого ряда геополитических и геоэкономических факторов",</segment>
		<segment id="67" parent="281" relname="attribution">- уточнил журналист-международник, добавив,</segment>
		<segment id="68" parent="411" relname="attribution">что в Тегеране считают</segment>
		<segment id="69" parent="411" relname="span">возможным достичь целей в обеспечении безопасности в регионе</segment>
		<segment id="70" parent="69" relname="condition">только при сотрудничестве с Москвой и Пекином.</segment>
		<segment id="71" parent="286" relname="attribution">В свою очередь управляющий партнер консалтингового агентства по финансовым коммуникациям "Frontier" Квинн Мартин (Quinn Martin) напомнил,</segment>
		<segment id="72" parent="286" relname="span">что участникам саммитов в Уфе предстоит решить массу задач,</segment>
		<segment id="73" parent="72" relname="purpose">чтобы обеспечить дальнейший успех сделанных ранее заявлений.</segment>
		<segment id="74" parent="288" relname="span">"У Нового банка развития огромный потенциал,</segment>
		<segment id="75" parent="74" relname="cause">поскольку его поддерживают страны с суммарным ВВП в 20% от мирового уровня.</segment>
		<segment id="76" parent="290" relname="span">Однако труднее всего будет с мелочами:</segment>
		<segment id="77" parent="289" relname="joint">как распределятся полномочия между учредителями,</segment>
		<segment id="78" parent="289" relname="joint">кто еще присоединится,</segment>
		<segment id="79" parent="289" relname="joint">и, что самое важное, какие проекты получат финансирование.</segment>
		<segment id="80" parent="292" relname="joint">Это трудные вопросы,</segment>
		<segment id="81" parent="291" relname="span">и банку может потребоваться еще несколько лет,</segment>
		<segment id="82" parent="81" relname="purpose">чтобы заработать в полную силу",</segment>
		<segment id="83" parent="406" relname="attribution">- пояснил эксперт.</segment>
		<segment id="84" parent="296" relname="attribution">Тем не менее он выразил абсолютную уверенность в том,</segment>
		<segment id="85" parent="296" relname="span">что Москва сумела удачно подобрать время</segment>
		<segment id="86" parent="85" relname="purpose">для проведения совместных саммитов в Уфе.</segment>
		<segment id="87" parent="299" relname="span">"Выбранный момент крайне благоволит укреплению отношений России с другими странами ШОС и БРИКС.</segment>
		<segment id="88" parent="298" relname="joint">Кремль обеспокоен американскими и европейскими санкциями</segment>
		<segment id="89" parent="298" relname="joint">и очень сильно хочет показать Западу, что у Москвы есть и другие друзья",</segment>
		<segment id="90" parent="299" relname="attribution">- сказал управляющий партнер консалтингового агентства "Frontier".</segment>
		<segment id="91" parent="413" relname="attribution">Вместе с тем политолог, содиректор исследовательского центра "BRICLab" при Колумбийском университете, основатель Центра бизнес-дипломатии Маркос Тройхо (Marcos Troyjo) подчеркнул,</segment>
		<segment id="92" parent="93" relname="attribution">что результаты уфимских саммитов позволяют говорить</segment>
		<segment id="93" parent="413" relname="span">об эволюции БРИКС и ШОС как региональных международных организаций.</segment>
		<segment id="94" parent="303" relname="contrast">"ШОС создавалась с упором на вопросы безопасности,</segment>
		<segment id="95" parent="303" relname="contrast">а теперь расширяет свою активность и на другие сферы деятельности, включая финансирование инфраструктурных проектов.</segment>
		<segment id="96" parent="305" relname="span">В БРИКС перемены еще заметнее.</segment>
		<segment id="97" parent="304" relname="joint">Сегодня БРИКС - это важный инструмент международного регулирования</segment>
		<segment id="98" parent="304" relname="joint">и, соответственно, формирования многополярного мирового порядка.</segment>
		<segment id="99" parent="306" relname="span">Таким образом, нам стоит говорить о появлении БРИКС 2.0",</segment>
		<segment id="100" parent="308" relname="attribution">- отметил эксперт.</segment>
		<segment id="101" parent="311" relname="joint">По его мнению, Бразилия, Россия, Индия, Китай и ЮАР должны сосредоточиться на управлении глобальной экономикой</segment>
		<segment id="102" parent="311" relname="joint">и позиционировать НБР как альтернативу Всемирному банку для развивающихся государств,</segment>
		<segment id="103" parent="312" relname="joint">а странам ШОС следует сконцентрироваться на вопросах безопасности.</segment>
		<segment id="104" parent="105" relname="purpose">"Для достижения этих целей</segment>
		<segment id="105" parent="313" relname="span">необходимо вести работу по двум направлениям.</segment>
		<segment id="106" parent="315" relname="span">Во-первых, несомненно, нужно использовать авторитет этих стран</segment>
		<segment id="107" parent="314" relname="joint">для реформирования ООН</segment>
		<segment id="108" parent="314" relname="joint">и адаптации Организации Объединенных Наций к новым испытаниям, в которых опасность исходит не от определенного государства в традиционном смысле.</segment>
		<segment id="109" parent="316" relname="joint">Во-вторых, требуется расширить сотрудничество между спецслужбами и экспертами по компьютерной безопасности в рамках БРИКС и ШОС",</segment>
		<segment id="110" parent="317" relname="attribution">- сказал основатель Центра бизнес-дипломатии.</segment>
		<segment id="111" parent="112" relname="cause">"В тех сферах, где интересы этих организаций совпадают - в частности, кредитование на цели развития, улучшение экономического управления, создание равноправного мирового порядка, - БРИКС и ШОС стоит работать параллельно друг с другом без оглядки на различия во взглядах, экономическом влиянии и политических целях.</segment>
		<segment id="112" parent="320" relname="span">В таком случае обе организации просуществуют еще очень долго",</segment>
		<segment id="113" parent="320" relname="attribution">- продолжил Маркос Тройхо.</segment>
		<segment id="114" parent="115" relname="attribution">В то же время его коллега, содиректор исследовательского центра "BRICLab" при Колумбийском университете, управляющий директор компании по управлению активами "HSBC Global Asset Management" Кристиан Дезеглиз (Christian Deseglise) обратил внимание на то,</segment>
		<segment id="115" parent="322" relname="span">что объемы взаимной торговли между Бразилией, Россией, Индией, Китаем и ЮАР на протяжении последних четырех лет неуклонно сокращались.</segment>
		<segment id="116" parent="324" relname="span">"Очень важно уменьшить количество торговых барьеров между странами БРИКС.</segment>
		<segment id="117" parent="323" relname="contrast">В регионе подписано много двухсторонних и многосторонних торговых соглашений,</segment>
		<segment id="118" parent="323" relname="contrast">однако не меньше существует и запретительных мер, мешающих коммерческой деятельности",</segment>
		<segment id="119" parent="324" relname="attribution">- подчеркнул эксперт.</segment>
		<segment id="120" parent="121" relname="attribution">Он отметил также,</segment>
		<segment id="121" parent="327" relname="span">что начало работы Нового банка развития и Пула условных валютных резервов с совокупным капиталом в 200 млрд. долларов является позитивной новостью не только для участников организации, но и для значительной части всего остального мира.</segment>
		<segment id="122" parent="123" relname="attribution">"Я считаю,</segment>
		<segment id="123" parent="328" relname="span">что эти финансовые институты знаменуют становление БРИКС в новом качестве. [&hellip;]</segment>
		<segment id="124" parent="328" relname="elaboration">Они могут стать альтернативой Всемирному банку, а также Азиатскому, Африканскому и Межамериканскому банкам развития",</segment>
		<segment id="125" parent="329" relname="attribution">- пояснил Кристиан Дезеглиз,</segment>
		<segment id="126" parent="331" relname="joint">добавив, что именно стагнация западных финансовых институтов спровоцировала появление НБР БРИКС.</segment>
		<segment id="127" parent="128" relname="attribution">Он предположил,</segment>
		<segment id="128" parent="333" relname="span">что новые инвестиционные банки Азии и фонд экономического пояса "Шелковый путь" должны сосредоточить усилия не на конкуренции с Западом, а на конструктивной работе в сферах с недостаточным финансированием.</segment>
		<segment id="129" parent="335" relname="span">"Только в странах Азии существуют потребности в инфраструктурных инвестициях в объеме около 80 млрд. рублей ежегодно.</segment>
		<segment id="130" parent="131" relname="attribution">Так что я считаю,</segment>
		<segment id="131" parent="334" relname="span">что они все же смогут изменить мир к лучшему",</segment>
		<segment id="132" parent="335" relname="attribution">- сказал управляющий директор компании "HSBC Global Asset Management".</segment>
		<segment id="133" parent="134" relname="attribution">Политолог, профессор кафедры философии и политологии Национального университета имени аль-Фараби в Казахстане Сейлбек Мусатаев (Seylbek Musataev) также высказал мнение,</segment>
		<segment id="134" parent="338" relname="span">что своим появлением АБИИ, НБР и "Шелковый путь" во многом обязаны именно кризису эффективности Международного валютного фонда и других западных мировых финансовых институтов.</segment>
		<segment id="135" parent="136" relname="attribution">Кроме того, он обратил внимание на то,</segment>
		<segment id="136" parent="339" relname="span">что по итогам саммитов в Уфе Шанхайская организация сотрудничества вышла на другие континенты.</segment>
		<segment id="137" parent="346" relname="span">"Рамки ШОС расширяются.</segment>
		<segment id="138" parent="341" relname="span">Индия и Пакистан,</segment>
		<segment id="139" parent="138" relname="elaboration">которые раньше были наблюдателями,</segment>
		<segment id="140" parent="342" relname="same-unit">приняты в качестве полноправных членов.</segment>
		<segment id="141" parent="345" relname="joint">Наблюдателями стали такие государства, как Армения и Азербайджан.</segment>
		<segment id="142" parent="344" relname="span">ШОС стала большим геополитическим объединением,</segment>
		<segment id="143" parent="343" relname="joint">где страны, которые раньше противостояли друг другу,</segment>
		<segment id="144" parent="343" relname="joint">в рамках организации смогут решить спорные моменты",</segment>
		<segment id="145" parent="347" relname="attribution">- подчеркнул политолог.</segment>
		<segment id="146" parent="417" relname="attribution">Говоря о крупных проектах, предложенных в рамках саммитов 8-10 июля, Сейлбек Мусатаев особо отметил</segment>
		<segment id="147" parent="417" relname="span">важность "Шелкового пути",</segment>
		<segment id="148" parent="416" relname="same-unit">который,</segment>
		<segment id="149" parent="150" relname="attribution">по его мнению,</segment>
		<segment id="150" parent="415" relname="span">будет способствовать инфраструктурному развитию всех вовлеченных сторон.</segment>
		<segment id="151" parent="351" relname="contrast">"Ранее были опасения у некоторых стран - в частности, США и Евросоюза, что этот проект приведет к усилению влияния Китая в Центральной Азии - в Казахстане, Таджикистане и так далее.</segment>
		<segment id="152" parent="350" relname="joint">Но члены ШОС опровергли данные опасения</segment>
		<segment id="153" parent="154" relname="attribution">и подтвердили,</segment>
		<segment id="154" parent="419" relname="span">что взаимовыгодное партнерство отвечает всем внутренним интересам стран Шанхайской организации сотрудничества",</segment>
		<segment id="155" parent="352" relname="attribution">- пояснил профессор кафедры философии и политологии Национального университета аль-Фараби.</segment>
		<segment id="156" parent="357" relname="joint">Кроме того, по его мнению, не меньшего внимания заслуживает и тема противодействия мировым террористическим угрозам, которая была затронута не только на саммите ШОС, но и в ходе встреч глав стран БРИКС.</segment>
		<segment id="157" parent="158" relname="cause">"Существующие методы и средства показали свою неэффективность,</segment>
		<segment id="158" parent="355" relname="span">и поэтому члены Шанхайской организации сотрудничества намерены предложить Совету безопасности ООН новые методы и пути борьбы с терроризмом, экстремизмом и сепаратизмом",</segment>
		<segment id="159" parent="355" relname="attribution">- сказал Сейлбек Мусатаев.</segment>
		<segment id="160" parent="161" relname="attribution">В свою очередь экономист, руководитель отдела по изучению торговой и экономической политики Института южноазиатских исследований Национального университета Сингапура Амитенду Палит (Amitendu Palit) подчеркнул,</segment>
		<segment id="161" parent="358" relname="span">что для Шанхайской организации сотрудничества эта тема в настоящее время особенно болезненна.</segment>
		<segment id="162" parent="360" relname="span">"Принимая во внимание тот факт,</segment>
		<segment id="163" parent="359" relname="span">что члены ШОС географически расположены рядом с территориями,</segment>
		<segment id="164" parent="163" relname="elaboration">на которых активны исламисты и прочие экстремисты,</segment>
		<segment id="165" parent="361" relname="span">можно ожидать, что ШОС будет весьма продуктивна в вопросе борьбы с терроризмом, а также с незаконной торговлей наркотиками и оружием,</segment>
		<segment id="166" parent="165" relname="evaluation">что очень и очень важно",</segment>
		<segment id="167" parent="362" relname="attribution">- констатировал эксперт.</segment>
		<segment id="168" parent="364" relname="span">На его взгляд, Индия и Пакистан,</segment>
		<segment id="169" parent="168" relname="elaboration">которые несколько лет имели статус наблюдателей в международной организации,</segment>
		<segment id="170" parent="365" relname="joint">в значительной степени заинтересованы в противодействии этим угрозам</segment>
		<segment id="171" parent="365" relname="joint">и окажут посильную помощь в установлении мира и порядка в Азии.</segment>
		<segment id="172" parent="370" relname="joint">Кроме того, экономист приветствовал визит президента Ирана в Уфу,</segment>
		<segment id="173" parent="368" relname="attribution">а также отметил,</segment>
		<segment id="174" parent="367" relname="joint">что Тегеран в скором будущем станет ключевым партнером для крупных азиатских держав</segment>
		<segment id="175" parent="367" relname="joint">и с большой степенью вероятности войдет в состав Шанхайской организации сотрудничества.</segment>
		<segment id="176" parent="177" relname="attribution">В то же время он предположил,</segment>
		<segment id="177" parent="371" relname="span">что потенциал ШОС и БРИКС до сих пор не реализован полностью.</segment>
		<segment id="178" parent="373" relname="contrast">"Я согласен с мнением, что саммиты свидетельствуют о начале становления нового мирового порядка,</segment>
		<segment id="179" parent="372" relname="span">однако их участникам необходимо приложить значительные усилия,</segment>
		<segment id="180" parent="179" relname="purpose">чтобы пройти путь от начальной точки до полномасштабной и долгосрочной программы развития и сотрудничества",</segment>
		<segment id="181" parent="374" relname="attribution">- сказал Амитенду Палит.</segment>
		<segment id="182" parent="423" relname="same-unit">Так,</segment>
		<segment id="183" parent="422" relname="attribution">по его словам,</segment>
		<segment id="184" parent="420" relname="span">членам ШОС, которые уделяли внимание преимущественно вопросам безопасности, следует расширить круг тем</segment>
		<segment id="185" parent="184" relname="purpose">для обсуждения,</segment>
		<segment id="186" parent="378" relname="span">а странам БРИКС необходимо подписать многостороннее торговое и инвестиционное соглашение</segment>
		<segment id="187" parent="377" relname="joint">для укрепления</segment>
		<segment id="188" parent="377" relname="joint">и развития экономических взаимосвязей группы.</segment>
		<segment id="189" parent="382" relname="span">"Я испытываю больший оптимизм в отношении БРИКС.</segment>
		<segment id="190" parent="191" relname="attribution">Думаю,</segment>
		<segment id="191" parent="381" relname="span">они уже положили хорошее начало",</segment>
		<segment id="192" parent="382" relname="attribution">- заметил эксперт.</segment>
		<segment id="193" parent="385" relname="attribution">Кроме того, он подчеркнул,</segment>
		<segment id="194" parent="385" relname="span">что Новый банк развития сможет достигнуть значительных успехов совместно с Азиатским банком инфраструктурных инвестиций и фондом китайского "Шелкового пути",</segment>
		<segment id="195" parent="194" relname="condition">но только при условии, что они будут следовать единой инвестиционной стратегии, основанной не на взаимной конкуренции, а на разделении сфер деятельности в рамках скоординированной экономической стратегии.</segment>
		<segment id="196" parent="197" relname="attribution">Амитенду Палит также высказал мнение,</segment>
		<segment id="197" parent="387" relname="span">что саммиты БРИКС и Шанхайской организации сотрудничества являются площадками, на которых страны Азии могут заниматься решением собственных внутренних проблем без вмешательства западных держав.</segment>
		<segment id="198" parent="388" relname="joint">"Выявляя общие друг для друга вопросы</segment>
		<segment id="199" parent="388" relname="joint">и действуя на основах взаимовыручки,</segment>
		<segment id="200" parent="389" relname="span">ШОС и БРИКС фактически противопоставляют себя западному миропорядку по ряду направлений.</segment>
		<segment id="201" parent="202" relname="condition">Если подобный процесс продолжится,</segment>
		<segment id="202" parent="390" relname="span">это пойдет на благо всем странам",</segment>
		<segment id="203" parent="391" relname="attribution">- подытожил представитель Национального университета Сингапура.</segment>
		<segment id="204" parent="405" relname="joint">Группа БРИКС объединяет пять наиболее быстро развивающихся крупных стран мира - Китай, Россию, Бразилию, Индию и ЮАР.</segment>
		<segment id="205" parent="394" relname="sequence">Свое первое название - "BRIC" (БРИК) - группа получила в ноябре 2001 года по первым буквам стран в ее составе на тот момент: Бразилии, России, Индии и Китая.</segment>
		<segment id="206" parent="394" relname="sequence">В 2011 году после присоединения Южно-Африканской Республики международное объединение было переименовано в "BRICS" (БРИКС, от S - South Africa).</segment>
		<segment id="207" parent="395" relname="joint">Первая краткая встреча лидеров государств группы прошла в июле 2008 года в японском городе Тояко-Онсен,</segment>
		<segment id="208" parent="395" relname="joint">а первый полномасштабный ежегодный саммит состоялся в российском Екатеринбурге 16 июня 2009 года совместно со встречей глав ШОС.</segment>
		<segment id="209" parent="210" relname="evaluation">Одним из наиболее значимых результатов деятельности БРИКС является</segment>
		<segment id="210" parent="396" relname="span">создание собственных финансовых институтов - Нового банка развития и Пула условных валютных резервов.</segment>
		<segment id="211" parent="396" relname="elaboration">Декларация об учреждении новых финансовых учреждений была подписана в ходе VI саммита группы 15-17 июля 2014 года в бразильском городе Форталеза.</segment>
		<segment id="212" parent="404" relname="sequence">Официальное открытие НБР БРИКС состоялось в Шанхае 21 июля 2015 года.</segment>
		<segment id="213" parent="404" relname="sequence">Шанхайская организация сотрудничества была основана лидерами России, Китая, Казахстана, Киргизии, Таджикистана и Узбекистана в 2001 году.</segment>
		<segment id="214" parent="398" relname="span">До основания ШОС все вышеперечисленные страны, кроме Узбекистана, были участницами "Шанхайской пятерки" - политического объединения,</segment>
		<segment id="215" parent="214" relname="elaboration">основанного на Соглашении об укреплении доверия в военной области в районе границы (Шанхай, 1996) и Соглашении о взаимном сокращении вооруженных сил в районе границы (Москва, 1997).</segment>
		<segment id="216" parent="398" relname="elaboration">После включения в организацию Узбекистана "пятерка" стала "шестеркой" и получила свое текущее название.</segment>
		<segment id="217" parent="404" relname="sequence">В настоящее время Афганистан, Иран, Монголия и Белоруссия имеют в ШОС статус наблюдателя, а Турция, Шри-Ланка, Армения, Азербайджан, Камбоджа и Непал - партнера по диалогу.</segment>
		<segment id="218" parent="400" relname="span">В отношении Индии и Пакистана,</segment>
		<segment id="219" parent="218" relname="elaboration">которые ранее являлись наблюдателями,</segment>
		<segment id="220" parent="401" relname="joint">в настоящий момент начата процедура приема в организацию.</segment>
		<segment id="221" parent="402" relname="joint">Среди основных целей ШОС - укрепление взаимного доверия между государствами-членами;</segment>
		<segment id="222" parent="402" relname="joint">содействие их эффективному сотрудничеству в политической, торгово-экономической, научно-технической, культурной и других областях;</segment>
		<segment id="223" parent="403" relname="joint">совместное обеспечение</segment>
		<segment id="224" parent="403" relname="joint">и поддержание мира, безопасности и стабильности в регионе;</segment>
		<segment id="225" parent="402" relname="joint">продвижение к созданию демократического, справедливого и рационального нового международного политического и экономического порядка.</segment>
		<group id="226" type="span" parent="235" relname="joint"/>
		<group id="227" type="multinuc" parent="235" relname="joint"/>
		<group id="228" type="span" parent="227" relname="joint"/>
		<group id="229" type="multinuc" parent="426" relname="span"/>
		<group id="230" type="multinuc" parent="11" relname="elaboration"/>
		<group id="231" type="span" parent="232" relname="comparison"/>
		<group id="232" type="multinuc" parent="233" relname="joint"/>
		<group id="233" type="multinuc" parent="235" relname="joint"/>
		<group id="235" type="multinuc" parent="236" relname="span"/>
		<group id="236" type="span" parent="237" relname="span"/>
		<group id="237" type="span" />
		<group id="238" type="multinuc" parent="409" relname="span"/>
		<group id="239" type="span" parent="248" relname="joint"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" parent="19" relname="elaboration"/>
		<group id="242" type="span" parent="248" relname="joint"/>
		<group id="243" type="span" parent="245" relname="span"/>
		<group id="244" type="span" parent="246" relname="joint"/>
		<group id="245" type="span" parent="246" relname="joint"/>
		<group id="246" type="multinuc" parent="23" relname="evidence"/>
		<group id="247" type="span" parent="248" relname="joint"/>
		<group id="248" type="multinuc" />
		<group id="249" type="span" parent="29" relname="evaluation"/>
		<group id="250" type="span" parent="253" relname="joint"/>
		<group id="251" type="span" parent="252" relname="span"/>
		<group id="252" type="span" parent="253" relname="joint"/>
		<group id="253" type="multinuc" />
		<group id="254" type="span" parent="255" relname="span"/>
		<group id="255" type="span" parent="262" relname="joint"/>
		<group id="256" type="span" parent="258" relname="sequence"/>
		<group id="257" type="span" parent="42" relname="cause"/>
		<group id="258" type="multinuc" parent="260" relname="span"/>
		<group id="259" type="span" parent="258" relname="sequence"/>
		<group id="260" type="span" parent="261" relname="span"/>
		<group id="261" type="span" parent="262" relname="joint"/>
		<group id="262" type="multinuc" />
		<group id="263" type="span" parent="264" relname="joint"/>
		<group id="264" type="multinuc" parent="272" relname="joint"/>
		<group id="265" type="span" parent="267" relname="joint"/>
		<group id="266" type="span" parent="267" relname="joint"/>
		<group id="267" type="multinuc" parent="272" relname="joint"/>
		<group id="268" type="multinuc" parent="269" relname="restatement"/>
		<group id="269" type="multinuc" parent="270" relname="span"/>
		<group id="270" type="span" parent="271" relname="span"/>
		<group id="271" type="span" parent="272" relname="joint"/>
		<group id="272" type="multinuc" />
		<group id="273" type="multinuc" parent="276" relname="attribution"/>
		<group id="274" type="span" parent="276" relname="span"/>
		<group id="275" type="span" parent="274" relname="elaboration"/>
		<group id="276" type="span" parent="277" relname="span"/>
		<group id="277" type="span" parent="278" relname="span"/>
		<group id="278" type="span" parent="279" relname="joint"/>
		<group id="279" type="multinuc" />
		<group id="280" type="span" parent="285" relname="joint"/>
		<group id="281" type="span" parent="282" relname="span"/>
		<group id="282" type="span" parent="284" relname="joint"/>
		<group id="284" type="multinuc" parent="285" relname="joint"/>
		<group id="285" type="multinuc" />
		<group id="286" type="span" parent="287" relname="span"/>
		<group id="287" type="span" parent="295" relname="joint"/>
		<group id="288" type="span" parent="294" relname="contrast"/>
		<group id="289" type="multinuc" parent="76" relname="elaboration"/>
		<group id="290" type="span" parent="293" relname="span"/>
		<group id="291" type="span" parent="292" relname="joint"/>
		<group id="292" type="multinuc" parent="406" relname="span"/>
		<group id="293" type="span" parent="294" relname="contrast"/>
		<group id="294" type="multinuc" parent="295" relname="joint"/>
		<group id="295" type="multinuc" />
		<group id="296" type="span" parent="297" relname="span"/>
		<group id="297" type="span" parent="301" relname="joint"/>
		<group id="298" type="multinuc" parent="87" relname="elaboration"/>
		<group id="299" type="span" parent="300" relname="span"/>
		<group id="300" type="span" parent="301" relname="joint"/>
		<group id="301" type="multinuc" />
		<group id="303" type="multinuc" parent="307" relname="comparison"/>
		<group id="304" type="multinuc" parent="96" relname="evidence"/>
		<group id="305" type="span" parent="99" relname="cause"/>
		<group id="306" type="span" parent="307" relname="comparison"/>
		<group id="307" type="multinuc" parent="308" relname="span"/>
		<group id="308" type="span" parent="309" relname="span"/>
		<group id="309" type="span" parent="310" relname="joint"/>
		<group id="310" type="multinuc" />
		<group id="311" type="multinuc" parent="312" relname="joint"/>
		<group id="312" type="multinuc" parent="319" relname="joint"/>
		<group id="313" type="span" parent="317" relname="span"/>
		<group id="314" type="multinuc" parent="106" relname="purpose"/>
		<group id="315" type="span" parent="316" relname="joint"/>
		<group id="316" type="multinuc" parent="313" relname="elaboration"/>
		<group id="317" type="span" parent="318" relname="span"/>
		<group id="318" type="span" parent="319" relname="joint"/>
		<group id="319" type="multinuc" />
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" parent="319" relname="joint"/>
		<group id="322" type="span" parent="326" relname="joint"/>
		<group id="323" type="multinuc" parent="116" relname="elaboration"/>
		<group id="324" type="span" parent="325" relname="span"/>
		<group id="325" type="span" parent="326" relname="joint"/>
		<group id="326" type="multinuc" />
		<group id="327" type="span" parent="332" relname="joint"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="330" relname="span"/>
		<group id="330" type="span" parent="331" relname="joint"/>
		<group id="331" type="multinuc" parent="332" relname="joint"/>
		<group id="332" type="multinuc" />
		<group id="333" type="span" parent="337" relname="joint"/>
		<group id="334" type="span" parent="129" relname="evaluation"/>
		<group id="335" type="span" parent="336" relname="span"/>
		<group id="336" type="span" parent="337" relname="joint"/>
		<group id="337" type="multinuc" />
		<group id="338" type="span" parent="340" relname="joint"/>
		<group id="339" type="span" parent="340" relname="joint"/>
		<group id="340" type="multinuc" />
		<group id="341" type="span" parent="342" relname="same-unit"/>
		<group id="342" type="multinuc" parent="345" relname="joint"/>
		<group id="343" type="multinuc" parent="142" relname="elaboration"/>
		<group id="344" type="span" parent="346" relname="elaboration"/>
		<group id="345" type="multinuc" parent="137" relname="evidence"/>
		<group id="346" type="span" parent="347" relname="span"/>
		<group id="347" type="span" parent="348" relname="span"/>
		<group id="348" type="span" parent="340" relname="joint"/>
		<group id="350" type="multinuc" parent="351" relname="contrast"/>
		<group id="351" type="multinuc" parent="352" relname="span"/>
		<group id="352" type="span" parent="353" relname="span"/>
		<group id="353" type="span" parent="354" relname="joint"/>
		<group id="354" type="multinuc" />
		<group id="355" type="span" parent="356" relname="span"/>
		<group id="356" type="span" parent="357" relname="joint"/>
		<group id="357" type="multinuc" />
		<group id="358" type="span" parent="363" relname="joint"/>
		<group id="359" type="span" parent="162" relname="elaboration"/>
		<group id="360" type="span" parent="361" relname="cause"/>
		<group id="361" type="span" parent="362" relname="span"/>
		<group id="362" type="span" parent="408" relname="span"/>
		<group id="363" type="multinuc" />
		<group id="364" type="span" parent="366" relname="same-unit"/>
		<group id="365" type="multinuc" parent="366" relname="same-unit"/>
		<group id="366" type="multinuc" parent="363" relname="joint"/>
		<group id="367" type="multinuc" parent="368" relname="span"/>
		<group id="368" type="span" parent="369" relname="span"/>
		<group id="369" type="span" parent="370" relname="joint"/>
		<group id="370" type="multinuc" parent="376" relname="joint"/>
		<group id="371" type="span" parent="376" relname="joint"/>
		<group id="372" type="span" parent="373" relname="contrast"/>
		<group id="373" type="multinuc" parent="374" relname="span"/>
		<group id="374" type="span" parent="375" relname="span"/>
		<group id="375" type="span" parent="376" relname="joint"/>
		<group id="376" type="multinuc" />
		<group id="377" type="multinuc" parent="186" relname="purpose"/>
		<group id="378" type="span" parent="424" relname="span"/>
		<group id="380" type="multinuc" parent="422" relname="span"/>
		<group id="381" type="span" parent="189" relname="elaboration"/>
		<group id="382" type="span" parent="425" relname="span"/>
		<group id="384" type="multinuc" />
		<group id="385" type="span" parent="386" relname="span"/>
		<group id="386" type="span" parent="384" relname="joint"/>
		<group id="387" type="span" parent="393" relname="joint"/>
		<group id="388" type="multinuc" parent="200" relname="cause"/>
		<group id="389" type="span" parent="391" relname="span"/>
		<group id="390" type="span" parent="389" relname="cause"/>
		<group id="391" type="span" parent="392" relname="span"/>
		<group id="392" type="span" parent="393" relname="joint"/>
		<group id="393" type="multinuc" />
		<group id="394" type="multinuc" parent="404" relname="sequence"/>
		<group id="395" type="multinuc" parent="404" relname="sequence"/>
		<group id="396" type="span" parent="397" relname="span"/>
		<group id="397" type="span" parent="404" relname="sequence"/>
		<group id="398" type="span" parent="399" relname="span"/>
		<group id="399" type="span" parent="404" relname="sequence"/>
		<group id="400" type="span" parent="401" relname="joint"/>
		<group id="401" type="multinuc" parent="404" relname="sequence"/>
		<group id="402" type="multinuc" parent="405" relname="joint"/>
		<group id="403" type="multinuc" parent="402" relname="joint"/>
		<group id="404" type="multinuc" parent="405" relname="joint"/>
		<group id="405" type="multinuc" />
		<group id="406" type="span" parent="407" relname="span"/>
		<group id="407" type="span" parent="290" relname="evaluation"/>
		<group id="408" type="span" parent="363" relname="joint"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" parent="15" relname="elaboration"/>
		<group id="411" type="span" parent="412" relname="span"/>
		<group id="412" type="span" parent="284" relname="joint"/>
		<group id="413" type="span" parent="414" relname="span"/>
		<group id="414" type="span" parent="310" relname="joint"/>
		<group id="415" type="span" parent="416" relname="same-unit"/>
		<group id="416" type="multinuc" parent="147" relname="elaboration"/>
		<group id="417" type="span" parent="418" relname="span"/>
		<group id="418" type="span" parent="354" relname="joint"/>
		<group id="419" type="span" parent="350" relname="joint"/>
		<group id="420" type="span" parent="380" relname="joint"/>
		<group id="421" type="span" parent="423" relname="same-unit"/>
		<group id="422" type="span" parent="421" relname="span"/>
		<group id="423" type="multinuc" parent="384" relname="joint"/>
		<group id="424" type="span" parent="380" relname="joint"/>
		<group id="425" type="span" parent="378" relname="elaboration"/>
		<group id="426" type="span" parent="427" relname="span"/>
		<group id="427" type="span" parent="235" relname="joint"/>
	</body>
</rst>