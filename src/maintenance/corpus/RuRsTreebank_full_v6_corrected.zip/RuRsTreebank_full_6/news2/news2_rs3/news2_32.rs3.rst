<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="218" relname="contrast">Антироссийские санкции ослабили экономику,</segment>
		<segment id="2" parent="218" relname="contrast">но сплотили людей против Запада</segment>
		<segment id="3" parent="219" relname="attribution">— Дэн Стейнбок</segment>
		<segment id="4" parent="224" relname="span">Санкции против России,</segment>
		<segment id="5" parent="4" relname="elaboration">введенные Евросоюзом, США и другими странами в 2014 году,</segment>
		<segment id="6" parent="221" relname="joint">ослабили ее экономику,</segment>
		<segment id="7" parent="220" relname="span">серьезно осложнили дальнейший диалог с Кремлем,</segment>
		<segment id="8" parent="7" relname="elaboration">фактически создав предпосылки для новой холодной войны,</segment>
		<segment id="9" parent="223" relname="contrast">но при этом сплотили население вокруг национального лидера Владимира Путина (Vladimir Putin).</segment>
		<segment id="10" parent="226" relname="attribution">К такому выводу пришел американский эксперт в сфере международного бизнеса, межгосударственных отношений и макроэкономики Дэн Стейнбок (Dan Steinbock) в статье "Последствия антироссийских санкций".</segment>
		<segment id="11" parent="478" relname="attribution">В ней он, в частности, отмечает,</segment>
		<segment id="12" parent="227" relname="comparison">что ВВП России в первом квартале 2015 года снизился на 2,2%,</segment>
		<segment id="13" parent="227" relname="comparison">а во втором - на 4,6%</segment>
		<segment id="14" parent="476" relname="same-unit">относительно аналогичных периодов прошлого года,</segment>
		<segment id="15" parent="477" relname="contrast">но на фоне обесценивания нефти, валютного кризиса и падения потребительского спроса это не стало ни для кого неожиданностью.</segment>
		<segment id="16" parent="481" relname="attribution">Аналитик указывает также,</segment>
		<segment id="17" parent="235" relname="joint">что параллельно с попытками ускорить диверсификацию промышленности</segment>
		<segment id="18" parent="235" relname="joint">и смягчить последствия снижения цен на энергоносители</segment>
		<segment id="19" parent="236" relname="contrast">Кремль отвернулся от Европы и США</segment>
		<segment id="20" parent="236" relname="contrast">и обратил свой взор на Восток.</segment>
		<segment id="21" parent="240" relname="effect">"Тем не менее рубль в паре с долларом за последний год потерял свыше 43%.</segment>
		<segment id="22" parent="23" relname="attribution">В Вашингтоне пришли к заключению,</segment>
		<segment id="23" parent="240" relname="span">что санкции работают.</segment>
		<segment id="24" parent="241" relname="evaluation">Однако возникает вопрос: на кого?"</segment>
		<segment id="25" parent="242" relname="attribution">- интересуется эксперт.</segment>
		<segment id="26" parent="243" relname="span">Ниже ИА "PenzaNews" приводит полностью статью Дэна Стейнбока,</segment>
		<segment id="27" parent="26" relname="elaboration">ранее опубликованную в ряде зарубежных СМИ,</segment>
		<segment id="28" parent="244" relname="same-unit">в собственном переводе.</segment>
		<segment id="29" parent="259" relname="preparation">Санкции объединили Россию</segment>
		<segment id="30" parent="256" relname="span">В марте 2014 года Вашингтон и Брюссель ввели санкции против ряда российских бизнесменов и корпораций</segment>
		<segment id="31" parent="30" relname="effect">в ответ на события в Крыму и на юго-востоке Украины.</segment>
		<segment id="32" parent="534" relname="span">Уже более полутора лет они возлагают надежды на то, что российское общество в конечном итоге выступит против президента Владимира Путина</segment>
		<segment id="33" parent="533" relname="joint">из-за санкций</segment>
		<segment id="34" parent="533" relname="joint">и украинского кризиса.</segment>
		<segment id="35" parent="470" relname="span">До Майдана поддержка населением национального лидера составляла лишь 61%,</segment>
		<segment id="36" parent="35" relname="evaluation">что являлось худшим показателем с 2000 года,</segment>
		<segment id="37" parent="261" relname="span">и рейтинг главы государства неуклонно снижался</segment>
		<segment id="38" parent="37" relname="effect">из-за неблагоприятных перспектив в экономике.</segment>
		<segment id="39" parent="264" relname="joint">Однако западные санкции</segment>
		<segment id="40" parent="264" relname="joint">и присоединение Крыма к России</segment>
		<segment id="41" parent="267" relname="span">вызвали рост поддержки действий Кремля.</segment>
		<segment id="42" parent="43" relname="attribution">По данным негосударственной исследовательской организации "Левада-Центр",</segment>
		<segment id="43" parent="269" relname="span">на сегодняшний день рейтинг Владимира Путина закрепился на уровне 87%.</segment>
		<segment id="44" parent="271" relname="attribution">По информации Всероссийского центра изучения общественного мнения (ВЦИОМ),</segment>
		<segment id="45" parent="270" relname="comparison">пропутинскую партию "Единая Россия" в настоящее время поддерживают около 56% населения,</segment>
		<segment id="46" parent="270" relname="comparison">в то время как за всех вместе взятых коммунистов, милитаристов, националистов и социал-демократов выступают только около 15% россиян.</segment>
		<segment id="47" parent="274" relname="attribution">Как считают некоторые американские обозреватели,</segment>
		<segment id="48" parent="274" relname="span">рост популярности Владимира Путина и централизма государственной власти вызван тем,</segment>
		<segment id="49" parent="272" relname="comparison">что действия премьер-министра и правительства страны одобряют менее 65% населения,</segment>
		<segment id="50" parent="272" relname="comparison">а действия парламента - менее 45% россиян.</segment>
		<segment id="51" parent="536" relname="contrast">Однако подобные доводы весьма сомнительны.</segment>
		<segment id="52" parent="276" relname="span">Не стоит забывать, что,</segment>
		<segment id="53" parent="52" relname="attribution">согласно опросам американского института общественного мнения Gallup,</segment>
		<segment id="54" parent="277" relname="same-unit">кабинет Барака Обамы (Barack Obama) и конгресс США пользуются одобрением только у 40% и 15% жителей государства соответственно.</segment>
		<segment id="55" parent="278" relname="comparison">Иными словами, Владимир Путин популярен в России в два раза больше, чем Барак Обама в Соединенных Штатах,</segment>
		<segment id="56" parent="278" relname="comparison">а уровень поддержки российского парламента втрое выше, чем у американского конгресса.</segment>
		<segment id="57" parent="285" relname="attribution">Вместе с тем на Западе продолжают считать,</segment>
		<segment id="58" parent="284" relname="joint">что "вся проблема в Путине,</segment>
		<segment id="59" parent="284" relname="joint">а Россия с нами".</segment>
		<segment id="60" parent="289" relname="span">В реальности же действия президента РФ совпадают с позицией народа,</segment>
		<segment id="61" parent="60" relname="elaboration">в том числе умеренного большинства и зарождающегося среднего класса.</segment>
		<segment id="62" parent="545" relname="comparison">До мирового экономического кризиса почти пятая часть жителей страны подпадали под параметры среднего класса,</segment>
		<segment id="63" parent="545" relname="comparison">однако к сегодняшнему дню их стало вдвое или даже втрое меньше.</segment>
		<segment id="64" parent="539" relname="span">Месяцы санкций ожесточили людей по обе стороны баррикад в российской политике.</segment>
		<segment id="65" parent="295" relname="comparison">Те, кто раньше придерживался умеренных взглядов, превратились в агрессивных националистов,</segment>
		<segment id="66" parent="295" relname="comparison">а социал-демократы стали ярыми коммунистами.</segment>
		<segment id="67" parent="540" relname="comparison">До введения санкций более половины россиян отзывались о Соединенных Штатах положительно.</segment>
		<segment id="68" parent="540" relname="comparison">Сейчас же США пользуются одобрением только у 15% населения.</segment>
		<segment id="69" parent="301" relname="span">Аналогичным образом снизилась и поддержка политики Барака Обамы среди граждан РФ</segment>
		<segment id="70" parent="300" relname="span">- от 40% до 11%,</segment>
		<segment id="71" parent="70" relname="attribution">согласно данным социологического института Pew Research.</segment>
		<segment id="72" parent="547" relname="background">В то же время</segment>
		<segment id="73" parent="546" relname="attribution">18% американцев стали считать</segment>
		<segment id="74" parent="546" relname="span">Россию наибольшей угрозой для США</segment>
		<segment id="75" parent="74" relname="elaboration">- вдвое больше, чем раньше.</segment>
		<segment id="76" parent="308" relname="span">Все эти изменения происходят на фоне постепенной эскалации напряженности между Россией, Украиной, США и Европой</segment>
		<segment id="77" parent="76" relname="concession">(хотя их претензии друг к другу не всегда пересекаются).</segment>
		<segment id="78" parent="307" relname="contrast">В Брюсселе не испытывают энтузиазма по поводу расширения санкций в ближайшем будущем,</segment>
		<segment id="79" parent="307" relname="contrast">но и не намерены снимать их при первой же возможности.</segment>
		<segment id="80" parent="542" relname="span">Предвыборная кампания 2016 года в США может ознаменоваться всплеском антипутинской риторики.</segment>
		<segment id="81" parent="80" relname="elaboration">Американские конгрессмены уже предлагают крайние меры по борьбе с Кремлем: от официальных обвинений России в нарушении договора о РСМД до исключения Москвы из ВТО.</segment>
		<segment id="82" parent="317" relname="span">Однако, к сожалению, мало кто в Соединенных Штатах полностью осознает весь масштаб последствий санкций.</segment>
		<segment id="83" parent="82" relname="effect">Помимо прочего, это вызвано разницей в том, как действия Вашингтона воспринимают в США и в остальном мире.</segment>
		<segment id="84" parent="315" relname="attribution">По данным Gallup,</segment>
		<segment id="85" parent="314" relname="comparison">только 2% жителей Америки видят в решениях Белого дома "значительную угрозу для мировой стабильности",</segment>
		<segment id="86" parent="314" relname="comparison">тогда как во всем остальном мире такой позиции придерживается каждый четвертый опрошенный.</segment>
		<segment id="87" parent="332" relname="preparation">От надежд на разрядку к новой холодной войне</segment>
		<segment id="88" parent="329" relname="span">Современные "специалисты по России" словно соревнуются, кто придумает прогноз мрачнее.</segment>
		<segment id="89" parent="321" relname="joint">Пессимизм всегда был в моде,</segment>
		<segment id="90" parent="320" relname="span">а упрекнуть пессимистов в неправоте уже никто не решается</segment>
		<segment id="91" parent="318" relname="joint">- ведь сейчас Москве угрожают расширением санкций,</segment>
		<segment id="92" parent="318" relname="joint">снижением цен на нефть и газ,</segment>
		<segment id="93" parent="318" relname="joint">падением курса рубля</segment>
		<segment id="94" parent="318" relname="joint">и ростом инфляции.</segment>
		<segment id="95" parent="327" relname="preparation">Однако был ли экономический спад в России действительно неизбежным и таким уж "естественным"?</segment>
		<segment id="96" parent="327" relname="span">Однозначный ответ: нет.</segment>
		<segment id="97" parent="322" relname="span">В начале весны 2015 года,</segment>
		<segment id="98" parent="97" relname="background">когда цены на нефть пошли вверх,</segment>
		<segment id="99" parent="323" relname="joint">Россия по-прежнему демонстрировала неплохой потенциал.</segment>
		<segment id="100" parent="101" relname="condition">Если бы вы тогда инвестировали в РФ,</segment>
		<segment id="101" parent="325" relname="span">то полгода спустя могли бы извлечь неплохую прибыль с учетом всех рисков.</segment>
		<segment id="102" parent="333" relname="span">Россия продолжает демонстрировать хороший потенциал в части оборота ценных бумаг,</segment>
		<segment id="103" parent="102" relname="attribution">о чем говорят данные компании Bloomberg.</segment>
		<segment id="104" parent="105" relname="attribution">По сведениям аналитиков корпорации,</segment>
		<segment id="105" parent="532" relname="span">относительная прибыль Москвы на фоне других стран БРИКС держится на высоком уровне.</segment>
		<segment id="106" parent="529" relname="preparation">Гораздо труднее ответить на другой вопрос: действительно ли все на Западе, в том числе и сторонники санкций, так уж сильно хотят добиться рецессии в России?</segment>
		<segment id="107" parent="337" relname="attribution">По предположениям многих экспертов,</segment>
		<segment id="108" parent="337" relname="span">экономические меры против Кремля направлены на то,</segment>
		<segment id="109" parent="108" relname="purpose">чтобы "кнутом и пряником" заставить Москву отказаться от тех действий, которые не сходятся с интересами Запада.</segment>
		<segment id="110" parent="341" relname="attribution">Однако ряд противников санкций утверждают,</segment>
		<segment id="111" parent="340" relname="contrast">что Запад хочет подрезать крылья российской экономике,</segment>
		<segment id="112" parent="340" relname="contrast">вместо того чтобы способствовать проведению рыночных и экономических реформ в стране.</segment>
		<segment id="113" parent="344" relname="attribution">В их числе ведущий эксперт по России Стивен Коэн (Stephen Cohen), который еще в 2006 году предупреждал:</segment>
		<segment id="114" parent="344" relname="span">"Отношения Москвы и Вашингтона настолько ухудшились,</segment>
		<segment id="115" parent="342" relname="joint">что уже имеет смысл говорить о новой холодной войне</segment>
		<segment id="116" parent="342" relname="joint">или даже о продолжении старой".</segment>
		<segment id="117" parent="524" relname="evaluation">Действительно, текущие тенденции в экономике и геополитике указывают на снижающуюся вероятность разрядки и постепенный переход к новой холодной войне.</segment>
		<segment id="118" parent="522" relname="preparation">На пути к трехпроцентному спаду</segment>
		<segment id="119" parent="520" relname="span">До введения санкций в России ожидали сохранение слабого роста экономики в 2014-2015 годах</segment>
		<segment id="120" parent="119" relname="cause">из-за стабильно низкого спроса на нефть и малопривлекательного инвестиционного климата, осложненного бюрократическими препонами.</segment>
		<segment id="121" parent="351" relname="attribution">В начале 2014 года экономисты предполагали,</segment>
		<segment id="122" parent="350" relname="comparison">что рынок за год вырастет на 1,7%,</segment>
		<segment id="123" parent="350" relname="comparison">а в 2015 году - на 2,3%.</segment>
		<segment id="124" parent="358" relname="span">Сейчас эти прогнозы остались лишь несбыточными мечтами,</segment>
		<segment id="125" parent="124" relname="attribution">о которых мало кто помнит.</segment>
		<segment id="126" parent="352" relname="comparison">За минувший год спад экономики России под давлением санкций составил 3,5%.</segment>
		<segment id="127" parent="352" relname="comparison">В этом году также стоит ожидать сокращения на 3-3,4%.</segment>
		<segment id="128" parent="353" relname="span">На сегодняшний день самым оптимистичным сценарием на 2016 год</segment>
		<segment id="129" parent="128" relname="attribution">аналитики называют</segment>
		<segment id="130" parent="354" relname="same-unit">возвращение к слабому росту - менее 0,5%.</segment>
		<segment id="131" parent="363" relname="comparison">Курс национальной валюты снизился до 67 рублей за доллар</segment>
		<segment id="132" parent="519" relname="span">и 77 рублей за евро</segment>
		<segment id="133" parent="365" relname="span">- и второй показатель здесь наиболее важен,</segment>
		<segment id="134" parent="133" relname="effect">так как Брюссель и Москва поддерживают тесные экономические связи.</segment>
		<segment id="135" parent="517" relname="preparation">Что же можно сказать о среднесрочных перспективах?</segment>
		<segment id="136" parent="368" relname="comparison">При наилучшем развитии событий темпы роста российской экономики достигнут 1,5% к концу десятилетия</segment>
		<segment id="137" parent="368" relname="comparison">и останутся на том же уровне в начале следующего.</segment>
		<segment id="138" parent="369" relname="span">Однако это сущие крохи по сравнению с 7-процентным ростом,</segment>
		<segment id="139" parent="138" relname="elaboration">который был у стран БРИКС до 2008 года.</segment>
		<segment id="140" parent="514" relname="span">И даже эти прогнозы в скором времени могут стать неосуществимыми</segment>
		<segment id="141" parent="140" relname="cause">из-за слабого развития России, усиления антироссийских настроений в Европе, эскалации напряженности между Москвой и Брюсселем, экономического спада на Украине и появления новых геополитических угроз у границ РФ.</segment>
		<segment id="142" parent="375" relname="span">В 2009 году Дмитрий Медведев (Dmitry Medvedev),</segment>
		<segment id="143" parent="142" relname="elaboration">который в то время являлся президентом России,</segment>
		<segment id="144" parent="376" relname="same-unit">запустил программу модернизации страны</segment>
		<segment id="145" parent="377" relname="joint">с целью диверсификации экономики и снижения зависимости от нефтегазовой индустрии.</segment>
		<segment id="146" parent="380" relname="joint">Такой шаг к новому уровню продуктивности вполне закономерен,</segment>
		<segment id="147" parent="380" relname="joint">и многие развитые промышленные страны рано или поздно проходили этот этап.</segment>
		<segment id="148" parent="381" relname="joint">Однако энергоносители по-прежнему остаются крупнейшей статьей экспорта России,</segment>
		<segment id="149" parent="381" relname="joint">а объем инвестиций неуклонно уменьшается.</segment>
		<segment id="150" parent="511" relname="preparation">Снижение цен на энергоносители</segment>
		<segment id="151" parent="516" relname="preparation">Почему же цены на нефть до сих пор не поднялись вверх?</segment>
		<segment id="152" parent="507" relname="attribution">По общепринятому мнению,</segment>
		<segment id="153" parent="507" relname="span">падение котировок спровоцировано ведущими нефтедобытчиками Аравийского полуострова, такими как Саудовская Аравия,</segment>
		<segment id="154" parent="155" relname="purpose">которые пытаются помешать американским конкурентам взять на вооружение ноу-хау,</segment>
		<segment id="155" parent="508" relname="span">сделав переход на новые методы добычи экономически невыгодным.</segment>
		<segment id="156" parent="390" relname="attribution">Как считают сторонники этой точки зрения,</segment>
		<segment id="157" parent="158" relname="purpose">арабские страны стремятся отсрочить крах своей нефтяной монополии</segment>
		<segment id="158" parent="390" relname="span">через сдерживание роста цен.</segment>
		<segment id="159" parent="396" relname="attribution">Согласно другой версии,</segment>
		<segment id="160" parent="395" relname="joint">отношения Америки и Египта, а также общие военные интересы США, Саудовской Аравии и стран Персидского залива сейчас стали гораздо важнее денег,</segment>
		<segment id="161" parent="484" relname="span">а низкие цены превратились в инструмент</segment>
		<segment id="162" parent="161" relname="purpose">для решения геополитических задач.</segment>
		<segment id="163" parent="164" relname="attribution">По данным Центрального банка Российской Федерации,</segment>
		<segment id="164" parent="400" relname="span">существует высокая вероятность того, что цены на нефть не скоро поднимутся выше 60 долларов за баррель.</segment>
		<segment id="165" parent="398" relname="comparison">Несмотря на то, что сейчас котировки держатся в районе 44 долларов,</segment>
		<segment id="166" parent="485" relname="comparison">к концу года они могут подойти вплотную к 60 долларам,</segment>
		<segment id="167" parent="483" relname="span">что на 5 долларов меньше заявленного американскими компаниями минимального порога</segment>
		<segment id="168" parent="167" relname="purpose">для увеличения объемов добычи сланцевой нефти.</segment>
		<segment id="169" parent="170" relname="attribution">Из отчетов российских нефтеперерабатывающих компаний следует,</segment>
		<segment id="170" parent="408" relname="span">что две трети из них работает в убыток.</segment>
		<segment id="171" parent="404" relname="joint">В конце июля ЦБ РФ снизил ключевую ставку на 50 базисных пунктов до 11%</segment>
		<segment id="172" parent="505" relname="joint">и выпустил предупреждение об уменьшении экономической активности,</segment>
		<segment id="173" parent="505" relname="joint">при этом охарактеризовав инфляцию как не столь угрожающую.</segment>
		<segment id="174" parent="407" relname="span">До недавнего времени дела на российском рынке шли относительно спокойно</segment>
		<segment id="175" parent="174" relname="effect">благодаря фискальной политике Кремля, мерам количественного смягчения и буферному капиталу.</segment>
		<segment id="176" parent="488" relname="contrast">Однако объем инвестиций продолжал снижаться.</segment>
		<segment id="177" parent="416" relname="comparison">Всего несколько лет назад уровень прямых российских инвестиций за рубежом составлял около 16% от валового прироста основного капитала.</segment>
		<segment id="178" parent="416" relname="comparison">За прошлый год этот показатель снизился до 14%.</segment>
		<segment id="179" parent="417" relname="span">Кроме того, роль зарубежных инвестиций в российские компании кардинально изменилась:</segment>
		<segment id="180" parent="412" relname="comparison">если в 2013 году они составляли более 15% [от ВВП],</segment>
		<segment id="181" parent="412" relname="comparison">то к концу прошлого года их доля сократилась до 5%.</segment>
		<segment id="182" parent="415" relname="attribution">По мнению иностранных инвесторов,</segment>
		<segment id="183" parent="413" relname="joint">российским властям следует как можно скорее провести структурные реформы</segment>
		<segment id="184" parent="413" relname="joint">и более активно бороться с коррупцией.</segment>
		<segment id="185" parent="501" relname="preparation">Разногласия в руководстве ЦБ РФ ни для кого не стали сюрпризом.</segment>
		<segment id="186" parent="498" relname="attribution">Первый заместитель председателя Центробанка Дмитрий Тулин (Dmitri Tulin) высказался</segment>
		<segment id="187" parent="496" relname="joint">за смягчение монетарной политики</segment>
		<segment id="188" parent="496" relname="joint">и целевое кредитование промышленности</segment>
		<segment id="189" parent="497" relname="purpose">для восстановления экономики,</segment>
		<segment id="190" parent="191" relname="attribution">а глава ЦБ Эльвира Набиуллина (Elvira Nabiullina) выступила</segment>
		<segment id="191" parent="437" relname="span">в поддержку традиционных мер влияния на рынок.</segment>
		<segment id="192" parent="429" relname="attribution">В то же время они сходятся во мнении,</segment>
		<segment id="193" parent="428" relname="effect">что дальнейшее падение нефтяных котировок</segment>
		<segment id="194" parent="440" relname="span">истощит резервы ЦБ РФ,</segment>
		<segment id="195" parent="194" relname="elaboration">объем которых оценивается в 360 млрд. долларов.</segment>
		<segment id="196" parent="452" relname="preparation">Напряженность на горизонте</segment>
		<segment id="197" parent="433" relname="joint">Преимущества России заключаются в ее стратегических силах и народном единстве,</segment>
		<segment id="198" parent="433" relname="joint">и США должны об этом помнить.</segment>
		<segment id="199" parent="495" relname="span">Российская Федерация занимает третье место в мире по расходам на вооружение после Соединенных Штатов и Китая.</segment>
		<segment id="200" parent="445" relname="contrast">Оборонный бюджет Америки в прошлом году был сокращен на 7%,</segment>
		<segment id="201" parent="445" relname="contrast">тогда как Москва, напротив, приняла решение увеличить его на 8%.</segment>
		<segment id="202" parent="446" relname="span">Владимир Путин остается верен своему плану провести модернизацию Вооруженных сил РФ к 2020 году,</segment>
		<segment id="203" parent="202" relname="elaboration">что потребует 600 млрд. долларов,</segment>
		<segment id="204" parent="447" relname="joint">и санкции Запада только способствуют поддержке этих мер россиянами.</segment>
		<segment id="205" parent="460" relname="joint">Не стоит забывать, что Россия - ядерная держава.</segment>
		<segment id="206" parent="458" relname="contrast">Хотя у Вашингтона на вооружении находится около 2 тыс. 80 боеголовок,</segment>
		<segment id="207" parent="456" relname="joint">Москва держит наготове 1 тыс. 780 атомных ракет,</segment>
		<segment id="208" parent="456" relname="joint">а общее число имеющихся у РФ ядерных боезарядов - 7 тыс. 500 единиц - превышает американские запасы.</segment>
		<segment id="209" parent="210" relname="effect">За прошедшие полтора года санкции [введенные против России и Россией против Запада] усилили экономический спад в Европе,</segment>
		<segment id="210" parent="489" relname="span">снизив эффективность национальных бюджетных мер и программ количественного смягчения Европейского Центробанка.</segment>
		<segment id="211" parent="490" relname="span">Результатом этого стало падение общих показателей мирового роста, в том числе и в США, и дальнейшее усиление антиамериканских и антиевропейских настроений в России.</segment>
		<segment id="212" parent="464" relname="joint">Нефтяные котировки по-прежнему держатся на низком уровне,</segment>
		<segment id="213" parent="464" relname="joint">а ФРС США планирует повысить ключевую ставку этой осенью.</segment>
		<segment id="214" parent="491" relname="span">Сильнее всего это ударит по развивающимся нефтегазовым экономикам, среди которых и Россия.</segment>
		<segment id="215" parent="468" relname="joint">Несомненно, между Вашингтоном и Москвой, между Кремлем и Брюсселем сейчас установилась атмосфера взаимной неприязни.</segment>
		<segment id="216" parent="468" relname="joint">Однако санкции будут только способствовать раздору, а отнюдь не примирению.</segment>
		<segment id="217" parent="492" relname="evaluation">Быть может, политикам стоит в первую очередь сосредоточиться на выходе из экономической рецессии и поиске геополитического диалога?</segment>
		<group id="218" type="multinuc" parent="219" relname="span"/>
		<group id="219" type="span" parent="473" relname="span"/>
		<group id="220" type="span" parent="221" relname="joint"/>
		<group id="221" type="multinuc" parent="222" relname="span"/>
		<group id="222" type="span" parent="223" relname="contrast"/>
		<group id="223" type="multinuc" parent="225" relname="span"/>
		<group id="224" type="span" parent="225" relname="effect"/>
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" parent="474" relname="span"/>
		<group id="227" type="multinuc" parent="476" relname="same-unit"/>
		<group id="235" type="multinuc" parent="480" relname="joint"/>
		<group id="236" type="multinuc" parent="480" relname="joint"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" parent="242" relname="span"/>
		<group id="242" type="span" parent="245" relname="span"/>
		<group id="243" type="span" parent="244" relname="same-unit"/>
		<group id="244" type="multinuc" parent="247" relname="span"/>
		<group id="245" type="span" parent="246" relname="joint"/>
		<group id="246" type="multinuc" />
		<group id="247" type="span" parent="246" relname="joint"/>
		<group id="252" type="multinuc" parent="259" relname="span"/>
		<group id="253" type="span" />
		<group id="256" type="span" parent="252" relname="joint"/>
		<group id="259" type="span" parent="253" relname="span"/>
		<group id="261" type="span" parent="262" relname="joint"/>
		<group id="262" type="multinuc" parent="471" relname="contrast"/>
		<group id="264" type="multinuc" parent="265" relname="span"/>
		<group id="265" type="span" parent="41" relname="effect"/>
		<group id="267" type="span" parent="472" relname="span"/>
		<group id="269" type="span" parent="267" relname="elaboration"/>
		<group id="270" type="multinuc" parent="271" relname="span"/>
		<group id="271" type="span" parent="535" relname="span"/>
		<group id="272" type="multinuc" parent="273" relname="span"/>
		<group id="273" type="span" parent="48" relname="effect"/>
		<group id="274" type="span" parent="275" relname="span"/>
		<group id="275" type="span" parent="536" relname="contrast"/>
		<group id="276" type="span" parent="277" relname="same-unit"/>
		<group id="277" type="multinuc" parent="279" relname="span"/>
		<group id="278" type="multinuc" parent="280" relname="span"/>
		<group id="279" type="span" parent="281" relname="restatement"/>
		<group id="280" type="span" parent="281" relname="restatement"/>
		<group id="281" type="multinuc" parent="537" relname="evidence"/>
		<group id="284" type="multinuc" parent="285" relname="span"/>
		<group id="285" type="span" parent="290" relname="span"/>
		<group id="289" type="span" parent="291" relname="contrast"/>
		<group id="290" type="span" parent="291" relname="contrast"/>
		<group id="291" type="multinuc" parent="293" relname="span"/>
		<group id="293" type="span" parent="294" relname="joint"/>
		<group id="294" type="multinuc" />
		<group id="295" type="multinuc" parent="296" relname="span"/>
		<group id="296" type="span" parent="64" relname="elaboration"/>
		<group id="300" type="span" parent="69" relname="elaboration"/>
		<group id="301" type="span" parent="303" relname="comparison"/>
		<group id="303" type="multinuc" parent="541" relname="joint"/>
		<group id="307" type="multinuc" parent="310" relname="span"/>
		<group id="308" type="span" parent="309" relname="joint"/>
		<group id="309" type="multinuc" />
		<group id="310" type="span" parent="309" relname="joint"/>
		<group id="314" type="multinuc" parent="315" relname="span"/>
		<group id="315" type="span" parent="316" relname="span"/>
		<group id="316" type="span" parent="317" relname="elaboration"/>
		<group id="317" type="span" parent="543" relname="span"/>
		<group id="318" type="multinuc" parent="319" relname="span"/>
		<group id="319" type="span" parent="90" relname="effect"/>
		<group id="320" type="span" parent="321" relname="joint"/>
		<group id="321" type="multinuc" parent="328" relname="span"/>
		<group id="322" type="span" parent="323" relname="joint"/>
		<group id="323" type="multinuc" parent="324" relname="span"/>
		<group id="324" type="span" parent="326" relname="span"/>
		<group id="325" type="span" parent="324" relname="elaboration"/>
		<group id="326" type="span" parent="96" relname="elaboration"/>
		<group id="327" type="span" parent="330" relname="span"/>
		<group id="328" type="span" parent="88" relname="elaboration"/>
		<group id="329" type="span" parent="331" relname="joint"/>
		<group id="330" type="span" parent="331" relname="joint"/>
		<group id="331" type="multinuc" parent="332" relname="span"/>
		<group id="332" type="span" />
		<group id="333" type="span" parent="531" relname="span"/>
		<group id="337" type="span" parent="338" relname="span"/>
		<group id="338" type="span" parent="528" relname="contrast"/>
		<group id="340" type="multinuc" parent="341" relname="span"/>
		<group id="341" type="span" parent="526" relname="span"/>
		<group id="342" type="multinuc" parent="343" relname="span"/>
		<group id="343" type="span" parent="114" relname="elaboration"/>
		<group id="344" type="span" parent="524" relname="span"/>
		<group id="350" type="multinuc" parent="351" relname="span"/>
		<group id="351" type="span" parent="356" relname="span"/>
		<group id="352" type="multinuc" parent="359" relname="span"/>
		<group id="353" type="span" parent="354" relname="same-unit"/>
		<group id="354" type="multinuc" parent="357" relname="span"/>
		<group id="356" type="span" parent="521" relname="sequence"/>
		<group id="357" type="span" parent="352" relname="comparison"/>
		<group id="358" type="span" parent="361" relname="span"/>
		<group id="359" type="span" parent="358" relname="elaboration"/>
		<group id="361" type="span" parent="362" relname="span"/>
		<group id="362" type="span" parent="521" relname="sequence"/>
		<group id="363" type="multinuc" />
		<group id="365" type="span" parent="132" relname="evaluation"/>
		<group id="368" type="multinuc" parent="370" relname="span"/>
		<group id="369" type="span" parent="371" relname="comparison"/>
		<group id="370" type="span" parent="371" relname="comparison"/>
		<group id="371" type="multinuc" parent="372" relname="span"/>
		<group id="372" type="span" parent="517" relname="span"/>
		<group id="375" type="span" parent="376" relname="same-unit"/>
		<group id="376" type="multinuc" parent="378" relname="span"/>
		<group id="377" type="multinuc" parent="379" relname="span"/>
		<group id="378" type="span" parent="382" relname="span"/>
		<group id="379" type="span" parent="378" relname="purpose"/>
		<group id="380" type="multinuc" parent="383" relname="span"/>
		<group id="381" type="multinuc" parent="513" relname="contrast"/>
		<group id="382" type="span" parent="384" relname="span"/>
		<group id="383" type="span" parent="382" relname="evaluation"/>
		<group id="384" type="span" parent="513" relname="contrast"/>
		<group id="390" type="span" parent="392" relname="span"/>
		<group id="392" type="span" parent="509" relname="elaboration"/>
		<group id="395" type="multinuc" parent="396" relname="span"/>
		<group id="396" type="span" parent="506" relname="span"/>
		<group id="398" type="multinuc" parent="486" relname="span"/>
		<group id="400" type="span" parent="486" relname="preparation"/>
		<group id="404" type="multinuc" parent="409" relname="span"/>
		<group id="407" type="span" parent="488" relname="contrast"/>
		<group id="408" type="span" parent="411" relname="joint"/>
		<group id="409" type="span" parent="411" relname="joint"/>
		<group id="411" type="multinuc" />
		<group id="412" type="multinuc" parent="414" relname="span"/>
		<group id="413" type="multinuc" parent="415" relname="span"/>
		<group id="414" type="span" parent="179" relname="elaboration"/>
		<group id="415" type="span" parent="418" relname="span"/>
		<group id="416" type="multinuc" parent="419" relname="span"/>
		<group id="417" type="span" parent="421" relname="span"/>
		<group id="418" type="span" parent="417" relname="elaboration"/>
		<group id="419" type="span" parent="420" relname="joint"/>
		<group id="420" type="multinuc" />
		<group id="421" type="span" parent="420" relname="joint"/>
		<group id="425" type="span" parent="500" relname="contrast"/>
		<group id="428" type="span" parent="441" relname="span"/>
		<group id="429" type="span" parent="444" relname="span"/>
		<group id="433" type="multinuc" parent="448" relname="span"/>
		<group id="437" type="span" parent="425" relname="span"/>
		<group id="440" type="span" parent="428" relname="span"/>
		<group id="441" type="span" parent="429" relname="span"/>
		<group id="444" type="span" parent="503" relname="contrast"/>
		<group id="445" type="multinuc" parent="450" relname="span"/>
		<group id="446" type="span" parent="447" relname="joint"/>
		<group id="447" type="multinuc" parent="451" relname="span"/>
		<group id="448" type="span" parent="449" relname="joint"/>
		<group id="449" type="multinuc" parent="452" relname="span"/>
		<group id="450" type="span" parent="199" relname="elaboration"/>
		<group id="451" type="span" parent="449" relname="joint"/>
		<group id="452" type="span" parent="504" relname="span"/>
		<group id="456" type="multinuc" parent="457" relname="span"/>
		<group id="457" type="span" parent="458" relname="contrast"/>
		<group id="458" type="multinuc" parent="459" relname="span"/>
		<group id="459" type="span" parent="460" relname="joint"/>
		<group id="460" type="multinuc" />
		<group id="464" type="multinuc" parent="214" relname="effect"/>
		<group id="468" type="multinuc" parent="492" relname="span"/>
		<group id="470" type="span" parent="262" relname="joint"/>
		<group id="471" type="multinuc" />
		<group id="472" type="span" parent="471" relname="contrast"/>
		<group id="473" type="span" parent="474" relname="preparation"/>
		<group id="474" type="span" parent="475" relname="span"/>
		<group id="475" type="span" />
		<group id="476" type="multinuc" parent="477" relname="contrast"/>
		<group id="477" type="multinuc" parent="478" relname="span"/>
		<group id="478" type="span" parent="479" relname="span"/>
		<group id="479" type="span" />
		<group id="480" type="multinuc" parent="481" relname="span"/>
		<group id="481" type="span" parent="482" relname="span"/>
		<group id="482" type="span" />
		<group id="483" type="span" parent="485" relname="comparison"/>
		<group id="484" type="span" parent="395" relname="joint"/>
		<group id="485" type="multinuc" parent="398" relname="comparison"/>
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" />
		<group id="488" type="multinuc" parent="411" relname="joint"/>
		<group id="489" type="span" parent="211" relname="effect"/>
		<group id="490" type="span" parent="494" relname="joint"/>
		<group id="491" type="span" parent="494" relname="joint"/>
		<group id="492" type="span" parent="493" relname="span"/>
		<group id="493" type="span" />
		<group id="494" type="multinuc" />
		<group id="495" type="span" parent="449" relname="joint"/>
		<group id="496" type="multinuc" parent="497" relname="span"/>
		<group id="497" type="span" parent="498" relname="span"/>
		<group id="498" type="span" parent="499" relname="span"/>
		<group id="499" type="span" parent="500" relname="contrast"/>
		<group id="500" type="multinuc" parent="503" relname="contrast"/>
		<group id="501" type="span" parent="502" relname="span"/>
		<group id="502" type="span" />
		<group id="503" type="multinuc" parent="501" relname="span"/>
		<group id="504" type="span" />
		<group id="505" type="multinuc" parent="404" relname="joint"/>
		<group id="506" type="span" parent="515" relname="comparison"/>
		<group id="507" type="span" parent="509" relname="span"/>
		<group id="508" type="span" parent="153" relname="elaboration"/>
		<group id="509" type="span" parent="510" relname="span"/>
		<group id="510" type="span" parent="515" relname="comparison"/>
		<group id="511" type="span" parent="512" relname="span"/>
		<group id="512" type="span" />
		<group id="513" type="multinuc" />
		<group id="514" type="span" parent="372" relname="evaluation"/>
		<group id="515" type="multinuc" parent="516" relname="span"/>
		<group id="516" type="span" parent="511" relname="span"/>
		<group id="517" type="span" parent="518" relname="span"/>
		<group id="518" type="span" />
		<group id="519" type="span" parent="363" relname="comparison"/>
		<group id="520" type="span" parent="521" relname="sequence"/>
		<group id="521" type="multinuc" parent="522" relname="span"/>
		<group id="522" type="span" parent="523" relname="span"/>
		<group id="523" type="span" />
		<group id="524" type="span" parent="525" relname="span"/>
		<group id="525" type="span" parent="526" relname="elaboration"/>
		<group id="526" type="span" parent="527" relname="span"/>
		<group id="527" type="span" parent="528" relname="contrast"/>
		<group id="528" type="multinuc" parent="529" relname="span"/>
		<group id="529" type="span" parent="530" relname="span"/>
		<group id="530" type="span" />
		<group id="531" type="span" />
		<group id="532" type="span" parent="333" relname="elaboration"/>
		<group id="533" type="multinuc" parent="32" relname="effect"/>
		<group id="534" type="span" parent="252" relname="joint"/>
		<group id="535" type="span" />
		<group id="536" type="multinuc" parent="537" relname="span"/>
		<group id="537" type="span" parent="538" relname="span"/>
		<group id="538" type="span" />
		<group id="539" type="span" />
		<group id="540" type="multinuc" parent="541" relname="joint"/>
		<group id="541" type="multinuc" />
		<group id="542" type="span" parent="544" relname="contrast"/>
		<group id="543" type="span" parent="544" relname="contrast"/>
		<group id="544" type="multinuc" />
		<group id="545" type="multinuc" parent="294" relname="joint"/>
		<group id="546" type="span" parent="547" relname="span"/>
		<group id="547" type="span" parent="548" relname="span"/>
		<group id="548" type="span" parent="303" relname="comparison"/>
	</body>
</rst>