<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="130" relname="span">Мир должен осознать циничность действий военно-промышленного лобби США</segment>
		<segment id="2" parent="1" relname="attribution">— эксперт</segment>
		<segment id="3" parent="124" relname="span">Действия американского военно-промышленного лобби,</segment>
		<segment id="4" parent="3" relname="elaboration">пользующегося широкой поддержкой СМИ и политического истэблишмента,</segment>
		<segment id="5" parent="127" relname="span">способствуют разжиганию нестабильности по всему земному шару,</segment>
		<segment id="6" parent="125" relname="joint">поэтому мировой общественности следует внимательнее следить за ситуацией</segment>
		<segment id="7" parent="125" relname="joint">и пресекать возможные попытки эскалации напряженности.</segment>
		<segment id="8" parent="238" relname="attribution">Об этом пишет антивоенный активист, правозащитник, автор ряда книг и публикаций о международной политике, мировых конфликтах и кризисах Хабиб Сиддики (Habib Siddiqi) в своей статье "Война и спекулянты на ней".</segment>
		<segment id="9" parent="131" relname="attribution">Он напоминает,</segment>
		<segment id="10" parent="131" relname="span">что кровопролитие оставалось неотъемлемой частью человеческой жизни до середины XX века,</segment>
		<segment id="11" parent="10" relname="background">когда мир увидел все ужасы Второй мировой войны.</segment>
		<segment id="12" parent="227" relname="span">"После ее окончания в 1945 году была основана Организация Объединенных Наций,</segment>
		<segment id="13" parent="12" relname="purpose">члены которой поставили перед собой единственную цель - защитить грядущие поколения от бича войны.</segment>
		<segment id="14" parent="133" relname="joint">Кроме того, страны ООН выразили решимость вновь утвердить веру в неотъемлемые права и свободы человека, равноправие полов и наций,</segment>
		<segment id="15" parent="133" relname="joint">создать надлежащие условия для соблюдения международного права",</segment>
		<segment id="16" parent="137" relname="attribution">- отмечает автор статьи.</segment>
		<segment id="17" parent="142" relname="same-unit">Однако,</segment>
		<segment id="18" parent="141" relname="attribution">с его точки зрения,</segment>
		<segment id="19" parent="138" relname="span">в наши дни некоторые державы,</segment>
		<segment id="20" parent="19" relname="elaboration">позабыв об уроках прошлого,</segment>
		<segment id="21" parent="139" relname="same-unit">злоупотребляют своей властью,</segment>
		<segment id="22" >из-за чего по всему миру продолжают возникать все новые вооруженные столкновения.</segment>
		<segment id="23" parent="147" relname="attribution">Как утверждает правозащитник,</segment>
		<segment id="24" parent="144" relname="span">гонка вооружений между США и СССР,</segment>
		<segment id="25" parent="24" relname="elaboration">начавшаяся после победы союзных войск над нацистской Германией,</segment>
		<segment id="26" parent="145" relname="span">создала благоприятные условия для формирования своеобразного симбиоза между военной индустрией и вооруженными силами Соединенных Штатов,</segment>
		<segment id="27" parent="26" relname="elaboration">которые нуждались в скорейшей модернизации.</segment>
		<segment id="28" parent="148" relname="attribution">По словам активиста,</segment>
		<segment id="29" parent="148" relname="span">уже к 1960-м годам темпы их развития стали настолько угрожающими,</segment>
		<segment id="30" parent="29" relname="elaboration">что президент США Дуайт Эйзенхауэр (Dwight Eisenhower) посвятил этой проблеме свое последнее выступление на посту главы государства.</segment>
		<segment id="31" parent="32" relname="attribution">"В [прощальной] речи 17 января 1961 года</segment>
		<segment id="32" parent="154" relname="span">он предостерег народ Соединенных Штатов о существовании величайшей угрозы для демократии со стороны [американского] военно-промышленного комплекса - колоссального союза военных подрядчиков и вооруженных сил.</segment>
		<segment id="33" parent="149" relname="joint">В прошлом Дуайт Эйзенхауэр был генералом армии США</segment>
		<segment id="34" parent="149" relname="joint">и непосредственно руководил войсками антигитлеровской коалиции во время высадки в Нормандии.</segment>
		<segment id="35" parent="153" relname="span">Он выступил с прощальной речью</segment>
		<segment id="36" parent="150" relname="joint">накануне своего ухода из Белого дома</segment>
		<segment id="37" parent="150" relname="joint">после двух президентских сроков и</segment>
		<segment id="38" parent="150" relname="joint">всего за несколько дней до присяги нового лидера страны Джона Кеннеди (John F. Kennedy)",</segment>
		<segment id="39" parent="156" relname="attribution">- отмечает Хабиб Сиддики.</segment>
		<segment id="40" parent="158" relname="attribution">По его мнению,</segment>
		<segment id="41" parent="157" relname="joint">слова Дуайта Эйзенхауэра оказали значительное влияние на общественность 1960-х годов</segment>
		<segment id="42" parent="157" relname="joint">и фактически стали лозунгом антивоенного движения.</segment>
		<segment id="43" parent="233" relname="attribution">"[Он] заявил</segment>
		<segment id="44" parent="233" relname="span">о недопустимости чрезмерных расходов на гонку вооружений,</segment>
		<segment id="45" parent="159" relname="span">из-за которых другие направления,</segment>
		<segment id="46" parent="45" relname="elaboration">в том числе образование и здравоохранение,</segment>
		<segment id="47" parent="160" relname="same-unit">лишались финансирования.</segment>
		<segment id="48" parent="165" relname="attribution">В словах бывшего президента США о том, что</segment>
		<segment id="49" parent="165" relname="span">"мы обязаны научиться улаживать споры,</segment>
		<segment id="50" parent="163" relname="contrast">не прибегая к оружию,</segment>
		<segment id="51" parent="163" relname="contrast">но руководствуясь исключительно своим разумом и благой целью",</segment>
		<segment id="52" parent="230" relname="evaluation">чувствуется человек, который лично пережил ужасы и несмываемую горечь войны",</segment>
		<segment id="53" parent="231" relname="attribution">- констатирует автор статьи.</segment>
		<segment id="54" parent="55" relname="attribution">В то же время он отмечает,</segment>
		<segment id="55" parent="241" relname="span">что пророческие опасения бывшего главы американского государства к концу XX - началу XXI века воплотились в реальность.</segment>
		<segment id="56" parent="175" relname="span">"Со временем "торговцы войной" стали неотделимы от высокопоставленных политических структур.</segment>
		<segment id="57" parent="169" relname="span">Расписавшись во взаимной любви с властями, эти спекулянты на чужом страдании до такой степени изменили политический курс [страны],</segment>
		<segment id="58" parent="57" relname="elaboration">что не только производители и торговцы оружием, но и довлеющие над ними политики начали считать войну делом крайне выгодным для всех.</segment>
		<segment id="59" parent="170" relname="effect">Военная индустрия создает тысячи рабочих мест для специалистов самых разных профессий,</segment>
		<segment id="60" parent="170" relname="span">что всегда хорошо для политиков,</segment>
		<segment id="61" parent="60" relname="elaboration">прекрасно знающих, как финансовые проблемы влияют на население.</segment>
		<segment id="62" parent="172" relname="effect">Ведь чем плотнее набиты кошельки обычных людей,</segment>
		<segment id="63" parent="171" relname="joint">тем спокойнее живется властям</segment>
		<segment id="64" parent="171" relname="joint">и тем выше рейтинг у лидера сытого народа",</segment>
		<segment id="65" parent="177" relname="attribution">- напоминает эксперт.</segment>
		<segment id="66" parent="182" relname="attribution">По его словам,</segment>
		<segment id="67" parent="178" relname="span">влиятельные лица из самых разных слоев населения,</segment>
		<segment id="68" parent="67" relname="elaboration">включая монархов, революционеров и народных избранников,</segment>
		<segment id="69" parent="180" relname="same-unit">на протяжении всей истории человечества оказывали поддержку торговцам оружием ради огромных денег,</segment>
		<segment id="70" parent="182" relname="span">и представители американского военного лобби не стали исключением.</segment>
		<segment id="71" parent="184" relname="attribution">"Вот еще одно из высказываний [Дуайта Эйзенхауэра]:</segment>
		<segment id="72" parent="183" relname="span">"Самолет, который пролетает в небе над вами, стоит 750 тыс. долларов</segment>
		<segment id="73" parent="72" relname="elaboration">- больше, чем человек может заработать за всю свою жизнь.</segment>
		<segment id="74" parent="184" relname="span">Разве хоть одна страна может позволить себе такие траты слишком долго?".</segment>
		<segment id="75" parent="186" relname="span">Эта цифра к нашему времени выросла в тысячу раз,</segment>
		<segment id="76" parent="75" relname="elaboration">превратилась почти в четверть миллиарда долларов",</segment>
		<segment id="77" parent="188" relname="attribution">- пишет антивоенный активист.</segment>
		<segment id="78" parent="189" relname="span">"Для справки: стелс-бомбардировщик B-2 Spirit,</segment>
		<segment id="79" parent="78" relname="elaboration">защищенный от обнаружения инфракрасными, акустическими, электромагнитными детекторами и радарами,</segment>
		<segment id="80" parent="190" relname="same-unit">стоит 2,4 млрд. долларов.</segment>
		<segment id="81" parent="82" relname="effect">Из-за запредельной цены</segment>
		<segment id="82" parent="191" relname="span">конгресс США принял решение урезать заказ 1987 года до 21 единицы техники вместо изначальных 132",</segment>
		<segment id="83" parent="193" relname="attribution">- продолжает автор статьи.</segment>
		<segment id="84" parent="198" relname="attribution">С его точки зрения,</segment>
		<segment id="85" parent="195" relname="span">беспощадный цинизм американского военно-промышленного лобби,</segment>
		<segment id="86" parent="85" relname="elaboration">провоцирующего ради прибыли кровавые вооруженные конфликты по всему миру,</segment>
		<segment id="87" parent="196" relname="span">сегодня особенно заметен на Ближнем Востоке,</segment>
		<segment id="88" parent="194" relname="span">где на армию тратятся огромные средства,</segment>
		<segment id="89" parent="88" relname="elaboration">которые могли бы быть направлены на решение проблем в социальной сфере.</segment>
		<segment id="90" parent="199" relname="span">"По данным Стокгольмского международного института исследования проблем мира (SIPRI),</segment>
		<segment id="91" parent="90" relname="elaboration">собирающего сведения о продажах оружия,</segment>
		<segment id="92" parent="245" relname="comparison">военные расходы в этом регионе к 2014 году составили почти 200 млрд. долларов</segment>
		<segment id="93" parent="245" relname="comparison">- на 57% выше, чем в 2005 году.</segment>
		<segment id="94" parent="203" relname="span">В значительной мере это объясняется тем,</segment>
		<segment id="95" parent="94" relname="effect">что постоянные клиенты - союзники США начали закупать дорогостоящее оружие.</segment>
		<segment id="96" parent="201" relname="span">В их числе Ирак и Саудовская Аравия,</segment>
		<segment id="97" parent="96" relname="elaboration">которым, впрочем, по-прежнему приходится нелегко в борьбе с более мелкими и хуже вооруженными противниками.</segment>
		<segment id="98" parent="201" relname="elaboration">Расходы на закупки оружия в этих двух странах по сравнению с 2005 годом увеличились на 286% и 112% соответственно",</segment>
		<segment id="99" parent="248" relname="attribution">- поясняет Хабиб Сиддики.</segment>
		<segment id="100" parent="207" relname="attribution">Он считает также,</segment>
		<segment id="101" parent="207" relname="span">что агрессивная реакция целого ряда высокопоставленных лиц на успех переговоров по иранской ядерной программе 14 июля 2015 года</segment>
		<segment id="102" parent="101" relname="evaluation">свидетельствует о глубинной взаимосвязи внешнеполитического курса США с интересами военно-промышленного лобби.</segment>
		<segment id="103" parent="218" relname="span">"Они рвут и мечут.</segment>
		<segment id="104" parent="209" relname="joint">Агрессивные выпады в отношении Тегерана перешли все границы,</segment>
		<segment id="105" parent="208" relname="span">а газеты и журналы пестрят статьями об иранской "угрозе для основы существования" "бедного" Израиля,</segment>
		<segment id="106" parent="105" relname="concession">который, кстати, в наше время является четвертой страной в мире по военному потенциалу.</segment>
		<segment id="107" parent="215" relname="span">Сделка с Ираном,</segment>
		<segment id="108" parent="211" relname="span">очевидно, стоит на пути у этих людей,</segment>
		<segment id="109" parent="108" relname="elaboration">которые хотят пополнить свои кошельки на десятки миллиардов долларов на очередном конфликте.</segment>
		<segment id="110" parent="212" relname="span">Помните журналистку New York Times Джудит Миллер (Judith Miller) и ее полную лжи статью об оружии массового поражения в Ираке,</segment>
		<segment id="111" parent="110" relname="elaboration">которое так и не нашли?</segment>
		<segment id="112" parent="212" relname="elaboration">Эта публикация стала настоящей квинтэссенцией "желтой прессы".</segment>
		<segment id="113" parent="214" relname="span">Сегодня "партия войны" ищет новую Джудит Миллер,</segment>
		<segment id="114" parent="113" relname="purpose">чтобы заложить фундамент под атаку против Ирана", -</segment>
		<segment id="115" parent="220" relname="attribution">пишет правозащитник.</segment>
		<segment id="116" parent="223" relname="attribution">По его мнению,</segment>
		<segment id="117" parent="223" relname="span">борьба с неограниченной экспансией военно-промышленного комплекса и риторикой агрессивно настроенных СМИ</segment>
		<segment id="118" parent="221" relname="joint">потребует сильной политической воли</segment>
		<segment id="119" parent="221" relname="joint">и всеобщего осознания недопустимости новых войн.</segment>
		<segment id="120" parent="224" relname="condition">"В противном случае</segment>
		<segment id="121" parent="224" relname="span">мы никогда не избавимся от бесконечного кровопролития,</segment>
		<segment id="122" parent="121" relname="effect">которое представляет угрозу не только для нас, но и для наших потомков",</segment>
		<segment id="123" parent="225" relname="attribution">- полагает автор статьи.</segment>
		<group id="124" type="span" parent="5" relname="effect"/>
		<group id="125" type="multinuc" parent="126" relname="span"/>
		<group id="126" type="span" parent="238" relname="span"/>
		<group id="127" type="span" parent="126" relname="effect"/>
		<group id="130" type="span" parent="239" relname="preparation"/>
		<group id="131" type="span" parent="236" relname="span"/>
		<group id="133" type="multinuc" parent="135" relname="span"/>
		<group id="135" type="span" parent="136" relname="joint"/>
		<group id="136" type="multinuc" parent="137" relname="span"/>
		<group id="137" type="span" parent="228" relname="span"/>
		<group id="138" type="span" parent="139" relname="same-unit"/>
		<group id="139" type="multinuc" parent="141" relname="span"/>
		<group id="141" type="span" parent="226" relname="span"/>
		<group id="142" type="multinuc" parent="143" relname="span"/>
		<group id="143" type="span" parent="22" relname="effect"/>
		<group id="144" type="span" parent="146" relname="same-unit"/>
		<group id="145" type="span" parent="146" relname="same-unit"/>
		<group id="146" type="multinuc" parent="147" relname="span"/>
		<group id="147" type="span" />
		<group id="148" type="span" />
		<group id="149" type="multinuc" parent="152" relname="joint"/>
		<group id="150" type="multinuc" parent="151" relname="span"/>
		<group id="151" type="span" parent="35" relname="background"/>
		<group id="152" type="multinuc" parent="155" relname="span"/>
		<group id="153" type="span" parent="152" relname="joint"/>
		<group id="154" type="span" parent="156" relname="span"/>
		<group id="155" type="span" parent="154" relname="elaboration"/>
		<group id="156" type="span" />
		<group id="157" type="multinuc" parent="158" relname="span"/>
		<group id="158" type="span" parent="235" relname="span"/>
		<group id="159" type="span" parent="160" relname="same-unit"/>
		<group id="160" type="multinuc" parent="44" relname="effect"/>
		<group id="163" type="multinuc" parent="164" relname="span"/>
		<group id="164" type="span" parent="49" relname="elaboration"/>
		<group id="165" type="span" parent="230" relname="span"/>
		<group id="169" type="span" parent="56" relname="elaboration"/>
		<group id="170" type="span" parent="174" relname="span"/>
		<group id="171" type="multinuc" parent="172" relname="span"/>
		<group id="172" type="span" parent="173" relname="span"/>
		<group id="173" type="span" parent="174" relname="evidence"/>
		<group id="174" type="span" parent="176" relname="span"/>
		<group id="175" type="span" parent="177" relname="span"/>
		<group id="176" type="span" parent="175" relname="elaboration"/>
		<group id="177" type="span" />
		<group id="178" type="span" parent="180" relname="same-unit"/>
		<group id="180" type="multinuc" parent="181" relname="span"/>
		<group id="181" type="span" parent="70" relname="evidence"/>
		<group id="182" type="span" />
		<group id="183" type="span" parent="74" relname="evaluation"/>
		<group id="184" type="span" parent="244" relname="span"/>
		<group id="186" type="span" parent="187" relname="joint"/>
		<group id="187" type="multinuc" parent="188" relname="span"/>
		<group id="188" type="span" parent="243" relname="span"/>
		<group id="189" type="span" parent="190" relname="same-unit"/>
		<group id="190" type="multinuc" parent="192" relname="span"/>
		<group id="191" type="span" parent="193" relname="span"/>
		<group id="192" type="span" parent="191" relname="preparation"/>
		<group id="193" type="span" />
		<group id="194" type="span" parent="87" relname="elaboration"/>
		<group id="195" type="span" parent="197" relname="same-unit"/>
		<group id="196" type="span" parent="197" relname="same-unit"/>
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" />
		<group id="199" type="span" parent="246" relname="attribution"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" parent="203" relname="elaboration"/>
		<group id="203" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="247" relname="effect"/>
		<group id="207" type="span" />
		<group id="208" type="span" parent="209" relname="joint"/>
		<group id="209" type="multinuc" parent="210" relname="span"/>
		<group id="210" type="span" parent="103" relname="elaboration"/>
		<group id="211" type="span" parent="107" relname="evaluation"/>
		<group id="212" type="span" parent="213" relname="span"/>
		<group id="213" type="span" parent="214" relname="preparation"/>
		<group id="214" type="span" parent="216" relname="span"/>
		<group id="215" type="span" parent="217" relname="joint"/>
		<group id="216" type="span" parent="217" relname="joint"/>
		<group id="217" type="multinuc" parent="219" relname="span"/>
		<group id="218" type="span" parent="220" relname="span"/>
		<group id="219" type="span" parent="218" relname="elaboration"/>
		<group id="220" type="span" />
		<group id="221" type="multinuc" parent="222" relname="span"/>
		<group id="222" type="span" parent="117" relname="condition"/>
		<group id="223" type="span" />
		<group id="224" type="span" parent="225" relname="span"/>
		<group id="225" type="span" />
		<group id="226" type="span" parent="142" relname="same-unit"/>
		<group id="227" type="span" parent="136" relname="joint"/>
		<group id="228" type="span" parent="237" relname="span"/>
		<group id="230" type="span" parent="231" relname="span"/>
		<group id="231" type="span" parent="232" relname="span"/>
		<group id="232" type="span" parent="242" relname="contrast"/>
		<group id="233" type="span" parent="234" relname="span"/>
		<group id="234" type="span" />
		<group id="235" type="span" />
		<group id="236" type="span" parent="228" relname="preparation"/>
		<group id="237" type="span" />
		<group id="238" type="span" parent="239" relname="span"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" />
		<group id="241" type="span" parent="242" relname="contrast"/>
		<group id="242" type="multinuc" />
		<group id="243" type="span" />
		<group id="244" type="span" parent="187" relname="joint"/>
		<group id="245" type="multinuc" parent="246" relname="span"/>
		<group id="246" type="span" parent="247" relname="span"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" parent="249" relname="span"/>
		<group id="249" type="span" />
	</body>
</rst>