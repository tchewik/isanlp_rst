<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="64" relname="preparation">Город: В Чебоксарах состоялся первый фестиваль юношеских СМИ, фотоклубов, киностудий 2014 года</segment>
		<segment id="2" parent="63" relname="joint">Ежегодно в России и странах СНГ проходит около ста фестивалей и слетов юношеских фотоклубов, киностудий и средств массовой информации.</segment>
		<segment id="3" parent="51" relname="span">По традиции первыми принимает у себя будущих мастеров фотографии, телевидения, кино и печатных изданий – город Чебоксары,</segment>
		<segment id="4" parent="3" relname="elaboration">где ежегодно проходит два фестиваля юношеских СМИ «Волжские встречи».</segment>
		<segment id="6" parent="52" relname="span">В столицу Чувашии приехали представители 27 студий от Северодвинска до Краснодара и Пятигорска, от Калининграда до Иркутска и Читы.</segment>
		<segment id="7" parent="6" relname="elaboration">«Волжские встречи» открыли для себя представители городов Лесной (Свердловская область), Кумертау (Башкортостан), Волжска (Марий Эл) и Копейска (Челябинская область).</segment>
		<segment id="9" parent="53" relname="joint">Фестиваль поддержали Лига юных журналистов РФ, Творческое Агентство «Юнпресс» (Москва) и Всероссийский открытый форум детского и юношеского экранного творчества «Бумеранг».</segment>
		<segment id="10" parent="53" relname="joint">Вновь на высоком уровне ребят и их руководителей принимал Физкультурно-оздоровительный центр "Росинка" – один из самых комфортабельных и современных оздоровительных центров для детей.</segment>
		<segment id="12" parent="62" relname="joint">Программа мероприятия получилась насыщенной: интересные и полезные мастер-классы, деловые игры, творческая работа, неформальное общение.</segment>
		<segment id="13" parent="61" relname="span">Всем запомнились занятия по технике речи и интервью ведущего Первого канала Михаила Верещагина.</segment>
		<segment id="14" parent="58" relname="preparation">«Я учу детей и подростков культуре речи.</segment>
		<segment id="15" parent="54" relname="span">Каждому человеку необходимо разрабатывать дикцию,</segment>
		<segment id="16" parent="15" relname="evaluation">не зависимо от того, кем он хочет стать.</segment>
		<segment id="17" parent="56" relname="span">Также в современной жизни мы очень часто забываем о правильном произношении слов и ударений в них.</segment>
		<segment id="18" parent="55" relname="span">Все эти минусы можно перевести в плюсы,</segment>
		<segment id="19" parent="18" relname="condition">было бы желание»,</segment>
		<segment id="20" parent="59" relname="attribution">-  говорит Михаил Верещагин.</segment>
		<segment id="22" parent="67" relname="joint">Участники фестиваля отметили высокий уровень мастер-классов от Карины Тимошенко (ВГИК), Романа Баканова (Казанский федеральный университет) и Владимира Семенова (фотостудия «Смена»).</segment>
		<segment id="23" parent="67" relname="joint">Юные журналисты и фотографы готовили выпуски фестивальных газет, теледневников, кинофильмов и слайдшоу на заданные темы.</segment>
		<segment id="24" parent="66" relname="span">Ежедневно проходили просмотр и обсуждение фотографий, видеоработ и печатных изданий,</segment>
		<segment id="25" parent="24" relname="elaboration">которые участники привезли с собой.</segment>
		<segment id="27" parent="71" relname="span">Два дня с ребятами проводил игры известный детский психолог и тренер Марчел Паскаль из Кишинева.</segment>
		<segment id="28" parent="69" relname="sequence">В первый день участники провели дворовые игры в самом лагере «Росинка»,</segment>
		<segment id="29" parent="68" relname="span">а на второй они поехали в сельскую школу в Канашский район,</segment>
		<segment id="30" parent="29" relname="elaboration">где были организованы чувашские и русские игры для детей.</segment>
		<segment id="31" parent="70" relname="joint">Участники также узнали много нового о традициях дворовых игр.</segment>
		<segment id="32" parent="73" relname="joint">«Я посетила игру «Семь секретов общения»,</segment>
		<segment id="33" parent="72" relname="span">и мне очень понравился Марчел:</segment>
		<segment id="34" parent="33" relname="elaboration">он помог нам выразить свои эмоции.</segment>
		<segment id="35" parent="74" relname="span">После полученной травмы мне было тяжело общаться с людьми,</segment>
		<segment id="36" parent="35" relname="elaboration">я была очень замкнута,</segment>
		<segment id="37" parent="75" relname="contrast">но благодаря этому тренингу все мои страхи остались в прошлом. Большое спасибо Марчелу  Паскалю за это»,</segment>
		<segment id="38" parent="77" relname="attribution">- рассказала участница «Волжских Встреч» Наталья Мышева из Чебоксар.</segment>
		<segment id="40" parent="80" relname="span">Жизнь на фестивале не затихала ни на час!</segment>
		<segment id="41" parent="79" relname="joint">Даже ночью проходили мастер-классы по журналистике и фотографии,</segment>
		<segment id="42" parent="79" relname="joint">в пресс-центре кипела работа над дневниками и газетой «Волжских встреч»,</segment>
		<segment id="43" parent="79" relname="joint">а в 8 утра начинался новый день, полный открытий, эмоций и добрых встреч!</segment>
		<segment id="45" parent="82" relname="preparation">С 1 по 5 мая в Чебоксарах состоится основная часть Международного фестиваля юношеских СМИ, киностудий и фотоклубов «Волжские встречи-25».</segment>
		<segment id="46" parent="81" relname="joint">Столица Чувашии примет более 400 представителей юношеских редакции и студии телевидения, кино, печатных изданий и фотографии.</segment>
		<segment id="47" parent="81" relname="joint">С ребятами поделятся знаниями и опытом более 30 тренеров.</segment>
		<segment id="48" parent="81" relname="joint">Организаторы проекта готовят насыщенную программу и интересные сюрпризы!</segment>
		<segment id="50" >За 25 летнюю историю в фестивалях «Волжские встречи» приняли участие более семи тысяч человек из более тысячи редакций и студий.</segment>
		<group id="51" type="span" parent="63" relname="joint"/>
		<group id="52" type="span" />
		<group id="53" type="multinuc" />
		<group id="54" type="span" parent="57" relname="joint"/>
		<group id="55" type="span" parent="17" relname="evaluation"/>
		<group id="56" type="span" parent="57" relname="joint"/>
		<group id="57" type="multinuc" parent="58" relname="span"/>
		<group id="58" type="span" parent="59" relname="span"/>
		<group id="59" type="span" parent="60" relname="span"/>
		<group id="60" type="span" parent="13" relname="elaboration"/>
		<group id="61" type="span" parent="62" relname="joint"/>
		<group id="62" type="multinuc" />
		<group id="63" type="multinuc" parent="64" relname="span"/>
		<group id="64" type="span" parent="65" relname="span"/>
		<group id="65" type="span" />
		<group id="66" type="span" parent="67" relname="joint"/>
		<group id="67" type="multinuc" />
		<group id="68" type="span" parent="69" relname="sequence"/>
		<group id="69" type="multinuc" parent="70" relname="joint"/>
		<group id="70" type="multinuc" parent="27" relname="elaboration"/>
		<group id="71" type="span" />
		<group id="72" type="span" parent="73" relname="joint"/>
		<group id="73" type="multinuc" parent="76" relname="span"/>
		<group id="74" type="span" parent="75" relname="contrast"/>
		<group id="75" type="multinuc" parent="76" relname="elaboration"/>
		<group id="76" type="span" parent="77" relname="span"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" />
		<group id="79" type="multinuc" parent="40" relname="elaboration"/>
		<group id="80" type="span" />
		<group id="81" type="multinuc" parent="82" relname="span"/>
		<group id="82" type="span" parent="83" relname="span"/>
		<group id="83" type="span" />
	</body>
</rst>