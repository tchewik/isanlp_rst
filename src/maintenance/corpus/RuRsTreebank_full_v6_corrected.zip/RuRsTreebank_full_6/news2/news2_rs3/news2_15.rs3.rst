<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="201" relname="preparation">Культура: В память о защитниках родной земли...</segment>
		<segment id="2" parent="99" relname="span">В рыцарских доспехах, с щитами, с мечами, копьями, стрелами, боевыми топорами, с войлочными шатрами, юртами, на конях, на собачьих упряжках прибыли к нам ратники</segment>
		<segment id="3" parent="2" relname="purpose">«зачерпнуть чувашского пива шеломом»,</segment>
		<segment id="4" parent="100" relname="span">приехали</segment>
		<segment id="5" parent="97" relname="joint">добыть себе чести, предводителю Чувашского фестиваля — известному в республике ратоборцу Евгению Васильеву — славу,</segment>
		<segment id="6" parent="97" relname="joint">оказать князю четырехбашенного городища Чемень-батыра Сергею Сорокину — уважение, многочисленным зрителям из Чебоксар и окрестных районов - неописуемую радость.</segment>
		<segment id="7" parent="103" relname="concession">Ни мокрый снег, ни шаловливый ветер не смогли остановить ратоборцев.</segment>
		<segment id="8" parent="102" relname="joint">Надвигались на линию за ратью рать,</segment>
		<segment id="9" parent="102" relname="joint">сражались отряд за отрядом.</segment>
		<segment id="10" parent="104" relname="joint">Одна дружина за другой шли на защиту родной земли (то бишь - своей клубной чести),</segment>
		<segment id="11" parent="104" relname="joint">и частенько случалось так, что витязи до единого падали на поле брани.</segment>
		<segment id="12" parent="203" relname="span">Это был хорошо подготовленный, серьезный, целеустремленно-содержательный Межрегиональный VI фестиваль боевых искусств под названием «Тени наших предков».</segment>
		<segment id="13" parent="130" relname="span">Я бы назвал не тенью, а Памятью предков.</segment>
		<segment id="14" parent="132" relname="span">Это действительно добрая память и славное чествование подвигов наших пращуров.</segment>
		<segment id="15" parent="106" relname="joint">Где-то здесь, у Адылъяла на переправе через Волгу, оставил свое имя великий полководец Атилла,</segment>
		<segment id="16" parent="106" relname="joint">вошли в легенду Чурабатор и Чемень богатырь,</segment>
		<segment id="17" parent="106" relname="joint">здесь насмерть бились отряды суваро-булгар против супостатов из чингизидской орды,</segment>
		<segment id="18" parent="106" relname="joint">здесь на чувашском стане при Московско-Сибирской столбовой дороге отдыхал былинный Илья Муромец,</segment>
		<segment id="19" parent="106" relname="joint">отсюда шли на Казань полки Ивана Грозного,</segment>
		<segment id="20" parent="108" relname="span">в этих корабельных дубравах в 1722 году бродил Петр Первый.</segment>
		<segment id="21" parent="20" relname="elaboration">И оставил он на память потомкам Царский дуб, Белый мост, Казачий дол...</segment>
		<segment id="22" parent="107" relname="same-unit">Через много веков, под белыми узорами пролетающих по небу реактивных самолетов, под гул огромных автофургонов,</segment>
		<segment id="23" parent="117" relname="cause">всматриваясь на профессиональную реконструкцию средневекового рукопашного боя, в мастерство метания копья и фехтования мечом,</segment>
		<segment id="24" parent="117" relname="span">мне вспомнились давным-давно выученные наизусть строфы из «Слова о полку Игореве»:</segment>
		<segment id="25" parent="110" relname="same-unit">Есть молодцы у нас для битв</segment>
		<segment id="26" parent="110" relname="same-unit">В шеломах кованых латинских.</segment>
		<segment id="27" parent="111" relname="same-unit">Под их стопой земля дрожит</segment>
		<segment id="28" parent="111" relname="same-unit">В пределах близких и не близких.</segment>
		<segment id="29" parent="109" relname="joint">Чуть в стороне от дружин стояли,</segment>
		<segment id="30" parent="109" relname="joint">следили за боем,</segment>
		<segment id="31" parent="109" relname="joint">вскрикивали</segment>
		<segment id="32" parent="109" relname="joint">и причитали княгини в дорогих одеяниях.</segment>
		<segment id="33" parent="119" relname="contrast">Вначале думал, что артистов из театра пригласили для исторического фона,</segment>
		<segment id="34" parent="119" relname="contrast">но потом понял, что они тоже члены боевых клубов и участницы сражений.</segment>
		<segment id="35" parent="36" relname="cause">Когда одного дружинника сильно отлупили в ногу,</segment>
		<segment id="36" parent="140" relname="span">я видел, как «княгиня» успокаивала своего однополчанина с сердоболием и любовью.</segment>
		<segment id="37" parent="138" relname="preparation">Помните плач Ярославны?</segment>
		<segment id="38" parent="129" relname="span">Точно так же произошло на одной из четырех башен городища,</segment>
		<segment id="39" parent="38" relname="elaboration">названного в честь древнего предка чувашского народа царя Кубрата...</segment>
		<segment id="40" parent="125" relname="same-unit">«Ветер, ветер, почему, могучий ,</segment>
		<segment id="41" parent="125" relname="same-unit">Ты забыл старинное родство,</segment>
		<segment id="42" parent="124" relname="same-unit">Вражьих стрел зачем ты мечешь тучи</segment>
		<segment id="43" parent="124" relname="same-unit">На дружины князья моего?</segment>
		<segment id="44" parent="120" relname="contrast">После боев дружины с бранного поля ушли по своим юртам, шалашам, мастерским и кузницам на «рекогносцировку»,</segment>
		<segment id="45" parent="121" relname="span">а зрители — по 16 станам городища на обед</segment>
		<segment id="46" parent="45" relname="background">(котлы там кипели весь день!).</segment>
		<segment id="47" parent="122" relname="span">Мне показалось, что битва захлебнулась,</segment>
		<segment id="48" parent="47" relname="cause">исчерпав себя.</segment>
		<segment id="49" parent="123" relname="contrast">Оказывается, ошибся!</segment>
		<segment id="50" parent="146" relname="sequence">Боевое ристалище (большую круглую сцену) заняли мальчики и девочки разных возрастов из Чебоксарской школы ратоборцев</segment>
		<segment id="51" parent="146" relname="sequence">и стали показывать дедовские приемы боевого искусства.</segment>
		<segment id="52" parent="194" relname="span">Тут произошло невообразимое!</segment>
		<segment id="53" parent="147" relname="span">Дети, их матери</segment>
		<segment id="54" parent="53" relname="background">(отцов тут было мало),</segment>
		<segment id="55" parent="148" relname="same-unit">бабушки, дедушки птичьей стаей налетели к сцене.</segment>
		<segment id="56" parent="57" relname="attribution">Умелый организатор, ведущий фестиваля Евгений Васильев объяснял</segment>
		<segment id="57" parent="204" relname="span">сложные приемы и правила боя.</segment>
		<segment id="58" parent="150" relname="span">Первый круг боев трех пар зрители-мальчики внимали разинув рты</segment>
		<segment id="59" parent="58" relname="elaboration">(именно так — я специально следил за ними),</segment>
		<segment id="60" parent="157" relname="span">а потом сами тут же стали между собой тягаться.</segment>
		<segment id="61" parent="153" relname="contrast">У некоторых были маленькие мечи, топоры,</segment>
		<segment id="62" parent="155" relname="span">а у других — палки из леса да без щитов!</segment>
		<segment id="63" parent="62" relname="evaluation">(Щитов на фестивале, видимо, не продавали).</segment>
		<segment id="64" parent="154" relname="span">Вот думаю, будет сеча от бабушек детям, и от начальников — организаторам фестиваля,</segment>
		<segment id="65" parent="64" relname="condition">если кто-нибудь из них царапнет другого до крови.</segment>
		<segment id="66" parent="159" relname="span">Ничего подобного!</segment>
		<segment id="67" parent="66" relname="elaboration">Наши дети не хуже рыцарей чести!</segment>
		<segment id="68" parent="160" relname="contrast">Это мы, взрослые-заскорузлые, в большинстве своем с пень колоду ведем воспитание будущих воинов.</segment>
		<segment id="69" parent="196" relname="span">Восторженная радость мальчиков была полна,</segment>
		<segment id="70" parent="69" relname="background">когда десятилетний бравый Кирилл одержал победу над старшим соперником.</segment>
		<segment id="71" parent="197" relname="span">Это был живой убедительный урок,</segment>
		<segment id="72" parent="71" relname="elaboration">которого, к сожалению, нет в наших школах.</segment>
		<segment id="73" parent="185" relname="span">До темноты мерили мастерство богатыри на личном первенстве.</segment>
		<segment id="74" parent="164" relname="joint">От ударов искры летали,</segment>
		<segment id="75" parent="164" relname="joint">рукоятки мечей ломались,</segment>
		<segment id="76" parent="164" relname="joint">щепки откалывались от щитов.</segment>
		<segment id="77" parent="165" relname="evaluation">Взрослые дерутся очень дерзко, неотступно.</segment>
		<segment id="78" parent="79" relname="cause">Победив нескольких соперников,</segment>
		<segment id="79" parent="167" relname="span">вот-вот должен дружинник услышать заветное слово «победитель»,</segment>
		<segment id="80" parent="166" relname="joint">но тут выходит следующий меченосец</segment>
		<segment id="81" parent="166" relname="joint">и вышибает многократного удальца...</segment>
		<segment id="82" parent="172" relname="joint">...Храбрых воителей мирных «битв» встречал наигрышем кавала почетный краевед Николай Фомиряков,</segment>
		<segment id="83" parent="172" relname="joint">поздравили Глава Вурман-Сюктерской сельской администрации Олег Ерманов, депутат поселенческого собрания Вячеслав Спиридонов, депутат Чебоксарского районного собрания Николай Хорасев, лидеры партии пенсионеров Валерий Сапожников и Вурнарского землячества Андрей Суварин, президент Чувашской народной академии наук и искусств Евгений Ерагин и другие.</segment>
		<segment id="84" parent="173" relname="joint">Чествование победителей и участников фестиваля состоялось в Анат-Кинярской средней школе.</segment>
		<segment id="85" parent="173" relname="joint">Дипломы, награды и подарки вручили член президиума Чувашского национального конгресса Эдуард Бахмисов, председатель фонда национальной культуры «Сувар» Тимер Тяпкин, председатель Союза чувашских краеведов Сергей Сорокин.</segment>
		<segment id="86" parent="180" relname="span">Большое, благородное дело делают исторические клубы Поволжья.</segment>
		<segment id="87" parent="86" relname="cause">Их братское единство — яркий пример укрепления единой гражданственности и патриотизма многонациональной России.</segment>
		<segment id="88" parent="179" relname="span">Я слышал, что это кому-то (не без причины, конечно) не нравится...</segment>
		<segment id="89" parent="177" relname="joint">Пусть.</segment>
		<segment id="90" parent="177" relname="joint">Караван идет.</segment>
		<segment id="91" parent="174" relname="joint">Живите и не ведайте обид,</segment>
		<segment id="92" parent="174" relname="joint">Друг другу помогайте нелукаво.</segment>
		<segment id="93" parent="175" relname="same-unit">Всем, кто за землю Русскую стоит,</segment>
		<segment id="94" parent="175" relname="same-unit">Князьям и верной их дружине слава!</segment>
		<segment id="95" parent="198" relname="attribution">Это снова из «Слова о полку Игореве».</segment>
		<segment id="96" parent="199" relname="evaluation">Разве не подходит к нашему времени?</segment>
		<group id="97" type="multinuc" parent="98" relname="span"/>
		<group id="98" type="span" parent="4" relname="purpose"/>
		<group id="99" type="span" parent="101" relname="joint"/>
		<group id="100" type="span" parent="101" relname="joint"/>
		<group id="101" type="multinuc" parent="103" relname="span"/>
		<group id="102" type="multinuc" parent="136" relname="span"/>
		<group id="103" type="span" parent="133" relname="span"/>
		<group id="104" type="multinuc" parent="105" relname="span"/>
		<group id="105" type="span" parent="102" relname="joint"/>
		<group id="106" type="multinuc" parent="131" relname="span"/>
		<group id="107" type="multinuc" />
		<group id="108" type="span" parent="106" relname="joint"/>
		<group id="109" type="multinuc" parent="114" relname="span"/>
		<group id="110" type="multinuc" parent="112" relname="span"/>
		<group id="111" type="multinuc" parent="113" relname="span"/>
		<group id="112" type="span" parent="115" relname="joint"/>
		<group id="113" type="span" parent="115" relname="joint"/>
		<group id="114" type="span" parent="115" relname="joint"/>
		<group id="115" type="multinuc" parent="116" relname="span"/>
		<group id="116" type="span" parent="24" relname="elaboration"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" parent="107" relname="same-unit"/>
		<group id="119" type="multinuc" parent="142" relname="span"/>
		<group id="120" type="multinuc" parent="144" relname="span"/>
		<group id="121" type="span" parent="120" relname="contrast"/>
		<group id="122" type="span" parent="145" relname="span"/>
		<group id="123" type="multinuc" parent="143" relname="span"/>
		<group id="124" type="multinuc" parent="127" relname="span"/>
		<group id="125" type="multinuc" parent="126" relname="span"/>
		<group id="126" type="span" parent="128" relname="joint"/>
		<group id="127" type="span" parent="128" relname="joint"/>
		<group id="128" type="multinuc" parent="137" relname="span"/>
		<group id="129" type="span" parent="138" relname="span"/>
		<group id="130" type="span" parent="12" relname="evaluation"/>
		<group id="131" type="span" parent="14" relname="elaboration"/>
		<group id="132" type="span" parent="13" relname="evidence"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" parent="135" relname="joint"/>
		<group id="135" type="multinuc" parent="201" relname="span"/>
		<group id="136" type="span" parent="135" relname="joint"/>
		<group id="137" type="span" parent="129" relname="elaboration"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="140" relname="elaboration"/>
		<group id="140" type="span" parent="141" relname="span"/>
		<group id="141" type="span" parent="142" relname="evidence"/>
		<group id="142" type="span" />
		<group id="143" type="span" />
		<group id="144" type="span" parent="122" relname="cause"/>
		<group id="145" type="span" parent="123" relname="contrast"/>
		<group id="146" type="multinuc" parent="195" relname="span"/>
		<group id="147" type="span" parent="149" relname="span"/>
		<group id="148" type="multinuc" parent="158" relname="span"/>
		<group id="149" type="span" parent="148" relname="same-unit"/>
		<group id="150" type="span" parent="151" relname="span"/>
		<group id="151" type="span" parent="152" relname="sequence"/>
		<group id="152" type="multinuc" parent="187" relname="span"/>
		<group id="153" type="multinuc" parent="156" relname="span"/>
		<group id="154" type="span" parent="161" relname="span"/>
		<group id="155" type="span" parent="153" relname="contrast"/>
		<group id="156" type="span" parent="60" relname="background"/>
		<group id="157" type="span" parent="152" relname="sequence"/>
		<group id="158" type="span" parent="191" relname="joint"/>
		<group id="159" type="span" parent="160" relname="contrast"/>
		<group id="160" type="multinuc" parent="163" relname="span"/>
		<group id="161" type="span" parent="162" relname="contrast"/>
		<group id="162" type="multinuc" parent="188" relname="span"/>
		<group id="163" type="span" parent="162" relname="contrast"/>
		<group id="164" type="multinuc" parent="165" relname="span"/>
		<group id="165" type="span" parent="171" relname="span"/>
		<group id="166" type="multinuc" parent="168" relname="span"/>
		<group id="167" type="span" parent="169" relname="span"/>
		<group id="168" type="span" parent="170" relname="contrast"/>
		<group id="169" type="span" parent="170" relname="contrast"/>
		<group id="170" type="multinuc" parent="184" relname="span"/>
		<group id="171" type="span" parent="183" relname="span"/>
		<group id="172" type="multinuc" parent="182" relname="span"/>
		<group id="173" type="multinuc" />
		<group id="174" type="multinuc" parent="198" relname="span"/>
		<group id="175" type="multinuc" parent="176" relname="span"/>
		<group id="176" type="span" parent="174" relname="joint"/>
		<group id="177" type="multinuc" parent="178" relname="span"/>
		<group id="178" type="span" parent="88" relname="solutionhood"/>
		<group id="179" type="span" parent="181" relname="contrast"/>
		<group id="180" type="span" parent="181" relname="contrast"/>
		<group id="181" type="multinuc" />
		<group id="182" type="span" parent="173" relname="joint"/>
		<group id="183" type="span" parent="73" relname="elaboration"/>
		<group id="184" type="span" parent="185" relname="elaboration"/>
		<group id="185" type="span" parent="186" relname="span"/>
		<group id="186" type="span" />
		<group id="187" type="span" parent="189" relname="span"/>
		<group id="188" type="span" parent="187" relname="evaluation"/>
		<group id="189" type="span" parent="192" relname="span"/>
		<group id="190" type="span" parent="189" relname="elaboration"/>
		<group id="191" type="multinuc" parent="193" relname="span"/>
		<group id="192" type="span" parent="191" relname="joint"/>
		<group id="193" type="span" parent="52" relname="elaboration"/>
		<group id="194" type="span" parent="146" relname="sequence"/>
		<group id="195" type="span" />
		<group id="196" type="span" parent="190" relname="span"/>
		<group id="197" type="span" parent="196" relname="conclusion"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="177" relname="joint"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" parent="203" relname="preparation"/>
		<group id="203" type="span" />
		<group id="204" type="span" parent="191" relname="joint"/>
	</body>
</rst>