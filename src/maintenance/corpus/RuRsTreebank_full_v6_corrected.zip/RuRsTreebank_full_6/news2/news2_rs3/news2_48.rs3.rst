<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="241" relname="preparation">Конфликт Эр-Рияда и Тегерана может замедлить процесс мирного диалога на Ближнем Востоке</segment>
		<segment id="2" parent="226" relname="span">Дипломатический скандал между Саудовской Аравией и Исламской республикой Иран (ИРИ),</segment>
		<segment id="3" parent="225" relname="joint">спровоцированный казнью шиитского проповедника Нимра ан-Нимра (Nimr al-Nimr)</segment>
		<segment id="4" parent="225" relname="joint">и последовавшими вслед за этим атаками на посольство и консульство Эр-Рияда в двух городах,</segment>
		<segment id="5" parent="227" relname="same-unit">стал главной темой экстренного заседания Лиги арабских государств (ЛАГ) на уровне глав МИД, состоявшегося 10 января 2016 года.</segment>
		<segment id="6" parent="228" relname="span">В ходе встречи в Каире,</segment>
		<segment id="7" parent="6" relname="elaboration">инициированной саудовской стороной,</segment>
		<segment id="8" parent="230" relname="span">министры иностранных дел стран ЛАГ осудили Иран</segment>
		<segment id="9" parent="233" relname="cause">за нападения на дипмиссии и вмешательство в дела ближневосточных государств.</segment>
		<segment id="10" parent="231" relname="span">При этом Ливан,</segment>
		<segment id="11" parent="10" relname="elaboration">где шиитское движение является сильным,</segment>
		<segment id="12" parent="232" relname="same-unit">отказался поддержать заявление</segment>
		<segment id="13" parent="234" relname="cause">из-за обвинений организации "Хезболла" в террористической деятельности в ряде стран, в том числе в Сирии и Бахрейне.</segment>
		<segment id="14" parent="420" relname="span">За день до этого, 9 января, с похожим заявлением выступили главы МИД стран Совета сотрудничества арабских государств Персидского залива,</segment>
		<segment id="15" parent="418" relname="attribution">которые также объявили</segment>
		<segment id="16" parent="418" relname="span">о готовности предпринять дополнительные меры</segment>
		<segment id="17" parent="16" relname="condition">в случае враждебных действий со стороны Ирана.</segment>
		<segment id="18" parent="243" relname="span">Взаимоотношения между Эр-Риядом и Тегераном резко ухудшились</segment>
		<segment id="19" parent="421" relname="attribution">после того, как 2 января 2016 года Саудовская Аравия объявила</segment>
		<segment id="20" parent="421" relname="span">об исполнении смертного приговора в отношении 47 человек,</segment>
		<segment id="21" parent="20" relname="elaboration">осужденных за терроризм.</segment>
		<segment id="22" parent="244" relname="span">Среди казненных оказался и шиитский проповедник Нимр ан-Нимр,</segment>
		<segment id="23" parent="238" relname="span">приговоренный к высшей мере наказания в 2014 году</segment>
		<segment id="24" parent="23" relname="cause">за разжигание розни и расшатывание национального единства.</segment>
		<segment id="25" parent="252" relname="elaboration">Действия саудитов вызвали жесткую критику со стороны высокопоставленных представителей Ирана, Ирака и Сирии, а также главы внешнеполитической службы Евросоюза Федерики Могерини (Federica Mogherini) и омбудсмена ФРГ Кристофа Штрессера (Christoph Straesser).</segment>
		<segment id="26" parent="27" relname="attribution">3 января Эр-Рияд объявил</segment>
		<segment id="27" parent="248" relname="span">о прекращении дипломатических отношений с Ираном.</segment>
		<segment id="28" parent="246" relname="span">Поводом для этого стали ночные беспорядки у здания посольства Саудовской Аравии в Тегеране,</segment>
		<segment id="29" parent="245" relname="joint">когда демонстранты ворвались на территорию диппредставительства,</segment>
		<segment id="30" parent="245" relname="joint">разгромили</segment>
		<segment id="31" parent="245" relname="joint">и подожгли его.</segment>
		<segment id="32" parent="247" relname="joint">Одновременно нападению подверглось и консульство Эр-Рияда во втором по величине иранском городе - Мешхеде.</segment>
		<segment id="33" parent="249" relname="comparison">Из солидарности с Эр-Риядом - одним из лидеров арабского суннитского мира - дипломатические отношения с Ираном прекратили Бахрейн, Судан, Сомали и Джибути,</segment>
		<segment id="34" parent="249" relname="comparison">а Кувейт, Катар и ОАЭ понизили уровень дипотношений до уровня поверенного в делах.</segment>
		<segment id="35" >При этом кризис в отношениях двух стран затронул не только дипломатическую сферу.</segment>
		<segment id="36" parent="37" relname="attribution">Так, Эр-Рияд и его союзники заявили</segment>
		<segment id="37" parent="423" relname="span">о планах бойкотировать иранскую продукцию,</segment>
		<segment id="38" parent="253" relname="sequence">а 5 января один из богатейших людей в мире принц аль-Валид ибн Талал ибн Абдель Азиз аль-Сауд (Al-Waleed bin Talal bin Abdulaziz Al-Saud) отказался от инвестиций в ИРИ.</segment>
		<segment id="39" parent="40" relname="attribution">В качестве ответных мер правительство Тегерана 7 января объявило</segment>
		<segment id="40" parent="254" relname="span">о разрыве торговых связей с саудитами,</segment>
		<segment id="41" parent="255" relname="joint">ограничило импорт продукции из стран, поддержавших казнь Нимра ан-Нимра,</segment>
		<segment id="42" parent="255" relname="joint">и продлило запрет для иранцев на совершение малого паломничества в Мекку.</segment>
		<segment id="43" parent="424" relname="attribution">В то же время обе стороны заявили</segment>
		<segment id="44" parent="424" relname="span">о намерениях продолжить участие в межсирийских переговорах по урегулированию ситуации</segment>
		<segment id="45" parent="44" relname="elaboration">- ближайшие должны начаться в Женеве в понедельник, 25 января.</segment>
		<segment id="46" parent="47" relname="attribution">Тем не менее ряд политиков, обозревателей и экспертов по всему миру опасаются,</segment>
		<segment id="47" parent="260" relname="span">что разрыв дипотношений между странами может привести к очередному росту напряженности на Ближнем Востоке.</segment>
		<segment id="48" parent="257" relname="attribution">По их мнению,</segment>
		<segment id="49" parent="257" relname="span">недавние события затруднят поиск мирного решения конфликтов не только в Ираке и Сирии, но и в Йемене,</segment>
		<segment id="50" parent="49" relname="elaboration">где 2 января, в день казни Нимра ан-Нимра, было объявлено об окончании режима прекращения огня.</segment>
		<segment id="51" parent="259" relname="attribution">В частности, работающий в Лондоне обозреватель, политолог, эксперт по Ираку, Турции, Сирии и Ближнему Востоку Башдар Исмаил (Bashdar Ismaeel) высказал предположение,</segment>
		<segment id="52" parent="258" relname="joint">что рискованные действия Эр-Рияда и его союзников раскололи арабский мир на два лагеря</segment>
		<segment id="53" parent="258" relname="joint">и усугубили давние противоречия между суннитами и шиитами.</segment>
		<segment id="54" parent="263" relname="joint">"Саудиты хотели не только послать Ирану вполне определенный сигнал,</segment>
		<segment id="55" parent="263" relname="joint">но и показать, что у них есть друзья в регионе.</segment>
		<segment id="56" parent="264" relname="evaluation">Несомненно, Эр-Рияд - крупный и весьма влиятельный игрок на Ближнем Востоке",</segment>
		<segment id="57" parent="265" relname="attribution">- пояснил эксперт в интервью ИА "PenzaNews".</segment>
		<segment id="58" parent="59" relname="attribution">С его точки зрения,</segment>
		<segment id="59" parent="283" relname="span">власти Саудовской Аравии пошли на столь смелый шаг</segment>
		<segment id="60" parent="59" relname="purpose">с целью предотвращения дальнейшей агрессии в отношении своих интересов, в том числе и в горячих точках Ближнего Востока.</segment>
		<segment id="61" parent="270" relname="contrast">"Трения между двумя странами возникали уже не раз.</segment>
		<segment id="62" parent="268" relname="span">Однако за 10 лет подковерная борьба Саудовской Аравии и Ирана</segment>
		<segment id="63" parent="62" relname="cause">за власть в Ираке, Сирии, в регионе в целом</segment>
		<segment id="64" parent="269" relname="same-unit">заметно обострилась.</segment>
		<segment id="65" parent="272" relname="elaboration">[&hellip;] Они открыто противостоят друг другу в Сирии.</segment>
		<segment id="66" parent="275" relname="span">Аналогичная ситуация и в Йемене,</segment>
		<segment id="67" parent="271" relname="span">где саудиты наносят авиаудары по позициям повстанцев-хуситов,</segment>
		<segment id="68" parent="67" relname="elaboration">спонсируемых ИРИ.</segment>
		<segment id="69" parent="278" relname="comparison">За последние годы Тегеран успешно продемонстрировал свое влияние в регионе.</segment>
		<segment id="70" parent="276" relname="span">В Эр-Рияде также приложили немало усилий,</segment>
		<segment id="71" parent="70" relname="purpose">чтобы сохранить свои позиции.</segment>
		<segment id="72" parent="277" relname="comparison">Саудиты настроены очень решительно</segment>
		<segment id="73" parent="277" relname="comparison">и намерены показать Ирану, что готовы ответить не только словом, но и делом",</segment>
		<segment id="74" parent="281" relname="attribution">- сказал Башдар Исмаил.</segment>
		<segment id="75" parent="284" relname="attribution">С его точки зрения,</segment>
		<segment id="76" parent="284" relname="span">дипломатический конфликт требует скорейшего урегулирования,</segment>
		<segment id="77" parent="76" relname="elaboration">в чем напрямую заинтересованы Россия, США и другие страны.</segment>
		<segment id="78" parent="286" relname="span">"Думаю, Россия и союзники будут играть в этом вопросе очень большую роль.</segment>
		<segment id="79" parent="285" relname="joint">На сегодняшний день Москва является ключевой фигурой на Ближнем Востоке - особенно по сирийскому вопросу.</segment>
		<segment id="80" parent="285" relname="joint">Кроме того, РФ поддерживает хорошие отношения с большинством стран арабского мира",</segment>
		<segment id="81" parent="286" relname="attribution">- заметил обозреватель.</segment>
		<segment id="82" parent="83" relname="attribution">В то же время политический консультант, эксперт по Ближнему Востоку и странам Персидского залива, старший исследователь Центра исламских исследований имени короля Фейсала в Эр-Рияде Джозеф Кечичиан (Joseph Kechichian) высказал мнение,</segment>
		<segment id="83" parent="292" relname="span">что конфликт между Ираном и Саудовской Аравией продлится не менее нескольких месяцев.</segment>
		<segment id="84" parent="289" relname="span">"Сейчас настал период спокойствия,</segment>
		<segment id="85" parent="84" relname="evaluation">который, скорее всего, пойдет всем на пользу.</segment>
		<segment id="86" parent="290" relname="span">Обе страны возьмут паузу,</segment>
		<segment id="87" parent="86" relname="purpose">чтобы разобраться в произошедшем",</segment>
		<segment id="88" parent="291" relname="attribution">- пояснил политолог.</segment>
		<segment id="89" parent="296" relname="attribution">Он напомнил,</segment>
		<segment id="90" parent="294" relname="joint">что Тегеран и Эр-Рияд были</segment>
		<segment id="91" parent="294" relname="joint">и останутся соседями,</segment>
		<segment id="92" parent="295" relname="span">а потому их взаимные контакты через некоторое время вновь будут возобновлены</segment>
		<segment id="93" parent="92" relname="condition">при содействии других стран региона.</segment>
		<segment id="94" parent="297" relname="joint">"Они от природы не враги друг другу,</segment>
		<segment id="95" parent="297" relname="joint">у них немало общего,</segment>
		<segment id="96" parent="298" relname="concession">хотя их взгляды по целому ряду вопросов сильно разнятся",</segment>
		<segment id="97" parent="302" relname="span">- сказал исследователь,</segment>
		<segment id="98" parent="300" relname="span">подчеркнув при этом, что инициатива Саудовской Аравии разорвать дипломатические отношения</segment>
		<segment id="99" parent="299" relname="span">обусловлена исключительно атаками на диппредставительства,</segment>
		<segment id="100" parent="99" relname="elaboration">которые Эр-Рияд расценивает как вмешательство в свои внутренние дела.</segment>
		<segment id="101" parent="102" relname="attribution">"Власти государства пришли к мнению,</segment>
		<segment id="102" parent="303" relname="span">что данное решение будет наилучшим шагом в интересах страны на текущий момент",</segment>
		<segment id="103" parent="104" relname="attribution">- подчеркнул Джозеф Кечичиан,</segment>
		<segment id="104" parent="428" relname="span">добавив, что в Эр-Рияде понимают возможные негативные последствия для мирных процессов по Сирии, Йемену и Ираку.</segment>
		<segment id="105" parent="311" relname="attribution">Вместе с тем иранист, исследователь французского Института международных и стратегических отношений Тьерри Ковий (Thierry Coville) предположил,</segment>
		<segment id="106" parent="311" relname="span">что нападения на посольство Саудовской Аравии в Тегеране и консульство в Мешхеде могли быть внутренней провокацией,</segment>
		<segment id="107" parent="106" relname="elaboration">направленной против действующей власти.</segment>
		<segment id="108" parent="430" relname="cause">"Иранское политическое сообщество практические единогласно осудило их.</segment>
		<segment id="109" parent="429" relname="cause">[&hellip;] Я предполагаю,</segment>
		<segment id="110" parent="429" relname="span">что эти атаки могли быть организованы какими-то экстремистами,</segment>
		<segment id="111" parent="312" relname="joint">которые, вероятно, недовольны раскладом сил в Иране</segment>
		<segment id="112" parent="312" relname="joint">и захотели усложнить задачу нынешнему правительству в преддверии февральских парламентских выборов",</segment>
		<segment id="113" parent="431" relname="attribution">- пояснил эксперт.</segment>
		<segment id="114" parent="317" relname="attribution">Говоря об истории взаимоотношений между двумя странами, он напомнил,</segment>
		<segment id="115" parent="317" relname="span">что в конце XX века Иран в годы правления президента Али Акбара Хашеми Рафсанджани (Ali Akbar Hashemi Rafsanjani) выстроил качественно новые конструктивные отношения с Эр-Риядом,</segment>
		<segment id="116" parent="115" relname="elaboration">которые сохранялись несколько лет.</segment>
		<segment id="117" parent="319" relname="span">"Думаю, нынешняя полоса напряженности берет начало в 2003 году,</segment>
		<segment id="118" parent="318" relname="joint">когда в Ираке был свергнут президент Саддам Хусейн (Saddam Hussein)</segment>
		<segment id="119" parent="318" relname="joint">и к власти пришло шиитское правительство.</segment>
		<segment id="120" parent="320" relname="joint">С тех пор саудиты стали абсолютно одержимы иранской угрозой",</segment>
		<segment id="121" parent="321" relname="attribution">- сказал исследователь.</segment>
		<segment id="122" parent="326" relname="attribution">С его точки зрения,</segment>
		<segment id="123" parent="324" relname="joint">нынешний курс Эр-Рияда на нагнетание напряженности против Ирана и всего шиитского сообщества в целом является крайне опасной стратегией</segment>
		<segment id="124" parent="325" relname="span">и создает прецедент для таких террористических группировок, как "Исламское государство" (ИГ, в арабском варианте - ДАИШ;</segment>
		<segment id="125" parent="124" relname="elaboration">группировка запрещена в России).</segment>
		<segment id="126" parent="127" relname="attribution">"Я не собираюсь утверждать,</segment>
		<segment id="127" parent="433" relname="span">что у Ирана нет планов в регионе,</segment>
		<segment id="128" parent="327" relname="span">однако Тегеран вовсе не делает акцент на религиозном противостоянии.</segment>
		<segment id="129" parent="130" relname="attribution">[&hellip;] По моему мнению,</segment>
		<segment id="130" parent="328" relname="span">необходимо вернуться к прежней дипломатии.</segment>
		<segment id="131" parent="328" relname="cause">Ведь шииты и сунниты долгое время жили в мире на Ближнем Востоке",</segment>
		<segment id="132" parent="332" relname="span">- напомнил эксперт,</segment>
		<segment id="133" parent="330" relname="same-unit">добавив, что ряд арабских государств, таких как ОАЭ,</segment>
		<segment id="134" parent="135" relname="concession">невзирая на противоречия,</segment>
		<segment id="135" parent="331" relname="span">продолжают поддерживать тесные экономические связи с Тегераном.</segment>
		<segment id="136" parent="335" relname="attribution">В свою очередь директор Центра проблем трансформации политических систем и культур факультета мировой политики МГУ, научный сотрудник Института востоковедения РАН, эксперт Российского совета по международным делам (РСМД) Василий Кузнецов (Vasily Kuznetsov) усомнился в том,</segment>
		<segment id="137" parent="138" relname="cause">что сам по себе разрыв дипломатических отношений</segment>
		<segment id="138" parent="335" relname="span">приведет к каким-либо значительным глобальным последствиям.</segment>
		<segment id="139" parent="338" relname="span">"Я бы просто рассматривал этот эпизод как один из элементов в общем движении стран и регионов к усилению ирано-саудовской конфронтации.</segment>
		<segment id="140" parent="336" relname="contrast">Я думаю, что она будет усиливаться в политической сфере, экономической, военной, в тех конфликтах, где Иран и Саудовская Аравия уже прямо или косвенно присутствуют, в Сирии и в Ираке.</segment>
		<segment id="141" parent="142" relname="cause">Но я не думаю, что эта конфликтность</segment>
		<segment id="142" parent="337" relname="span">выльется в прямое вооруженное противостояние",</segment>
		<segment id="143" parent="338" relname="attribution">- заметил эксперт.</segment>
		<segment id="144" parent="341" relname="attribution">Он пояснил,</segment>
		<segment id="145" parent="339" relname="span">что казнь проповедника Нимра ан-Нимра,</segment>
		<segment id="146" parent="145" relname="elaboration">который стал символом шиитского меньшинства в Саудовской Аравии,</segment>
		<segment id="147" parent="340" relname="same-unit">свидетельствует о переходе Эр-Рияда к более жесткой политике в отношении оппозиции внутри страны.</segment>
		<segment id="148" parent="348" relname="span">"Я думаю, что это связано с двумя факторами.</segment>
		<segment id="149" parent="346" relname="span">Во-первых, экономический - общее ухудшение экономической ситуации в королевстве, которое есть.</segment>
		<segment id="150" parent="342" relname="contrast">Его не надо переоценивать,</segment>
		<segment id="151" parent="342" relname="contrast">но оно тем не менее существует.</segment>
		<segment id="152" parent="343" relname="joint">[&hellip;] С другой стороны, внутри королевства есть борьба за власть между разными группами принцев,</segment>
		<segment id="153" parent="344" relname="same-unit">и существует такая точка зрения:</segment>
		<segment id="154" parent="155" relname="purpose">чтобы не допустить роста протестности,</segment>
		<segment id="155" parent="345" relname="span">сейчас надо очень жестко задавить любые попытки",</segment>
		<segment id="156" parent="348" relname="attribution">- подчеркнул Василий Кузнецов.</segment>
		<segment id="157" parent="158" relname="attribution">Вместе с тем он выразил уверенность в том,</segment>
		<segment id="158" parent="437" relname="span">что дипломатические отношения Ирана и Саудовской Аравии все же будут восстановлены при участии России, США и других государств.</segment>
		<segment id="159" parent="353" relname="span">"Но проблема не в дипотношениях:</segment>
		<segment id="160" parent="159" relname="elaboration">существует фундаментальная проблема глубокого недоверия двух стран друг к другу, соперничества между ними, разного прочтения региональной ситуации.</segment>
		<segment id="161" parent="354" relname="span">[&hellip;] И в той, и в другой стране должно измениться понимание ситуации,</segment>
		<segment id="162" parent="161" relname="concession">но в ближайшей перспективе возможности для такого изменения не очень просматриваются",</segment>
		<segment id="163" parent="355" relname="attribution">- уточнил представитель РСМД.</segment>
		<segment id="164" parent="358" relname="attribution">В то же время научный сотрудник Иракского института стратегических исследований в Бейруте, эксперт Ближневосточного центра Карнеги Ренад Мансур (Renad Mansour) отметил,</segment>
		<segment id="165" parent="358" relname="span">что Иран и Саудовская Аравия не могут стать полноценными союзниками,</segment>
		<segment id="166" parent="357" relname="span">поскольку нуждаются во взаимной вражде</segment>
		<segment id="167" parent="166" relname="purpose">для существования.</segment>
		<segment id="168" parent="359" relname="span">"Разрыв дипотношений</segment>
		<segment id="169" parent="168" relname="cause">из-за протестов и сожженного посольства</segment>
		<segment id="170" parent="359" relname="evaluation">с многих точек зрения кажется чрезмерным шагом.</segment>
		<segment id="171" parent="361" relname="span">Однако этот случай отлично демонстрирует ту напряженность между ними, которая присутствует уже значительное время",</segment>
		<segment id="172" parent="361" relname="attribution">- сказал эксперт.</segment>
		<segment id="173" parent="362" relname="attribution">Вместе с тем он предположил,</segment>
		<segment id="174" parent="362" relname="span">что казнь шиитского богослова Нимра ан-Нимра могла быть попыткой саудовских властей отвлечь внимание от казни радикальных исламистов суннитского толка,</segment>
		<segment id="175" parent="174" relname="elaboration">которым сопереживает определенная часть населения страны.</segment>
		<segment id="176" parent="363" relname="span">"Эр-Рияд нуждается в межконфессиональной напряженности,</segment>
		<segment id="177" parent="176" relname="purpose">чтобы оставаться у власти.</segment>
		<segment id="178" parent="179" relname="condition">Создавая образ внешней угрозы со стороны Ирана, шиитов и шиитской экспансии,</segment>
		<segment id="179" parent="364" relname="span">они получают поддержку суннитского большинства в стране",</segment>
		<segment id="180" parent="365" relname="attribution">- пояснил Ренад Мансур.</segment>
		<segment id="181" parent="367" relname="attribution">По его мнению,</segment>
		<segment id="182" parent="366" relname="contrast">холодная война между суннитами и шиитами не грозит перейти в прямое столкновение на религиозной почве,</segment>
		<segment id="183" parent="366" relname="contrast">однако мирный процесс в Сирии, Йемене и Ираке рискует затянуться.</segment>
		<segment id="184" parent="372" relname="contrast">"Разрыв дипломатических связей означает прекращение взаимных контактов,</segment>
		<segment id="185" parent="371" relname="same-unit">а прошлый опыт показывает,</segment>
		<segment id="186" parent="368" relname="concession">что даже если одна сторона в чем-то не согласна с другой,</segment>
		<segment id="187" parent="368" relname="span">нужно все равно поддерживать диалог</segment>
		<segment id="188" parent="370" relname="joint">- просто для того, чтобы знать</segment>
		<segment id="189" parent="370" relname="joint">и понимать оппонента",</segment>
		<segment id="190" parent="373" relname="attribution">- подчеркнул научный сотрудник Иракского института стратегических исследований.</segment>
		<segment id="191" parent="380" relname="attribution">В свою очередь эксперт по Ближнему востоку, глава катарского отделения британского Королевского объединенного института оборонных исследований Майкл Стивенс (Michael Stephens) предположил,</segment>
		<segment id="192" parent="380" relname="span">что Эр-Рияд неудачно выбрал время,</segment>
		<segment id="193" parent="192" relname="purpose">чтобы привести в исполнение приговор шиитскому проповеднику.</segment>
		<segment id="194" parent="381" relname="contrast">"Они хотели послать определенный сигнал Западу и собственному населению.</segment>
		<segment id="195" parent="381" relname="contrast">[&hellip;]Однако в текущей политической обстановке решение казнить богослова-шиита в любом случае было бы воспринято очень плохо",</segment>
		<segment id="196" parent="197" relname="attribution">- пояснил эксперт,</segment>
		<segment id="197" parent="439" relname="span">добавив, что Нимр ан-Нимр за годы судебного процесса успел стать значимой фигурой для шиитов.</segment>
		<segment id="198" parent="387" relname="attribution">Говоря о нападениях на диппредставительства в Иране, он напомнил</segment>
		<segment id="199" parent="386" relname="span">об аналогичном инциденте 29 ноября 2011 года,</segment>
		<segment id="200" parent="199" relname="elaboration">когда группа радикалов разгромила посольство Великобритании в Тегеране после введения нового пакета санкций,</segment>
		<segment id="201" parent="387" relname="span">в ответ на что от иранских дипломатов потребовали незамедлительно покинуть Лондон.</segment>
		<segment id="202" parent="401" relname="span">"Действия демонстрантов [в ночь на 3 января 2016 года] являются явным нарушением Венской конвенции о дипломатических сношениях 1961 года",</segment>
		<segment id="203" parent="202" relname="attribution">- сказал Майкл Стивенс.</segment>
		<segment id="204" parent="388" relname="attribution">По его мнению,</segment>
		<segment id="205" parent="388" relname="span">агрессивная реакция иранского сообщества и жесткие ответные меры Эр-Рияда</segment>
		<segment id="206" parent="205" relname="cause">обусловлены тем, что при текущей степени напряженности ни одна сторона не хочет показаться слабой.</segment>
		<segment id="207" parent="391" relname="attribution">С точки зрения аналитика,</segment>
		<segment id="208" parent="389" relname="span">рост напряженности</segment>
		<segment id="209" parent="208" relname="cause">из-за разрыва дипотношений</segment>
		<segment id="210" parent="390" relname="same-unit">может усугубить не только конфликты в арабском мире, но и европейский миграционный кризис.</segment>
		<segment id="211" parent="393" relname="span">"Вероятнее всего, именно России и США придется приложить здесь наибольшие усилия.</segment>
		<segment id="212" parent="392" relname="span">Думаю, это единственные страны, у которых достаточно дипломатического влияния в регионе,</segment>
		<segment id="213" parent="212" relname="elaboration">чтобы заставить Эр-Рияд и Тегеран пойти на уступки",</segment>
		<segment id="214" parent="397" relname="attribution">- отметил он,</segment>
		<segment id="215" parent="397" relname="span">добавив, что решение Вашингтона дистанцироваться от проблем на Ближнем Востоке</segment>
		<segment id="216" parent="215" relname="evaluation">пока только усугубило ситуацию.</segment>
		<segment id="217" parent="411" relname="span">Кроме того, Майкл Стивенс призвал ООН, а также политиков Запада и Востока активизировать и конкретизировать многосторонний диалог по Йемену и Сирии,</segment>
		<segment id="218" parent="395" relname="joint">чтобы остановить военные действия</segment>
		<segment id="219" parent="396" relname="span">и воспользоваться этим</segment>
		<segment id="220" parent="219" relname="purpose">для долгосрочной нормализации отношений между Саудовской Аравией и Ираном.</segment>
		<segment id="221" parent="399" relname="restatement">"Несомненно, разрыв дипотношений никак не поможет решению существующих проблем в арабском мире.</segment>
		<segment id="222" parent="223" relname="cause">Сейчас очень непростое время, много конфликтов,</segment>
		<segment id="223" parent="398" relname="span">и крайне важно, чтобы все сближались, а не расходились",</segment>
		<segment id="224" parent="400" relname="attribution">- подчеркнул эксперт.</segment>
		<group id="225" type="multinuc" parent="2" relname="cause"/>
		<group id="226" type="span" parent="227" relname="same-unit"/>
		<group id="227" type="multinuc" parent="241" relname="span"/>
		<group id="228" type="span" parent="229" relname="same-unit"/>
		<group id="229" type="multinuc" parent="233" relname="span"/>
		<group id="230" type="span" parent="229" relname="same-unit"/>
		<group id="231" type="span" parent="232" relname="same-unit"/>
		<group id="232" type="multinuc" parent="234" relname="span"/>
		<group id="233" type="span" parent="239" relname="span"/>
		<group id="234" type="span" parent="240" relname="span"/>
		<group id="238" type="span" parent="22" relname="elaboration"/>
		<group id="239" type="span" parent="242" relname="joint"/>
		<group id="240" type="span" parent="242" relname="joint"/>
		<group id="241" type="span" />
		<group id="242" type="multinuc" parent="241" relname="elaboration"/>
		<group id="243" type="span" parent="252" relname="span"/>
		<group id="244" type="span" parent="243" relname="elaboration"/>
		<group id="245" type="multinuc" parent="28" relname="elaboration"/>
		<group id="246" type="span" parent="247" relname="joint"/>
		<group id="247" type="multinuc" parent="248" relname="cause"/>
		<group id="248" type="span" parent="250" relname="span"/>
		<group id="249" type="multinuc" parent="251" relname="joint"/>
		<group id="250" type="span" parent="251" relname="joint"/>
		<group id="251" type="multinuc" />
		<group id="252" type="span" />
		<group id="253" type="multinuc" parent="256" relname="sequence"/>
		<group id="254" type="span" parent="255" relname="joint"/>
		<group id="255" type="multinuc" parent="256" relname="sequence"/>
		<group id="256" type="multinuc" parent="35" relname="elaboration"/>
		<group id="257" type="span" parent="261" relname="span"/>
		<group id="258" type="multinuc" parent="259" relname="span"/>
		<group id="259" type="span" parent="266" relname="span"/>
		<group id="260" type="span" parent="426" relname="span"/>
		<group id="261" type="span" parent="260" relname="elaboration"/>
		<group id="263" type="multinuc" parent="264" relname="span"/>
		<group id="264" type="span" parent="265" relname="span"/>
		<group id="265" type="span" parent="267" relname="span"/>
		<group id="266" type="span" parent="282" relname="span"/>
		<group id="267" type="span" parent="266" relname="elaboration"/>
		<group id="268" type="span" parent="269" relname="same-unit"/>
		<group id="269" type="multinuc" parent="270" relname="contrast"/>
		<group id="270" type="multinuc" parent="272" relname="span"/>
		<group id="271" type="span" parent="66" relname="elaboration"/>
		<group id="272" type="span" parent="273" relname="span"/>
		<group id="273" type="span" parent="274" relname="comparison"/>
		<group id="274" type="multinuc" parent="280" relname="span"/>
		<group id="275" type="span" parent="274" relname="comparison"/>
		<group id="276" type="span" parent="279" relname="span"/>
		<group id="277" type="multinuc" parent="276" relname="elaboration"/>
		<group id="278" type="multinuc" parent="280" relname="evaluation"/>
		<group id="279" type="span" parent="278" relname="comparison"/>
		<group id="280" type="span" parent="281" relname="span"/>
		<group id="281" type="span" />
		<group id="282" type="span" />
		<group id="283" type="span" parent="282" relname="evaluation"/>
		<group id="284" type="span" parent="288" relname="span"/>
		<group id="285" type="multinuc" parent="78" relname="cause"/>
		<group id="286" type="span" parent="287" relname="span"/>
		<group id="287" type="span" parent="288" relname="elaboration"/>
		<group id="288" type="span" />
		<group id="289" type="span" parent="291" relname="span"/>
		<group id="290" type="span" parent="289" relname="elaboration"/>
		<group id="291" type="span" parent="293" relname="span"/>
		<group id="292" type="span" parent="309" relname="span"/>
		<group id="293" type="span" parent="292" relname="elaboration"/>
		<group id="294" type="multinuc" parent="295" relname="cause"/>
		<group id="295" type="span" parent="296" relname="span"/>
		<group id="296" type="span" parent="307" relname="span"/>
		<group id="297" type="multinuc" parent="298" relname="span"/>
		<group id="298" type="span" parent="301" relname="span"/>
		<group id="299" type="span" parent="98" relname="cause"/>
		<group id="300" type="span" parent="427" relname="span"/>
		<group id="301" type="span" parent="305" relname="span"/>
		<group id="302" type="span" parent="300" relname="attribution"/>
		<group id="303" type="span" parent="306" relname="span"/>
		<group id="305" type="span" parent="308" relname="span"/>
		<group id="306" type="span" parent="305" relname="elaboration"/>
		<group id="307" type="span" parent="310" relname="span"/>
		<group id="308" type="span" parent="307" relname="elaboration"/>
		<group id="309" type="span" />
		<group id="310" type="span" parent="309" relname="cause"/>
		<group id="311" type="span" parent="315" relname="span"/>
		<group id="312" type="multinuc" parent="110" relname="elaboration"/>
		<group id="315" type="span" />
		<group id="317" type="span" parent="323" relname="span"/>
		<group id="318" type="multinuc" parent="117" relname="elaboration"/>
		<group id="319" type="span" parent="320" relname="joint"/>
		<group id="320" type="multinuc" parent="321" relname="span"/>
		<group id="321" type="span" parent="322" relname="span"/>
		<group id="322" type="span" parent="333" relname="span"/>
		<group id="323" type="span" parent="322" relname="evidence"/>
		<group id="324" type="multinuc" parent="326" relname="span"/>
		<group id="325" type="span" parent="324" relname="joint"/>
		<group id="326" type="span" parent="334" relname="span"/>
		<group id="327" type="span" parent="328" relname="cause"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="436" relname="span"/>
		<group id="330" type="multinuc" parent="434" relname="span"/>
		<group id="331" type="span" parent="330" relname="same-unit"/>
		<group id="332" type="span" parent="434" relname="attribution"/>
		<group id="333" type="span" />
		<group id="334" type="span" parent="333" relname="evaluation"/>
		<group id="335" type="span" parent="349" relname="span"/>
		<group id="336" type="multinuc" parent="139" relname="elaboration"/>
		<group id="337" type="span" parent="336" relname="contrast"/>
		<group id="338" type="span" parent="350" relname="span"/>
		<group id="339" type="span" parent="340" relname="same-unit"/>
		<group id="340" type="multinuc" parent="341" relname="span"/>
		<group id="341" type="span" parent="351" relname="span"/>
		<group id="342" type="multinuc" parent="149" relname="elaboration"/>
		<group id="343" type="multinuc" parent="347" relname="joint"/>
		<group id="344" type="multinuc" parent="343" relname="joint"/>
		<group id="345" type="span" parent="344" relname="same-unit"/>
		<group id="346" type="span" parent="347" relname="joint"/>
		<group id="347" type="multinuc" parent="148" relname="elaboration"/>
		<group id="348" type="span" parent="352" relname="span"/>
		<group id="349" type="span" parent="416" relname="span"/>
		<group id="350" type="span" parent="349" relname="elaboration"/>
		<group id="351" type="span" parent="356" relname="span"/>
		<group id="352" type="span" parent="351" relname="cause"/>
		<group id="353" type="span" parent="354" relname="cause"/>
		<group id="354" type="span" parent="355" relname="span"/>
		<group id="355" type="span" parent="415" relname="span"/>
		<group id="356" type="span" parent="437" relname="concession"/>
		<group id="357" type="span" parent="165" relname="cause"/>
		<group id="358" type="span" parent="374" relname="span"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="171" relname="concession"/>
		<group id="361" type="span" parent="375" relname="span"/>
		<group id="362" type="span" parent="376" relname="span"/>
		<group id="363" type="span" parent="365" relname="span"/>
		<group id="364" type="span" parent="363" relname="elaboration"/>
		<group id="365" type="span" parent="377" relname="span"/>
		<group id="366" type="multinuc" parent="367" relname="span"/>
		<group id="367" type="span" parent="378" relname="span"/>
		<group id="368" type="span" parent="369" relname="span"/>
		<group id="369" type="span" parent="371" relname="same-unit"/>
		<group id="370" type="multinuc" parent="187" relname="purpose"/>
		<group id="371" type="multinuc" parent="372" relname="contrast"/>
		<group id="372" type="multinuc" parent="373" relname="span"/>
		<group id="373" type="span" />
		<group id="374" type="span" />
		<group id="375" type="span" parent="374" relname="evidence"/>
		<group id="376" type="span" parent="379" relname="span"/>
		<group id="377" type="span" parent="376" relname="elaboration"/>
		<group id="378" type="span" />
		<group id="379" type="span" parent="378" relname="cause"/>
		<group id="380" type="span" parent="384" relname="span"/>
		<group id="381" type="multinuc" parent="382" relname="span"/>
		<group id="382" type="span" parent="385" relname="span"/>
		<group id="384" type="span" parent="403" relname="span"/>
		<group id="385" type="span" parent="384" relname="cause"/>
		<group id="386" type="span" parent="201" relname="cause"/>
		<group id="387" type="span" parent="402" relname="span"/>
		<group id="388" type="span" parent="406" relname="span"/>
		<group id="389" type="span" parent="390" relname="same-unit"/>
		<group id="390" type="multinuc" parent="391" relname="span"/>
		<group id="391" type="span" parent="407" relname="span"/>
		<group id="392" type="span" parent="211" relname="cause"/>
		<group id="393" type="span" parent="409" relname="span"/>
		<group id="395" type="multinuc" parent="217" relname="purpose"/>
		<group id="396" type="span" parent="395" relname="joint"/>
		<group id="397" type="span" parent="440" relname="span"/>
		<group id="398" type="span" parent="399" relname="restatement"/>
		<group id="399" type="multinuc" parent="400" relname="span"/>
		<group id="400" type="span" parent="412" relname="span"/>
		<group id="401" type="span" parent="405" relname="span"/>
		<group id="402" type="span" parent="401" relname="preparation"/>
		<group id="403" type="span" parent="404" relname="comparison"/>
		<group id="404" type="multinuc" parent="410" relname="span"/>
		<group id="405" type="span" parent="404" relname="comparison"/>
		<group id="406" type="span" parent="410" relname="evaluation"/>
		<group id="407" type="span" parent="408" relname="span"/>
		<group id="408" type="span" parent="409" relname="cause"/>
		<group id="409" type="span" />
		<group id="410" type="span" />
		<group id="411" type="span" />
		<group id="412" type="span" parent="411" relname="cause"/>
		<group id="414" type="multinuc" />
		<group id="415" type="span" parent="414" relname="contrast"/>
		<group id="416" type="span" parent="417" relname="joint"/>
		<group id="417" type="multinuc" parent="414" relname="contrast"/>
		<group id="418" type="span" parent="419" relname="span"/>
		<group id="419" type="span" parent="14" relname="elaboration"/>
		<group id="420" type="span" parent="242" relname="joint"/>
		<group id="421" type="span" parent="422" relname="span"/>
		<group id="422" type="span" parent="18" relname="elaboration"/>
		<group id="423" type="span" parent="253" relname="sequence"/>
		<group id="424" type="span" parent="425" relname="span"/>
		<group id="425" type="span" parent="426" relname="concession"/>
		<group id="426" type="span" />
		<group id="427" type="span" parent="301" relname="attribution"/>
		<group id="428" type="span" parent="303" relname="attribution"/>
		<group id="429" type="span" parent="430" relname="span"/>
		<group id="430" type="span" parent="431" relname="span"/>
		<group id="431" type="span" parent="432" relname="span"/>
		<group id="432" type="span" parent="315" relname="elaboration"/>
		<group id="433" type="span" parent="128" relname="concession"/>
		<group id="434" type="span" parent="435" relname="span"/>
		<group id="435" type="span" parent="329" relname="attribution"/>
		<group id="436" type="span" />
		<group id="437" type="span" parent="438" relname="span"/>
		<group id="438" type="span" parent="417" relname="joint"/>
		<group id="439" type="span" parent="382" relname="attribution"/>
		<group id="440" type="span" parent="393" relname="attribution"/>
	</body>
</rst>