<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="126" relname="preparation">Программу Евросоюза по распределению беженцев необходимо довести до конца — мнение эксперта</segment>
		<segment id="2" parent="126" relname="span">Страны Евросоюза должны как можно скорее выполнить план по распределению 160 тыс. вынужденных переселенцев из Сирии, Ирака и Эритреи, преодолеть взаимные разногласия и разработать единую программу по выходу из затянувшегося кризиса.</segment>
		<segment id="3" parent="2" relname="attribution">Об этом пишет эксперт Греческого фонда европейской и внешней политики (ELIAMEP), специализирующегося на проблемах нелегальной миграции, Ангелики Димитриади (Angeliki Dimitriadi) в статье "Где же распределение ответственности?", опубликованной в зарубежных СМИ.</segment>
		<segment id="4" parent="222" relname="attribution">Она напоминает,</segment>
		<segment id="5" parent="222" relname="span">что в начале ноября 2015 года из Афин в Люксембург отправились первые 30 участников программы переселения беженцев, прибывших в Грецию, в том числе четыре семьи из Сирии и две из Ирака.</segment>
		<segment id="6" parent="251" relname="span">"На организованной по этому случаю торжественной церемонии присутствовали премьер-министр Греции Алексис Ципрас (Alexis Tsipras), еврокомиссар по вопросам миграции, внутренних дел и гражданства Димитрис Аврамопулос (Dimitris Avramopoulos), президент Европарламента Мартин Шульц (Martin Schulz), глава МИД Люксембурга Жан Ассельборн (Jean Asselborn) и замминистра по миграционной политике Греции Яннис Музалас (Yiannis Mouzalas)",</segment>
		<segment id="7" parent="6" relname="attribution">- замечает аналитик.</segment>
		<segment id="8" parent="132" relname="same-unit">Вместе с тем она подчеркивает, что</segment>
		<segment id="9" parent="10" relname="concession">после многочисленных заявлений и саммитов Евросоюз</segment>
		<segment id="10" parent="131" relname="span">до сих пор не достиг заметных успехов в этом вопросе.</segment>
		<segment id="11" parent="131" relname="elaboration">В частности, из 160 тыс. беженцев, которые ожидают распределения в Италии, Греции и Венгрии, страны ЕС приняли не более 200 человек и создали условия менее чем для 1,5 тыс. вынужденных переселенцев.</segment>
		<segment id="12" parent="225" relname="span">Кроме того, члены Евросоюза не выделили на решение проблемы достаточного количества специалистов по миграции и сотрудников пограничных служб.</segment>
		<segment id="13" parent="14" relname="attribution">Она указывает,</segment>
		<segment id="14" parent="224" relname="span">что проект системы "горячих точек" - центров по распределению, проверке и временному размещению соискателей убежища - на сегодняшний день фактически терпит провал.</segment>
		<segment id="15" parent="250" relname="span">Так, в Греции и Италии,</segment>
		<segment id="16" parent="15" relname="elaboration">куда каждый день прибывают тысячи мигрантов из стран Африки и Ближнего Востока,</segment>
		<segment id="17" parent="135" relname="same-unit">к началу ноября 2015 года было запущено лишь по одному подобному учреждению.</segment>
		<segment id="18" parent="138" relname="attribution">"В Риме официально заявили,</segment>
		<segment id="19" parent="138" relname="span">что откроют новые центры только тогда,</segment>
		<segment id="20" parent="137" relname="joint">когда другие члены Евросоюза активизируются</segment>
		<segment id="21" parent="137" relname="joint">и начнут оперативно принимать беженцев.</segment>
		<segment id="22" parent="141" relname="attribution">Еще в сентябре премьер-министр страны Маттео Ренци (Matteo Renzi) подчеркнул,</segment>
		<segment id="23" parent="140" relname="contrast">что Италия готова строить такие центры,</segment>
		<segment id="24" parent="140" relname="contrast">однако распределение мигрантов - задача Европы",</segment>
		<segment id="25" parent="143" relname="attribution">- пишет эксперт.</segment>
		<segment id="26" parent="260" relname="same-unit">В то же время,</segment>
		<segment id="27" parent="258" relname="attribution">по ее словам,</segment>
		<segment id="28" parent="258" relname="span">Афины испытывают серьезный недостаток ресурсов</segment>
		<segment id="29" parent="28" relname="condition">при отсутствии реальной помощи от Европы</segment>
		<segment id="30" parent="145" relname="joint">и действуют с большим отставанием от графика,</segment>
		<segment id="31" parent="146" relname="attribution">на что еще в октябре 2015 года обратил внимание канцлер Австрии Вернер Файман (Werner Faymann) в ходе посещения недавно открывшегося центра для мигрантов на острове Лесбос.</segment>
		<segment id="32" parent="227" relname="attribution">"После визита он заявил,</segment>
		<segment id="33" parent="227" relname="span">что своевременно подготовить остальные центры не удастся,</segment>
		<segment id="34" parent="33" relname="cause">поскольку "не были продуманы ни сроки, ни организация работ.</segment>
		<segment id="35" parent="149" relname="purpose">Чтобы открыть их к концу года,</segment>
		<segment id="36" parent="148" relname="joint">необходим головной штаб,</segment>
		<segment id="37" parent="148" relname="joint">требуется значительно больше средств, значительно больше людей",</segment>
		<segment id="38" parent="150" relname="attribution">- цитирует Ангелики Димитриади политика.</segment>
		<segment id="39" parent="231" relname="attribution">Также автор публикации отмечает,</segment>
		<segment id="40" parent="231" relname="span">что среди всех стран Евросоюза обязательства по миграционным квотам сейчас выполняют только Германия, Австрия и Швеция,</segment>
		<segment id="41" parent="40" relname="elaboration">которые также рассматривают запросы на предоставление убежища напрямую.</segment>
		<segment id="42" parent="43" relname="attribution">"Стокгольм уже заявил</segment>
		<segment id="43" parent="252" relname="span">о планах потребовать немедленного запуска системы распределения беженцев по Евросоюзу.</segment>
		<segment id="44" parent="252" relname="cause">Это говорит о том, что в Швеции не хватает мест.</segment>
		<segment id="45" parent="157" relname="same-unit">Страны,</segment>
		<segment id="46" parent="47" relname="cause">которым пришлось тяжелее всего в ходе миграционного кризиса,</segment>
		<segment id="47" parent="156" relname="span">предупреждают,</segment>
		<segment id="48" parent="158" relname="joint">что не справляются с нагрузкой,</segment>
		<segment id="49" parent="158" relname="joint">и грозятся закрыть границы.</segment>
		<segment id="50" parent="159" relname="span">Только Германия по-прежнему намерена держать границы открытыми - в особенности для сирийцев",</segment>
		<segment id="51" parent="50" relname="attribution">- пишет Ангелики Димитриади.</segment>
		<segment id="52" parent="164" relname="attribution">По ее словам,</segment>
		<segment id="53" parent="54" relname="attribution">согласно официальной статистике,</segment>
		<segment id="54" parent="164" relname="span">в ФРГ уже находятся свыше 758 тыс. соискателей убежища, более трети из них - выходцы из Сирии.</segment>
		<segment id="55" parent="56" relname="evaluation">В результате власти Германии были вынуждены пойти на попятную,</segment>
		<segment id="56" parent="165" relname="span">и сейчас они предоставляют новоприбывшим беженцам только вспомогательную защиту сроком на один год.</segment>
		<segment id="57" parent="167" relname="attribution">С точки зрения аналитика,</segment>
		<segment id="58" parent="59" relname="condition">на фоне приближающейся зимы и растущего числа жертв среди мигрантов, пытающихся попасть в ЕС морским путем,</segment>
		<segment id="59" parent="167" relname="span">власти Евросоюза неоправданно затягивают решение кризиса,</segment>
		<segment id="60" parent="169" relname="span">что грозит на долгие годы превратить пограничные страны Европы в "зоны ожидания" для сотен тысяч людей.</segment>
		<segment id="61" parent="62" relname="attribution">"В Еврокомиссии призывают</segment>
		<segment id="62" parent="257" relname="span">сохранять терпение</segment>
		<segment id="63" parent="64" relname="attribution">и заявляют</segment>
		<segment id="64" parent="256" relname="span">о планах ускорить работу с беженцами.</segment>
		<segment id="65" parent="174" relname="same-unit">Однако</segment>
		<segment id="66" parent="67" relname="condition">если число распределяемых вынужденных мигрантов так и будет исчисляться десятками, а не сотнями,</segment>
		<segment id="67" parent="173" relname="span">то заявленную цифру в 160 тыс. человек не удастся выполнить и через два года.</segment>
		<segment id="68" parent="69" relname="condition">Кроме того, говоря об этой проблеме,</segment>
		<segment id="69" parent="175" relname="span">не стоит забывать и про тех, кто приезжает не из Сирии.</segment>
		<segment id="70" parent="177" relname="span">Жители Афганистана, Эритреи, Ирака, Сомали и Судана также стремятся в Европу,</segment>
		<segment id="71" parent="176" relname="joint">хотя их значительно меньше,</segment>
		<segment id="72" parent="176" relname="joint">и многие из них не вошли в программу распределения.</segment>
		<segment id="73" parent="179" relname="contrast">Что же будет ожидать тех, кто по закону имеет право претендовать на убежище,</segment>
		<segment id="74" parent="179" relname="contrast">но не соответствует недавно введенным критериям?"</segment>
		<segment id="75" parent="234" relname="attribution">- задается вопросом Ангелики Димитриади.</segment>
		<segment id="76" parent="237" relname="attribution">По ее мнению,</segment>
		<segment id="77" parent="236" relname="contrast">нынешний миграционный кризис невозможно решить в короткие сроки и усилиями только отдельной части Евросоюза,</segment>
		<segment id="78" parent="236" relname="contrast">однако некоторые страны ЕС по-прежнему не хотят принимать участие в разрешении общей проблемы.</segment>
		<segment id="79" parent="180" relname="cause">"Миграционный кризис вызван целым комплексом проблем,</segment>
		<segment id="80" parent="81" relname="purpose">для разрешения которых</segment>
		<segment id="81" parent="180" relname="span">необходимо провести структурные реформы в странах на всем маршруте беженцев в Европу.</segment>
		<segment id="82" parent="182" relname="joint">На эти реформы уйдут десятилетия,</segment>
		<segment id="83" parent="182" relname="joint">а их последствия могут стать непредсказуемыми.</segment>
		<segment id="84" parent="190" relname="span">Сейчас же ЕС нужно осознать, что мир изменился, а вместе с ним и международная роль Евросоюза.</segment>
		<segment id="85" parent="84" relname="elaboration">Внимание Брюсселя должно быть сосредоточено как вовнутрь, так и вовне",</segment>
		<segment id="86" parent="190" relname="attribution">- считает автор публикации.</segment>
		<segment id="87" parent="241" relname="attribution">С ее точки зрения,</segment>
		<segment id="88" parent="241" relname="span">Европа очень нуждается в более гибкой и оперативной системе по работе с мигрантами,</segment>
		<segment id="89" parent="88" relname="elaboration">участие в которой должно стать обязательным для всех членов ЕС.</segment>
		<segment id="90" parent="193" relname="attribution">Вместе с тем Ангелики Димитриади призывает</segment>
		<segment id="91" parent="192" relname="same-unit">в ближайшее время рассмотреть возможность создания легальных коридоров миграции и</segment>
		<segment id="92" parent="191" relname="span">привлечения административного ресурса европейских посольств</segment>
		<segment id="93" parent="92" relname="purpose">для обработки заявлений на предоставление убежища.</segment>
		<segment id="94" parent="200" relname="span">"Пора открыто обсудить и демографическую сторону проблемы.</segment>
		<segment id="95" parent="196" relname="joint">Сколько именно человек сможет принять Евросоюз?</segment>
		<segment id="96" parent="196" relname="joint">За какой срок?</segment>
		<segment id="97" parent="198" relname="evaluation">Еще один вопрос, и притом очень важный:</segment>
		<segment id="98" parent="197" relname="joint">какова потребность ЕС в мигрантах сейчас</segment>
		<segment id="99" parent="197" relname="joint">и как она может измениться в дальнейшем?</segment>
		<segment id="100" parent="101" relname="condition">Если мы приложим все необходимые усилия,</segment>
		<segment id="101" parent="201" relname="span">то в результате выиграют и беженцы, и Европа",</segment>
		<segment id="102" parent="201" relname="attribution">- полагает эксперт.</segment>
		<segment id="103" parent="244" relname="attribution">В то же время она считает,</segment>
		<segment id="104" parent="244" relname="span">что европейские власти могут заручиться поддержкой других стран</segment>
		<segment id="105" parent="104" relname="condition">на условиях обязательного мониторинга со стороны ЕС.</segment>
		<segment id="106" parent="203" relname="attribution">По мнению Ангелики Димитриади,</segment>
		<segment id="107" parent="202" relname="joint">Евросоюзу необходимо как можно скорее предоставить Италии и Греции требуемую материальную и кадровую помощь,</segment>
		<segment id="108" parent="202" relname="joint">скоординировать деятельность государственных и некоммерческих организаций,</segment>
		<segment id="109" parent="202" relname="joint">а также начать подготовку к распределению беженцев.</segment>
		<segment id="110" parent="209" relname="span">"Такие приготовления будут восприняты как жест доброй воли не только внутри ЕС, но и за его пределами.</segment>
		<segment id="111" parent="110" relname="evaluation">Это покажет, что Европа наконец-то взяла ситуацию в свои руки",</segment>
		<segment id="112" parent="209" relname="attribution">- считает она.</segment>
		<segment id="113" parent="248" relname="attribution">При этом аналитик подчеркивает,</segment>
		<segment id="114" parent="210" relname="contrast">что подобные меры не остановят миграционный поток,</segment>
		<segment id="115" parent="262" relname="same-unit">однако начатую работу,</segment>
		<segment id="116" parent="117" relname="attribution">по ее словам,</segment>
		<segment id="117" parent="261" relname="span">необходимо довести до конца.</segment>
		<segment id="118" parent="211" relname="contrast">"Планируемая цифра в 160 тыс. человек - капля в море по сравнению с миллионами беженцев в Иордании, Ливане и Турции.</segment>
		<segment id="119" parent="213" relname="span">Но это станет для Евросоюза проверкой того,</segment>
		<segment id="120" parent="212" relname="joint">насколько он готов</segment>
		<segment id="121" parent="212" relname="joint">и способен адаптироваться к переменам в мире.</segment>
		<segment id="122" parent="214" relname="cause">Нынешний миграционный кризис будет далеко не последним,</segment>
		<segment id="123" parent="124" relname="condition">и если мы не сможем дать достойный ответ на вызовы настоящего,</segment>
		<segment id="124" parent="214" relname="span">то нас ждет весьма мрачное будущее",</segment>
		<segment id="125" parent="215" relname="attribution">- заключает Ангелики Димитриади.</segment>
		<group id="126" type="span" parent="130" relname="span"/>
		<group id="127" type="multinuc" parent="128" relname="span"/>
		<group id="128" type="span" parent="129" relname="span"/>
		<group id="129" type="span" />
		<group id="130" type="span" parent="128" relname="preparation"/>
		<group id="131" type="span" parent="133" relname="span"/>
		<group id="132" type="multinuc" parent="136" relname="joint"/>
		<group id="133" type="span" parent="132" relname="same-unit"/>
		<group id="135" type="multinuc" parent="153" relname="preparation"/>
		<group id="136" type="multinuc" parent="127" relname="contrast"/>
		<group id="137" type="multinuc" parent="19" relname="condition"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="143" relname="span"/>
		<group id="140" type="multinuc" parent="141" relname="span"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="139" relname="elaboration"/>
		<group id="143" type="span" parent="226" relname="span"/>
		<group id="145" type="multinuc" parent="146" relname="span"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" parent="151" relname="span"/>
		<group id="148" type="multinuc" parent="149" relname="span"/>
		<group id="149" type="span" parent="150" relname="span"/>
		<group id="150" type="span" parent="229" relname="span"/>
		<group id="151" type="span" parent="152" relname="joint"/>
		<group id="152" type="multinuc" parent="153" relname="span"/>
		<group id="153" type="span" parent="154" relname="span"/>
		<group id="154" type="span" />
		<group id="156" type="span" parent="157" relname="same-unit"/>
		<group id="157" type="multinuc" parent="254" relname="attribution"/>
		<group id="158" type="multinuc" parent="254" relname="span"/>
		<group id="159" type="span" parent="178" relname="span"/>
		<group id="160" type="multinuc" parent="161" relname="contrast"/>
		<group id="161" type="multinuc" parent="162" relname="span"/>
		<group id="162" type="span" parent="163" relname="span"/>
		<group id="163" type="span" />
		<group id="164" type="span" parent="233" relname="span"/>
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" parent="159" relname="elaboration"/>
		<group id="167" type="span" parent="249" relname="span"/>
		<group id="169" type="span" parent="188" relname="preparation"/>
		<group id="170" type="multinuc" parent="185" relname="contrast"/>
		<group id="173" type="span" parent="174" relname="same-unit"/>
		<group id="174" type="multinuc" parent="186" relname="joint"/>
		<group id="175" type="span" parent="184" relname="span"/>
		<group id="176" type="multinuc" parent="70" relname="concession"/>
		<group id="177" type="span" parent="175" relname="elaboration"/>
		<group id="178" type="span" parent="161" relname="contrast"/>
		<group id="179" type="multinuc" parent="234" relname="span"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="183" relname="span"/>
		<group id="182" type="multinuc" parent="189" relname="contrast"/>
		<group id="183" type="span" parent="239" relname="elaboration"/>
		<group id="184" type="span" parent="186" relname="joint"/>
		<group id="185" type="multinuc" parent="188" relname="span"/>
		<group id="186" type="multinuc" parent="185" relname="contrast"/>
		<group id="187" type="span" />
		<group id="188" type="span" parent="187" relname="span"/>
		<group id="189" type="multinuc" parent="181" relname="evaluation"/>
		<group id="190" type="span" parent="194" relname="span"/>
		<group id="191" type="span" parent="192" relname="same-unit"/>
		<group id="192" type="multinuc" parent="193" relname="span"/>
		<group id="193" type="span" parent="195" relname="span"/>
		<group id="194" type="span" parent="243" relname="span"/>
		<group id="195" type="span" parent="200" relname="preparation"/>
		<group id="196" type="multinuc" parent="94" relname="elaboration"/>
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" parent="196" relname="joint"/>
		<group id="200" type="span" parent="208" relname="span"/>
		<group id="201" type="span" parent="246" relname="span"/>
		<group id="202" type="multinuc" parent="219" relname="span"/>
		<group id="203" type="span" parent="204" relname="span"/>
		<group id="204" type="span" parent="220" relname="joint"/>
		<group id="205" type="multinuc" parent="206" relname="span"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" />
		<group id="208" type="span" parent="206" relname="solutionhood"/>
		<group id="209" type="span" parent="247" relname="span"/>
		<group id="210" type="multinuc" parent="248" relname="span"/>
		<group id="211" type="multinuc" parent="217" relname="elaboration"/>
		<group id="212" type="multinuc" parent="119" relname="condition"/>
		<group id="213" type="span" parent="211" relname="contrast"/>
		<group id="214" type="span" parent="215" relname="span"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" parent="221" relname="span"/>
		<group id="217" type="span" parent="218" relname="span"/>
		<group id="218" type="span" parent="220" relname="joint"/>
		<group id="219" type="span" parent="203" relname="span"/>
		<group id="220" type="multinuc" parent="216" relname="solutionhood"/>
		<group id="221" type="span" />
		<group id="222" type="span" parent="223" relname="span"/>
		<group id="223" type="span" parent="127" relname="contrast"/>
		<group id="224" type="span" parent="12" relname="evaluation"/>
		<group id="225" type="span" parent="136" relname="joint"/>
		<group id="226" type="span" parent="152" relname="joint"/>
		<group id="227" type="span" parent="228" relname="span"/>
		<group id="228" type="span" parent="230" relname="span"/>
		<group id="229" type="span" parent="228" relname="elaboration"/>
		<group id="230" type="span" parent="147" relname="elaboration"/>
		<group id="231" type="span" parent="232" relname="span"/>
		<group id="232" type="span" parent="162" relname="preparation"/>
		<group id="233" type="span" parent="165" relname="cause"/>
		<group id="234" type="span" parent="235" relname="span"/>
		<group id="235" type="span" parent="238" relname="solutionhood"/>
		<group id="236" type="multinuc" parent="237" relname="span"/>
		<group id="237" type="span" parent="238" relname="span"/>
		<group id="238" type="span" parent="239" relname="span"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" />
		<group id="241" type="span" parent="242" relname="span"/>
		<group id="242" type="span" parent="194" relname="elaboration"/>
		<group id="243" type="span" parent="189" relname="contrast"/>
		<group id="244" type="span" parent="245" relname="span"/>
		<group id="245" type="span" parent="205" relname="joint"/>
		<group id="246" type="span" parent="205" relname="joint"/>
		<group id="247" type="span" parent="219" relname="evaluation"/>
		<group id="248" type="span" parent="217" relname="span"/>
		<group id="249" type="span" parent="60" relname="cause"/>
		<group id="250" type="span" parent="135" relname="same-unit"/>
		<group id="251" type="span" parent="5" relname="elaboration"/>
		<group id="252" type="span" parent="253" relname="span"/>
		<group id="253" type="span" parent="160" relname="joint"/>
		<group id="254" type="span" parent="255" relname="span"/>
		<group id="255" type="span" parent="160" relname="joint"/>
		<group id="256" type="span" parent="170" relname="joint"/>
		<group id="257" type="span" parent="170" relname="joint"/>
		<group id="258" type="span" parent="259" relname="span"/>
		<group id="259" type="span" parent="260" relname="same-unit"/>
		<group id="260" type="multinuc" parent="145" relname="joint"/>
		<group id="261" type="span" parent="262" relname="same-unit"/>
		<group id="262" type="multinuc" parent="210" relname="contrast"/>
	</body>
</rst>