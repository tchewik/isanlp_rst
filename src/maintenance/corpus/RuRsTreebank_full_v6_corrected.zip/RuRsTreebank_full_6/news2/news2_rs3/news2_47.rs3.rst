<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="515" relname="preparation">Шенгенское соглашение нуждается в скорейшей комплексной реформе — Родерик Паркс</segment>
		<segment id="2" parent="271" relname="span">Европейский союз,</segment>
		<segment id="3" parent="2" relname="elaboration">предпринимающий попытки справиться с наплывом беженцев,</segment>
		<segment id="4" parent="272" relname="same-unit">нуждается в эффективном реформировании Шенгенского соглашения и качественно новых инструментах</segment>
		<segment id="5" parent="273" relname="purpose">для долгосрочного прогнозирования миграционных волн.</segment>
		<segment id="6" parent="274" relname="attribution">Об этом в статье "20 лет спустя: пересмотр Шенгена" пишет эксперт в сфере миграции Института Европейского союза по вопросам безопасности (EUISS) Родерик Паркс (Roderick Parkes).</segment>
		<segment id="7" parent="281" relname="attribution">Ее текст, опубликованный в зарубежных СМИ, ИА "PenzaNews" приводит ниже в собственном переводе и без сокращений.</segment>
		<segment id="8" parent="279" relname="contrast">Недавние предложения реформировать Шенгенскую зону сводятся к тому, чтобы превратить ее в полноценную пограничную систему, включая тщательный контроль на границе и погранвойска.</segment>
		<segment id="9" parent="276" relname="contrast">Однако Шенген создавался в 1995 году не как традиционная система пограничного контроля.</segment>
		<segment id="10" parent="276" relname="contrast">Скорее наоборот: соглашение адаптировало сеть европейских внутренних границ под новую эру глобализации.</segment>
		<segment id="11" parent="277" relname="joint">Сегодня международная обстановка в очередной раз претерпела значительные изменения,</segment>
		<segment id="12" parent="277" relname="joint">и для Шенгена настало время реформ,</segment>
		<segment id="13" parent="278" relname="contrast">однако при их разработке стоит учесть уникальное прошлое этой системы.</segment>
		<segment id="14" parent="296" relname="preparation">Система отсроченного предупреждения</segment>
		<segment id="15" parent="295" relname="span">В последнее время в ЕС все чаще звучат призывы создать классическую систему раннего предупреждения (СРП) о притоке мигрантов,</segment>
		<segment id="16" parent="15" relname="elaboration">которая уже существует в ряде западных стран.</segment>
		<segment id="17" parent="282" relname="condition">В случае неожиданного наплыва людей,</segment>
		<segment id="18" parent="19" relname="attribution">как утверждают сторонники этой идеи,</segment>
		<segment id="19" parent="282" relname="span">СРП даст Евросоюзу достаточно времени,</segment>
		<segment id="20" parent="283" relname="purpose">чтобы мобилизовать ресурсы наподобие "дублинской" программы распределения беженцев и мер правовой защиты.</segment>
		<segment id="21" parent="286" relname="joint">В ЕС уже существует как минимум одна система предупреждения о военных конфликтах и других зарубежных "движущих факторах".</segment>
		<segment id="22" parent="284" relname="span">Также Евросоюз сейчас работает над созданием еще одной системы</segment>
		<segment id="23" parent="22" relname="purpose">для обнаружения "притягивающих факторов" наподобие пробелов в защите границ,</segment>
		<segment id="24" parent="285" relname="joint">и эти две структуры могут быть объединены в классическую СРП.</segment>
		<segment id="25" parent="519" relname="span">Однако такому объединению, как Евросоюз, может на самом деле потребоваться система не раннего, а отсроченного предупреждения.</segment>
		<segment id="26" parent="516" relname="joint">ЕС окружен зонами непредсказуемых и взаимосвязанных конфликтов - на Украине, в Сирии и не только -</segment>
		<segment id="27" parent="516" relname="joint">и между возникновением очага напряженности за рубежом и новой волной иммиграции в Европу может пройти значительное время, вплоть до нескольких лет.</segment>
		<segment id="28" parent="289" relname="span">Периметр Шенгенской зоны - это 42 тыс. 673 км морских и 7 тыс. 721 км сухопутных границ,</segment>
		<segment id="29" parent="28" relname="elaboration">за которыми следят 26 стран-участников.</segment>
		<segment id="30" parent="288" relname="joint">Такая структура просто не способна длительное время находиться в состоянии повышенной готовности</segment>
		<segment id="31" parent="297" relname="span">или быстро мобилизовать ресурсы</segment>
		<segment id="32" parent="31" relname="purpose">для встречи надвигающейся волны миграции.</segment>
		<segment id="33" parent="34" relname="purpose">Чтобы быть наготове,</segment>
		<segment id="34" parent="430" relname="span">Шенгену необходимо проводить долгосрочный мониторинг международной обстановки в период между возникновением конфликта и последующим наплывом мигрантов.</segment>
		<segment id="35" parent="36" relname="purpose">Чтобы понять, зачем это нужно,</segment>
		<segment id="36" parent="427" relname="span">рассмотрим примеры Сирии и Ливии.</segment>
		<segment id="37" parent="298" relname="contrast">Еще в 2011 году после арабской весны в ЕС ожидали прибытия по меньшей мере 300-400 тыс. беженцев,</segment>
		<segment id="38" parent="298" relname="contrast">однако в тот год их можно было едва ли не пересчитать по пальцам.</segment>
		<segment id="39" parent="299" relname="joint">В результате к середине 2012 года власти Евросоюза не только вновь открыли границы,</segment>
		<segment id="40" parent="299" relname="joint">но и предложили жителям арабских стран в самый разгар реформ весьма привлекательные условия для переезда.</segment>
		<segment id="41" parent="302" relname="span">Однако к тому времени поток нелегальных мигрантов уже начал расти.</segment>
		<segment id="42" parent="43" relname="cause">Евросоюз мобилизовал свои ресурсы слишком быстро</segment>
		<segment id="43" parent="303" relname="span">и в результате оказался не готов к последующему наплыву беженцев.</segment>
		<segment id="44" parent="314" relname="evaluation">Причины для такой задержки между вспышкой напряженности и началом активной миграции не столь очевидны, но весьма поучительны.</segment>
		<segment id="45" parent="306" relname="same-unit">Еще до 2011 года в ЕС</segment>
		<segment id="46" parent="47" relname="purpose">на заработки</segment>
		<segment id="47" parent="305" relname="span">активно приезжали граждане мусульманских стран,</segment>
		<segment id="48" parent="307" relname="joint">и сразу после арабской весны многие из них, полные надежд, решили вернуться домой.</segment>
		<segment id="49" parent="520" relname="evaluation">Скорее всего, этот обратный поток дестабилизировал обстановку в регионе.</segment>
		<segment id="50" parent="313" relname="span">Затем ситуация ухудшилась еще больше</segment>
		<segment id="51" parent="50" relname="elaboration">после того, как люди начали покидать Ливию и Египет после революций, бросая работу и свое имущество.</segment>
		<segment id="52" parent="308" relname="joint">В результате нарушилась работа хрупких североафриканских сетей денежных переводов,</segment>
		<segment id="53" parent="308" relname="joint">вырос спрос на услуги контрабандистов,</segment>
		<segment id="54" parent="309" relname="span">а у вооруженных ополченцев,</segment>
		<segment id="55" parent="54" relname="elaboration">раньше служивших местным авторитарным властям,</segment>
		<segment id="56" parent="310" relname="same-unit">оказались развязаны руки.</segment>
		<segment id="57" parent="417" relname="span">Даже спустя четыре года у Евросоюза до сих пор нет полных данных</segment>
		<segment id="58" parent="57" relname="elaboration">о том, как именно возникают миграционные волны.</segment>
		<segment id="59" parent="317" relname="joint">Агентство по контролю за границами Frontex собирает статистику по новоприбывшим мигрантам,</segment>
		<segment id="60" parent="317" relname="joint">а Европейская служба поддержки лиц, претендующих на получение убежища (EASO), ведет еженедельный учет входящим запросам.</segment>
		<segment id="61" parent="318" relname="contrast">Однако эти сведения не позволяют эффективно прогнозировать будущие тенденции.</segment>
		<segment id="62" parent="322" relname="span">Возьмем такой пример:</segment>
		<segment id="63" parent="544" relname="evaluation">известно, что</segment>
		<segment id="64" parent="321" relname="comparison">70% новоприбывших мигрантов - мужчины, которые с большой долей вероятности останутся в Европе надолго</segment>
		<segment id="65" parent="319" relname="span">(в то время как женщины среднего возраста,</segment>
		<segment id="66" parent="65" relname="evaluation">которых часто называют самой благонамеренной группой,</segment>
		<segment id="67" parent="320" relname="same-unit">обычно возвращаются домой быстрее всех).</segment>
		<segment id="68" parent="324" relname="span">Но эти сведения не дают ответа на другой важный вопрос:</segment>
		<segment id="69" parent="68" relname="elaboration">когда именно за этими мужчинами последуют остальные члены их семей?</segment>
		<segment id="70" parent="326" relname="contrast">Для ответа на подобные вопросы странам Шенгена нужно уделять меньше внимания "движущим" и "притягивающим" факторам в начальных и конечных точках миграции,</segment>
		<segment id="71" parent="327" relname="span">а тщательнее изучать сложные "промежуточные факторы",</segment>
		<segment id="72" parent="325" relname="joint">которые затормаживают</segment>
		<segment id="73" parent="325" relname="joint">или ускоряют процесс.</segment>
		<segment id="74" parent="333" relname="span">Наиболее яркий пример - контрабандисты, которые нелегально перевозят людей.</segment>
		<segment id="75" parent="328" relname="joint">За последние четыре года их активность заметно возросла,</segment>
		<segment id="76" parent="328" relname="joint">а деятельность этих преступных группировок по своей роли и функционалу стала напоминать структуры, которыми пользовались туристы в Европе.</segment>
		<segment id="77" parent="329" relname="span">Вероятнее всего, именно контрабанда людей станет целью нового исследования EASO,</segment>
		<segment id="78" parent="77" relname="purpose">направленного на выявление алгоритма принятия решений соискателями убежища.</segment>
		<segment id="79" parent="330" relname="span">Его результаты вполне могут принести пользу,</segment>
		<segment id="80" parent="79" relname="condition">став основой европейской СРП о мигрантах в будущем.</segment>
		<segment id="81" parent="535" relname="preparation">И дело не только в готовности или способности Шенгена оперативно реагировать.</segment>
		<segment id="82" parent="341" relname="span">Классическая система раннего предупреждения больше подходит для отдельно взятой страны</segment>
		<segment id="83" parent="82" relname="purpose">как способ залатать бреши в законодательстве в период затишья.</segment>
		<segment id="84" parent="342" relname="contrast">Однако для сверхдержавы, которая стремится управлять миграционными потоками здесь и сейчас, лучше всего подойдет именно система отсроченного предупреждения.</segment>
		<segment id="85" parent="343" relname="concession">Шенгенская зона полагается на способность Евросоюза влиять на причины миграции еще в зародыше.</segment>
		<segment id="86" parent="339" relname="joint">Делать это становится все сложнее,</segment>
		<segment id="87" parent="339" relname="joint">и здесь система отсроченного предупреждения позволит по меньшей мере контролировать миграцию уже по ходу ее развития.</segment>
		<segment id="88" parent="336" relname="preparation">Рассмотрим такую ситуацию:</segment>
		<segment id="89" parent="335" relname="condition">если Евросоюз убедит власти Эритреи отказаться от всеобщей воинской обязанности,</segment>
		<segment id="90" parent="335" relname="span">к чему это приведет:</segment>
		<segment id="91" parent="334" relname="joint">к сокращению потока беженцев</segment>
		<segment id="92" parent="334" relname="joint">или же к росту числа безработных молодых людей в Африке?</segment>
		<segment id="93" parent="340" relname="span">И что будет затем,</segment>
		<segment id="94" parent="93" relname="condition">если этим молодым людям не удастся найти работу в странах Персидского залива?</segment>
		<segment id="95" parent="423" relname="preparation">"Ненормальный" пограничный контроль</segment>
		<segment id="96" parent="421" relname="contrast">Кроме того, в ЕС звучат призывы укрепить внешние границы.</segment>
		<segment id="97" parent="347" relname="span">Однако у такого объединения, как Евросоюз,</segment>
		<segment id="98" parent="97" relname="elaboration">площадь которого увеличивалась по меньшей мере 7 раз за последние 40 лет,</segment>
		<segment id="99" parent="348" relname="same-unit">нет внешних границ в традиционном смысле этого слова</segment>
		<segment id="100" parent="350" relname="span">- есть набор соглашений с соседями о взаимном сотрудничестве,</segment>
		<segment id="101" parent="100" relname="elaboration">которые не так просто "укрепить".</segment>
		<segment id="102" parent="351" relname="span">Это хорошо заметно на примере юго-восточной границы Евросоюза - длинной (13 тыс. 676 км вдоль линии греческого побережья), неоднородной</segment>
		<segment id="103" parent="102" relname="cause">(так как проходит через бывшие территории Югославии)</segment>
		<segment id="104" parent="352" relname="same-unit">и нечеткой.</segment>
		<segment id="105" parent="353" relname="span">Через нее в ЕС могут попасть жители пяти балканских стран из шести,</segment>
		<segment id="106" parent="105" relname="condition">имея при себе только паспорт.</segment>
		<segment id="107" parent="355" relname="span">Кроме того, власти Косово сейчас проводят внутренние реформы,</segment>
		<segment id="108" parent="107" relname="purpose">чтобы также получить это право.</segment>
		<segment id="109" parent="354" relname="joint">Аналогичные требования все настойчивее звучат со стороны Турции.</segment>
		<segment id="110" parent="357" relname="span">Нечеткая граница</segment>
		<segment id="111" parent="110" relname="cause">стала результатом вполне определенной политики.</segment>
		<segment id="112" parent="359" relname="purpose">Евросоюз преследовал цель провести "функциональную интеграцию" региона</segment>
		<segment id="113" parent="359" relname="span">и потому поощрял межгосударственные экономические контакты на Балканах - трудовую миграцию, товарооборот и транснациональный бизнес -</segment>
		<segment id="114" parent="358" relname="joint">чтобы деполитизировать этнические противоречия</segment>
		<segment id="115" parent="358" relname="joint">и заставить государственных деятелей пойти на сближение.</segment>
		<segment id="116" parent="361" relname="span">ЕС,</segment>
		<segment id="117" parent="116" relname="elaboration">будучи крупным рынком для Западных Балкан,</segment>
		<segment id="118" parent="362" relname="same-unit">взял эти экономические факторы на вооружение</segment>
		<segment id="119" parent="363" relname="purpose">ради создания стратегического преимущества.</segment>
		<segment id="120" parent="367" relname="same-unit">В итоге</segment>
		<segment id="121" parent="366" relname="cause">благодаря политике Брюсселя</segment>
		<segment id="122" parent="364" relname="joint">западнобалканские страны укрепили внутренние границы,</segment>
		<segment id="123" parent="364" relname="joint">провели реформы</segment>
		<segment id="124" parent="365" relname="span">и наладили взаимное сотрудничество,</segment>
		<segment id="125" parent="124" relname="purpose">чтобы получить доступ к европейскому рынку.</segment>
		<segment id="126" parent="383" relname="preparation">Однако в настоящее время проблема заключается в том, что наибольшая активность на транснациональном уровне сейчас приходится именно на нелегальную сферу.</segment>
		<segment id="127" parent="380" relname="span">Преступные сети зарабатывают миллионы,</segment>
		<segment id="128" parent="127" relname="cause">перевозя мигрантов из Ближнего Востока и Южной Азии в Грецию и дальше - через Сербию и Македонию в другие страны Европы.</segment>
		<segment id="129" parent="376" relname="span">Принцип работы этих нелегальных группировок во многом схож с наиболее эффективными госучреждениями:</segment>
		<segment id="130" parent="373" relname="joint">в них вовлечены лица разных национальностей,</segment>
		<segment id="131" parent="373" relname="joint">они действуют предприимчиво</segment>
		<segment id="132" parent="374" relname="span">и добиваются результата,</segment>
		<segment id="133" parent="132" relname="cause">находя клиентов по всему миру.</segment>
		<segment id="134" parent="377" relname="joint">К тому же они заслужили репутацию тех, кто всегда выполняет свои обещания.</segment>
		<segment id="135" parent="378" relname="elaboration">Преступная группа может перебросить мигранта из Турции в Германию за четыре дня или даже быстрее.</segment>
		<segment id="136" parent="375" relname="joint">Однако они действуют незаконно</segment>
		<segment id="137" parent="375" relname="joint">и подвергают людей огромной опасности.</segment>
		<segment id="138" parent="139" relname="cause">Эти преступные сети</segment>
		<segment id="139" parent="530" relname="span">подталкивают Западные Балканы к функциональному расколу.</segment>
		<segment id="140" parent="404" relname="span">Контрабандисты успешно перевозят своих сирийских, иракских и афганских "клиентов" втайне от местного населения и властей.</segment>
		<segment id="141" parent="384" relname="span">Огромное число мигрантов - около 3-4 тыс. ежедневно - перебираются из Греции в Сербию и Македонию,</segment>
		<segment id="142" parent="141" relname="concession">хотя приток беженцев в Грецию уже сократился всего до 500 человек в сутки.</segment>
		<segment id="143" parent="388" relname="span">Волна миграции распространяется во все стороны</segment>
		<segment id="144" parent="386" relname="span">именно благодаря контрабандистам,</segment>
		<segment id="145" parent="385" relname="joint">которые предлагают новые способы попасть в Италию через Албанию</segment>
		<segment id="146" parent="385" relname="joint">или добраться напрямую до Румынии по морю.</segment>
		<segment id="147" parent="148" relname="evaluation">Неудивительно, что</segment>
		<segment id="148" parent="546" relname="span">в результате социальные и политические противоречия на Западных Балканах обострились.</segment>
		<segment id="149" parent="407" relname="span">Еще хуже то, что в отдельных случаях контрабандисты работают с беженцами гораздо эффективнее властей.</segment>
		<segment id="150" parent="149" relname="elaboration">Там, где европейские законы слишком суровы, они их просто обходят.</segment>
		<segment id="151" parent="152" relname="attribution">Греческие НКО и вовсе заявляют,</segment>
		<segment id="152" parent="406" relname="span">что система распределения беженцев Евросоюза вынуждена "соперничать" с контрабандистами в части оперативности.</segment>
		<segment id="153" parent="425" relname="span">А соперничество в этой сфере - дело непростое.</segment>
		<segment id="154" parent="389" relname="contrast">Беженцы хотят уладить все как можно скорее,</segment>
		<segment id="155" parent="389" relname="contrast">а система ЕС продолжает вязнуть в разногласиях с коммерческими авиакомпаниями.</segment>
		<segment id="156" parent="408" relname="joint">К тому же в ней согласились участвовать еще не все члены Евросоюза.</segment>
		<segment id="157" parent="391" relname="span">Однако второй вариант</segment>
		<segment id="158" parent="390" relname="joint">- закрыть границы</segment>
		<segment id="159" parent="390" relname="joint">и оборвать все связи -</segment>
		<segment id="160" parent="393" relname="span">просто невозможно воплотить в жизнь:</segment>
		<segment id="161" parent="162" relname="cause">более того, сама мысль об этом</segment>
		<segment id="162" parent="394" relname="span">подталкивает многих к опрометчивым поступкам.</segment>
		<segment id="163" parent="412" relname="span">Те, кто живет на Балканах, сейчас стремятся быстрее попасть в Евросоюз,</segment>
		<segment id="164" parent="163" relname="cause">опасаясь, что вскоре они лишатся такой возможности.</segment>
		<segment id="165" parent="401" relname="cause">На текущий момент 29% заявлений о предоставлении убежища рассматриваются дольше 6 месяцев,</segment>
		<segment id="166" parent="401" relname="span">чем пользуются албанцы и сербы,</segment>
		<segment id="167" parent="400" relname="sequence">которые приезжают в ЕС,</segment>
		<segment id="168" parent="400" relname="sequence">подают документы</segment>
		<segment id="169" parent="400" relname="sequence">и исчезают из поля зрения.</segment>
		<segment id="170" parent="415" relname="span">Те же, кто остался, перестают верить, что визовый режим с ЕС вообще когда-нибудь будет отменен.</segment>
		<segment id="171" parent="170" relname="elaboration">В Косово уже выступают против усиления внутреннего пограничного контроля.</segment>
		<segment id="172" parent="402" relname="preparation">На повестку дня вновь выходит проблема регионального дисбаланса.</segment>
		<segment id="173" parent="395" relname="same-unit">Через Сербию</segment>
		<segment id="174" parent="175" relname="cause">из-за ее размера</segment>
		<segment id="175" parent="396" relname="span">сейчас проходят почти все миграционные потоки,</segment>
		<segment id="176" parent="397" relname="joint">что не только создает дополнительную нагрузку,</segment>
		<segment id="177" parent="398" relname="span">но и дает Белграду инструмент политического влияния на соседей,</segment>
		<segment id="178" parent="177" relname="elaboration">к которым при необходимости можно "перенаправить" беженцев.</segment>
		<segment id="179" parent="526" relname="preparation">Единственный позитивный момент в этой ситуации - "нетипичная интеграция".</segment>
		<segment id="180" parent="431" relname="span">За последние несколько недель страны Балканского полуострова начали ужесточать свои требования по работе с мигрантами,</segment>
		<segment id="181" parent="180" relname="elaboration">приблизив их к общеевропейским стандартам,</segment>
		<segment id="182" parent="431" relname="concession">несмотря на то, что создать даже 6 тыс. мест для беженцев в одной Сербии кажется невыполнимой задачей.</segment>
		<segment id="183" parent="432" relname="joint">Они выступили против того, чтобы их считали "транзитными территориями",</segment>
		<segment id="184" parent="432" relname="joint">потребовали большего влияния на европейскую политику</segment>
		<segment id="185" parent="432" relname="joint">и предложили ряд идей, в том числе программу по распределению беженцев на Балканах.</segment>
		<segment id="186" parent="436" relname="span">Кроме того, органы правопорядка балканских государств</segment>
		<segment id="187" parent="434" relname="same-unit">- которые</segment>
		<segment id="188" parent="189" relname="condition">при необходимости</segment>
		<segment id="189" parent="435" relname="span">могут действовать крайне эффективно -</segment>
		<segment id="190" parent="437" relname="same-unit">начали активнее сотрудничать [с коллегами из Шенгена] по ряду вопросов,</segment>
		<segment id="191" parent="438" relname="elaboration">включая борьбу с терроризмом.</segment>
		<segment id="192" parent="442" relname="evaluation">Эта спонтанная и нетипичная интеграция [Балкан с Евросоюзом] в конечном итоге может укрепить взаимоотношения сильнее, чем простое решение закрыть границы.</segment>
		<segment id="193" parent="524" relname="preparation">Свобода "последующего перемещения"</segment>
		<segment id="194" parent="524" relname="span">Беженцы, направляющиеся в Европу через Балканы, ставят под угрозу саму идею свободного перемещения в рамках Шенгенской зоны.</segment>
		<segment id="195" parent="461" relname="span">ЕС, Норвегия и Швейцария в этом году получили рекордное количество заявлений на предоставление убежища - в общей сумме около 1,07 млн. обращений,</segment>
		<segment id="196" parent="195" relname="elaboration">при этом 97% поступило от новоприбывших.</segment>
		<segment id="197" parent="448" relname="span">Более того, среди беженцев много несовершеннолетних из Афганистана, Пакистана, Сомали и Албании</segment>
		<segment id="198" parent="197" relname="condition">без сопровождения взрослых.</segment>
		<segment id="199" parent="444" relname="span">Это не "разведчики",</segment>
		<segment id="200" parent="199" relname="elaboration">за которыми потом потянутся их семьи,</segment>
		<segment id="201" parent="447" relname="span">а всего лишь дети,</segment>
		<segment id="202" parent="443" relname="span">тайком отправленные в Европу родителями</segment>
		<segment id="203" parent="202" relname="purpose">для самостоятельной жизни,</segment>
		<segment id="204" parent="447" relname="elaboration">которые представляют для ЕС весьма непростую проблему.</segment>
		<segment id="205" parent="450" relname="same-unit">На сегодняшний день Евросоюз избрал</segment>
		<segment id="206" parent="207" relname="purpose">для ее решения</segment>
		<segment id="207" parent="449" relname="span">классический правительственный инструмент: систему распределения.</segment>
		<segment id="208" parent="451" relname="joint">Следуя вполне четкому алгоритму, ЕС планирует поселить каждого беженца в конкретной стране</segment>
		<segment id="209" parent="451" relname="joint">и ввести жесткие ограничения на последующее перемещение по Европе.</segment>
		<segment id="210" parent="453" relname="span">С этой целью власти Евросоюза сейчас стремятся как можно скорее принять ряд мер по распределению беженцев,</segment>
		<segment id="211" parent="210" relname="elaboration">с которыми сопряжено огромное множество факторов.</segment>
		<segment id="212" parent="453" relname="elaboration">В частности, они учитывают национальность, наличие возможных родственников в Европе, знание языков, профессиональные навыки, даже текущую экономическую и демографическую динамику в стране назначения.</segment>
		<segment id="213" parent="471" relname="preparation">В системе распределения приняли участие свыше 160 вынужденных мигрантов, отобранных властями Греции и Италии.</segment>
		<segment id="214" parent="455" relname="span">Нынешняя схема показала себя более эффективной, чем пробный проект на Мальте,</segment>
		<segment id="215" parent="214" relname="elaboration">где новоприбывших беженцев одно время обязывали проходить процедуру оформления документов и подтверждения статуса.</segment>
		<segment id="216" parent="457" relname="span">Тем не менее программа создает значительную нагрузку на местные власти,</segment>
		<segment id="217" parent="216" relname="evaluation">что вызывает некоторое беспокойство:</segment>
		<segment id="218" parent="457" relname="elaboration">например, в центре распределения на греческом острове Лесбос работает команда всего из 10 человек.</segment>
		<segment id="219" parent="454" relname="joint">Перед европейскими пограничными службами поставлена задача не только набирать кандидатов на участие в программе распределения,</segment>
		<segment id="220" parent="454" relname="joint">но и создавать условия для их постоянного размещения,</segment>
		<segment id="221" parent="454" relname="joint">а также выявлять преступников и террористов.</segment>
		<segment id="222" parent="469" relname="cause">Здесь большой простор для ошибок.</segment>
		<segment id="223" parent="464" relname="joint">В этом свете хочется предложить расширить уже существующий механизм распределения</segment>
		<segment id="224" parent="464" relname="joint">и предоставить беженцам право выбирать, где они хотели бы жить в будущем.</segment>
		<segment id="225" parent="492" relname="span">Еще 20 лет назад лидеры стран ЕС обсуждали концепцию европейской миграционной конвенции,</segment>
		<segment id="226" parent="465" relname="span">в рамках которой предлагалось выдавать вынужденным мигрантам вид на жительство в другой стране Европы</segment>
		<segment id="227" parent="226" relname="condition">по прошествии определенного времени.</segment>
		<segment id="228" parent="493" relname="span">В итоге власти все же предоставили такое право экономическим мигрантам, но не беженцам</segment>
		<segment id="229" parent="467" relname="span">- во многом из-за негативного опыта с выходцами из Сомали,</segment>
		<segment id="230" parent="466" relname="sequence">которые получали гражданство в одной стране,</segment>
		<segment id="231" parent="466" relname="sequence">а затем переезжали в другую,</segment>
		<segment id="232" parent="467" relname="evaluation">что создавало серьезные проблемы для евроинтеграции.</segment>
		<segment id="233" parent="476" relname="contrast">Само собой, это решение не идеально.</segment>
		<segment id="234" parent="476" relname="contrast">Однако наилучшим способом защитить европейские принципы свободы передвижения может стать именно активное насаждение этих принципов.</segment>
		<segment id="235" parent="472" relname="joint">У детей, которые попали в ЕС без родителей, впереди большое будущее,</segment>
		<segment id="236" parent="472" relname="joint">а экономическая и демографическая ситуация может кардинально измениться за несколько лет.</segment>
		<segment id="237" parent="238" relname="condition">Если мы предоставим несовершеннолетним беженцам право на свободу передвижения в будущем,</segment>
		<segment id="238" parent="473" relname="span">это позволит смягчить негативное впечатление от программы распределения сейчас.</segment>
		<segment id="239" parent="475" relname="purpose">Чтобы исключить попытки злоупотребить этим правом,</segment>
		<segment id="240" parent="474" relname="joint">можно сделать его доступным только для лиц, проживших в ЕС длительное время,</segment>
		<segment id="241" parent="474" relname="joint">или по достижении определенного уровня благосостояния.</segment>
		<segment id="242" parent="481" relname="span">Такой подход может погасить еще только зарождающиеся угрозы для европейской безопасности</segment>
		<segment id="243" parent="242" relname="elaboration">- например, возможную радикализацию беженцев в ближайшем будущем.</segment>
		<segment id="244" parent="479" relname="joint">После терактов в Мадриде в 2004 году в Евросоюзе наметилась явная тенденция к распространению "доморощенного терроризма" - особенно среди мигрантов второго поколения.</segment>
		<segment id="245" parent="480" relname="span">Также напряженность растет</segment>
		<segment id="246" parent="245" relname="cause">из-за ощущения субъективности европейских властей в части следования идеалам ЕС.</segment>
		<segment id="247" parent="491" relname="span">Гарантии свободного перемещения по Шенгенской зоне позволят предотвратить аналогичную ситуацию среди новоприбывших беженцев:</segment>
		<segment id="248" parent="477" relname="joint">они не будут чувствовать себя "взаперти" на территории отдельно взятой страны</segment>
		<segment id="249" parent="477" relname="joint">и тем более не станут брать пример с идеологов и подстрекателей за пределами Европы.</segment>
		<segment id="250" parent="506" relname="preparation">Реконструкция Шенгена</segment>
		<segment id="251" parent="503" relname="span">Важно понимать, что речь идет не о защите европейских ценностей ради самих ценностей.</segment>
		<segment id="252" parent="499" relname="span">Свобода перемещения по Европе лежит в основе веских коммерческих интересов</segment>
		<segment id="253" parent="252" relname="elaboration">(так, благодаря Шенгену сети курьерской доставки ежегодно экономят 80 млн. евро)</segment>
		<segment id="254" parent="500" relname="joint">и значительно укрепляет вес Евросоюза на международной арене.</segment>
		<segment id="255" parent="505" relname="span">Однако эти коммерческие и политические интересы удастся сохранить</segment>
		<segment id="256" parent="255" relname="condition">только при условии, если население ЕС будет по-прежнему видеть в свободе перемещения преимущество, а не источник опасности.</segment>
		<segment id="257" parent="507" relname="span">Нынешние показатели - еще не предел:</segment>
		<segment id="258" parent="259" relname="concession">несмотря на то, что Шенгенская зона существует 30 лет,</segment>
		<segment id="259" parent="501" relname="span">всего лишь около 14 млн. европейцев (менее 3%) проживают вне страны, в которой они родились.</segment>
		<segment id="260" parent="512" relname="span">Шенген был задуман как инновационный метод территориального управления.</segment>
		<segment id="261" parent="260" relname="evaluation">Он стал победой экономических и политических интересов над национальными противоречиями.</segment>
		<segment id="262" parent="508" relname="cause">Жизнеспособность проекта зависела от успехов ЕС по проведению эффективной политики в других странах.</segment>
		<segment id="263" parent="508" relname="span">В связи с этим членам Евросоюза нужно понять, как бороться с причинами миграции и преступности за рубежом,</segment>
		<segment id="264" parent="263" relname="purpose">чтобы вновь открыть границы без каких-либо опасений.</segment>
		<segment id="265" parent="502" relname="cause">Мир изменился,</segment>
		<segment id="266" parent="502" relname="span">и Евросоюзу стало сложнее пропагандировать идею свободного пересечения границ,</segment>
		<segment id="267" parent="266" relname="elaboration">на которой основываются остальные ценности ЕС.</segment>
		<segment id="268" parent="511" relname="span">Тем не менее ответ на изменившуюся международную обстановку обязан стать инновационным.</segment>
		<segment id="269" parent="510" relname="span">Европа не должна прибегать к традиционным мерам,</segment>
		<segment id="270" parent="269" relname="elaboration">которые скорее уместны для отдельно взятой нации.</segment>
		<group id="271" type="span" parent="272" relname="same-unit"/>
		<group id="272" type="multinuc" parent="273" relname="span"/>
		<group id="273" type="span" parent="274" relname="span"/>
		<group id="274" type="span" parent="515" relname="span"/>
		<group id="276" type="multinuc" parent="279" relname="contrast"/>
		<group id="277" type="multinuc" parent="278" relname="contrast"/>
		<group id="278" type="multinuc" parent="280" relname="joint"/>
		<group id="279" type="multinuc" parent="280" relname="joint"/>
		<group id="280" type="multinuc" parent="281" relname="span"/>
		<group id="281" type="span" parent="542" relname="span"/>
		<group id="282" type="span" parent="283" relname="span"/>
		<group id="283" type="span" parent="293" relname="span"/>
		<group id="284" type="span" parent="285" relname="joint"/>
		<group id="285" type="multinuc" parent="286" relname="joint"/>
		<group id="286" type="multinuc" parent="293" relname="elaboration"/>
		<group id="288" type="multinuc" parent="290" relname="span"/>
		<group id="289" type="span" parent="290" relname="cause"/>
		<group id="290" type="span" parent="291" relname="span"/>
		<group id="291" type="span" parent="517" relname="evidence"/>
		<group id="293" type="span" parent="294" relname="span"/>
		<group id="294" type="span" parent="295" relname="cause"/>
		<group id="295" type="span" parent="296" relname="span"/>
		<group id="296" type="span" parent="541" relname="span"/>
		<group id="297" type="span" parent="288" relname="joint"/>
		<group id="298" type="multinuc" parent="300" relname="cause"/>
		<group id="299" type="multinuc" parent="300" relname="span"/>
		<group id="300" type="span" parent="301" relname="span"/>
		<group id="301" type="span" parent="41" relname="concession"/>
		<group id="302" type="span" parent="304" relname="restatement"/>
		<group id="303" type="span" parent="304" relname="restatement"/>
		<group id="304" type="multinuc" parent="428" relname="span"/>
		<group id="305" type="span" parent="306" relname="same-unit"/>
		<group id="306" type="multinuc" parent="307" relname="joint"/>
		<group id="307" type="multinuc" parent="520" relname="span"/>
		<group id="308" type="multinuc" parent="316" relname="span"/>
		<group id="309" type="span" parent="310" relname="same-unit"/>
		<group id="310" type="multinuc" parent="308" relname="joint"/>
		<group id="312" type="multinuc" parent="314" relname="span"/>
		<group id="313" type="span" parent="312" relname="sequence"/>
		<group id="314" type="span" parent="315" relname="span"/>
		<group id="315" type="span" parent="539" relname="span"/>
		<group id="316" type="span" />
		<group id="317" type="multinuc" parent="318" relname="contrast"/>
		<group id="318" type="multinuc" parent="416" relname="span"/>
		<group id="319" type="span" parent="320" relname="same-unit"/>
		<group id="320" type="multinuc" parent="321" relname="comparison"/>
		<group id="321" type="multinuc" parent="544" relname="span"/>
		<group id="322" type="span" parent="323" relname="contrast"/>
		<group id="323" type="multinuc" parent="416" relname="elaboration"/>
		<group id="324" type="span" parent="323" relname="contrast"/>
		<group id="325" type="multinuc" parent="71" relname="elaboration"/>
		<group id="326" type="multinuc" parent="332" relname="span"/>
		<group id="327" type="span" parent="326" relname="contrast"/>
		<group id="328" type="multinuc" parent="329" relname="cause"/>
		<group id="329" type="span" parent="331" relname="span"/>
		<group id="330" type="span" parent="329" relname="evaluation"/>
		<group id="331" type="span" parent="74" relname="elaboration"/>
		<group id="332" type="span" parent="537" relname="span"/>
		<group id="333" type="span" parent="332" relname="elaboration"/>
		<group id="334" type="multinuc" parent="90" relname="elaboration"/>
		<group id="335" type="span" parent="336" relname="span"/>
		<group id="336" type="span" parent="337" relname="span"/>
		<group id="337" type="span" parent="338" relname="joint"/>
		<group id="338" type="multinuc" parent="344" relname="elaboration"/>
		<group id="339" type="multinuc" parent="343" relname="span"/>
		<group id="340" type="span" parent="338" relname="joint"/>
		<group id="341" type="span" parent="342" relname="contrast"/>
		<group id="342" type="multinuc" parent="346" relname="span"/>
		<group id="343" type="span" parent="344" relname="span"/>
		<group id="344" type="span" parent="345" relname="span"/>
		<group id="345" type="span" parent="346" relname="cause"/>
		<group id="346" type="span" parent="535" relname="span"/>
		<group id="347" type="span" parent="348" relname="same-unit"/>
		<group id="348" type="multinuc" parent="349" relname="contrast"/>
		<group id="349" type="multinuc" parent="419" relname="span"/>
		<group id="350" type="span" parent="349" relname="contrast"/>
		<group id="351" type="span" parent="352" relname="same-unit"/>
		<group id="352" type="multinuc" parent="356" relname="span"/>
		<group id="353" type="span" parent="354" relname="joint"/>
		<group id="354" type="multinuc" parent="356" relname="cause"/>
		<group id="355" type="span" parent="354" relname="joint"/>
		<group id="356" type="span" parent="420" relname="span"/>
		<group id="357" type="span" parent="372" relname="preparation"/>
		<group id="358" type="multinuc" parent="113" relname="purpose"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="369" relname="joint"/>
		<group id="361" type="span" parent="362" relname="same-unit"/>
		<group id="362" type="multinuc" parent="363" relname="span"/>
		<group id="363" type="span" parent="370" relname="span"/>
		<group id="364" type="multinuc" parent="366" relname="span"/>
		<group id="365" type="span" parent="364" relname="joint"/>
		<group id="366" type="span" parent="368" relname="span"/>
		<group id="367" type="multinuc" parent="371" relname="span"/>
		<group id="368" type="span" parent="367" relname="same-unit"/>
		<group id="369" type="multinuc" parent="371" relname="cause"/>
		<group id="370" type="span" parent="369" relname="joint"/>
		<group id="371" type="span" parent="372" relname="span"/>
		<group id="372" type="span" parent="533" relname="span"/>
		<group id="373" type="multinuc" parent="129" relname="elaboration"/>
		<group id="374" type="span" parent="373" relname="joint"/>
		<group id="375" type="multinuc" parent="382" relname="contrast"/>
		<group id="376" type="span" parent="377" relname="joint"/>
		<group id="377" type="multinuc" parent="378" relname="span"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="380" relname="elaboration"/>
		<group id="380" type="span" parent="381" relname="span"/>
		<group id="381" type="span" parent="382" relname="contrast"/>
		<group id="382" type="multinuc" parent="383" relname="span"/>
		<group id="383" type="span" parent="532" relname="span"/>
		<group id="384" type="span" parent="387" relname="joint"/>
		<group id="385" type="multinuc" parent="144" relname="elaboration"/>
		<group id="386" type="span" parent="143" relname="cause"/>
		<group id="387" type="multinuc" parent="140" relname="elaboration"/>
		<group id="388" type="span" parent="387" relname="joint"/>
		<group id="389" type="multinuc" parent="408" relname="joint"/>
		<group id="390" type="multinuc" parent="157" relname="elaboration"/>
		<group id="391" type="span" parent="392" relname="same-unit"/>
		<group id="392" type="multinuc" parent="409" relname="span"/>
		<group id="393" type="span" parent="392" relname="same-unit"/>
		<group id="394" type="span" parent="160" relname="elaboration"/>
		<group id="395" type="multinuc" parent="399" relname="cause"/>
		<group id="396" type="span" parent="395" relname="same-unit"/>
		<group id="397" type="multinuc" parent="399" relname="span"/>
		<group id="398" type="span" parent="397" relname="joint"/>
		<group id="399" type="span" parent="402" relname="span"/>
		<group id="400" type="multinuc" parent="166" relname="elaboration"/>
		<group id="401" type="span" parent="403" relname="span"/>
		<group id="402" type="span" parent="528" relname="span"/>
		<group id="403" type="span" parent="413" relname="joint"/>
		<group id="404" type="span" parent="405" relname="span"/>
		<group id="405" type="span" parent="531" relname="span"/>
		<group id="406" type="span" parent="410" relname="span"/>
		<group id="407" type="span" parent="406" relname="cause"/>
		<group id="408" type="multinuc" parent="411" relname="comparison"/>
		<group id="409" type="span" parent="411" relname="comparison"/>
		<group id="410" type="span" parent="529" relname="span"/>
		<group id="411" type="multinuc" parent="424" relname="span"/>
		<group id="412" type="span" parent="413" relname="joint"/>
		<group id="413" type="multinuc" parent="414" relname="comparison"/>
		<group id="414" type="multinuc" parent="424" relname="elaboration"/>
		<group id="415" type="span" parent="414" relname="comparison"/>
		<group id="416" type="span" parent="418" relname="span"/>
		<group id="417" type="span" parent="538" relname="span"/>
		<group id="418" type="span" parent="417" relname="evidence"/>
		<group id="419" type="span" parent="422" relname="span"/>
		<group id="420" type="span" parent="419" relname="elaboration"/>
		<group id="421" type="multinuc" parent="423" relname="span"/>
		<group id="422" type="span" parent="421" relname="contrast"/>
		<group id="423" type="span" parent="534" relname="span"/>
		<group id="424" type="span" parent="426" relname="span"/>
		<group id="425" type="span" parent="410" relname="evaluation"/>
		<group id="426" type="span" parent="153" relname="evidence"/>
		<group id="427" type="span" parent="428" relname="preparation"/>
		<group id="428" type="span" parent="429" relname="span"/>
		<group id="429" type="span" parent="430" relname="evidence"/>
		<group id="430" type="span" parent="540" relname="span"/>
		<group id="431" type="span" parent="433" relname="span"/>
		<group id="432" type="multinuc" parent="433" relname="elaboration"/>
		<group id="433" type="span" parent="439" relname="span"/>
		<group id="434" type="multinuc" parent="186" relname="elaboration"/>
		<group id="435" type="span" parent="434" relname="same-unit"/>
		<group id="436" type="span" parent="437" relname="same-unit"/>
		<group id="437" type="multinuc" parent="438" relname="span"/>
		<group id="438" type="span" parent="441" relname="span"/>
		<group id="439" type="span" parent="440" relname="joint"/>
		<group id="440" type="multinuc" parent="442" relname="span"/>
		<group id="441" type="span" parent="440" relname="joint"/>
		<group id="442" type="span" parent="526" relname="span"/>
		<group id="443" type="span" parent="201" relname="elaboration"/>
		<group id="444" type="span" parent="445" relname="contrast"/>
		<group id="445" type="multinuc" parent="448" relname="elaboration"/>
		<group id="446" type="span" parent="445" relname="contrast"/>
		<group id="447" type="span" parent="446" relname="span"/>
		<group id="448" type="span" parent="462" relname="span"/>
		<group id="449" type="span" parent="450" relname="same-unit"/>
		<group id="450" type="multinuc" parent="452" relname="span"/>
		<group id="451" type="multinuc" parent="452" relname="elaboration"/>
		<group id="452" type="span" parent="460" relname="span"/>
		<group id="453" type="span" parent="459" relname="span"/>
		<group id="454" type="multinuc" parent="470" relname="joint"/>
		<group id="455" type="span" parent="456" relname="contrast"/>
		<group id="456" type="multinuc" parent="471" relname="span"/>
		<group id="457" type="span" parent="458" relname="span"/>
		<group id="458" type="span" parent="470" relname="joint"/>
		<group id="459" type="span" parent="497" relname="span"/>
		<group id="460" type="span" parent="459" relname="purpose"/>
		<group id="461" type="span" parent="463" relname="span"/>
		<group id="462" type="span" parent="461" relname="elaboration"/>
		<group id="463" type="span" parent="194" relname="elaboration"/>
		<group id="464" type="multinuc" parent="469" relname="span"/>
		<group id="465" type="span" parent="225" relname="elaboration"/>
		<group id="466" type="multinuc" parent="229" relname="elaboration"/>
		<group id="467" type="span" parent="468" relname="span"/>
		<group id="468" type="span" parent="228" relname="cause"/>
		<group id="469" type="span" parent="495" relname="span"/>
		<group id="470" type="multinuc" parent="456" relname="contrast"/>
		<group id="471" type="span" parent="498" relname="span"/>
		<group id="472" type="multinuc" parent="484" relname="preparation"/>
		<group id="473" type="span" parent="482" relname="joint"/>
		<group id="474" type="multinuc" parent="475" relname="span"/>
		<group id="475" type="span" parent="483" relname="span"/>
		<group id="476" type="multinuc" parent="486" relname="span"/>
		<group id="477" type="multinuc" parent="247" relname="elaboration"/>
		<group id="479" type="multinuc" parent="481" relname="elaboration"/>
		<group id="480" type="span" parent="479" relname="joint"/>
		<group id="481" type="span" parent="489" relname="span"/>
		<group id="482" type="multinuc" parent="484" relname="span"/>
		<group id="483" type="span" parent="482" relname="joint"/>
		<group id="484" type="span" parent="485" relname="span"/>
		<group id="485" type="span" parent="486" relname="elaboration"/>
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" parent="488" relname="comparison"/>
		<group id="488" type="multinuc" parent="490" relname="span"/>
		<group id="489" type="span" parent="488" relname="comparison"/>
		<group id="490" type="span" parent="496" relname="span"/>
		<group id="491" type="span" parent="496" relname="conclusion"/>
		<group id="492" type="span" parent="494" relname="sequence"/>
		<group id="493" type="span" parent="494" relname="sequence"/>
		<group id="494" type="multinuc" parent="522" relname="span"/>
		<group id="495" type="span" parent="522" relname="preparation"/>
		<group id="496" type="span" />
		<group id="497" type="span" />
		<group id="498" type="span" parent="497" relname="evaluation"/>
		<group id="499" type="span" parent="500" relname="joint"/>
		<group id="500" type="multinuc" parent="251" relname="elaboration"/>
		<group id="501" type="span" parent="257" relname="elaboration"/>
		<group id="502" type="span" parent="509" relname="span"/>
		<group id="503" type="span" parent="504" relname="contrast"/>
		<group id="504" type="multinuc" parent="506" relname="span"/>
		<group id="505" type="span" parent="504" relname="contrast"/>
		<group id="506" type="span" />
		<group id="507" type="span" parent="506" relname="elaboration"/>
		<group id="508" type="span" parent="514" relname="span"/>
		<group id="509" type="span" parent="268" relname="concession"/>
		<group id="510" type="span" parent="268" relname="elaboration"/>
		<group id="511" type="span" />
		<group id="512" type="span" parent="513" relname="joint"/>
		<group id="513" type="multinuc" />
		<group id="514" type="span" parent="513" relname="joint"/>
		<group id="515" type="span" parent="543" relname="span"/>
		<group id="516" type="multinuc" parent="517" relname="span"/>
		<group id="517" type="span" parent="518" relname="span"/>
		<group id="518" type="span" parent="25" relname="elaboration"/>
		<group id="519" type="span" />
		<group id="520" type="span" parent="521" relname="span"/>
		<group id="521" type="span" parent="312" relname="sequence"/>
		<group id="522" type="span" parent="523" relname="span"/>
		<group id="523" type="span" parent="490" relname="preparation"/>
		<group id="524" type="span" parent="525" relname="span"/>
		<group id="525" type="span" />
		<group id="526" type="span" parent="527" relname="span"/>
		<group id="527" type="span" />
		<group id="528" type="span" />
		<group id="529" type="span" />
		<group id="530" type="span" parent="405" relname="preparation"/>
		<group id="531" type="span" />
		<group id="532" type="span" />
		<group id="533" type="span" />
		<group id="534" type="span" />
		<group id="535" type="span" parent="536" relname="span"/>
		<group id="536" type="span" />
		<group id="537" type="span" />
		<group id="538" type="span" />
		<group id="539" type="span" parent="316" relname="cause"/>
		<group id="540" type="span" />
		<group id="541" type="span" />
		<group id="542" type="span" />
		<group id="543" type="span" />
		<group id="544" type="span" parent="545" relname="span"/>
		<group id="545" type="span" parent="62" relname="elaboration"/>
		<group id="546" type="span" parent="404" relname="evaluation"/>
	</body>
</rst>