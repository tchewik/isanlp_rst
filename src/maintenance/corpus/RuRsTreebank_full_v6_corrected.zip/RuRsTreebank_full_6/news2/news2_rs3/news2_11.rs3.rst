<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="85" relname="preparation">Искусство: Выставка «Шупашкарт — 2015»</segment>
		<segment id="2" parent="85" relname="span">В Чувашском государственном художественном музее на прошлой неделе открылась 5-я Международная выставка дизайна, архитектуры и декоративно-прикладного искусства «Шупашкарт — 2015».</segment>
		<segment id="3" parent="2" relname="elaboration">Она занимает весь главный второй этаж ЧГХМ.</segment>
		<segment id="4" parent="89" relname="joint">Организаторы выставки — Союзы дизайнеров России и Чувашской Республики.</segment>
		<segment id="5" parent="87" relname="span">Вернисаж открыло эстрадное песенно-танцевальное трио девушек «Дуняша-style» в стилизованных платьях.</segment>
		<segment id="6" parent="5" relname="elaboration">Они пели на чувашском и русском языках.</segment>
		<segment id="7" parent="88" relname="sequence">Затем состоялся показ современных костюмов в национальном стиле.</segment>
		<segment id="8" parent="90" relname="span">В торжественной части выступали представители руководства Союза дизайнеров России и председатель правления Союза дизайнеров ЧР Александр Астраханцев.</segment>
		<segment id="9" parent="8" relname="elaboration">Вручались награды и членский билет СД РФ.</segment>
		<segment id="10" parent="92" relname="joint">В центральном зале экспонируются плакаты, в том числе, посвящённые русским и советским поэтам и юбилейным датам.</segment>
		<segment id="11" parent="91" relname="span">В восточной анфиладе представлены работы и нашего земляка, чувашского графика и живописца Владимира Игнатьева (1955-1994).</segment>
		<segment id="12" parent="11" relname="elaboration">Помнится, он был организатором в ЧГХМ актуальной Всероссийской выставки плаката «Волга – боль России» (1994).</segment>
		<segment id="13" parent="96" relname="joint">В соседнем зале на фоне своего красочного декоративного батика давала интервью местному телевидению чебоксарская художница и дизайнер Ирина Наумова.</segment>
		<segment id="14" parent="95" relname="span">Ближе к окну представлены ещё 8 акварелей автора.</segment>
		<segment id="15" parent="94" relname="span">На них изображены цветы – любимая тема прекрасной половины человечества.</segment>
		<segment id="16" parent="93" relname="span">Среди них выделяется «Южный пейзаж» с солнечным двориком.</segment>
		<segment id="17" parent="16" relname="evaluation">В нём есть настроение – радость бытия курортника, приехавшего в долгожданный летний отпуск на море из более прохладной средней полосы.</segment>
		<segment id="18" parent="98" relname="span">В южной анфиладе один из небольших залов почти полностью занимают натюрморты с цветами другого чебоксарского дизайнера, модельера и художницы Людмилы Шуркиной.</segment>
		<segment id="19" parent="20" relname="cause">Среди них – самый удачный, на наш взгляд, натюрморт с белым кувшином.</segment>
		<segment id="20" parent="97" relname="span">На его фоне я и попросил сфотографироваться автора.</segment>
		<segment id="21" parent="99" relname="span">Кроме натюрмортов в зале также представлены два авторских платья на манекенах.</segment>
		<segment id="22" parent="21" relname="elaboration">Вокруг них ходили заинтересовавшиеся дамы.</segment>
		<segment id="23" parent="102" relname="span">Отметим, что Персональная выставка Л.Шуркиной уже была в галерее «Серебряный век» Национальной библиотеки ЧР в 2013-м году.</segment>
		<segment id="24" parent="101" relname="joint">На ней тогда побывал ваш корреспондент,</segment>
		<segment id="25" parent="101" relname="joint">и, помнится, опубликовал свои заметки.</segment>
		<segment id="26" parent="146" relname="span">… Во время осмотра к автору этих строк обратилась с вопросом сотрудница музея по поводу другой публикации.</segment>
		<segment id="27" parent="105" relname="span">- Вы не из газеты…?</segment>
		<segment id="28" parent="104" relname="contrast">- Нет.</segment>
		<segment id="29" parent="104" relname="contrast">Но иногда посылаю туда свои материалы.</segment>
		<segment id="30" parent="107" relname="span">- Там напечатана информация о выставке Олега Польдяева с двумя иллюстрациями…</segment>
		<segment id="31" parent="106" relname="span">- Да я посылал туда такую информацию.</segment>
		<segment id="32" parent="31" relname="evaluation">Наверно, это она.</segment>
		<segment id="33" parent="34" relname="cause">- Когда мы увидели эти фотографии,</segment>
		<segment id="34" parent="108" relname="span">у нас возник вопрос.</segment>
		<segment id="35" parent="109" relname="contrast">На той выставке столько хороших пейзажей.</segment>
		<segment id="36" parent="109" relname="contrast">А напечатаны две…</segment>
		<segment id="37" parent="111" relname="span">Сотрудница замялась.</segment>
		<segment id="38" parent="37" relname="cause">У неё вертелись на языке слова, которые она не произнесла вслух.</segment>
		<segment id="39" parent="113" relname="span">- Две … ,</segment>
		<segment id="40" parent="112" relname="joint">- догадался автор</segment>
		<segment id="41" parent="112" relname="joint">и озвучил их.</segment>
		<segment id="42" parent="114" relname="span">- Д-да,</segment>
		<segment id="43" parent="42" relname="attribution">- подтвердила собеседница.</segment>
		<segment id="44" parent="45" relname="condition">(Если заменить это экспрессивное разговорно-просторечное словосочетание,</segment>
		<segment id="45" parent="147" relname="span">то можно заменить его нейтральной лексикой, эвфемизмом – обнажённые женщины.)</segment>
		<segment id="46" parent="145" relname="joint">- Интересно. Значит, напечатали.</segment>
		<segment id="47" parent="115" relname="joint">- Вы можете посмотреть газету в нашей библиотеке.</segment>
		<segment id="48" parent="115" relname="joint">Я покажу.</segment>
		<segment id="49" parent="50" relname="purpose">Чтобы ответить на вопрос</segment>
		<segment id="50" parent="116" relname="span">пришлось спуститься в музейную библиотеку для ознакомления со свежим номером газеты.</segment>
		<segment id="51" parent="118" relname="span">По пути сотрудница ненадолго подошла к коллегам и дизайнерам у фуршетного стола, установленного в уютном углу фойе.</segment>
		<segment id="52" parent="51" relname="elaboration">К тому моменту, когда мы в основном завершили осмотр экспозиции, содержимое стола  уже явно не представляло того привлекательного натюрморта, каким оно бывает в начале торжества.</segment>
		<segment id="53" parent="119" relname="span">Зато мы ещё успели в библиотеку,</segment>
		<segment id="54" parent="53" relname="elaboration">где совместно с библиотекарем разобрали публикацию с двумя иллюстрациями.</segment>
		<segment id="55" parent="121" relname="span">Сотрудниц интересовало</segment>
		<segment id="56" parent="55" relname="elaboration">– почему именно эти две работы заинтересовали автора, а не, например, пейзажи?</segment>
		<segment id="57" parent="58" relname="cause">- 1. У меня оставалось мало места в карте памяти фотоаппарата.</segment>
		<segment id="58" parent="122" relname="span">И остальные кадры могли не поместиться.</segment>
		<segment id="59" parent="123" relname="span">2. Выставку я увидел случайно,</segment>
		<segment id="60" parent="59" relname="evidence">так как о ней не знал.</segment>
		<segment id="61" parent="124" relname="joint">К тому же выставка работала последние дни.</segment>
		<segment id="62" parent="124" relname="joint">И скоро её должны были демонтировать.</segment>
		<segment id="63" parent="125" relname="cause">Я, кажется, спешил.</segment>
		<segment id="64" parent="125" relname="span">И время было ограничено.</segment>
		<segment id="65" parent="64" relname="elaboration">Сфотографировал оперативно то, что понравилось.</segment>
		<segment id="66" parent="127" relname="joint">Хотя и остальные произведения на выставке были все хороши.</segment>
		<segment id="67" parent="127" relname="joint">И желание сделать полный фотоальбом с выставки было.</segment>
		<segment id="68" parent="128" relname="contrast">Но ещё не освоил это в системе Google без помощи специалиста.</segment>
		<segment id="69" parent="131" relname="comparison">3. Есть логика мужская,</segment>
		<segment id="70" parent="131" relname="comparison">и женская.</segment>
		<segment id="71" parent="132" relname="elaboration">Взгляды мужчин и женщин, как известно, не всегда совпадают.</segment>
		<segment id="72" parent="134" relname="span">Что бросается, прежде всего, в глаза мужчин на выставке?</segment>
		<segment id="73" parent="72" relname="solutionhood">Правильно – жанр ню.</segment>
		<segment id="74" parent="138" relname="span">(Эти гендерные различия в современном европейском, американском, и вообще в западном обществе, а теперь и в российском, широко используются в рекламе.</segment>
		<segment id="75" parent="137" relname="span">Например, при рекламе какого-то товара, особенно дорогого, используются молоденькие симпатичные девушки с белозубыми улыбками в коротких одеждах или их фото крупным планом.</segment>
		<segment id="76" parent="136" relname="joint">Вспомните рекламу автомобилей на выставках, презентациях, в автосалонах и проч.</segment>
		<segment id="77" parent="136" relname="joint">Или – рекламные щиты (билборды) у обочин автодорог.</segment>
		<segment id="78" parent="138" relname="attribution">Это мне объясняла моя близкая родственница, изучавшая социальную психологию в вузе.</segment>
		<segment id="79" parent="139" relname="joint">Или посмотрите – как выглядят сотрудницы банков.)</segment>
		<segment id="80" parent="144" relname="joint">4. И вообще, непростой высокохудожественный жанр ню – один из самых древних и почитаемых в мировом изобразительном искусстве.</segment>
		<segment id="81" parent="143" relname="joint">5. Из двух иллюстраций только одна была в жанре ню.</segment>
		<segment id="82" parent="142" relname="span">Другая – скорее представляла бытовой жанр.</segment>
		<segment id="83" parent="141" relname="span">Это была работа «Сон»,</segment>
		<segment id="84" parent="83" relname="elaboration">где была изображена спящая женщина, накрытая красивым голубым одеялом.</segment>
		<group id="85" type="span" parent="86" relname="span"/>
		<group id="86" type="span" parent="89" relname="joint"/>
		<group id="87" type="span" parent="88" relname="sequence"/>
		<group id="88" type="multinuc" parent="89" relname="joint"/>
		<group id="89" type="multinuc" />
		<group id="90" type="span" parent="88" relname="sequence"/>
		<group id="91" type="span" parent="92" relname="joint"/>
		<group id="92" type="multinuc" />
		<group id="93" type="span" parent="15" relname="elaboration"/>
		<group id="94" type="span" parent="14" relname="elaboration"/>
		<group id="95" type="span" parent="96" relname="joint"/>
		<group id="96" type="multinuc" />
		<group id="97" type="span" parent="18" relname="elaboration"/>
		<group id="98" type="span" parent="100" relname="joint"/>
		<group id="99" type="span" parent="100" relname="joint"/>
		<group id="100" type="multinuc" parent="103" relname="joint"/>
		<group id="101" type="multinuc" parent="23" relname="elaboration"/>
		<group id="102" type="span" parent="103" relname="joint"/>
		<group id="103" type="multinuc" />
		<group id="104" type="multinuc" parent="27" relname="solutionhood"/>
		<group id="105" type="span" parent="145" relname="joint"/>
		<group id="106" type="span" parent="30" relname="solutionhood"/>
		<group id="107" type="span" parent="145" relname="joint"/>
		<group id="108" type="span" parent="110" relname="span"/>
		<group id="109" type="multinuc" parent="108" relname="elaboration"/>
		<group id="110" type="span" parent="145" relname="joint"/>
		<group id="111" type="span" parent="145" relname="joint"/>
		<group id="112" type="multinuc" parent="39" relname="attribution"/>
		<group id="113" type="span" parent="145" relname="joint"/>
		<group id="114" type="span" parent="148" relname="span"/>
		<group id="115" type="multinuc" parent="145" relname="joint"/>
		<group id="116" type="span" parent="117" relname="joint"/>
		<group id="117" type="multinuc" />
		<group id="118" type="span" parent="120" relname="contrast"/>
		<group id="119" type="span" parent="120" relname="contrast"/>
		<group id="120" type="multinuc" parent="117" relname="joint"/>
		<group id="121" type="span" parent="117" relname="joint"/>
		<group id="122" type="span" parent="144" relname="joint"/>
		<group id="123" type="span" parent="130" relname="joint"/>
		<group id="124" type="multinuc" parent="130" relname="joint"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="129" relname="span"/>
		<group id="127" type="multinuc" parent="128" relname="contrast"/>
		<group id="128" type="multinuc" parent="126" relname="concession"/>
		<group id="129" type="span" parent="124" relname="joint"/>
		<group id="130" type="multinuc" parent="144" relname="joint"/>
		<group id="131" type="multinuc" parent="132" relname="span"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" parent="134" relname="preparation"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="140" relname="span"/>
		<group id="136" type="multinuc" parent="75" relname="evidence"/>
		<group id="137" type="span" parent="74" relname="evidence"/>
		<group id="138" type="span" parent="149" relname="span"/>
		<group id="139" type="multinuc" parent="135" relname="background"/>
		<group id="140" type="span" parent="144" relname="joint"/>
		<group id="141" type="span" parent="82" relname="evidence"/>
		<group id="142" type="span" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="144" relname="joint"/>
		<group id="144" type="multinuc" />
		<group id="145" type="multinuc" parent="26" relname="elaboration"/>
		<group id="146" type="span" />
		<group id="147" type="span" parent="114" relname="elaboration"/>
		<group id="148" type="span" parent="145" relname="joint"/>
		<group id="149" type="span" parent="139" relname="joint"/>
	</body>
</rst>