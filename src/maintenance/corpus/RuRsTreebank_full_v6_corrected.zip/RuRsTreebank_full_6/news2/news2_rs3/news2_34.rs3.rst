<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >Участники саммита ОДКБ продемонстрировали свою решительность в борьбе против терроризма</segment>
		<segment id="2" parent="351" relname="span">Очередная сессия Совета коллективной безопасности Организации Договора о коллективной безопасности (ОДКБ) завершила свою работу в Душанбе 15 сентября 2015 года.</segment>
		<segment id="3" parent="220" relname="span">Вопросы эффективного реагирования на наиболее актуальные военно-политические вызовы,</segment>
		<segment id="4" parent="3" relname="elaboration">связанные с активизацией экстремистских и террористических группировок, а также дестабилизацией обстановки у границ стран ОДКБ,</segment>
		<segment id="5" parent="221" relname="span">стали приоритетной темой встречи,</segment>
		<segment id="6" parent="351" relname="elaboration">участие в которой приняли главы России, Армении, Белоруссии, Казахстана, Кыргызстана и Таджикистана.</segment>
		<segment id="7" parent="248" relname="span">При этом особое внимание в ходе саммита было уделено рассмотрению итогов внезапной проверки Коллективных сил оперативного реагирования (КСОР).</segment>
		<segment id="8" parent="411" relname="attribution">Как было отмечено,</segment>
		<segment id="9" parent="223" relname="joint">поставленные цели достигнуты,</segment>
		<segment id="10" parent="223" relname="joint">апробирован механизм функционирования системы кризисного реагирования ОДКБ в части, касающейся применения сил и средств коллективной безопасности,</segment>
		<segment id="11" parent="223" relname="joint">а также отработаны вопросы по приведению соединений и воинских частей, входящих в КСОР, в высшие степени боевой готовности с выполнением комплекса мероприятий в соответствии с национальными планами.</segment>
		<segment id="12" parent="13" relname="attribution">По мнению президента Кыргызстана Алмазбека Атамбаева (Almazbek Atambaev),</segment>
		<segment id="13" parent="352" relname="span">расширение влияния в Афганистане террористической группировки "Исламское государство" (ИГ) несет прямую угрозу для безопасности стран-членов ОДКБ.</segment>
		<segment id="14" parent="225" relname="span">"Особую обеспокоенность вызывают многочисленные факты вербовки и выезда граждан наших республик</segment>
		<segment id="15" parent="14" relname="purpose">для участия в вооруженных конфликтах на стороне ИГ</segment>
		<segment id="16" parent="224" relname="span">и их последующее возвращение</segment>
		<segment id="17" parent="16" relname="purpose">для продолжения террористической и вербовочной деятельности в странах региона",</segment>
		<segment id="18" parent="19" relname="attribution">- сказал он,</segment>
		<segment id="19" parent="413" relname="span">добавив, что в такой ситуации важно сконцентрировать усилия организации на решении практических проблем.</segment>
		<segment id="20" parent="231" relname="attribution">Глава Белоруссии Александр Лукашенко (Alexander Lukashenko) также отметил,</segment>
		<segment id="21" parent="230" relname="joint">что тлеющие конфликты обострились,</segment>
		<segment id="22" parent="230" relname="joint">и возникли новые очаги нестабильности в странах Ближнего Востока, Афганистане и у границ стран ОДКБ.</segment>
		<segment id="23" parent="229" relname="span">"В такой ситуации требуется укрепление военной мощи и Коллективных сил оперативного реагирования",</segment>
		<segment id="24" parent="355" relname="span">- подчеркнул он,</segment>
		<segment id="25" parent="24" relname="background">выступая на заседании Совета ОДКБ в расширенном составе.</segment>
		<segment id="26" parent="27" relname="attribution">Между тем президент Армении Серж Саргсян (Serzh Sargsyan) обратил внимание на то,</segment>
		<segment id="27" parent="415" relname="span">что организация прошла 20-летний период становления,</segment>
		<segment id="28" parent="416" relname="joint">и заявил о необходимости принятия новой долгосрочной стратегии.</segment>
		<segment id="29" parent="356" relname="span">"Эту работу нужно продолжить на системной основе,</segment>
		<segment id="30" parent="29" relname="elaboration">имея перед собой четко обозначенный ориентир развития на среднесрочную перспективу.</segment>
		<segment id="31" parent="356" relname="elaboration">Исходя из этого, предлагаю в качестве одного из первых приоритетов на предстоящий период зафиксировать завершение разработки стратегии коллективной безопасности ОДКБ на период до 2025 года и ее принятие в 2016 году",</segment>
		<segment id="32" parent="234" relname="attribution">- сказал он.</segment>
		<segment id="33" parent="237" relname="attribution">В свою очередь президент России Владимир Путин (Vladimir Putin) напомнил,</segment>
		<segment id="34" parent="236" relname="joint">что "Исламское государство" уже контролирует значительные территории</segment>
		<segment id="35" parent="236" relname="joint">и планирует распространить свою активность на Европу и Азию.</segment>
		<segment id="36" parent="240" relname="span">"Элементарный здравый смысл, ответственность за глобальную и региональную безопасность требуют объединения усилий мирового сообщества против этой угрозы.</segment>
		<segment id="37" parent="238" relname="joint">Нужно отложить в сторону геополитические амбиции,</segment>
		<segment id="38" parent="359" relname="span">отказаться от так называемых двойных стандартов, от политики прямого или косвенного использования отдельных террористических группировок</segment>
		<segment id="39" parent="358" relname="span">для достижения собственных конъюнктурных целей,</segment>
		<segment id="40" parent="39" relname="elaboration">в том числе смены неугодных кому бы то ни было правительств и режимов.</segment>
		<segment id="41" parent="240" relname="elaboration">Россия, как вы знаете, предложила безотлагательно взяться за оформление широкой коалиции по противодействию экстремистам.</segment>
		<segment id="42" parent="364" relname="span">Она должна объединить всех,</segment>
		<segment id="43" parent="239" relname="joint">кто готов внести</segment>
		<segment id="44" parent="410" relname="span">и уже вносит реальный вклад в борьбу с террором</segment>
		<segment id="45" parent="365" relname="span">― так, как это делают сегодня вооруженные силы и Ирака, и самой Сирии.</segment>
		<segment id="46" parent="250" relname="span">Мы поддерживаем правительство Сирии,</segment>
		<segment id="47" parent="46" relname="evaluation">хотел бы это сказать,</segment>
		<segment id="48" parent="360" relname="same-unit">в противостоянии террористической агрессии,</segment>
		<segment id="49" parent="241" relname="joint">оказываем</segment>
		<segment id="50" parent="241" relname="joint">и будем оказывать ему необходимую военно-техническую помощь</segment>
		<segment id="51" parent="242" relname="joint">и призываем присоединиться к нам другие страны",</segment>
		<segment id="52" parent="362" relname="attribution">― сказал российский лидер.</segment>
		<segment id="53" parent="366" relname="attribution">По его словам,</segment>
		<segment id="54" parent="366" relname="span">страны Организации Договора о коллективной безопасности намерены и дальше укреплять взаимодействие своих вооруженных формирований.</segment>
		<segment id="55" parent="54" relname="elaboration">"Планируется целый ряд мероприятий по этому направлению.</segment>
		<segment id="56" parent="245" relname="attribution">Хотел бы подчеркнуть также,</segment>
		<segment id="57" parent="243" relname="joint">что наше сотрудничество в рамках ОДКБ, безусловно, не направлено против кого бы то ни было.</segment>
		<segment id="58" parent="243" relname="joint">Мы открыты к конструктивному взаимодействию</segment>
		<segment id="59" parent="244" relname="elaboration">- именно такой подход закреплен в итоговом заявлении",</segment>
		<segment id="60" parent="367" relname="attribution">― подчеркнул Владимир Путин.</segment>
		<segment id="61" parent="370" relname="attribution">Комментируя итоги встречи на высшем уровне, научный сотрудник сектора проблем региональной безопасности Российского института стратегических исследований (РИСИ) Иван Моньков (Ivan Monkov) назвал завершившуюся сессию ОДКБ значимым шагом на пути к построению устойчивой системы коллективной безопасности в регионе.</segment>
		<segment id="62" parent="63" relname="cause">"Нарастающая международная напряженность, изоляция Москвы, террористические угрозы со стороны набирающего влияния "Исламского государства"</segment>
		<segment id="63" parent="372" relname="span">диктуют необходимость повышения боеспособности организации.</segment>
		<segment id="64" parent="371" relname="span">В связи с этим в Душанбе основное внимание было приковано к вопросам развития военной составляющей объединения.</segment>
		<segment id="65" parent="373" relname="span">Доклады об итогах проведения внезапных проверок КСОР и совместных учений дают понять, что организация способна реагировать на возможные кризисные ситуации на границах государств договора,</segment>
		<segment id="66" parent="65" relname="elaboration">которые более нельзя связывать с исключительной компетенцией одной страны",</segment>
		<segment id="67" parent="251" relname="attribution">― сказал он в интервью ИА "PenzaNews".</segment>
		<segment id="68" parent="253" relname="attribution">По словам эксперта,</segment>
		<segment id="69" parent="252" relname="joint">наиболее значимым результатом саммита стало подписание соглашений о коллективных авиационных силах ОДКБ и соглашения в области перевозок воинских и других формирований, движимого имущества и продукции военного назначения, а также первичное обсуждение вопроса о создании коллективной системы ПВО.</segment>
		<segment id="70" parent="256" relname="span">"Что касается терроризма, то впервые за 20-летнюю историю существования организации, страны-члены сталкиваются с реальной необходимостью противостояния внешней угрозе,</segment>
		<segment id="71" parent="255" relname="span">которая исходит от международного террористического формирования "Исламское государство",</segment>
		<segment id="72" parent="71" relname="elaboration">распространяющего сферу своего влияния на Афганистан.</segment>
		<segment id="73" parent="254" relname="restatement">Данный факт требует повышения уровня обороноспособности объединения, готовности к оперативному антикризисному реагированию",</segment>
		<segment id="74" parent="374" relname="attribution">― отметил собеседник агентства.</segment>
		<segment id="75" parent="259" relname="span">При этом он высоко оценил тот уровень развития, на котором сейчас находится организация,</segment>
		<segment id="76" parent="75" relname="elaboration">подчеркнув заметный прогресс в ее работе.</segment>
		<segment id="77" parent="376" relname="span">"ОДКБ постепенно перерастает из формального регионального объединения в рабочую трансрегиональную структуру,</segment>
		<segment id="78" parent="79" relname="attribution">участники которой заявляют</segment>
		<segment id="79" parent="418" relname="span">о намерении выступить единым фронтом на 70-й сессии Генассамблеи ООН в Нью-Йорке по тематике предотвращения размещения оружия в космосе, а также о мерах по противодействию международному терроризму",</segment>
		<segment id="80" parent="260" relname="attribution">― пояснил Иван Моньков.</segment>
		<segment id="81" parent="378" relname="solutionhood">Отвечая на вопрос о перспективах дальнейшего сотрудничества стран-членов ОДКБ,</segment>
		<segment id="82" parent="83" relname="attribution">он уточнил,</segment>
		<segment id="83" parent="378" relname="span">что определяющим является сирийский кризис.</segment>
		<segment id="84" parent="85" relname="condition">"В случае поражения правительства Башара Асада (Bashar Assad)</segment>
		<segment id="85" parent="379" relname="span">вариант развития событий, при котором боевики ИГ устремят свой взор на Иран, а за ним на Кавказ и Центральную Азию, является вероятным.</segment>
		<segment id="86" parent="380" relname="span">В такой ситуации ОДКБ способна перерасти из регионального военно-политического блока в гаранта обеспечения коллективной безопасности глобального уровня",</segment>
		<segment id="87" parent="380" relname="attribution">― предположил эксперт.</segment>
		<segment id="88" parent="89" relname="attribution">В свою очередь депутат Национального собрания Армении Теван Погосян (Tevan Poghosyan) высказал мнение о том,</segment>
		<segment id="89" parent="382" relname="span">что ОДКБ к настоящему времени не смогла стать организацией, ставящей во главу угла понятие "коллективная безопасность".</segment>
		<segment id="90" parent="285" relname="span">"В реальности интересы стран-участниц этого альянса в большей мере направлены на сотрудничество с Россией, а не друг с другом,</segment>
		<segment id="91" parent="90" relname="elaboration">не говоря уже о защите друг друга.</segment>
		<segment id="92" parent="286" relname="span">Нужно признать, что подобные объединения наиболее эффективны в том случае,</segment>
		<segment id="93" parent="92" relname="condition">если работают как сетевая система взаимопомощи и взаимозависимости.</segment>
		<segment id="94" parent="383" relname="span">Между союзниками по ОДКБ нет общего чувства и восприятия целеполагания.</segment>
		<segment id="95" parent="384" relname="span">В результате иногда какая-либо страна-участница на международной арене может вполне умышленно проигнорировать жизненные интересы своего союзника",</segment>
		<segment id="96" parent="385" relname="attribution">― пояснил он свою позицию.</segment>
		<segment id="97" parent="98" relname="attribution">По словам политика,</segment>
		<segment id="98" parent="388" relname="span">прозвучавшие в ходе саммита заявления не отвечают на реальные вызовы и угрозы каждой страны-участницы.</segment>
		<segment id="99" parent="386" relname="contrast">"Азербайджан каждый день организовывает диверсии и военные вылазки на границе с Арменией,</segment>
		<segment id="100" parent="386" relname="contrast">однако ОДКБ это игнорирует.</segment>
		<segment id="101" parent="387" relname="attribution">Я считаю,</segment>
		<segment id="102" parent="387" relname="span">что об этом должны говорить именно Белоруссия, Казахстан, Кыргызстан, Таджикистан и Россия как союзники Армении.</segment>
		<segment id="103" parent="102" relname="evaluation">Это были бы шаги, соответствующие букве и духу коллективной безопасности",</segment>
		<segment id="104" parent="390" relname="attribution">― сказал Теван Погосян.</segment>
		<segment id="105" parent="292" relname="attribution">По его мнению,</segment>
		<segment id="106" parent="291" relname="joint">в ближайшем будущем ОДКБ не сможет существенно повысить свою значимость на международной арене,</segment>
		<segment id="107" parent="291" relname="joint">а члены альянса будут укреплять компонент безопасности в двустороннем сотрудничестве с Россией.</segment>
		<segment id="108" parent="295" relname="attribution">Директор Центра региональных исследований в Ереване, бывший сотрудник аппарата Сената США Ричард Киракосян (Richard Giragosyan) также отметил,</segment>
		<segment id="109" parent="295" relname="span">что саммит Организации Договора о коллективной безопасности в Душанбе многих в Армении разочаровал.</segment>
		<segment id="110" parent="296" relname="span">"Это объясняется отсутствием какого-либо упоминания нагорно-карабахского конфликта в декларации саммита.</segment>
		<segment id="111" parent="112" relname="cause">Учитывая эскалацию напряженности и участившиеся атаки со стороны Азербайджана,</segment>
		<segment id="112" parent="294" relname="span">армяне ожидали более очевидной поддержки партнеров по ОДКБ",</segment>
		<segment id="113" parent="296" relname="attribution">― пояснил он.</segment>
		<segment id="114" parent="115" relname="attribution">При этом, по словам эксперта,</segment>
		<segment id="115" parent="392" relname="span">акцент саммита на борьбу с терроризмом был вполне естественным и важным.</segment>
		<segment id="116" parent="299" relname="span">"Во-первых, это напрямую касается проблемы исламистского терроризма, в частности, "Исламского государства",</segment>
		<segment id="117" parent="116" relname="elaboration">которое имеет собственные каналы связи с территориями Северного Кавказа и странами Центральной Азии.</segment>
		<segment id="118" parent="298" relname="joint">Во-вторых, ситуация в области безопасности в Афганистане также оказывает непосредственное влияние на общую стабильность в регионе",</segment>
		<segment id="119" parent="300" relname="attribution">― уточнил Ричард Киракосян.</segment>
		<segment id="120" parent="121" relname="attribution">По его мнению,</segment>
		<segment id="121" parent="308" relname="span">ведущую роль в организации сейчас играет Россия,</segment>
		<segment id="122" parent="304" relname="span">однако если раньше это было позитивным моментом,</segment>
		<segment id="123" parent="122" relname="elaboration">демонстрирующим заинтересованность Москвы в обеспечении безопасности своих партнеров,</segment>
		<segment id="124" parent="305" relname="span">то теперь ОДКБ напрямую ассоциируется с российской конфронтацией с Западом.</segment>
		<segment id="125" parent="126" relname="attribution">Ричард Киракосян отметил также,</segment>
		<segment id="126" parent="306" relname="cause">что будущее сотрудничество в рамках ОДКБ осложнено присущим отдельным государствам-членам соперничеством и конкуренцией.</segment>
		<segment id="127" parent="128" relname="condition">"Пока члены организации не смогут урегулировать эти разногласия,</segment>
		<segment id="128" parent="394" relname="span">ОДКБ по-прежнему будет нуждаться в твердом российском руководстве",</segment>
		<segment id="129" parent="394" relname="attribution">― сказал он.</segment>
		<segment id="130" parent="316" relname="attribution">Между тем научный сотрудник Аналитического центра МГИМО МИД РФ, эксперт Российского совета по международным делам Шарбатулло Содиков (Sharbatullo Sodikov) оценил перспективы дальнейшего взаимодействия более позитивно.</segment>
		<segment id="131" parent="310" relname="span">"ОДКБ - одна из крупнейших региональных организаций современности,</segment>
		<segment id="132" parent="395" relname="span">полных аналогов которой нет:</segment>
		<segment id="133" parent="311" relname="span">ведь она охраняет безопасность на постсоветском пространстве ― геополитической целостности,</segment>
		<segment id="134" parent="133" relname="elaboration">которая появилась в свете истории сравнительно недавно.</segment>
		<segment id="135" parent="312" relname="span">Актуальность задач ОДКБ ― это ее внешнеполитическая активность, активность общего командования ее войск,</segment>
		<segment id="136" parent="135" relname="elaboration">которые построены по принципу КСОР.</segment>
		<segment id="137" parent="313" relname="span">Значимость и влиятельность ОДКБ подчеркивает ее углубляющееся сотрудничество с ООН,</segment>
		<segment id="138" parent="137" relname="elaboration">ведь последняя ставит своей задачей усиление работы в регионах мира с целью повышения уровня безопасности",</segment>
		<segment id="139" parent="315" relname="attribution">― отметил аналитик.</segment>
		<segment id="140" parent="141" relname="attribution">По его словам,</segment>
		<segment id="141" parent="317" relname="span">итоги саммита Организации Договора о коллективной безопасности нельзя недооценивать.</segment>
		<segment id="142" parent="318" relname="span">"Отмечено всемирное значение угрозы террористических нападений на таджикско-афганской границе.</segment>
		<segment id="143" parent="397" relname="span">На фоне продвигающегося сотрудничества ООН и ОДКБ решение саммита, принятое в интересах необходимой военной помощи Таджикистану,</segment>
		<segment id="144" parent="396" relname="span">имеет мировое значение - в частности, в борьбе с таджикской оппозицией,</segment>
		<segment id="145" parent="144" relname="elaboration">которая по ряду пунктов сближается с ИГ",</segment>
		<segment id="146" parent="318" relname="attribution">― сказал Шарбатулло Содиков.</segment>
		<segment id="147" parent="148" relname="background">"Приветствуя и придерживаясь принципа невмешательства во внутренние дела стран-членов ОДКБ,</segment>
		<segment id="148" parent="319" relname="span">организация нашла способ четкого вооруженного противодействия покушениям с территории Афганистана на свободу и независимость Таджикистана,</segment>
		<segment id="149" parent="320" relname="span">а также подытожила задачи будущего</segment>
		<segment id="150" parent="149" relname="elaboration">― сохранение безопасности республик Центральной Азии",</segment>
		<segment id="151" parent="322" relname="attribution">― добавил он.</segment>
		<segment id="152" parent="323" relname="span">Кроме того, КСОР ОДКБ,</segment>
		<segment id="153" parent="152" relname="attribution">по словам эксперта,</segment>
		<segment id="154" parent="399" relname="span">является действенным инструментом</segment>
		<segment id="155" parent="154" relname="purpose">для обеспечения безопасности границ и суверенитета стран-членов организации.</segment>
		<segment id="156" parent="325" relname="span">"Представляется, что основным и самым успешным направлением дальнейшего сотрудничества будет отвод угрозы безопасности республик Центральной Азии,</segment>
		<segment id="157" parent="156" relname="elaboration">идущей из Афганистана.</segment>
		<segment id="158" parent="326" relname="span">Тем самым Россия как ведущий и наиболее богатый член ОДКБ задаст цель:</segment>
		<segment id="159" parent="158" relname="elaboration">сплотить новую - непроамериканскую - коалицию в борьбе с терроризмом и экстремизмом, в частности, с ИГ",</segment>
		<segment id="160" parent="328" relname="attribution">― отметил Шарбатулло Содиков.</segment>
		<segment id="161" parent="400" relname="evaluation">В свою очередь руководитель программы по изучению Восточной Европы, России и Средней Азии при Центре Роберта Боша Германского общества внешней политики Штефан Майстер (Stefan Meister) назвал итоги саммита не столь значительными.</segment>
		<segment id="162" parent="331" relname="contrast">"Президент России пытается связать проблему терроризма на Ближнем Востоке с Центральной Азией,</segment>
		<segment id="163" parent="331" relname="contrast">однако игнорирует тот факт, что растущая поддержка исламистских группировок в некоторых странах имеет внутригосударственные корни.</segment>
		<segment id="164" parent="165" relname="concession">В то время как исламистское давление из Афганистана на страны Центральной Азии увеличивается,</segment>
		<segment id="165" parent="330" relname="span">этот регион не является целью для ИГ.</segment>
		<segment id="166" parent="333" relname="span">Это означает, что Владимир Путин использовал саммит ОДКБ в большей степени для обращения к Соединенным Штатам и международному сообществу, а не к странам-участницам договора",</segment>
		<segment id="167" parent="333" relname="attribution">― сказал аналитик.</segment>
		<segment id="168" parent="401" relname="attribution">Он добавил,</segment>
		<segment id="169" parent="401" relname="span">что Россия является единственной страной,</segment>
		<segment id="170" parent="335" relname="joint">заинтересованной в том, чтобы быть проводником политики в сфере безопасности в регионе</segment>
		<segment id="171" parent="334" relname="span">и помогать с поставкой оружия государствам,</segment>
		<segment id="172" parent="171" relname="elaboration">которые нуждаются в защите своих границ.</segment>
		<segment id="173" parent="336" relname="attribution">По мнению эксперта,</segment>
		<segment id="174" parent="175" relname="concession">саммит не сможет серьезным образом повлиять на сложившуюся ситуацию,</segment>
		<segment id="175" parent="336" relname="span">однако сотрудничество в области безопасности будет продолжено.</segment>
		<segment id="176" parent="337" relname="joint">"В центре внимания организации окажется внутренняя политика стран.</segment>
		<segment id="177" parent="337" relname="joint">ОДКБ будет оставаться региональной структурой, помогающей стабилизировать безопасность в первую очередь в Центральной Азии",</segment>
		<segment id="178" parent="338" relname="attribution">― заключил Штефан Майстер.</segment>
		<segment id="179" parent="342" relname="attribution">Между тем, по словам старшего научного сотрудника ПИР-Центра Вадима Козюлина (Vadim Kozyulin),</segment>
		<segment id="180" parent="341" relname="joint">саммит показал, что лидеры государств ОДКБ видят реальную угрозу со стороны ИГ у своих границ,</segment>
		<segment id="181" parent="341" relname="joint">и готовятся противостоять ей в практическом плане.</segment>
		<segment id="182" parent="405" relname="preparation">"Именно прикладная сторона этой подготовки была сквозной темой всего саммита.</segment>
		<segment id="183" parent="344" relname="span">Отчасти это, возможно, связано с тем, что встреча проходила на фоне антитеррористической операции,</segment>
		<segment id="184" parent="183" relname="elaboration">проводимой в это самое время спецслужбами Таджикистана.</segment>
		<segment id="185" parent="343" relname="joint">Поэтому и речь шла об укреплении таджикско-афганской границы,</segment>
		<segment id="186" parent="343" relname="joint">усилении вооруженных сил.</segment>
		<segment id="187" parent="403" relname="span">Обсуждался вопрос об обязательности решений блока для государств-членов и о создании постоянно действующих эффективных совместных группировок войск, в том числе объединений ПВО и сил специальных операций.</segment>
		<segment id="188" parent="347" relname="joint">Страны приняли решение о создании центра кризисного реагирования ОДКБ на базе Минобороны РФ</segment>
		<segment id="189" parent="347" relname="joint">и обсудили формирование совместных авиационных сил.</segment>
		<segment id="190" parent="348" relname="span">То есть речь зашла о передаче странами части суверенных прав в руки организации,</segment>
		<segment id="191" parent="190" relname="evaluation">и это очень серьезная мера",</segment>
		<segment id="192" parent="406" relname="attribution">― отметил эксперт.</segment>
		<segment id="193" parent="283" relname="preparation">"В этом году в Таджикистане на границе с Афганистаном прошли масштабные маневры сил ОДКБ.</segment>
		<segment id="194" parent="276" relname="span">Это важно с военной точки зрения,</segment>
		<segment id="195" parent="194" relname="elaboration">ибо позволило отработать взаимодействие и быстрое реагирование на кризисную ситуацию,</segment>
		<segment id="196" parent="281" relname="span">а также важно с политической и психологической стороны:</segment>
		<segment id="197" parent="279" relname="span">жители удаленных районов Таджикистана увидели, что ОДКБ их не бросит,</segment>
		<segment id="198" parent="197" relname="elaboration">что организация в состоянии помочь не только словом, но и делом.</segment>
		<segment id="199" parent="278" relname="span">А боевики с сопредельных афганских районов получили сигнал о том,</segment>
		<segment id="200" parent="277" relname="span">что с соседями лучше жить в мире</segment>
		<segment id="201" parent="200" relname="cause">― у них есть серьезные защитники",</segment>
		<segment id="202" parent="284" relname="attribution">― добавил он.</segment>
		<segment id="203" parent="273" relname="attribution">По словам аналитика,</segment>
		<segment id="204" parent="273" relname="span">ОДКБ ― сравнительно молодая организация,</segment>
		<segment id="205" parent="204" relname="elaboration">которая вместе с тем имеет значительный послужной список, опыт проведения совместных операций и взаимодействия с международными организациями.</segment>
		<segment id="206" parent="409" relname="span">"Помимо военной и антитеррористической составляющей, у нее появился миротворческий компонент.</segment>
		<segment id="207" parent="206" relname="elaboration">Судя по международным новостям, он может оказаться очень востребован",</segment>
		<segment id="208" parent="409" relname="attribution">― предположил Вадим Козюлин.</segment>
		<segment id="209" parent="210" relname="attribution">Он также подчеркнул,</segment>
		<segment id="210" parent="271" relname="span">что у стран-участниц сложилась хорошая практика взаимодействия не только по военным, но и по политическим вопросам.</segment>
		<segment id="211" parent="269" relname="joint">"Обстановка в мире накаляется, возникают новые угрозы</segment>
		<segment id="212" parent="269" relname="joint">и не исчезают старые.</segment>
		<segment id="213" parent="408" relname="span">Значит, для ОДКБ будут возможности проявить себя",</segment>
		<segment id="214" parent="408" relname="attribution">― резюмировал эксперт.</segment>
		<segment id="215" parent="267" relname="span">Организация Договора о коллективной безопасности (ОДКБ) - военно-политический союз, созданный на основе одноименного договора,</segment>
		<segment id="216" parent="215" relname="elaboration">подписанного Арменией, Казахстаном, Кыргызстаном, Россией, Таджикистаном и Узбекистаном 15 мая 1992 года в Ташкенте.</segment>
		<segment id="217" parent="266" relname="sequence">В 1993 году к объединению присоединились Азербайджан, Грузия и Белоруссия.</segment>
		<segment id="218" parent="266" relname="sequence">Впоследствии Грузия, Азербайджан и Узбекистан покинули ряды организации.</segment>
		<segment id="219" parent="268" relname="purpose">Задачей ОДКБ является защита территориально-экономического пространства стран-участниц договора совместными усилиями армий и вспомогательных подразделений от любых внешних военно-политических агрессоров, международных террористов, а также от природных катастроф крупного масштаба.</segment>
		<group id="220" type="span" parent="350" relname="same-unit"/>
		<group id="221" type="span" parent="350" relname="same-unit"/>
		<group id="222" type="span" />
		<group id="223" type="multinuc" parent="411" relname="span"/>
		<group id="224" type="span" parent="226" relname="joint"/>
		<group id="225" type="span" parent="226" relname="joint"/>
		<group id="226" type="multinuc" parent="227" relname="span"/>
		<group id="227" type="span" parent="353" relname="span"/>
		<group id="228" type="span" parent="414" relname="span"/>
		<group id="229" type="span" parent="232" relname="span"/>
		<group id="230" type="multinuc" parent="231" relname="span"/>
		<group id="231" type="span" parent="354" relname="span"/>
		<group id="232" type="span" />
		<group id="234" type="span" parent="235" relname="span"/>
		<group id="235" type="span" parent="417" relname="span"/>
		<group id="236" type="multinuc" parent="237" relname="span"/>
		<group id="237" type="span" parent="357" relname="span"/>
		<group id="238" type="multinuc" parent="36" relname="elaboration"/>
		<group id="239" type="multinuc" parent="42" relname="elaboration"/>
		<group id="240" type="span" />
		<group id="241" type="multinuc" parent="242" relname="joint"/>
		<group id="242" type="multinuc" parent="361" relname="joint"/>
		<group id="243" type="multinuc" parent="244" relname="span"/>
		<group id="244" type="span" parent="245" relname="span"/>
		<group id="245" type="span" parent="367" relname="span"/>
		<group id="246" type="span" parent="368" relname="concession"/>
		<group id="248" type="span" parent="222" relname="elaboration"/>
		<group id="250" type="span" parent="360" relname="same-unit"/>
		<group id="251" type="span" parent="370" relname="span"/>
		<group id="252" type="multinuc" parent="253" relname="span"/>
		<group id="253" type="span" parent="375" relname="span"/>
		<group id="254" type="multinuc" parent="257" relname="span"/>
		<group id="255" type="span" parent="70" relname="elaboration"/>
		<group id="256" type="span" parent="257" relname="cause"/>
		<group id="257" type="span" parent="258" relname="span"/>
		<group id="258" type="span" parent="374" relname="span"/>
		<group id="259" type="span" parent="77" relname="evaluation"/>
		<group id="260" type="span" parent="263" relname="span"/>
		<group id="261" type="span" parent="265" relname="background"/>
		<group id="262" type="span" parent="264" relname="restatement"/>
		<group id="263" type="span" parent="264" relname="restatement"/>
		<group id="264" type="multinuc" parent="265" relname="span"/>
		<group id="265" type="span" />
		<group id="266" type="multinuc" parent="268" relname="span"/>
		<group id="267" type="span" parent="266" relname="sequence"/>
		<group id="268" type="span" />
		<group id="269" type="multinuc" parent="213" relname="background"/>
		<group id="270" type="span" parent="272" relname="joint"/>
		<group id="271" type="span" parent="272" relname="joint"/>
		<group id="272" type="multinuc" />
		<group id="273" type="span" parent="407" relname="span"/>
		<group id="274" type="multinuc" />
		<group id="275" type="span" parent="274" relname="joint"/>
		<group id="276" type="span" parent="282" relname="joint"/>
		<group id="277" type="span" parent="199" relname="elaboration"/>
		<group id="278" type="span" parent="280" relname="joint"/>
		<group id="279" type="span" parent="280" relname="joint"/>
		<group id="280" type="multinuc" parent="196" relname="elaboration"/>
		<group id="281" type="span" parent="282" relname="joint"/>
		<group id="282" type="multinuc" parent="283" relname="span"/>
		<group id="283" type="span" parent="284" relname="span"/>
		<group id="284" type="span" />
		<group id="285" type="span" parent="288" relname="cause"/>
		<group id="286" type="span" parent="384" relname="background"/>
		<group id="287" type="span" />
		<group id="288" type="span" parent="385" relname="span"/>
		<group id="289" type="span" parent="293" relname="background"/>
		<group id="290" type="span" parent="390" relname="span"/>
		<group id="291" type="multinuc" parent="292" relname="span"/>
		<group id="292" type="span" parent="293" relname="span"/>
		<group id="293" type="span" />
		<group id="294" type="span" parent="110" relname="concession"/>
		<group id="295" type="span" parent="391" relname="span"/>
		<group id="296" type="span" parent="297" relname="span"/>
		<group id="297" type="span" parent="391" relname="elaboration"/>
		<group id="298" type="multinuc" parent="300" relname="span"/>
		<group id="299" type="span" parent="298" relname="joint"/>
		<group id="300" type="span" parent="393" relname="span"/>
		<group id="301" type="span" parent="302" relname="contrast"/>
		<group id="302" type="multinuc" />
		<group id="303" type="span" parent="302" relname="contrast"/>
		<group id="304" type="span" parent="124" relname="concession"/>
		<group id="305" type="span" parent="121" relname="evaluation"/>
		<group id="306" type="span" parent="307" relname="span"/>
		<group id="307" type="span" parent="309" relname="sequence"/>
		<group id="308" type="span" parent="309" relname="sequence"/>
		<group id="309" type="multinuc" />
		<group id="310" type="span" parent="314" relname="joint"/>
		<group id="311" type="span" parent="132" relname="elaboration"/>
		<group id="312" type="span" parent="314" relname="joint"/>
		<group id="313" type="span" parent="314" relname="joint"/>
		<group id="314" type="multinuc" parent="315" relname="span"/>
		<group id="315" type="span" parent="316" relname="span"/>
		<group id="316" type="span" />
		<group id="317" type="span" />
		<group id="318" type="span" parent="398" relname="span"/>
		<group id="319" type="span" parent="321" relname="joint"/>
		<group id="320" type="span" parent="321" relname="joint"/>
		<group id="321" type="multinuc" parent="322" relname="span"/>
		<group id="322" type="span" />
		<group id="323" type="span" parent="324" relname="same-unit"/>
		<group id="324" type="multinuc" parent="327" relname="span"/>
		<group id="325" type="span" parent="326" relname="cause"/>
		<group id="326" type="span" parent="328" relname="span"/>
		<group id="327" type="span" />
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="327" relname="evidence"/>
		<group id="330" type="span" parent="332" relname="joint"/>
		<group id="331" type="multinuc" parent="332" relname="joint"/>
		<group id="332" type="multinuc" parent="166" relname="solutionhood"/>
		<group id="333" type="span" parent="400" relname="span"/>
		<group id="334" type="span" parent="335" relname="joint"/>
		<group id="335" type="multinuc" parent="169" relname="elaboration"/>
		<group id="336" type="span" parent="340" relname="span"/>
		<group id="337" type="multinuc" parent="338" relname="span"/>
		<group id="338" type="span" parent="339" relname="span"/>
		<group id="339" type="span" parent="340" relname="elaboration"/>
		<group id="340" type="span" />
		<group id="341" type="multinuc" parent="342" relname="span"/>
		<group id="342" type="span" />
		<group id="343" type="multinuc" parent="345" relname="span"/>
		<group id="344" type="span" parent="402" relname="span"/>
		<group id="345" type="span" parent="346" relname="span"/>
		<group id="346" type="span" parent="404" relname="joint"/>
		<group id="347" type="multinuc" parent="349" relname="restatement"/>
		<group id="348" type="span" parent="349" relname="restatement"/>
		<group id="349" type="multinuc" parent="187" relname="elaboration"/>
		<group id="350" type="multinuc" parent="2" relname="elaboration"/>
		<group id="351" type="span" parent="222" relname="span"/>
		<group id="352" type="span" parent="228" relname="span"/>
		<group id="353" type="span" parent="352" relname="elaboration"/>
		<group id="354" type="span" parent="229" relname="background"/>
		<group id="355" type="span" parent="23" relname="attribution"/>
		<group id="356" type="span" parent="234" relname="span"/>
		<group id="357" type="span" parent="36" relname="background"/>
		<group id="358" type="span" parent="38" relname="purpose"/>
		<group id="359" type="span" parent="238" relname="joint"/>
		<group id="360" type="multinuc" parent="361" relname="joint"/>
		<group id="361" type="multinuc" parent="362" relname="span"/>
		<group id="362" type="span" parent="363" relname="span"/>
		<group id="363" type="span" parent="45" relname="elaboration"/>
		<group id="364" type="span" />
		<group id="365" type="span" parent="44" relname="elaboration"/>
		<group id="366" type="span" parent="246" relname="span"/>
		<group id="367" type="span" parent="368" relname="span"/>
		<group id="368" type="span" parent="369" relname="span"/>
		<group id="369" type="span" />
		<group id="370" type="span" />
		<group id="371" type="span" parent="251" relname="span"/>
		<group id="372" type="span" parent="64" relname="cause"/>
		<group id="373" type="span" parent="371" relname="elaboration"/>
		<group id="374" type="span" parent="261" relname="span"/>
		<group id="375" type="span" parent="258" relname="background"/>
		<group id="376" type="span" parent="260" relname="span"/>
		<group id="377" type="span" parent="381" relname="background"/>
		<group id="378" type="span" parent="377" relname="span"/>
		<group id="379" type="span" parent="86" relname="condition"/>
		<group id="380" type="span" parent="381" relname="span"/>
		<group id="381" type="span" parent="262" relname="span"/>
		<group id="382" type="span" parent="287" relname="span"/>
		<group id="383" type="span" parent="95" relname="cause"/>
		<group id="384" type="span" parent="288" relname="span"/>
		<group id="385" type="span" />
		<group id="386" type="multinuc" parent="290" relname="background"/>
		<group id="387" type="span" parent="290" relname="span"/>
		<group id="388" type="span" parent="289" relname="span"/>
		<group id="389" type="span" parent="388" relname="elaboration"/>
		<group id="390" type="span" parent="389" relname="span"/>
		<group id="391" type="span" parent="303" relname="span"/>
		<group id="392" type="span" parent="301" relname="span"/>
		<group id="393" type="span" parent="392" relname="elaboration"/>
		<group id="394" type="span" parent="306" relname="span"/>
		<group id="395" type="span" parent="131" relname="elaboration"/>
		<group id="396" type="span" parent="143" relname="evaluation"/>
		<group id="397" type="span" parent="142" relname="background"/>
		<group id="398" type="span" parent="317" relname="elaboration"/>
		<group id="399" type="span" parent="324" relname="same-unit"/>
		<group id="400" type="span" />
		<group id="401" type="span" />
		<group id="402" type="span" parent="345" relname="cause"/>
		<group id="403" type="span" parent="404" relname="joint"/>
		<group id="404" type="multinuc" parent="405" relname="span"/>
		<group id="405" type="span" parent="406" relname="span"/>
		<group id="406" type="span" />
		<group id="407" type="span" parent="274" relname="joint"/>
		<group id="408" type="span" parent="270" relname="span"/>
		<group id="409" type="span" parent="275" relname="span"/>
		<group id="410" type="span" parent="239" relname="joint"/>
		<group id="411" type="span" parent="412" relname="span"/>
		<group id="412" type="span" parent="7" relname="elaboration"/>
		<group id="413" type="span" parent="228" relname="attribution"/>
		<group id="414" type="span" />
		<group id="415" type="span" parent="416" relname="joint"/>
		<group id="416" type="multinuc" parent="235" relname="attribution"/>
		<group id="417" type="span" />
		<group id="418" type="span" parent="376" relname="elaboration"/>
	</body>
</rst>