<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="2" relname="preparation">Новость: В Башкирии поставили спектакль «Серебряное войско» М.Карягиной</segment>
		<segment id="2" parent="62" relname="span">Конкурсную программу V Международного фестиваля тюркоязычных театров «Туганлык» в Уфе 7 сентября открыл спектакль Чувашского государственного театра юного зрителя имени М. Сеспеля «Серебряное войско» М.Карягиной.</segment>
		<segment id="3" parent="65" relname="span">Публика на спектакль собралась разная.</segment>
		<segment id="4" parent="64" relname="span">В зрительном зале Государственного академического русского драматического театра присутствовали критики, члены жюри, коллеги из других театров, представители чувашской диаспоры, приехавшие из разных уголков Башкортостана, молодежь.</segment>
		<segment id="5" parent="63" relname="joint">Заявленная тема оказалась весьма актуальной не только в контексте чувашской культуры,</segment>
		<segment id="6" parent="63" relname="joint">но вызвала весьма широкий профессиональный и зрительский интерес.</segment>
		<segment id="7" parent="68" relname="span">В спектакле задействован практически весь состав Чувашского государственного театра юного зрителя,</segment>
		<segment id="8" parent="67" relname="joint">эту постановку артисты любят</segment>
		<segment id="9" parent="67" relname="joint">и всегда с большим вдохновением выходят на сцену.</segment>
		<segment id="10" parent="70" relname="span">Счастливой оказалась и фестивальная история спектакля,</segment>
		<segment id="11" parent="69" relname="span">он стал лауреатом трех международных фестивалей:</segment>
		<segment id="12" parent="11" relname="evidence">в городах Конья (Турция), Казань (Республика Татарстан), Саранск (Республика Мордовия), высоко оценили его театральные критики.</segment>
		<segment id="13" parent="73" relname="span">Однако новый выход на сцену всегда — новый экзамен, с которым труппа в очередной раз успешно справилась.</segment>
		<segment id="14" parent="72" relname="joint">Новые сильные интонации прозвучали в образе главной героини Эльбану в исполнении Натальи Шамбулиной,</segment>
		<segment id="15" parent="72" relname="joint">свежо зазвучал голос Шелеби (Ольга Мацуцына),</segment>
		<segment id="16" parent="72" relname="joint">сила духа и напористость амазонок, ни капли не сомневавшихся в успехе, передавались зрительному залу, аплодировавшему каждому выходу артистов на сцену.</segment>
		<segment id="17" parent="90" relname="span">Трагедия оставила сильные впечатления.</segment>
		<segment id="18" parent="75" relname="span">«Спектакль очень интересный,</segment>
		<segment id="19" parent="74" relname="joint">тем более я в первый раз в жизни вижу чувашский театр,</segment>
		<segment id="20" parent="74" relname="joint">слышу чувашскую речь.</segment>
		<segment id="21" parent="75" relname="evaluation">Искусство разных народов – это всегда интересно»,</segment>
		<segment id="22" parent="76" relname="attribution">- отметил один из уфимцев.</segment>
		<segment id="23" parent="79" relname="attribution">Другая зрительница призналась,</segment>
		<segment id="24" parent="78" relname="joint">что с чувашами ее связывает многое – это чувашские корни,</segment>
		<segment id="25" parent="78" relname="joint">ей было приятно увидеть театр в гостях в Башкирии.</segment>
		<segment id="26" parent="27" relname="attribution">Молодой Владимир, художественный руководитель театра-студии «Птица»  рассказал,</segment>
		<segment id="27" parent="81" relname="span">что давно интересуется чувашской культурой.</segment>
		<segment id="28" parent="29" relname="cause">«Я был на Днях чувашской культуры в Башкирии в июне этого года</segment>
		<segment id="29" parent="82" relname="span">и потому мой выбор чувашского спектакля не случаен.</segment>
		<segment id="30" parent="83" relname="joint">Мне интересен чувашский этнос,</segment>
		<segment id="31" parent="83" relname="joint">хотелось больше узнать историю этого народа.</segment>
		<segment id="32" parent="84" relname="joint">Постановка интересна своей сценографией, динамикой развития сюжета,</segment>
		<segment id="33" parent="84" relname="joint">чувствуется любовь автора и исполнителей к материалу, своему народу»,</segment>
		<segment id="34" parent="87" relname="attribution">— заметил он.</segment>
		<segment id="35" parent="99" relname="attribution">На обсуждении заслуженный деятель искусств России Сергей Яшин еще раз отметил высокую степень актуальности поднятой темы.</segment>
		<segment id="36" parent="91" relname="joint">«Еще 15 лет назад этот спектакль, наверное, не звучал бы так актуально</segment>
		<segment id="37" parent="91" relname="joint">и нужно.</segment>
		<segment id="38" parent="94" relname="joint">Напоминание о корнях, традициях,  которые веками передавались от сердца к сердцу, чрезвычайно важно.</segment>
		<segment id="39" parent="92" relname="joint">К сожалению, человечество страдает забывчивостью,</segment>
		<segment id="40" parent="92" relname="joint">и необходимо время от времени напоминать о том, откуда мы.</segment>
		<segment id="41" parent="93" relname="joint">Спектакль «Серебряное войско» мне показался удивительно современным со временем</segment>
		<segment id="42" parent="93" relname="joint">и очень нужным.</segment>
		<segment id="43" parent="97" relname="joint">Тем более в исполнении ТЮЗа, обращенного к юным людям, это вдвойне важно»,</segment>
		<segment id="44" parent="98" relname="attribution">- подчеркнул он.</segment>
		<segment id="45" parent="102" relname="joint">Какую оценку «Серебряному войску» даст жюри,</segment>
		<segment id="46" parent="102" relname="joint">станет известно через несколько дней.</segment>
		<segment id="47" parent="103" relname="joint">Торжественная церемония закрытия фестиваля состоится 13 сентября.</segment>
		<segment id="48" parent="107" relname="span">Чувашский театр преподнес еще один подарок своим сородичам из Башкортостана.</segment>
		<segment id="49" parent="105" relname="cause">В селе Бижбуляк артисты показали спектакль «Шăпа» Маргариты Михайловой.</segment>
		<segment id="50" parent="104" relname="joint">Жители Бижбулякского района благодарили артистов не только горячими аплодисментами,</segment>
		<segment id="51" parent="104" relname="joint">слезы на глазах говорили о многом.</segment>
		<segment id="52" parent="108" relname="span">«Для нас это очень большое событие,</segment>
		<segment id="53" parent="52" relname="elaboration">театры бывают у нас не так часто.</segment>
		<segment id="54" parent="110" relname="span">Спектакль «Шăпа» просто потряс нас,</segment>
		<segment id="55" parent="109" relname="joint">мы плакали</segment>
		<segment id="56" parent="109" relname="joint">и радовались вместе с артистами.</segment>
		<segment id="57" parent="111" relname="joint">Хочется пожелать театру больших успехов,</segment>
		<segment id="58" parent="111" relname="joint">пусть Бог помогает вам во всем»,</segment>
		<segment id="59" parent="113" relname="span">— благословил отец Георгий,</segment>
		<segment id="60" parent="59" relname="elaboration">приехавший посмотреть постановку за много километров.</segment>
		<segment id="61" parent="116" relname="evaluation">Безусловно, этот спектакль станет лучшей памятью о теплой встрече чувашей на башкирской земле.</segment>
		<group id="62" type="span" parent="66" relname="joint"/>
		<group id="63" type="multinuc" parent="4" relname="evaluation"/>
		<group id="64" type="span" parent="3" relname="elaboration"/>
		<group id="65" type="span" parent="66" relname="joint"/>
		<group id="66" type="multinuc" />
		<group id="67" type="multinuc" parent="7" relname="elaboration"/>
		<group id="68" type="span" parent="71" relname="joint"/>
		<group id="69" type="span" parent="10" relname="elaboration"/>
		<group id="70" type="span" parent="71" relname="joint"/>
		<group id="71" type="multinuc" />
		<group id="72" type="multinuc" parent="13" relname="evidence"/>
		<group id="73" type="span" parent="71" relname="joint"/>
		<group id="74" type="multinuc" parent="18" relname="elaboration"/>
		<group id="75" type="span" parent="76" relname="span"/>
		<group id="76" type="span" parent="77" relname="span"/>
		<group id="77" type="span" parent="89" relname="joint"/>
		<group id="78" type="multinuc" parent="79" relname="span"/>
		<group id="79" type="span" parent="80" relname="span"/>
		<group id="80" type="span" parent="89" relname="joint"/>
		<group id="81" type="span" parent="88" relname="attribution"/>
		<group id="82" type="span" parent="86" relname="span"/>
		<group id="83" type="multinuc" parent="82" relname="elaboration"/>
		<group id="84" type="multinuc" parent="85" relname="joint"/>
		<group id="85" type="multinuc" parent="87" relname="span"/>
		<group id="86" type="span" parent="85" relname="joint"/>
		<group id="87" type="span" parent="88" relname="span"/>
		<group id="88" type="span" parent="101" relname="span"/>
		<group id="89" type="multinuc" parent="17" relname="elaboration"/>
		<group id="90" type="span" />
		<group id="91" type="multinuc" parent="94" relname="joint"/>
		<group id="92" type="multinuc" parent="95" relname="contrast"/>
		<group id="93" type="multinuc" parent="97" relname="joint"/>
		<group id="94" type="multinuc" parent="95" relname="contrast"/>
		<group id="95" type="multinuc" parent="96" relname="span"/>
		<group id="96" type="span" parent="98" relname="span"/>
		<group id="97" type="multinuc" parent="96" relname="evaluation"/>
		<group id="98" type="span" parent="99" relname="span"/>
		<group id="99" type="span" parent="100" relname="span"/>
		<group id="100" type="span" parent="118" relname="joint"/>
		<group id="101" type="span" parent="89" relname="joint"/>
		<group id="102" type="multinuc" parent="103" relname="joint"/>
		<group id="103" type="multinuc" parent="118" relname="joint"/>
		<group id="104" type="multinuc" parent="105" relname="span"/>
		<group id="105" type="span" parent="106" relname="span"/>
		<group id="106" type="span" parent="48" relname="elaboration"/>
		<group id="107" type="span" />
		<group id="108" type="span" parent="115" relname="joint"/>
		<group id="109" type="multinuc" parent="54" relname="evidence"/>
		<group id="110" type="span" parent="115" relname="joint"/>
		<group id="111" type="multinuc" parent="112" relname="span"/>
		<group id="112" type="span" parent="114" relname="span"/>
		<group id="113" type="span" parent="112" relname="attribution"/>
		<group id="114" type="span" parent="115" relname="joint"/>
		<group id="115" type="multinuc" parent="116" relname="span"/>
		<group id="116" type="span" parent="117" relname="span"/>
		<group id="117" type="span" />
		<group id="118" type="multinuc" />
	</body>
</rst>