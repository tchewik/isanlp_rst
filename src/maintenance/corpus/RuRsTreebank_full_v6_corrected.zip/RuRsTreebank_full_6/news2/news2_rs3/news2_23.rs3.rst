<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="293" relname="joint">В странах Балтии, как и везде, должны помнить</segment>
		<segment id="2" parent="293" relname="joint">и чтить истинных героев, боровшихся с фашизмом</segment>
		<segment id="3" parent="294" relname="joint">Граждане стран Балтийского региона, как и все без исключения народы, должны помнить</segment>
		<segment id="4" parent="294" relname="joint">и чтить имена истинных героев, которые боролись с немецко-фашистскими захватчиками в годы Второй мировой войны.</segment>
		<segment id="5" parent="295" relname="attribution">Об этом в своей совместной статье пишут российский исследователь истории стран Балтии, автор многих научных публикаций и нескольких книг, кандидат исторических наук Михаил Крысин (Mikhail Krysin) и публицист, поэт, консультант и участник ряда кинофильмов Роман Андрейчук (Roman Andreychuk).</segment>
		<segment id="6" parent="297" relname="joint">Текст данной статьи, озаглавленной "Герои стран Балтии в борьбе против фашизма", ИА "PenzaNews" в канун 70-летия Великой Победы приводит ниже без сокращений.</segment>
		<segment id="7" parent="304" relname="joint">Их много.</segment>
		<segment id="8" parent="304" relname="joint">Их очень много.</segment>
		<segment id="9" parent="302" relname="span">Памятники ставить надо им, а не полицаям и легионерам из "Ваффен-СС", а, к примеру, солдатам Усмаского батальона из так называемой "группы генерала Курелиса"</segment>
		<segment id="10" parent="9" relname="elaboration">(кстати, готовившей диверсантов для засылки в тыл Красной Армии),</segment>
		<segment id="11" parent="300" relname="sequence">которые дали три крупных боя фашистам,</segment>
		<segment id="12" parent="301" relname="joint">а затем ушли в лес</segment>
		<segment id="13" parent="301" relname="joint">и воевали против немцев в рядах советских партизан.</segment>
		<segment id="14" parent="310" relname="span">А что, разве можно забыть эстонского подростка Карла Веске?</segment>
		<segment id="15" parent="307" relname="span">Фашисты не смогли сорвать с его груди красный пионерский галстук,</segment>
		<segment id="16" parent="15" relname="concession">как ни пытались,</segment>
		<segment id="17" parent="308" relname="joint">и в бешеной злобе повесили Карла.</segment>
		<segment id="18" parent="309" relname="span">Или подвиг латыша-подпольщика Арвида Редниека,</segment>
		<segment id="19" parent="18" relname="elaboration">оказавшего даже перед своим расстрелом в Бикерниекском лесу яростное сопротивление своим палачам?</segment>
		<segment id="20" parent="311" relname="joint">Или изгладились из памяти боевые дела партизанского полка "За Советскую Латвию" под командованием В.Я. Лайвиньша и Л.П. Ошкална?</segment>
		<segment id="21" parent="316" relname="contrast">В том-то и дело, что нет.</segment>
		<segment id="22" parent="312" relname="span">Но в души людей, прежде всего очень юных, темные силы стремятся протащить в качестве идеалов и примеров</segment>
		<segment id="23" parent="22" relname="purpose">для подражания таких моральных уродов, как Вейсс, Арайс, Бангерскис, Цукурс, палач рижского гетто.</segment>
		<segment id="24" parent="313" relname="span">О Цукурсе даже мюзикл поставили.</segment>
		<segment id="25" parent="24" relname="evaluation">Это же надо, до чего докатились!</segment>
		<segment id="26" parent="313" relname="elaboration">Все новые и новые способы изыскивают.</segment>
		<segment id="27" parent="321" relname="joint">В такой ситуации нельзя сидеть сложа руки.</segment>
		<segment id="28" parent="320" relname="span">А где наш ответ неофашистам?</segment>
		<segment id="29" parent="319" relname="span">Где, к примеру, мюзикл о сыне литовского крестьянина Станиславе Ваупшасове?</segment>
		<segment id="30" parent="318" relname="joint">Ваупшасов командовал батальоном пограничников во время финской войны, в годы Великой Отечественной войны - партизанским спецотрядом.</segment>
		<segment id="31" parent="317" relname="joint">Выполнял особые задания, в том числе в Северо-Восточном Китае,</segment>
		<segment id="32" parent="317" relname="joint">а также боролся с националистическим подпольем в Прибалтике.</segment>
		<segment id="33" parent="322" relname="span">А где песня о литовской пулеметчице Красной Армии, кавалере трех орденов Славы Дануте Станилиене,</segment>
		<segment id="34" parent="33" relname="elaboration">освобождавшей родные земли возле реки Неман?</segment>
		<segment id="35" parent="324" relname="span">Где фильм об эстонце Якобе Мартиновиче Кундере,</segment>
		<segment id="36" parent="35" relname="elaboration">который повторил подвиг Александра Матросова?</segment>
		<segment id="37" parent="323" relname="span">Такой же подвиг совершил гвардии рядовой эстонец Иосиф Иосифович Лаар 7 августа 1943 года в бою за хутор Ленинский Краснодарского края.</segment>
		<segment id="38" parent="37" relname="cause">Герой Советского Союза Лаар навечно зачислен в списки части.</segment>
		<segment id="39" parent="328" relname="span">В истории борьбы с гитлеровцами народов Прибалтики есть такие эпизоды,</segment>
		<segment id="40" parent="41" relname="condition">что если воспроизвести их в кино,</segment>
		<segment id="41" parent="327" relname="span">то зрители забудут о фильмах, повествующих о битве Рима против варваров и о захвате Константинополя турками.</segment>
		<segment id="42" parent="43" relname="evidence">Когда 1 июля 1941 года немцы вошли в Ригу,</segment>
		<segment id="43" parent="331" relname="span">то опорными пунктами ожесточенной войны против них стали синагоги.</segment>
		<segment id="44" parent="329" relname="joint">Сражение длилось несколько часов,</segment>
		<segment id="45" parent="329" relname="joint">синагоги были объяты пламенем,</segment>
		<segment id="46" parent="329" relname="joint">из их окон неслись пулеметные и автоматные очереди,</segment>
		<segment id="47" parent="329" relname="joint">а в это время раввины читали молитвы.</segment>
		<segment id="48" parent="330" relname="joint">Синагогу на Гоголевской улице штурмовали две роты солдат.</segment>
		<segment id="49" parent="330" relname="joint">В нескольких случаях на штурм синагог были направлены танки.</segment>
		<segment id="50" parent="337" relname="preparation">И вне синагоги были очаги сопротивления.</segment>
		<segment id="51" parent="337" relname="span">Рабочий лесопильного завода Абель из старого дробовика застрелил двух немцев, пытавшихся проникнуть в дом.</segment>
		<segment id="52" parent="334" relname="span">Немецкий офицер вызвал целый взвод,</segment>
		<segment id="53" parent="52" relname="purpose">чтобы захватить Абеля живым.</segment>
		<segment id="54" parent="335" relname="joint">Но Абель не сдался</segment>
		<segment id="55" parent="335" relname="joint">и погиб, сражаясь до последней минуты.</segment>
		<segment id="56" parent="339" relname="joint">С оружием в руках погиб директор школы, доктор философии Венского университета Элькишек.</segment>
		<segment id="57" parent="344" relname="span">Возле речки Маза Югла восточнее Риги отряд из 60 человек, возглавляемый студентом Рижского университета Абрамом Эпштейном, истребил больше 100 немцев.</segment>
		<segment id="58" parent="342" relname="contrast">Отряд во главе с командиром погиб почти полностью,</segment>
		<segment id="59" parent="341" relname="sequence">но несколько сотен еврейских женщин и детей скрылись в лес,</segment>
		<segment id="60" parent="340" relname="span">выбрались на Мадонское шоссе,</segment>
		<segment id="61" parent="60" relname="elaboration">где вела бой Красная армия,</segment>
		<segment id="62" parent="341" relname="sequence">и добрались до советских войск.</segment>
		<segment id="63" parent="343" relname="contrast">Да, это было тяжело.</segment>
		<segment id="64" parent="343" relname="contrast">Но все-таки наступил тот час, о котором писала литовская поэтесса Саломея Нерис.</segment>
		<segment id="65" parent="348" relname="joint">В боях за освобождение Латвии активно участвовал 130-й Латышский корпус под командованием генерала Д.Е. Бранткална.</segment>
		<segment id="66" parent="346" relname="cause">Возвращаясь к истории этого корпуса,</segment>
		<segment id="67" parent="346" relname="span">надо сказать,</segment>
		<segment id="68" parent="67" relname="purpose">что она начиналась с создания 202-й латышской стрелковой дивизии.</segment>
		<segment id="69" parent="352" relname="span">17-24 августа 130-й корпус участвовал в Мадонской операции по освобождению центральной части Латвии (Видземе).</segment>
		<segment id="70" parent="351" relname="joint">Особенно ожесточенные бои разгорелись у села Виеталва.</segment>
		<segment id="71" parent="350" relname="span">Длились они не три дня, как принято считать, а дольше.</segment>
		<segment id="72" parent="349" relname="span">Разведчику Янису Розе пришлось провести 5 дней на колокольне Виеталвской церкви, в нейтральной полосе,</segment>
		<segment id="73" parent="72" relname="cause">корректируя огонь 123-го полка 43-й гвардейской дивизии.</segment>
		<segment id="74" parent="360" relname="span">После боев за Виеталву,</segment>
		<segment id="75" parent="74" relname="elaboration">где было уничтожено более 300 единиц бронетехники и несколько тысяч солдат и офицеров противника,</segment>
		<segment id="76" parent="361" relname="span">130-й корпус получил короткий отдых,</segment>
		<segment id="77" parent="76" relname="purpose">чтобы 14 сентября 1944 года принять участие в наступлении на Балдоне в рамках Рижской операции.</segment>
		<segment id="78" parent="363" relname="joint">Правда, непосредственно в боях за Ригу корпусу участвовать не пришлось,</segment>
		<segment id="79" parent="357" relname="joint">однако сражения на подступах к Риге - под Балдоне, в районе Кекавы, вдоль шоссе "Рига - Елгава" - были не менее ожесточенными.</segment>
		<segment id="80" parent="366" relname="joint">13 октября после тяжелых боев была занята правобережная часть Риги.</segment>
		<segment id="81" parent="366" relname="joint">В левобережной части сопротивление продолжалось до 15 октября.</segment>
		<segment id="82" parent="378" relname="span">Уже на подступах к Риге местные жители встречали латышских солдат более чем радушно.</segment>
		<segment id="83" parent="368" relname="same-unit">"Как известно,</segment>
		<segment id="84" parent="85" relname="attribution">- вспоминает Янис Розе, -</segment>
		<segment id="85" parent="547" relname="span">мосты через Даугаву немцы взорвали.</segment>
		<segment id="86" parent="377" relname="span">Пришлось нам идти в обход, через Кекаву.</segment>
		<segment id="87" parent="372" relname="span">Честно скажу,</segment>
		<segment id="88" parent="369" relname="span">такого количества цветов,</segment>
		<segment id="89" parent="88" relname="elaboration">каким нас осыпали рижане,</segment>
		<segment id="90" parent="370" relname="same-unit">я в жизни не видел. Цветов и улыбок!</segment>
		<segment id="91" parent="374" relname="joint">С песнями, лихо печатая шаг, с развевающимися знаменами шли мы по улицам Риги,</segment>
		<segment id="92" parent="373" relname="joint">и у каждого было светло</segment>
		<segment id="93" parent="373" relname="joint">и радостно на душе".</segment>
		<segment id="94" parent="379" relname="joint">За бои под Ригой 130-й латышский стрелковый корпус был награжден орденом Суворова II степени, 308-я дивизия - орденом Боевого Красного Знамени,</segment>
		<segment id="95" parent="379" relname="joint">а 43-я гвардейская стрелковая дивизия получила почетное наименование "Рижская".</segment>
		<segment id="96" parent="380" relname="joint">3 тыс. 418 солдат и офицеров были награждены орденами и медалями.</segment>
		<segment id="97" parent="388" relname="span">В ходе боев в Латгалии и на подступах к Риге большую помощь наступавшим частям Красной Армии оказывали латышские партизаны, которые снабжали войска - и особенно авиацию - свежими разведданными и терроризировали тыл противника.</segment>
		<segment id="98" parent="387" relname="joint">По неполным данным, к 1 сентября 1944 года латышские партизаны взорвали 279 эшелонов противника, 53 моста,</segment>
		<segment id="99" parent="387" relname="joint">подбили 87 танков и бронемашин</segment>
		<segment id="100" parent="386" relname="span">и нанесли гитлеровцам значительные потери в живой силе</segment>
		<segment id="101" parent="385" relname="joint">- около 40 тыс. солдат и офицеров были убиты</segment>
		<segment id="102" parent="385" relname="joint">и ранены.</segment>
		<segment id="103" parent="390" relname="span">После освобождения Риги части 130-го латышского корпуса были на время отведены в тыл</segment>
		<segment id="104" parent="389" relname="joint">для отдыха</segment>
		<segment id="105" parent="389" relname="joint">и пополнения.</segment>
		<segment id="106" parent="391" relname="joint">С 23 декабря 1944 года 130-й корпус был переброшен на Джукстский участок фронта</segment>
		<segment id="107" parent="391" relname="joint">и участвовал в боях против последних гитлеровских войск в Курляндии.</segment>
		<segment id="108" parent="393" relname="joint">Здесь, в Курземе, бои были в основном позиционными.</segment>
		<segment id="109" parent="393" relname="joint">Сами бойцы называли их "каруселью".</segment>
		<segment id="110" parent="394" relname="joint">Кстати, левый фланг 308-й латышской стрелковой дивизии 130-го латышского корпуса РККА прикрывала 7-я Таллинская Краснознаменная стрелковая дивизия 8-го эстонского стрелкового корпуса.</segment>
		<segment id="111" parent="398" relname="span">Солдаты 130-го латышского стрелкового корпуса участвовали в разоружении 24-й пехотной дивизии вермахта и 19-й (латышской) гренадерской дивизии войск СС.</segment>
		<segment id="112" parent="111" relname="elaboration">С 9 по 12 мая 1945 года в имении Плане у реки Амула части 130-го латышского стрелкового корпуса Красной армии разоружили 1 тыс. 477 легионеров из состава 19-й латышской дивизии войск СС.</segment>
		<segment id="113" parent="397" relname="joint">Около 20 тыс. солдат и офицеров 130-го латышского стрелкового корпуса и латышских партизан были награждены орденами и медалями,</segment>
		<segment id="114" parent="397" relname="joint">а 28 из них (в том числе 3 партизан - И. Судмалис (посмертно), О. Ошкалнс и В. Самсонс) стали Героями Советского Союза.</segment>
		<segment id="115" parent="545" relname="preparation">История 130-го латышского корпуса РККА начиналась с создания 201-й латышской стрелковой дивизии.</segment>
		<segment id="116" parent="401" relname="attribution">3 августа 1941 года Государственный комитет обороны СССР (постановление №383)</segment>
		<segment id="117" parent="400" relname="span">в ответ на просьбу ЦК Компартии Латвии и правительства Латвийской ССР</segment>
		<segment id="118" parent="117" relname="purpose">о формировании воинской части из эвакуированных жителей Латвийской ССР</segment>
		<segment id="119" parent="401" relname="span">постановил сформировать в Московском военном округе Латышскую стрелковую дивизию "из состава бойцов бывшей Рабочей гвардии, милиции, партийно-советских работников и других граждан Латвийской ССР, эвакуированных на территорию РСФСР".</segment>
		<segment id="120" parent="544" relname="elaboration">Эта дивизия стала первой национальной воинской частью Красной армии.</segment>
		<segment id="121" parent="411" relname="sequence">Формирование латышской дивизии началось в августе 1941 года в Гороховецких лагерях неподалеку от города Горького [в настоящее время - Нижний Новгород].</segment>
		<segment id="122" parent="407" relname="sequence">Первые добровольцы начали прибывать уже 11-12 августа (в т.ч. около 2 тыс. 500 латвийских милиционеров и работников НКВД),</segment>
		<segment id="123" parent="406" relname="span">а 15-20 августа они начали прибывать группами по 100-200 человек из Горьковской, Ивановской и Кировской областей,</segment>
		<segment id="124" parent="123" relname="elaboration">где размещалось эвакуированное из Латвии население.</segment>
		<segment id="125" parent="409" relname="span">Мобилизация эвакуированных граждан Латвии началась только в сентябре 1941 года,</segment>
		<segment id="126" parent="408" relname="span">так как многих поначалу даже не хотели эвакуировать</segment>
		<segment id="127" parent="126" relname="cause">из-за царившего в первые дни войны недоверия к латышам и другим жителям западных областей СССР.</segment>
		<segment id="128" parent="410" relname="joint">В состав дивизии были включены и избежавшие окружения части 24-го латышского территориального корпуса, а также целый ряд латышских истребительных батальонов и рабочих полков, действовавших в Эстонии и под Ленинградом в июле 1941 года в рядах 1-го и 2-го (позже 76-го) латышских стрелковых полков в составе 8-й армии.</segment>
		<segment id="129" parent="410" relname="joint">Младший и средний командный состав составили командиры и красноармейцы расформированного 24-го латышского стрелкового корпуса.</segment>
		<segment id="130" parent="416" relname="span">Формирование латышской дивизии завершилось буквально за месяц - к 12 сентября 1941 года.</segment>
		<segment id="131" parent="413" relname="joint">Ее первым командиром стал Я. Вейкин (Вейкиньш),</segment>
		<segment id="132" parent="413" relname="joint">комиссарами были Э. Бирзитис и П. Зутис.</segment>
		<segment id="133" parent="417" relname="sequence">12 сентября 1941 года дивизия была полностью сформирована.</segment>
		<segment id="134" parent="414" relname="joint">3 декабря 1941 года она была передана в подчинение 33-й ударной армии Западного фронта</segment>
		<segment id="135" parent="414" relname="joint">и приняла свое боевое крещение в Битве за Москву.</segment>
		<segment id="136" parent="415" relname="joint">К тому времени дивизия насчитывала 10 тыс. 348 человек.</segment>
		<segment id="137" parent="415" relname="joint">Национальный состав был такой: 51% латышей, 26% русских и 17% евреев.</segment>
		<segment id="138" parent="433" relname="preparation">В ходе контрнаступления под Москвой 201-я латышская дивизия с 5 декабря 1941 года по 10 января 1942 года участвовала в освобождении Наро-Фоминска (27 декабря 1941 года) и Боровска (4 января 1942 года).</segment>
		<segment id="139" parent="421" relname="span">В ходе этих боев дивизия потеряла до 55% своего личного состава</segment>
		<segment id="140" parent="139" relname="evidence">(например, в 92-м полку потери составили 68%, а в 191-м полку - 70%).</segment>
		<segment id="141" parent="422" relname="joint">Командир дивизии Янис Вейкин 21 декабря был ранен</segment>
		<segment id="142" parent="422" relname="joint">и отправлен в тыл,</segment>
		<segment id="143" parent="423" relname="joint">вместо него дивизию возглавил полковник Генрих Паэгле.</segment>
		<segment id="144" parent="424" relname="sequence">2 февраля 1942 года дивизия вновь вернулась на фронт после отдыха и доукомплектования</segment>
		<segment id="145" parent="424" relname="sequence">и с 13 февраля принимала участие в затяжных позиционных боях под Старой Руссой и Демянском в составе 1-й ударной армии Северо-Западного фронта.</segment>
		<segment id="146" parent="425" relname="span">14 июня после четырехмесячных боев дивизия была отведена в тыл</segment>
		<segment id="147" parent="146" relname="purpose">для доукомплектования.</segment>
		<segment id="148" parent="427" relname="span">В июле-августе 1942 года 201-я дивизия снова вернулась на тот же участок фронта,</segment>
		<segment id="149" parent="426" relname="span">где ей пришлось вести тяжелые бои за "рамушевский коридор",</segment>
		<segment id="150" parent="149" relname="elaboration">по которому окруженная под Демянском немецкая группировка получала снабжение.</segment>
		<segment id="151" parent="428" relname="same-unit">10 сентября</segment>
		<segment id="152" parent="153" relname="cause">из-за потерь</segment>
		<segment id="153" parent="429" relname="span">дивизия снова была отведена в тыл</segment>
		<segment id="154" parent="430" relname="joint">и вернулась на фронт только в ноябре 1942 года.</segment>
		<segment id="155" parent="435" relname="span">В ходе весенних боев под Старой Руссой и под Демянском особенно отличился снайпер Янис Вилхелмс,</segment>
		<segment id="156" parent="155" relname="elaboration">уничтоживший в общей сложности около 150 солдат и офицеров противника.</segment>
		<segment id="157" parent="437" relname="span">За боевую доблесть он получил первое офицерское звание - младший лейтенант.</segment>
		<segment id="158" parent="436" relname="sequence">21 июля 1942 года он был принят в Кремле лично И.В. Сталиным</segment>
		<segment id="159" parent="436" relname="sequence">и получил звание Героя Советского Союза,</segment>
		<segment id="160" parent="436" relname="sequence">а впоследствии удостоен еще и американского "Креста за боевые заслуги".</segment>
		<segment id="161" parent="439" relname="joint">За героизм, проявленный в боях под Москвой и под Старой Руссой, 5 октября 1942 года 201-я латышская стрелковая дивизия была переименована в 43-ю гвардейскую латышскую стрелковую дивизию.</segment>
		<segment id="162" parent="441" relname="span">В течение 1943 года 43-я гвардейская дивизия еще несколько раз возвращалась под Старую Руссу с небольшими перерывами</segment>
		<segment id="163" parent="440" relname="joint">для отдыха и</segment>
		<segment id="164" parent="440" relname="joint">доукомплектования.</segment>
		<segment id="165" parent="442" relname="joint">Наконец, пришел победоносный 1944 год - год освобождения от оккупации.</segment>
		<segment id="166" parent="442" relname="joint">14-17 января 1944 года 43-я гвардейская латышская дивизия приняла участие в наступлении Ленинградского, Волховского и 2-го Прибалтийского фронтов.</segment>
		<segment id="167" parent="445" relname="span">Важнейшим результатом этого стало окончание блокады Ленинграда.</segment>
		<segment id="168" parent="446" relname="joint">Тем временем весной 1944 года началось формирование еще одной латышской дивизии РККА - 308-й стрелковой (3-го формирования), созданной на основе 1-го отдельного латышского стрелкового полка (7 тыс. 300 человек).</segment>
		<segment id="169" parent="446" relname="joint">Командиром дивизии стал генерал-майор Волдемар Дамбергс.</segment>
		<segment id="170" parent="446" relname="joint">Формирование 308-й дивизии завершилось 7 июля 1944 года.</segment>
		<segment id="171" parent="447" relname="joint">5 июня того же года 43-я гвардейская и 308-я (почти сформированная) латышские стрелковые дивизии образовали 130-й латышский стрелковый корпус (16 тыс. человек) под командованием генерал-майора Детлава Бранткалнса.</segment>
		<segment id="172" parent="447" relname="joint">С 27 июля корпус начал получать пополнение из призывников с освобожденной территории Латвии.</segment>
		<segment id="173" parent="447" relname="joint">Всего до конца войны было призвано 50 тыс. человек.</segment>
		<segment id="174" parent="449" relname="span">После этой мобилизации корпус по своему национальному составу снова стал преимущественно латышским.</segment>
		<segment id="175" parent="450" relname="joint">18 июля 1944 года воины 130-го латышского стрелкового корпуса, действовавшего в составе 2-го Прибалтийского фронта, одними из первых вступили на землю Латвии</segment>
		<segment id="176" parent="450" relname="joint">и освободили деревни Боркуйцы и Шкяуне.</segment>
		<segment id="177" parent="451" relname="joint">Первые части РККА вошли в Латвию 16 июня.</segment>
		<segment id="178" parent="451" relname="joint">Шкяуне был первым волостным центром Латвии, освобожденным от оккупантов.</segment>
		<segment id="179" parent="472" relname="attribution">Снайпер и разведчик 123-го полка 43-й гвардейской латышской дивизии, полный кавалер ордена Славы Янис Розе рассказывает:</segment>
		<segment id="180" parent="468" relname="joint">"&hellip;Выбили мы немцев из местечка Шкяуне [вблизи границы Латвии и РСФСР]</segment>
		<segment id="181" parent="452" relname="joint">&hellip;Старик подошел к нам</segment>
		<segment id="182" parent="452" relname="joint">и спросил:</segment>
		<segment id="183" parent="457" relname="span">"Вы, ребята, свои, что ли?"</segment>
		<segment id="184" parent="454" relname="joint">"Свои,</segment>
		<segment id="185" parent="186" relname="attribution">- отвечаем, -</segment>
		<segment id="186" parent="453" relname="span">латыши".</segment>
		<segment id="187" parent="455" relname="span">"А откуда вас столько взялось,</segment>
		<segment id="188" parent="187" relname="cause">что фрицев сумели прогнать?</segment>
		<segment id="189" parent="456" relname="joint">Неужто там, в России, какая новая Латвия объявилась?"</segment>
		<segment id="190" parent="459" relname="same-unit">"Никакой такой Латвии,</segment>
		<segment id="191" parent="192" relname="attribution">- отвечаем, -</segment>
		<segment id="192" parent="458" relname="span">нет.</segment>
		<segment id="193" parent="460" relname="joint">А собрались мы из разных мест</segment>
		<segment id="194" parent="461" relname="span">и теперь будем гнать фашистов,</segment>
		<segment id="195" parent="194" relname="cause">пока не утопим их в Янтарном море&hellip;".</segment>
		<segment id="196" parent="469" relname="joint">Тут старик внимательно осмотрел наши ордена, медали, пощупал погоны,</segment>
		<segment id="197" parent="469" relname="joint">а потом застыл в низком поклоне&hellip;".</segment>
		<segment id="198" parent="477" relname="preparation">Воины 130-го латышского корпуса в составе 2-го Прибалтийского фронта участвовали в Резекненско-Даугавпилской операции, в ходе которой в июле 1944 года были освобождены города Краслава, Лудза, Карсава и Виляка.</segment>
		<segment id="199" parent="474" relname="joint">27 июля при поддержке латышских партизан были освобождены Даугавпилс и Резекне,</segment>
		<segment id="200" parent="474" relname="joint">а к 8 августа был освобожден весь Даугавпилский уезд (Латгалия).</segment>
		<segment id="201" parent="476" relname="joint">Наиболее ожесточенное сопротивление противник оказал в боях у реки Айвиексте.</segment>
		<segment id="202" parent="475" relname="joint">8 августа 43-я гвардейская и 308-я дивизии освободили город Крустпилс,</segment>
		<segment id="203" parent="475" relname="joint">а 10 августа форсировали реку Айвиексте.</segment>
		<segment id="204" parent="479" relname="span">В ходе боев под Резекне звание Героя Советского Союза посмертно получил уроженец Латгалии, бывший курсант Рижского пехотного училища Михаил Орлов,</segment>
		<segment id="205" parent="204" relname="elaboration">к тому времени ставший командиром 4-й роты 125-го полка 43-й гвардейской латышской стрелковой дивизии.</segment>
		<segment id="206" parent="480" relname="joint">2 августа 1944 года со своей ротой он форсировал реку Аташу</segment>
		<segment id="207" parent="480" relname="joint">и перерезал шоссе и железную дорогу "Резекне - Крустпилс".</segment>
		<segment id="208" parent="481" relname="span">Здесь он получил свое шестое ранение,</segment>
		<segment id="209" parent="208" relname="cause">которое оказалось смертельным.</segment>
		<segment id="210" parent="482" relname="joint">Бойцы роты удерживали позицию до подхода основных сил полка.</segment>
		<segment id="211" parent="487" relname="preparation">Воины 16-й литовской дивизии полковника А.И. Урбшаса освободили важный морской порт Клайпеду.</segment>
		<segment id="212" parent="213" relname="cause">При освобождении Вильнюса Красной армией</segment>
		<segment id="213" parent="485" relname="span">удалось почти сразу выбить врага из Антакальниса и старого города.</segment>
		<segment id="214" parent="486" relname="joint">Поэтому уцелели университет, академия наук, литовское национальное общество в Антакальнисе, основанное Басанавичюсом.</segment>
		<segment id="215" parent="486" relname="joint">Уцелели все замечательные соборы Вильнюса - Св. Анны, Св. Петра и Павла, Св. Иоанна, Кафедральный, Бернардинский, здание старой ратуши.</segment>
		<segment id="216" parent="491" relname="joint">Но были расстреляны фашистами поэт Витаутас Монтвила, скульптор Винцас Грибас, адвокат Андрюс Булота с женой.</segment>
		<segment id="217" parent="489" relname="joint">Замучен лучший литовский хирург, специалист с мировым именем Владас Кузма,</segment>
		<segment id="218" parent="489" relname="joint">брошен в концлагерь другой литовский поэт - Теофилис Тильвитис.</segment>
		<segment id="219" parent="490" relname="joint">За помощь евреям была арестована подруга Саломеи Нерис Она Шимайте.</segment>
		<segment id="220" parent="490" relname="joint">Ее подвергли пыткам.</segment>
		<segment id="221" parent="492" relname="span">В Риге фашисты расстреливали латышей и евреев одной пулей, связав их попарно,</segment>
		<segment id="222" parent="221" relname="cause">убив так 100 человек.</segment>
		<segment id="223" parent="493" relname="joint">А в Литве сожгли заживо 119 жителей деревни Пирчюпис, среди которых была 61 женщина и 49 детей.</segment>
		<segment id="224" parent="494" relname="evaluation">Прославление убийц собственных народов, как это сейчас происходит в странах Балтии, сродни духовному суициду.</segment>
		<segment id="225" parent="497" relname="joint">Таллин освобождал 8-й эстонский корпус под командованием генерала Л.А. Пэрна.</segment>
		<segment id="226" parent="496" relname="joint">Бойцы корпуса в числе первых 22 сентября 1944 года ворвались в Таллин</segment>
		<segment id="227" parent="496" relname="joint">и предотвратили разрушения, подготовленные врагом.</segment>
		<segment id="228" parent="497" relname="joint">В состав корпуса входила 7-я эстонская стрелковая дивизия.</segment>
		<segment id="229" parent="497" relname="joint">Командиром ее был полковник К.А. Алликас, начальником штаба - Х.Р. Лессель.</segment>
		<segment id="230" parent="499" relname="contrast">Впрочем, эстонцы освобождали не только Таллин.</segment>
		<segment id="231" parent="498" relname="span">Они освобождали и Латвию, причем весной 1945 года,</segment>
		<segment id="232" parent="231" relname="elaboration">когда только "Курляндская группировка" немцев еще удерживалась на побережье Янтарного моря.</segment>
		<segment id="233" parent="500" relname="span">"Тут воевали отборные части СС,</segment>
		<segment id="234" parent="233" relname="attribution">- вспоминал Н. Куплайс из 308-й латышской дивизии. -</segment>
		<segment id="235" parent="501" relname="joint">И не только они,</segment>
		<segment id="236" parent="501" relname="joint">мне лично пришлось столкнуться с власовцами&hellip;</segment>
		<segment id="237" parent="510" relname="joint">В какой-то из дней, &hellip;должно быть в конце марта, &hellip;я со своими разведчиками подходил к небольшому хутору.</segment>
		<segment id="238" parent="502" relname="joint">Вдруг смотрим,</segment>
		<segment id="239" parent="502" relname="joint">из хутора через поле от нас убегают двое.</segment>
		<segment id="240" parent="510" relname="joint">По виду - наши, в телогрейках.</segment>
		<segment id="241" parent="509" relname="span">Только зачем тогда бегут?</segment>
		<segment id="242" parent="503" relname="span">А когда вошли в сарай,</segment>
		<segment id="243" parent="242" relname="elaboration">откуда они выбежали,</segment>
		<segment id="244" parent="504" relname="span">все стало ясно.</segment>
		<segment id="245" parent="508" relname="joint">Там, связанные колючей проволокой, лежали трое наших солдат.</segment>
		<segment id="246" parent="508" relname="joint">Были они облиты мазутом и медленно горели.</segment>
		<segment id="247" parent="505" relname="contrast">Как мы ни старались,</segment>
		<segment id="248" parent="505" relname="contrast">но спасти их не удалось&hellip;</segment>
		<segment id="249" parent="250" relname="attribution">Хозяева хутора сказали,</segment>
		<segment id="250" parent="506" relname="span">что те двое называли себя солдатами генерала Власова&hellip;</segment>
		<segment id="251" parent="507" relname="joint">Вот после этого мы и начали штурмовать железнодорожную насыпь, правее станции Блидене.</segment>
		<segment id="252" parent="507" relname="joint">А левыми нашими соседями были солдаты эстонского корпуса".</segment>
		<segment id="253" parent="527" relname="preparation">Именно здесь в бою за железнодорожную станцию Блидене Салдусской волости Салдусского края в Курземе Латвии геройски погиб эстонец, лейтенант Якоб Кундер.</segment>
		<segment id="254" parent="516" relname="joint">18 марта 1945 года он подобрался к немецкому ДЗОТу</segment>
		<segment id="255" parent="516" relname="joint">и попытался расстрелять его расчет из пистолета,</segment>
		<segment id="256" parent="517" relname="condition">но при этом был тяжело ранен.</segment>
		<segment id="257" parent="522" relname="span">Тогда он бросился грудью на пулемет.</segment>
		<segment id="258" parent="519" relname="joint">Когда тот замолчал,</segment>
		<segment id="259" parent="521" relname="span">подоспели и солдаты его взвода,</segment>
		<segment id="260" parent="520" relname="joint">которые забросали ДЗОТ гранатами</segment>
		<segment id="261" parent="520" relname="joint">и расстреляли из пулемета.</segment>
		<segment id="262" parent="524" relname="span">Посмертно эстонец Якоб Кундер,</segment>
		<segment id="263" parent="262" relname="elaboration">принимавший участие в освобождении Латвии от нацистов,</segment>
		<segment id="264" parent="525" relname="same-unit">был удостоен звания Героя Советского Союза.</segment>
		<segment id="265" parent="529" relname="span">Сегодня же некоторые политики стран Восточной Европы впадают в другую крайность</segment>
		<segment id="266" parent="265" relname="elaboration">- пытаются делить победу над нацизмом по национальному признаку:</segment>
		<segment id="267" parent="530" relname="joint">кто освобождал Освенцим,</segment>
		<segment id="268" parent="530" relname="joint">кто освобождал Берлин,</segment>
		<segment id="269" parent="530" relname="joint">сколько там было русских, украинцев или представителей других национальностей,</segment>
		<segment id="270" parent="530" relname="joint">кто из них внес больший вклад?</segment>
		<segment id="271" parent="537" relname="span">В связи с этим можно привести довольно характерный пример из истории освобождения Эстонии, во время боев за остров Сааремаа:</segment>
		<segment id="272" parent="532" relname="span">"Одну картину я запомнил надолго, на всю жизнь,</segment>
		<segment id="273" parent="272" relname="attribution">- вспоминает один из участников этих боев. -</segment>
		<segment id="274" parent="536" relname="joint">Из-за куста можжевельника выползли двое раненых.</segment>
		<segment id="275" parent="536" relname="joint">Они молча помогали друг другу.</segment>
		<segment id="276" parent="536" relname="joint">Кровь струилась у них из ран.</segment>
		<segment id="277" parent="536" relname="joint">Я их окликнул.</segment>
		<segment id="278" parent="536" relname="joint">Один ответил по-эстонски, другой - по-русски.</segment>
		<segment id="279" parent="536" relname="joint">Они не понимали друг друга.</segment>
		<segment id="280" parent="533" relname="span">Тяжелораненый эстонец жестами давал понять,</segment>
		<segment id="281" parent="280" relname="purpose">чтобы русский товарищ полз без него.</segment>
		<segment id="282" parent="534" relname="joint">Русский отрицательно качал головой</segment>
		<segment id="283" parent="534" relname="joint">и продолжал помогать эстонцу.</segment>
		<segment id="284" parent="536" relname="joint">Мы выручили обоих раненых.</segment>
		<segment id="285" parent="535" relname="joint">Они ни за что не хотели расставаться</segment>
		<segment id="286" parent="535" relname="joint">и поехали вместе в наш медсанбат".</segment>
		<segment id="287" parent="539" relname="span">Да, Солдат предвидел,</segment>
		<segment id="288" parent="287" relname="elaboration">что с фашизмом придется сражаться и спустя много лет после мая 1945 года.</segment>
		<segment id="289" parent="542" relname="span">И в этой битве нам поможет история -</segment>
		<segment id="290" parent="541" relname="span">такие ее эпизоды,</segment>
		<segment id="291" parent="540" relname="joint">когда мы воевали плечом к плечу против общего врага,</segment>
		<segment id="292" parent="540" relname="joint">и никто не думал, кто по национальности твой брат по оружию рядом с тобой.</segment>
		<group id="293" type="multinuc" parent="298" relname="preparation"/>
		<group id="294" type="multinuc" parent="295" relname="span"/>
		<group id="295" type="span" parent="296" relname="span"/>
		<group id="296" type="span" parent="297" relname="joint"/>
		<group id="297" type="multinuc" parent="298" relname="span"/>
		<group id="298" type="span" parent="299" relname="span"/>
		<group id="299" type="span" />
		<group id="300" type="multinuc" parent="302" relname="elaboration"/>
		<group id="301" type="multinuc" parent="300" relname="sequence"/>
		<group id="302" type="span" parent="303" relname="span"/>
		<group id="303" type="span" parent="305" relname="evaluation"/>
		<group id="304" type="multinuc" parent="305" relname="span"/>
		<group id="305" type="span" parent="306" relname="span"/>
		<group id="306" type="span" />
		<group id="307" type="span" parent="308" relname="joint"/>
		<group id="308" type="multinuc" parent="14" relname="elaboration"/>
		<group id="309" type="span" parent="311" relname="joint"/>
		<group id="310" type="span" parent="311" relname="joint"/>
		<group id="311" type="multinuc" />
		<group id="312" type="span" parent="315" relname="span"/>
		<group id="313" type="span" parent="314" relname="span"/>
		<group id="314" type="span" parent="312" relname="elaboration"/>
		<group id="315" type="span" parent="316" relname="contrast"/>
		<group id="316" type="multinuc" />
		<group id="317" type="multinuc" parent="318" relname="joint"/>
		<group id="318" type="multinuc" parent="29" relname="elaboration"/>
		<group id="319" type="span" parent="28" relname="elaboration"/>
		<group id="320" type="span" parent="321" relname="joint"/>
		<group id="321" type="multinuc" />
		<group id="322" type="span" parent="326" relname="joint"/>
		<group id="323" type="span" parent="325" relname="joint"/>
		<group id="324" type="span" parent="325" relname="joint"/>
		<group id="325" type="multinuc" parent="326" relname="joint"/>
		<group id="326" type="multinuc" />
		<group id="327" type="span" parent="39" relname="elaboration"/>
		<group id="328" type="span" parent="333" relname="span"/>
		<group id="329" type="multinuc" parent="330" relname="joint"/>
		<group id="330" type="multinuc" parent="331" relname="elaboration"/>
		<group id="331" type="span" parent="332" relname="span"/>
		<group id="332" type="span" parent="328" relname="evidence"/>
		<group id="333" type="span" />
		<group id="334" type="span" parent="336" relname="contrast"/>
		<group id="335" type="multinuc" parent="336" relname="contrast"/>
		<group id="336" type="multinuc" parent="51" relname="elaboration"/>
		<group id="337" type="span" parent="338" relname="span"/>
		<group id="338" type="span" parent="339" relname="joint"/>
		<group id="339" type="multinuc" />
		<group id="340" type="span" parent="341" relname="sequence"/>
		<group id="341" type="multinuc" parent="342" relname="contrast"/>
		<group id="342" type="multinuc" parent="57" relname="elaboration"/>
		<group id="343" type="multinuc" parent="344" relname="evaluation"/>
		<group id="344" type="span" parent="345" relname="span"/>
		<group id="345" type="span" />
		<group id="346" type="span" parent="347" relname="span"/>
		<group id="347" type="span" parent="348" relname="joint"/>
		<group id="348" type="multinuc" parent="352" relname="preparation"/>
		<group id="349" type="span" parent="71" relname="evidence"/>
		<group id="350" type="span" parent="351" relname="joint"/>
		<group id="351" type="multinuc" parent="69" relname="elaboration"/>
		<group id="352" type="span" parent="353" relname="span"/>
		<group id="353" type="span" />
		<group id="354" type="span" parent="362" relname="same-unit"/>
		<group id="355" type="span" parent="356" relname="same-unit"/>
		<group id="356" type="multinuc" parent="364" relname="span"/>
		<group id="357" type="multinuc" parent="358" relname="elaboration"/>
		<group id="358" type="span" parent="365" relname="span"/>
		<group id="359" type="span" />
		<group id="360" type="span" parent="354" relname="span"/>
		<group id="361" type="span" parent="355" relname="span"/>
		<group id="362" type="multinuc" parent="356" relname="same-unit"/>
		<group id="363" type="multinuc" parent="357" relname="joint"/>
		<group id="364" type="span" parent="358" relname="span"/>
		<group id="365" type="span" parent="359" relname="span"/>
		<group id="366" type="multinuc" parent="381" relname="joint"/>
		<group id="368" type="multinuc" parent="376" relname="sequence"/>
		<group id="369" type="span" parent="370" relname="same-unit"/>
		<group id="370" type="multinuc" parent="371" relname="span"/>
		<group id="371" type="span" parent="375" relname="span"/>
		<group id="372" type="span" parent="371" relname="evaluation"/>
		<group id="373" type="multinuc" parent="374" relname="joint"/>
		<group id="374" type="multinuc" parent="376" relname="sequence"/>
		<group id="375" type="span" parent="86" relname="elaboration"/>
		<group id="376" type="multinuc" parent="82" relname="elaboration"/>
		<group id="377" type="span" parent="376" relname="sequence"/>
		<group id="378" type="span" parent="381" relname="joint"/>
		<group id="379" type="multinuc" parent="380" relname="joint"/>
		<group id="380" type="multinuc" parent="383" relname="span"/>
		<group id="381" type="multinuc" parent="382" relname="span"/>
		<group id="382" type="span" parent="383" relname="cause"/>
		<group id="383" type="span" parent="384" relname="span"/>
		<group id="384" type="span" />
		<group id="385" type="multinuc" parent="100" relname="elaboration"/>
		<group id="386" type="span" parent="387" relname="joint"/>
		<group id="387" type="multinuc" parent="97" relname="elaboration"/>
		<group id="388" type="span" />
		<group id="389" type="multinuc" parent="103" relname="purpose"/>
		<group id="390" type="span" parent="392" relname="sequence"/>
		<group id="391" type="multinuc" parent="392" relname="sequence"/>
		<group id="392" type="multinuc" parent="395" relname="background"/>
		<group id="393" type="multinuc" parent="394" relname="joint"/>
		<group id="394" type="multinuc" parent="395" relname="span"/>
		<group id="395" type="span" parent="396" relname="span"/>
		<group id="396" type="span" />
		<group id="397" type="multinuc" parent="399" relname="joint"/>
		<group id="398" type="span" parent="399" relname="joint"/>
		<group id="399" type="multinuc" />
		<group id="400" type="span" parent="119" relname="cause"/>
		<group id="401" type="span" parent="544" relname="span"/>
		<group id="406" type="span" parent="407" relname="sequence"/>
		<group id="407" type="multinuc" parent="411" relname="sequence"/>
		<group id="408" type="span" parent="125" relname="cause"/>
		<group id="409" type="span" parent="411" relname="sequence"/>
		<group id="410" type="multinuc" parent="412" relname="joint"/>
		<group id="411" type="multinuc" parent="412" relname="joint"/>
		<group id="412" type="multinuc" />
		<group id="413" type="multinuc" parent="130" relname="elaboration"/>
		<group id="414" type="multinuc" parent="417" relname="sequence"/>
		<group id="415" type="multinuc" parent="418" relname="joint"/>
		<group id="416" type="span" parent="419" relname="preparation"/>
		<group id="417" type="multinuc" parent="418" relname="joint"/>
		<group id="418" type="multinuc" parent="419" relname="span"/>
		<group id="419" type="span" parent="420" relname="span"/>
		<group id="420" type="span" />
		<group id="421" type="span" parent="432" relname="joint"/>
		<group id="422" type="multinuc" parent="423" relname="joint"/>
		<group id="423" type="multinuc" parent="432" relname="joint"/>
		<group id="424" type="multinuc" parent="431" relname="sequence"/>
		<group id="425" type="span" parent="431" relname="sequence"/>
		<group id="426" type="span" parent="148" relname="elaboration"/>
		<group id="427" type="span" parent="431" relname="sequence"/>
		<group id="428" type="multinuc" parent="430" relname="joint"/>
		<group id="429" type="span" parent="428" relname="same-unit"/>
		<group id="430" type="multinuc" parent="431" relname="sequence"/>
		<group id="431" type="multinuc" parent="432" relname="joint"/>
		<group id="432" type="multinuc" parent="433" relname="span"/>
		<group id="433" type="span" parent="434" relname="span"/>
		<group id="434" type="span" />
		<group id="435" type="span" parent="438" relname="span"/>
		<group id="436" type="multinuc" parent="157" relname="elaboration"/>
		<group id="437" type="span" parent="435" relname="elaboration"/>
		<group id="438" type="span" parent="439" relname="joint"/>
		<group id="439" type="multinuc" />
		<group id="440" type="multinuc" parent="162" relname="purpose"/>
		<group id="441" type="span" parent="443" relname="comparison"/>
		<group id="442" type="multinuc" parent="444" relname="span"/>
		<group id="443" type="multinuc" parent="442" relname="joint"/>
		<group id="444" type="span" parent="167" relname="cause"/>
		<group id="445" type="span" />
		<group id="446" type="multinuc" />
		<group id="447" type="multinuc" parent="448" relname="span"/>
		<group id="448" type="span" parent="174" relname="cause"/>
		<group id="449" type="span" />
		<group id="450" type="multinuc" parent="451" relname="joint"/>
		<group id="451" type="multinuc" />
		<group id="452" type="multinuc" parent="466" relname="span"/>
		<group id="453" type="span" parent="454" relname="joint"/>
		<group id="454" type="multinuc" parent="183" relname="solutionhood"/>
		<group id="455" type="span" parent="456" relname="joint"/>
		<group id="456" type="multinuc" parent="463" relname="span"/>
		<group id="457" type="span" parent="465" relname="joint"/>
		<group id="458" type="span" parent="459" relname="same-unit"/>
		<group id="459" type="multinuc" parent="462" relname="joint"/>
		<group id="460" type="multinuc" parent="462" relname="joint"/>
		<group id="461" type="span" parent="460" relname="joint"/>
		<group id="462" type="multinuc" parent="463" relname="solutionhood"/>
		<group id="463" type="span" parent="464" relname="span"/>
		<group id="464" type="span" parent="465" relname="joint"/>
		<group id="465" type="multinuc" parent="466" relname="attribution"/>
		<group id="466" type="span" parent="467" relname="span"/>
		<group id="467" type="span" parent="468" relname="joint"/>
		<group id="468" type="multinuc" parent="470" relname="span"/>
		<group id="469" type="multinuc" parent="471" relname="span"/>
		<group id="470" type="span" parent="471" relname="cause"/>
		<group id="471" type="span" parent="472" relname="span"/>
		<group id="472" type="span" parent="473" relname="span"/>
		<group id="473" type="span" />
		<group id="474" type="multinuc" parent="476" relname="joint"/>
		<group id="475" type="multinuc" parent="476" relname="joint"/>
		<group id="476" type="multinuc" parent="477" relname="span"/>
		<group id="477" type="span" parent="478" relname="span"/>
		<group id="478" type="span" />
		<group id="479" type="span" parent="483" relname="preparation"/>
		<group id="480" type="multinuc" parent="482" relname="joint"/>
		<group id="481" type="span" parent="482" relname="joint"/>
		<group id="482" type="multinuc" parent="483" relname="span"/>
		<group id="483" type="span" parent="484" relname="span"/>
		<group id="484" type="span" />
		<group id="485" type="span" parent="487" relname="span"/>
		<group id="486" type="multinuc" parent="485" relname="cause"/>
		<group id="487" type="span" parent="488" relname="span"/>
		<group id="488" type="span" />
		<group id="489" type="multinuc" parent="491" relname="joint"/>
		<group id="490" type="multinuc" parent="491" relname="joint"/>
		<group id="491" type="multinuc" />
		<group id="492" type="span" parent="493" relname="joint"/>
		<group id="493" type="multinuc" parent="494" relname="span"/>
		<group id="494" type="span" parent="495" relname="span"/>
		<group id="495" type="span" />
		<group id="496" type="multinuc" parent="497" relname="joint"/>
		<group id="497" type="multinuc" />
		<group id="498" type="span" parent="499" relname="contrast"/>
		<group id="499" type="multinuc" parent="514" relname="preparation"/>
		<group id="500" type="span" parent="513" relname="joint"/>
		<group id="501" type="multinuc" parent="511" relname="span"/>
		<group id="502" type="multinuc" parent="510" relname="joint"/>
		<group id="503" type="span" parent="244" relname="cause"/>
		<group id="504" type="span" parent="508" relname="joint"/>
		<group id="505" type="multinuc" parent="508" relname="joint"/>
		<group id="506" type="span" parent="508" relname="joint"/>
		<group id="507" type="multinuc" parent="508" relname="joint"/>
		<group id="508" type="multinuc" parent="241" relname="solutionhood"/>
		<group id="509" type="span" parent="510" relname="joint"/>
		<group id="510" type="multinuc" parent="511" relname="elaboration"/>
		<group id="511" type="span" parent="512" relname="span"/>
		<group id="512" type="span" parent="513" relname="joint"/>
		<group id="513" type="multinuc" parent="514" relname="span"/>
		<group id="514" type="span" parent="515" relname="span"/>
		<group id="515" type="span" />
		<group id="516" type="multinuc" parent="517" relname="span"/>
		<group id="517" type="span" parent="518" relname="span"/>
		<group id="518" type="span" parent="257" relname="cause"/>
		<group id="519" type="multinuc" parent="523" relname="sequence"/>
		<group id="520" type="multinuc" parent="259" relname="elaboration"/>
		<group id="521" type="span" parent="519" relname="joint"/>
		<group id="522" type="span" parent="523" relname="sequence"/>
		<group id="523" type="multinuc" parent="526" relname="cause"/>
		<group id="524" type="span" parent="525" relname="same-unit"/>
		<group id="525" type="multinuc" parent="526" relname="span"/>
		<group id="526" type="span" parent="527" relname="span"/>
		<group id="527" type="span" parent="528" relname="span"/>
		<group id="528" type="span" />
		<group id="529" type="span" parent="531" relname="span"/>
		<group id="530" type="multinuc" parent="529" relname="elaboration"/>
		<group id="531" type="span" parent="538" relname="span"/>
		<group id="532" type="span" parent="536" relname="joint"/>
		<group id="533" type="span" parent="536" relname="joint"/>
		<group id="534" type="multinuc" parent="536" relname="joint"/>
		<group id="535" type="multinuc" parent="536" relname="joint"/>
		<group id="536" type="multinuc" parent="271" relname="elaboration"/>
		<group id="537" type="span" parent="531" relname="solutionhood"/>
		<group id="538" type="span" />
		<group id="539" type="span" parent="543" relname="joint"/>
		<group id="540" type="multinuc" parent="290" relname="elaboration"/>
		<group id="541" type="span" parent="289" relname="elaboration"/>
		<group id="542" type="span" parent="543" relname="joint"/>
		<group id="543" type="multinuc" />
		<group id="544" type="span" parent="545" relname="span"/>
		<group id="545" type="span" parent="546" relname="span"/>
		<group id="546" type="span" />
		<group id="547" type="span" parent="368" relname="same-unit"/>
	</body>
</rst>