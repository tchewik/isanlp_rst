<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="2" relname="preparation">Новость: Ушел из жизни талантливый организатор производства – Аркадий Павлович Айдак</segment>
		<segment id="2" parent="26" relname="span">9 сентября 2012 года на 76 году жизни скончался талантливый организатор производства, эколог, академик НАНИ Чувашской Республики, почетный профессор Российской академии менеджмента и агробизнеса, доцент Чувашского института повышения квалификации специалистов АПК, член-корреспондент и почетный профессор Академии кадровой политики Министерства сельского хозяйства Российской Федерации, почетный землеустроитель Российской Федерации председатель колхоза «Ленинская искра» в 1964 – 2007 годах, Почетный гражданин Ядринского района и Чувашской Республики Аркадий Павлович Айдак.</segment>
		<segment id="3" parent="27" relname="joint">Светлая память об Аркадии Павловиче Айдаке сохранится в наших сердцах.</segment>
		<segment id="4" parent="27" relname="joint">Гражданская панихида прощания с Аркадием Павловичем Айдаком пройдет 11 сентября 2012 г. в Верхнеачакском сельском Доме культуры Ядринского района с 12.00 до 13.00 часов.</segment>
		<segment id="5" parent="28" relname="sequence">Аркадий Павлович Айдак родился 7 июня 1937 года в деревне Чербай Ядринского района Чувашской Республики.</segment>
		<segment id="6" parent="28" relname="sequence">В 1961 году окончил русско-чувашское отделение историко-филологического факультета Чувашского государственного педагогического института им. И.Я.Яковлева.</segment>
		<segment id="7" parent="28" relname="sequence">В 1960 году работал инструктором отдела учащейся молодежи Чувашского обкома ВЛКСМ, в 1961 – пропагандист Ядринского райкома КПСС, первый секретарь Ядринского райкома ВЛКСМ.</segment>
		<segment id="8" parent="28" relname="sequence">В 1962 году – секретарь первичной парторганизации колхоза «Ленинская искра», с 1964 года – председатель колхоза «Ленинская искра».</segment>
		<segment id="9" parent="28" relname="sequence">43 года являлся бессменным руководителем колхоза «Ленинская искра».</segment>
		<segment id="10" parent="30" relname="joint">Под его руководством колхоз стал экономически крепким многоотраслевым хозяйством</segment>
		<segment id="11" parent="31" relname="span">и известным на всю страну лидеров сельскохозяйственного производства,</segment>
		<segment id="12" parent="29" relname="joint">в котором внедрялись передовые методы управления,</segment>
		<segment id="13" parent="29" relname="joint">эффективно решались социальные вопросы жителей села,</segment>
		<segment id="14" parent="29" relname="joint">построены школы, клубы, санаторий.</segment>
		<segment id="15" parent="32" relname="joint">По инициативе Аркадия Павловича и при его непосредственном участии созданы уникальные природные комплексы и объекты, микрозаказники растительного и животного мира;</segment>
		<segment id="16" parent="32" relname="joint">создано заповедно-охотничье хозяйство колхоза и завезены из разных регионов страны олени, сурки, кабаны, речные бобры, куропатки, перепела и другие виды, которые потом расселились по соседним районам республики.</segment>
		<segment id="17" parent="33" relname="joint">На территории колхоза «Ленинская искра» создано более 270 га рукотворных лесов, 64 пруда  общей площадью 84 га,</segment>
		<segment id="18" parent="33" relname="joint">образован особо охраняемый этноприродный парк Чувашской Республики «Ачаки»,</segment>
		<segment id="19" parent="33" relname="joint">открыта конноспортивная школа (35 верховых лошадей),</segment>
		<segment id="20" parent="33" relname="joint">возрождена традиция проведения национального праздника «Акатуй»</segment>
		<segment id="21" parent="35" relname="joint">Аркадий Павлович избирался народным депутатом СССР (1989), Верховного Совета Чувашской АССР (1985), районного и местных советов.</segment>
		<segment id="22" parent="35" relname="joint">Награжден орденами Трудового Красного Знамени, Почета (1997), медалями, золотой медалью ВДНХ СССР.</segment>
		<segment id="23" parent="35" relname="joint">Заслуженный работник сельского хозяйства Чувашской Республики (1994), заслуженный работник сельского хозяйства Российской Федерации (1997), заслуженный работник культуры Чувашской АССР (1979), заслуженный работник культуры РСФСР (1985)</segment>
		<segment id="24" parent="34" relname="joint">До последних дней Аркадий Павлович принимал активное участие в общественной жизни района,</segment>
		<segment id="25" parent="34" relname="joint">являлся членом Совета ветеранов.</segment>
		<group id="26" type="span" parent="27" relname="joint"/>
		<group id="27" type="multinuc" />
		<group id="28" type="multinuc" />
		<group id="29" type="multinuc" parent="11" relname="elaboration"/>
		<group id="30" type="multinuc" />
		<group id="31" type="span" parent="30" relname="joint"/>
		<group id="32" type="multinuc" parent="35" relname="joint"/>
		<group id="33" type="multinuc" parent="35" relname="joint"/>
		<group id="34" type="multinuc" parent="35" relname="joint"/>
		<group id="35" type="multinuc" />
	</body>
</rst>