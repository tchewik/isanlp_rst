<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="139" relname="preparation">Искусство: Аванмарт парни-2015</segment>
		<segment id="2" parent="137" relname="span">Вот и дождались:</segment>
		<segment id="3" parent="81" relname="joint">«Не нужен нам берег турецкий,</segment>
		<segment id="4" parent="81" relname="joint">и Африка нам не нужна!».</segment>
		<segment id="5" parent="138" relname="span">Аван-премию за «литературный» 2015 год надо было бы присудить Михаилу Исаковскому, автору этих провидческих строк…</segment>
		<segment id="6" parent="136" relname="span">Собственно, отсюда становится очевидным и имя лауреата Анти-премии за минувший год…</segment>
		<segment id="7" parent="82" relname="span">Да, да, тот самый Эрдоган, тот самый Реджеп!</segment>
		<segment id="8" parent="7" relname="evaluation">Более него кажется в этом году никто столько крови не попортил.</segment>
		<segment id="9" >Кажется, при чем тут мы, и «высокая» политика?</segment>
		<segment id="10" parent="124" relname="span">Вот том-то и дело,</segment>
		<segment id="11" parent="109" relname="span">что вся эта «политика» проходит через каждого из нас,</segment>
		<segment id="12" parent="110" relname="span">что делать,</segment>
		<segment id="13" parent="84" relname="joint">если пилоты с компании «Волга-Днепр», расстрелянных в Мали, живут в твоем дворе,</segment>
		<segment id="14" parent="83" relname="joint">а многие твои друзья и знакомые или учились в Турции</segment>
		<segment id="15" parent="83" relname="joint">или набирали кадры для учёбы там…</segment>
		<segment id="16" parent="125" relname="joint">Чему и зачем их там учили вроде бы начинаем осознавать.</segment>
		<segment id="17" parent="86" relname="span">Резонанс от сбитого бомбардировщика Су-24,</segment>
		<segment id="18" parent="17" relname="elaboration">сбитого в уходящем году в небе Сирии турецкими военными,</segment>
		<segment id="19" parent="85" relname="same-unit">кажется коснулся каждого в нашей стране.</segment>
		<segment id="20" parent="21" relname="evaluation">Понятно, что</segment>
		<segment id="21" parent="140" relname="span">бомбардировщики не конфетки и пряники разбрасывают,</segment>
		<segment id="22" parent="87" relname="joint">они тоже сеют разрушения и смерти…</segment>
		<segment id="23" parent="108" relname="span">Но… есть какие-то правила игры…</segment>
		<segment id="24" parent="101" relname="span">В детстве, на первом же оттаявшем бугорочке играли «В знамя».</segment>
		<segment id="25" parent="89" relname="evaluation">Игра нехитрая,</segment>
		<segment id="26" parent="88" relname="joint">на противоположных точках бугорочка устанавливали две палки (знамёна),</segment>
		<segment id="27" parent="88" relname="joint">а посередине проводили «границу».</segment>
		<segment id="28" parent="97" relname="purpose">Надо было лишить противника их палки-знамени.</segment>
		<segment id="29" parent="30" relname="condition">Если тебя за «границей» настигали хранители палки,</segment>
		<segment id="30" parent="94" relname="span">ты стоял «замороженный» до тех пор,</segment>
		<segment id="31" parent="90" relname="restatement">пока тебя свои не выручат,</segment>
		<segment id="32" parent="90" relname="restatement">и не «разморозят».</segment>
		<segment id="33" parent="34" relname="condition">Ну а если ты уж забежал на свою территорию,</segment>
		<segment id="34" parent="92" relname="span">тут уж их руки были бессильны,</segment>
		<segment id="35" parent="91" relname="sequence">теперь ты их мог ловить</segment>
		<segment id="36" parent="91" relname="sequence">и «морозить».</segment>
		<segment id="37" parent="101" relname="conclusion">Эти чисто пацанские понятия остались у меня до сих пор.</segment>
		<segment id="38" parent="107" relname="span">Это всё к тому сбитому самолёту…</segment>
		<segment id="39" parent="40" relname="condition">Если уж кто-то нарушил твою границу,</segment>
		<segment id="40" parent="104" relname="span">там и сбивай их, в своём небе,</segment>
		<segment id="41" parent="103" relname="condition">а если ты их сбиваешь над чужой территорией,</segment>
		<segment id="42" parent="103" relname="span">прости,</segment>
		<segment id="43" parent="42" relname="elaboration">это как не по-пацански, Рэджеп!</segment>
		<segment id="44" parent="135" relname="span">Задницу с ушами за 2015 год – Вам, уважаемый!</segment>
		<segment id="45" parent="127" relname="contrast">А что касается года литературы…</segment>
		<segment id="46" parent="123" relname="span">Нет, не получилось у меня книгу написать…</segment>
		<segment id="47" parent="46" relname="cause">Что ж, не всем дано…</segment>
		<segment id="48" parent="129" relname="span">Уходящий год – это и год 70-летия Победы.</segment>
		<segment id="49" parent="120" relname="comparison">Для меня самые проникновенные слова о войне – слова о последнем бое моего дедушки Порфирия.</segment>
		<segment id="50" parent="122" relname="span">Захватывают и книги Григория Свирского о войне,</segment>
		<segment id="51" parent="50" relname="cause">подкупая своей искренностью.</segment>
		<segment id="52" parent="121" relname="span">Когда-то с упоением прочитал книгу Андреева Порфирия Андреевича «Крутые вёрсты от Суры»…</segment>
		<segment id="53" parent="114" relname="span">Прочитал</segment>
		<segment id="54" parent="112" relname="joint">не только потому, что в детстве часто просыпался под звонкую мелодию его трубы,</segment>
		<segment id="55" parent="112" relname="joint">а потому, что строки эти написаны не для красного словца,</segment>
		<segment id="56" parent="113" relname="span">прочитал на одном дыхании,</segment>
		<segment id="57" parent="56" relname="concession">несмотря на многочисленные корректурные ошибки…</segment>
		<segment id="58" parent="118" relname="span">А вот рассказы В. Петровского после «ложила трубку» уже не мог читать…</segment>
		<segment id="59" parent="116" relname="joint">Конечно, интересных авторов много,</segment>
		<segment id="60" parent="116" relname="joint">и у каждого есть свой читатель…</segment>
		<segment id="61" parent="119" relname="span">Вот и переводы с шведского Иосифа Трера нет-нет, да и остановят тебя на несколько минут за монитором…</segment>
		<segment id="62" parent="117" relname="joint">И ты об этом нисколько не жалеешь,</segment>
		<segment id="63" parent="117" relname="joint">а удивляешься красивому слогу и лаконизму мысли…</segment>
		<segment id="64" parent="134" relname="preparation">Всё же, хватит вокруг да около…</segment>
		<segment id="65" parent="133" relname="joint">Лауреатом Аван-премии за 2015 год объявляется Марина Карягина - писатель, поэт, журналист.</segment>
		<segment id="66" parent="77" relname="span">Спасибо ей за свой посильный</segment>
		<segment id="67" parent="66" relname="elaboration">(а может и непосильный)</segment>
		<segment id="68" parent="80" relname="span">вклад</segment>
		<segment id="69" parent="79" relname="same-unit">в сохранение</segment>
		<segment id="70" parent="71" relname="attribution">признанного ЮНЕСКО</segment>
		<segment id="71" parent="141" relname="span">исчезающим</segment>
		<segment id="72" parent="79" relname="same-unit">чувашского языка!</segment>
		<segment id="73" parent="130" relname="span">Чего стоят её пионерские палиндромы на чувашском!</segment>
		<segment id="74" parent="73" relname="elaboration">(К примеру: «Ҫӗрӗпе пӗр ӗҫ» - для тех, кто понимает)</segment>
		<segment id="75" >Прими, Марина, поздравления!</segment>
		<group id="76" type="multinuc" parent="131" relname="span"/>
		<group id="77" type="span" parent="76" relname="same-unit"/>
		<group id="79" type="multinuc" parent="68" relname="elaboration"/>
		<group id="80" type="span" parent="76" relname="same-unit"/>
		<group id="81" type="multinuc" parent="2" relname="elaboration"/>
		<group id="82" type="span" parent="6" relname="elaboration"/>
		<group id="83" type="multinuc" parent="84" relname="joint"/>
		<group id="84" type="multinuc" parent="12" relname="condition"/>
		<group id="85" type="multinuc" parent="111" relname="background"/>
		<group id="86" type="span" parent="85" relname="same-unit"/>
		<group id="87" type="multinuc" parent="108" relname="concession"/>
		<group id="88" type="multinuc" parent="89" relname="span"/>
		<group id="89" type="span" parent="98" relname="span"/>
		<group id="90" type="multinuc" parent="30" relname="condition"/>
		<group id="91" type="multinuc" parent="93" relname="span"/>
		<group id="92" type="span" parent="93" relname="cause"/>
		<group id="93" type="span" parent="95" relname="span"/>
		<group id="94" type="span" parent="96" relname="joint"/>
		<group id="95" type="span" parent="96" relname="joint"/>
		<group id="96" type="multinuc" parent="97" relname="span"/>
		<group id="97" type="span" parent="99" relname="span"/>
		<group id="98" type="span" parent="99" relname="preparation"/>
		<group id="99" type="span" parent="100" relname="span"/>
		<group id="100" type="span" parent="24" relname="elaboration"/>
		<group id="101" type="span" parent="102" relname="span"/>
		<group id="102" type="span" parent="23" relname="elaboration"/>
		<group id="103" type="span" parent="106" relname="span"/>
		<group id="104" type="span" parent="105" relname="joint"/>
		<group id="105" type="multinuc" parent="38" relname="elaboration"/>
		<group id="106" type="span" parent="105" relname="joint"/>
		<group id="107" type="span" parent="44" relname="cause"/>
		<group id="108" type="span" parent="111" relname="span"/>
		<group id="109" type="span" parent="10" relname="elaboration"/>
		<group id="110" type="span" parent="11" relname="elaboration"/>
		<group id="111" type="span" parent="135" relname="preparation"/>
		<group id="112" type="multinuc" parent="53" relname="cause"/>
		<group id="113" type="span" parent="115" relname="joint"/>
		<group id="114" type="span" parent="115" relname="joint"/>
		<group id="115" type="multinuc" parent="52" relname="elaboration"/>
		<group id="116" type="multinuc" parent="58" relname="evaluation"/>
		<group id="117" type="multinuc" parent="61" relname="evaluation"/>
		<group id="118" type="span" parent="120" relname="comparison"/>
		<group id="119" type="span" parent="120" relname="comparison"/>
		<group id="120" type="multinuc" parent="128" relname="span"/>
		<group id="121" type="span" parent="120" relname="comparison"/>
		<group id="122" type="span" parent="120" relname="comparison"/>
		<group id="123" type="span" parent="127" relname="contrast"/>
		<group id="124" type="span" parent="125" relname="joint"/>
		<group id="125" type="multinuc" parent="9" relname="solutionhood"/>
		<group id="126" type="span" parent="48" relname="preparation"/>
		<group id="127" type="multinuc" parent="126" relname="span"/>
		<group id="128" type="span" />
		<group id="129" type="span" parent="128" relname="cause"/>
		<group id="130" type="span" parent="131" relname="elaboration"/>
		<group id="131" type="span" parent="132" relname="span"/>
		<group id="132" type="span" parent="133" relname="joint"/>
		<group id="133" type="multinuc" parent="134" relname="span"/>
		<group id="134" type="span" />
		<group id="135" type="span" />
		<group id="136" type="span" parent="139" relname="span"/>
		<group id="137" type="span" parent="5" relname="preparation"/>
		<group id="138" type="span" parent="136" relname="cause"/>
		<group id="139" type="span" />
		<group id="140" type="span" parent="87" relname="joint"/>
		<group id="141" type="span" parent="79" relname="same-unit"/>
	</body>
</rst>