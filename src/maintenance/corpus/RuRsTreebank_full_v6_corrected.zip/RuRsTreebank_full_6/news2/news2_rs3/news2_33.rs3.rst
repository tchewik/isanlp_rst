<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="275" relname="preparation">Миграционный кризис стал испытанием для европейских идеалов, политиков и общества</segment>
		<segment id="2" parent="273" relname="span">Внеочередной саммит Евросоюза по вопросу миграции намечен на предстоящую среду, 23 сентября.</segment>
		<segment id="3" parent="271" relname="attribution">Инициатором его созыва выступил глава Евросовета Дональд Туск (Donald Tusk), который 17 сентября сообщил,</segment>
		<segment id="4" parent="270" relname="joint">что намерен на текущей неделе совершить визиты в Египет и Иорданию</segment>
		<segment id="5" parent="270" relname="joint">и посетить лагеря беженцев.</segment>
		<segment id="6" parent="274" relname="joint">При этом провести экстренную встречу лидеров сообщества первым предложил за два дня до этого словацкий премьер-министр Роберт Фицо (Robert Fico).</segment>
		<segment id="7" parent="8" relname="attribution">Германия и Австрия позже заявили,</segment>
		<segment id="8" parent="515" relname="span">что поддерживают идею созыва на будущей неделе саммита ЕС.</segment>
		<segment id="9" parent="276" relname="span">В понедельник, 14 сентября, в Брюсселе состоялось заседание глав МВД стран ЕС,</segment>
		<segment id="10" parent="9" relname="elaboration">которое завершилось безрезультатно.</segment>
		<segment id="11" parent="276" relname="elaboration">Они так и не смогли договориться об обязательных квотах на распределение беженцев по странам союза.</segment>
		<segment id="12" parent="277" relname="span">Заседание закончилось без утверждения предложения</segment>
		<segment id="13" parent="12" relname="attribution">главы Еврокомиссии Жан-Клода Юнкера (Jean-Claude Juncker)</segment>
		<segment id="14" parent="278" relname="same-unit">об увеличении до 120 тыс. числа бегущих от войны мигрантов.</segment>
		<segment id="15" >Идея введения обязательных квот на распределение беженцев фактически расколола Европу.</segment>
		<segment id="16" parent="282" relname="contrast">В Германии, Франции, Бельгии, Швейцарии, Люксембурге и Литве выразили готовность поддержать этот процесс,</segment>
		<segment id="17" parent="282" relname="contrast">однако представители Венгрии, Словакии, Чехии, Польши, Румынии, Дании и ряда других стран подвергли идею Жан-Клода Юнкера жестокой критике.</segment>
		<segment id="18" parent="283" relname="span">В то же время власти Великобритании,</segment>
		<segment id="19" parent="18" relname="elaboration">где уже открыто говорят о своих планах выйти из Евросоюза,</segment>
		<segment id="20" parent="21" relname="attribution">отказались участвовать в схеме по распределению мигрантов, заявив</segment>
		<segment id="21" parent="516" relname="span">о намерении самостоятельно принять не более 50 тыс. граждан Сирии на основании собственных критериев отбора.</segment>
		<segment id="22" parent="298" relname="span">Между тем в Европу ежедневно продолжают прибывать тысячи человек из Сирии, Косово, Афганистана, Ирака, Эритреи, Пакистана и других стран,</segment>
		<segment id="23" parent="289" relname="span">покинувших свои дома</segment>
		<segment id="24" parent="287" relname="joint">из-за военных действий</segment>
		<segment id="25" parent="287" relname="joint">и нищеты.</segment>
		<segment id="26" parent="291" relname="attribution">По данным агентства по контролю за границами Frontex,</segment>
		<segment id="27" parent="290" relname="comparison">с начала 2015 года в Евросоюз прибыли более полумиллиона беженцев,</segment>
		<segment id="28" parent="290" relname="comparison">в то время как за весь 2014 год - 280 тыс. человек.</segment>
		<segment id="29" parent="292" relname="span">И эта цифра,</segment>
		<segment id="30" parent="29" relname="attribution">как отмечают обозреватели,</segment>
		<segment id="31" parent="293" relname="same-unit">к концу года может вырасти еще в два раза,</segment>
		<segment id="32" parent="294" relname="concession">несмотря на усилия Венгрии, Австрии, Македонии, Германии и других государств воспрепятствовать этому.</segment>
		<segment id="33" parent="302" relname="attribution">По мнению зарубежных аналитиков,</segment>
		<segment id="34" parent="300" relname="span">беженцы,</segment>
		<segment id="35" parent="34" relname="elaboration">которые попадают в Европу из-за слабого пограничного контроля,</segment>
		<segment id="36" parent="301" relname="same-unit">представляют значительную угрозу для стран ЕС.</segment>
		<segment id="37" parent="38" relname="attribution">Они опасаются также,</segment>
		<segment id="38" parent="306" relname="span">что среди сотен тысяч прибывающих людей могут скрываться боевики "Исламского государства".</segment>
		<segment id="39" parent="304" relname="effect">При этом со многими вынужденными мигрантами, находящимися в бедственном положении, уже работают вербовщики террористов,</segment>
		<segment id="40" parent="303" relname="joint">что в обозримом будущем может привести к "европейскому джихаду"</segment>
		<segment id="41" parent="303" relname="joint">и поставить под угрозу существование Шенгенского соглашения.</segment>
		<segment id="42" parent="43" relname="attribution">Вместе с тем многие эксперты и политики</segment>
		<segment id="43" parent="311" relname="span">призывают уделять внимание не только задаче помощи беженцам в Европе.</segment>
		<segment id="44" parent="310" relname="attribution">По их словам,</segment>
		<segment id="45" parent="309" relname="joint">необходимо искать корни проблемы в прошлом,</segment>
		<segment id="46" parent="309" relname="joint">делать на основе принятых тогда решений соответствующие выводы</segment>
		<segment id="47" parent="309" relname="joint">и не допускать тех ошибок, которые в будущем могут стать фатальными для миллионов граждан Евросоюза.</segment>
		<segment id="48" parent="314" relname="attribution">Так, например, директор сербского Центра междисциплинарных исследований Хоакин Флорес (Joaquin Flores) напомнил,</segment>
		<segment id="49" parent="313" relname="joint">что в НАТО длительное время фактически игнорировали тему возможных последствий конфликтов в Ливии, Сирии и Ираке,</segment>
		<segment id="50" parent="313" relname="joint">а отдельные западные страны и их союзники своим вмешательством активно поощряли кровопролитие на Ближнем Востоке.</segment>
		<segment id="51" parent="315" relname="joint">"Они [страны Европы] не смогут просто взять</segment>
		<segment id="52" parent="315" relname="joint">и заклеить эту прореху деньгами</segment>
		<segment id="53" parent="316" relname="purpose">и таким образом стабилизировать обстановку.</segment>
		<segment id="54" parent="55" relname="condition">Пока США и европейские друзья Вашингтона не прекратят и дальше расшатывать ситуацию,</segment>
		<segment id="55" parent="318" relname="span">напряжение будет только нарастать.</segment>
		<segment id="56" parent="319" relname="joint">А в регионе еще десятки миллионов людей.</segment>
		<segment id="57" parent="319" relname="joint">Что они с ними будут делать?</segment>
		<segment id="58" parent="319" relname="joint">Всех принимать?</segment>
		<segment id="59" parent="320" relname="evaluation">Так дело уж точно не пойдет",</segment>
		<segment id="60" parent="321" relname="attribution">- выразил свое возмущение аналитик в интервью иранскому телеканалу Press TV, назвав подход Брюсселя к вопросу механическим.</segment>
		<segment id="61" parent="62" relname="attribution">Директор европейского отделения международной организации "Друзья Земли" Магда Сточкевич (Magda Stoczkiewicz)</segment>
		<segment id="62" parent="336" relname="span">также осудила курс европейских политиков на "безрассудное сверхпотребление" мировых богатств.</segment>
		<segment id="63" parent="328" relname="comparison">"Наши решения здесь, в Европе, влияют на весь остальной мир.</segment>
		<segment id="64" parent="327" relname="span">Наши торговые соглашения подталкивают к бедности страны мирового юга,</segment>
		<segment id="65" parent="64" relname="elaboration">где транснациональные корпорации делают миллионы на дармовых ресурсах.</segment>
		<segment id="66" parent="325" relname="joint">Наша военная индустрия снабжает диктаторов,</segment>
		<segment id="67" parent="323" relname="purpose">а ради дешевых товаров для вечно голодной европейской экономики</segment>
		<segment id="68" parent="322" relname="joint">мы душим малоимущих</segment>
		<segment id="69" parent="322" relname="joint">и загрязняем окружающую среду.</segment>
		<segment id="70" parent="330" relname="span">Если первым лицам Европы не нужны беженцы,</segment>
		<segment id="71" parent="70" relname="condition">они обязаны разобраться с этими общесистемными проблемами.</segment>
		<segment id="72" parent="73" relname="condition">Если ЕС ничего не предпримет,</segment>
		<segment id="73" parent="331" relname="span">ситуация уйдет в пике",</segment>
		<segment id="74" parent="334" relname="span">- отметила она в статье,</segment>
		<segment id="75" parent="74" relname="elaboration">опубликованной в журнале The Parliament Magazine.</segment>
		<segment id="76" parent="340" relname="attribution">Схожую точку зрения высказал и член Бундестага от Левой партии Германии Штефан Либих (Stefan Liebich).</segment>
		<segment id="77" parent="337" relname="joint">"Если мы не будем предоставлять помощь тем государствам, откуда уезжают беженцы,</segment>
		<segment id="78" parent="337" relname="joint">если мы и дальше продолжим поставлять оружие в "сомнительные страны",</segment>
		<segment id="79" parent="337" relname="joint">если мы не перестанем бездумно тратить мировые богатства,</segment>
		<segment id="80" parent="339" relname="span">то не стоит ожидать, что поток людей, ищущих лучшей жизни, сократится",</segment>
		<segment id="81" parent="339" relname="attribution">- заявил политик.</segment>
		<segment id="82" >Он также обрушился с критикой на попытки Венгрии и ряда других европейских государств отвернуться от тысяч людей, оказавшихся в сложной ситуации.</segment>
		<segment id="83" parent="341" relname="contrast">"Сами по себе беженцы не представляют особой опасности для Евросоюза</segment>
		<segment id="84" parent="341" relname="contrast">- а вот отгораживаться от общих проблем опасно.</segment>
		<segment id="85" parent="347" relname="span">Всем нам необходимо объединить усилия в рамках ЕС,</segment>
		<segment id="86" parent="342" relname="joint">чтобы разрешить кризис</segment>
		<segment id="87" parent="342" relname="joint">и помочь нуждающимся.</segment>
		<segment id="88" parent="348" relname="span">Эти люди бежали от военных действий.</segment>
		<segment id="89" parent="344" relname="joint">Многие из них находятся в отчаянии</segment>
		<segment id="90" parent="344" relname="joint">и нуждаются в квалифицированной помощи",</segment>
		<segment id="91" parent="350" relname="attribution">- отметил Штефан Либих.</segment>
		<segment id="92" parent="93" relname="attribution">По его мнению,</segment>
		<segment id="93" parent="356" relname="span">Брюсселю необходимо в кратчайшие сроки организовать быстрые и легальные коридоры в Европу для вынужденных мигрантов.</segment>
		<segment id="94" parent="95" relname="purpose">"Если они хотят остановить незаконные перевозки людей через границу,</segment>
		<segment id="95" parent="352" relname="span">нужно заняться созданием таких коридоров.</segment>
		<segment id="96" parent="353" relname="joint">Это единственный способ положить конец гуманитарной катастрофе</segment>
		<segment id="97" parent="353" relname="joint">и уберечь от гибели тех, кто изо всех сил пытается спасти себя и свои семьи",</segment>
		<segment id="98" parent="355" relname="attribution">- сказал политик.</segment>
		<segment id="99" parent="100" relname="attribution">Вместе с тем старший аналитик венгерского Центра евроатлантической интеграции и демократии (CEID), бывший редактор газеты N&eacute;pszabads&aacute;g Эдит Инотай (Edit Inotai) отметила,</segment>
		<segment id="100" parent="358" relname="span">что беженцы уже потеряли веру в способность мирового сообщества положить конец военным действиям на Ближнем Востоке.</segment>
		<segment id="101" parent="359" relname="span">"Жестокость боевиков "Исламского государства" только подталкивает их к европейским границам",</segment>
		<segment id="102" parent="101" relname="attribution">- сказала она в интервью ИА "PenzaNews".</segment>
		<segment id="103" parent="363" relname="attribution">По ее словам,</segment>
		<segment id="104" parent="363" relname="span">жесткая реакция Венгрии на наплыв мигрантов</segment>
		<segment id="105" parent="360" relname="joint">вызвана не только внутриполитическими соображениями,</segment>
		<segment id="106" parent="361" relname="span">но и давлением со стороны Берлина и Вены</segment>
		<segment id="107" parent="106" relname="purpose">в попытке сдержать поток людей, пытающихся достичь Германии и Австрии.</segment>
		<segment id="108" parent="375" relname="contrast">"В Будапеште посчитали, что забор станет эффективной мерой защиты от беженцев.</segment>
		<segment id="109" parent="364" relname="contrast">Однако, по-видимому, они ошибались",</segment>
		<segment id="110" parent="365" relname="attribution">- констатировала собеседница агентства.</segment>
		<segment id="111" parent="366" relname="attribution">По ее мнению,</segment>
		<segment id="112" parent="113" relname="condition">если решение не будет найдено быстро,</segment>
		<segment id="113" parent="366" relname="span">то миграционный кризис подорвет доверие населения ЕС и всего международного сообщества к институтам Брюсселя.</segment>
		<segment id="114" parent="374" relname="span">"Не меньшую проблему представляет то, как задачу единства понимают на западе и востоке Европы.</segment>
		<segment id="115" parent="367" relname="span">В Германии и Скандинавии</segment>
		<segment id="116" parent="115" relname="elaboration">- особенно среди правящей политической элиты</segment>
		<segment id="117" parent="517" relname="span">- единство считают неотъемлемым принципом ЕС,</segment>
		<segment id="118" parent="518" relname="attribution">в то время как государства Центральной и Восточной Европы</segment>
		<segment id="119" parent="369" relname="contrast">требуют солидарности от западных соседей,</segment>
		<segment id="120" parent="369" relname="contrast">но не слишком спешат отвечать взаимностью",</segment>
		<segment id="121" parent="374" relname="attribution">- сказала эксперт.</segment>
		<segment id="122" parent="379" relname="attribution">Она подчеркнула,</segment>
		<segment id="123" parent="379" relname="span">что для выхода из сложной ситуации</segment>
		<segment id="124" parent="377" relname="joint">европейцам потребуется объединиться перед лицом трудностей ради общего блага,</segment>
		<segment id="125" parent="377" relname="joint">ввести механизм квот по приему мигрантов,</segment>
		<segment id="126" parent="377" relname="joint">а также выработать общие пограничные принципы.</segment>
		<segment id="127" parent="128" relname="attribution">В то же время заведующий отделом Ближнего Востока немецкого Общества защиты угнетенных народов Камаль Сидо (Kamal Sido) отметил,</segment>
		<segment id="128" parent="385" relname="span">что Брюссель не сможет в одиночку остановить кровопролитные конфликты.</segment>
		<segment id="129" parent="382" relname="joint">"Важно, чтобы европейские государства вместе с США и Россией работали над решением вопросов в Сирии, Ираке, Ливии, Йемене.</segment>
		<segment id="130" parent="380" relname="joint">Если эти проблемы не будут решены,</segment>
		<segment id="131" parent="380" relname="joint">если война в этих странах не прекратится,</segment>
		<segment id="132" parent="383" relname="span">то миграция беженцев продолжится",</segment>
		<segment id="133" parent="384" relname="attribution">- сказал правозащитник.</segment>
		<segment id="134" parent="389" relname="attribution">Он также добавил,</segment>
		<segment id="135" parent="388" relname="purpose">что государства Западной и Восточной Европы смогут найти выход</segment>
		<segment id="136" parent="387" relname="joint">только путем преодоления взаимных разногласий</segment>
		<segment id="137" parent="387" relname="joint">и выработки единой стратегии.</segment>
		<segment id="138" parent="391" relname="attribution">Кроме того, правозащитник призвал</segment>
		<segment id="139" parent="390" relname="joint">лидеров ЕС помочь вынужденным мигрантам</segment>
		<segment id="140" parent="390" relname="joint">и позволить им воссоединиться со своими родными и близкими.</segment>
		<segment id="141" parent="396" relname="span">"Самое главное - выделить больше финансов на строительство центров для беженцев в странах Европы.</segment>
		<segment id="142" parent="395" relname="span">Здесь очень много трудностей.</segment>
		<segment id="143" parent="392" relname="joint">В лагерях, где находятся беженцы, не хватает персонала.</segment>
		<segment id="144" parent="392" relname="joint">Нужно больше волонтеров, больше центров временного размещения.</segment>
		<segment id="145" parent="393" relname="span">Как известно, ситуация в Германии сейчас очень трудная:</segment>
		<segment id="146" parent="145" relname="elaboration">все лагеря для беженцев переполнены",</segment>
		<segment id="147" parent="396" relname="attribution">- уточнил Камаль Сидо.</segment>
		<segment id="148" parent="149" relname="attribution">Он также выразил уверенность в том,</segment>
		<segment id="149" parent="519" relname="span">что наплыв мигрантов не представляет серьезной угрозы для стабильности Евросоюза.</segment>
		<segment id="150" parent="408" relname="span">Диаметрально противоположного мнения в этом вопросе</segment>
		<segment id="151" parent="150" relname="attribution">придерживается содиректор программы по исследованию задач европейской власти Европейского совета по международным отношениям (ECFR) Сьюзи Деннисон (Susi Dennison).</segment>
		<segment id="152" parent="407" relname="attribution">В частности, она напомнила</segment>
		<segment id="153" parent="405" relname="span">о попытке массового убийства людей в скором поезде Thalys 21 августа 2015 года,</segment>
		<segment id="154" parent="153" relname="elaboration">следовавшем по маршруту "Амстердам - Брюссель - Париж",</segment>
		<segment id="155" parent="399" relname="span">когда гражданин Марокко,</segment>
		<segment id="156" parent="155" relname="elaboration">вооруженный автоматом, пистолетом и ножом,</segment>
		<segment id="157" parent="400" relname="same-unit">открыл стрельбу по пассажирам,</segment>
		<segment id="158" parent="401" relname="sequence">однако был быстро обезоружен,</segment>
		<segment id="159" parent="401" relname="sequence">а затем передан полиции.</segment>
		<segment id="160" parent="413" relname="span">"Сейчас вокруг задачи по борьбе с терроризмом идет бурное обсуждение,</segment>
		<segment id="161" parent="410" relname="span">и оно тесно сопряжено с темой беженцев,</segment>
		<segment id="162" parent="161" relname="effect">поскольку здесь стоит ребром проблема [упрощенного] пересечения границ.</segment>
		<segment id="163" parent="411" relname="evidence">Стрельба в поезде Thalys показала,</segment>
		<segment id="164" parent="411" relname="span">какую опасность могут представлять сотни тысяч мигрантов,</segment>
		<segment id="165" parent="164" relname="elaboration">свободно перемещающихся по Евросоюзу",</segment>
		<segment id="166" parent="415" relname="attribution">- пояснила эксперт.</segment>
		<segment id="167" parent="421" relname="attribution">По ее мнению,</segment>
		<segment id="168" parent="420" relname="joint">европейские политики оказались не готовы оперативно справиться с кризисной ситуацией,</segment>
		<segment id="169" parent="417" relname="purpose">а попытки Венгрии, Македонии и других государств отгородиться от потока беженцев</segment>
		<segment id="170" parent="416" relname="joint">высоким забором с колючей проволокой,</segment>
		<segment id="171" parent="416" relname="joint">а также введением мер паспортного контроля</segment>
		<segment id="172" parent="418" relname="evaluation">является "авральной реакцией".</segment>
		<segment id="173" parent="422" relname="span">"На внешних границах ЕС не знают, что делать с нахлынувшими беженцами,</segment>
		<segment id="174" parent="173" relname="concession">хотя для них эти государства являются лишь перевалочными пунктами на пути в Германию, Швецию и даже Великобританию",</segment>
		<segment id="175" parent="422" relname="attribution">- добавила Сьюзи Деннисон.</segment>
		<segment id="176" parent="177" relname="attribution">Она также подчеркнула,</segment>
		<segment id="177" parent="424" relname="span">что Брюссель до недавнего времени не предпринимал почти никаких шагов для разрешения проблемы в точках ее возникновения.</segment>
		<segment id="178" parent="429" relname="span">"Важно отметить, что европейские политики уделяют недостаточно внимания внешнеполитическим предпосылкам массовой миграции.</segment>
		<segment id="179" parent="178" relname="attribution">Я говорю об отсутствии реальных шагов по разрешению кризисов, генерирующих столь большое число беженцев",</segment>
		<segment id="180" parent="427" relname="attribution">- пояснила Сьюзи Деннисон,</segment>
		<segment id="181" parent="426" relname="joint">уточнив, что речь идет не только о Сирии,</segment>
		<segment id="182" parent="426" relname="joint">но также о многолетних беспорядках в Эритрее, Нигерии и других странах.</segment>
		<segment id="183" parent="184" relname="attribution">Вместе с тем она высказала убежденность в том,</segment>
		<segment id="184" parent="431" relname="span">что с экономической и социальной точки зрения Евросоюз способен справиться с потоками беженцев.</segment>
		<segment id="185" parent="434" relname="concession">"Даже при нынешней численности беженцев в Европе</segment>
		<segment id="186" parent="433" relname="comparison">подушевая нагрузка ничтожна</segment>
		<segment id="187" parent="433" relname="comparison">по сравнению с тем, сколько людей уже нашли убежище в Ливане, Иордании и Турции",</segment>
		<segment id="188" parent="435" relname="attribution">- отметила представитель Европейского совета по международным отношениям.</segment>
		<segment id="189" parent="439" relname="span">Похожую точку зрения озвучила</segment>
		<segment id="190" parent="189" relname="attribution">член либеральной Хорватской народной партии, министр иностранных дел и европейской интеграции Республики Хорватия Весна Пусич (Vesna Pusić).</segment>
		<segment id="191" parent="436" relname="span">"У Европы есть ресурсы, чтобы сотрудничать со странами, где сейчас проживает наибольшее число беженцев родом из раздираемых войной государств",</segment>
		<segment id="192" parent="193" relname="attribution">- подчеркнула политик,</segment>
		<segment id="193" parent="520" relname="span">добавив, что в средней и долгосрочной перспективе Брюссель может создать и обустроить безопасные территории рядом с зонами конфликтов.</segment>
		<segment id="194" parent="195" relname="attribution">Вместе с тем она признала,</segment>
		<segment id="195" parent="442" relname="span">что проблема массовой вынужденной миграции в Европе и Средиземноморье в настоящее время достигла невиданных масштабов.</segment>
		<segment id="196" parent="441" relname="attribution">Так, по словам главы МИД,</segment>
		<segment id="197" parent="440" relname="joint">за первую половину 2015 года в европейские государства прибыло в четыре раза больше мигрантов, чем за 2013 год,</segment>
		<segment id="198" parent="440" relname="joint">а центры временного размещения в Турции, Иордании, Ливане, Египте и Тунисе переполнены.</segment>
		<segment id="199" parent="444" relname="comparison">"Турция уже приняла 2 млн. человек,</segment>
		<segment id="200" parent="444" relname="comparison">а число беженцев в Иордании сейчас составляет почти 30% от коренного населения страны.</segment>
		<segment id="201" parent="445" relname="contrast">Они больше не могут справляться с потоком,</segment>
		<segment id="202" parent="445" relname="contrast">однако войны и конфликты в Южном Средиземноморье не утихают",</segment>
		<segment id="203" parent="448" relname="attribution">- заметила Весна Пусич.</segment>
		<segment id="204" parent="205" relname="attribution">С ее точки зрения,</segment>
		<segment id="205" parent="450" relname="span">ЕС нуждается в единой и целостной системе расселения вынужденных мигрантов в странах Европы.</segment>
		<segment id="206" parent="451" relname="span">"Нельзя допускать ситуацию, при которой все стремятся попасть в какие-то конкретные государства,</segment>
		<segment id="207" parent="206" relname="elaboration">относясь к остальным странам как к перевалочным пунктам,</segment>
		<segment id="208" parent="452" relname="span">потому что в этом случае планы по распределению нагрузки окажутся бессмысленными",</segment>
		<segment id="209" parent="452" relname="attribution">- заявила хорватский министр иностранных дел и европейской интеграции.</segment>
		<segment id="210" parent="454" relname="attribution">Кроме того, она призвала</segment>
		<segment id="211" parent="459" relname="joint">бороться с нелегальной контрабандой людей из стран Африки и Южного Средиземноморья,</segment>
		<segment id="212" parent="453" relname="joint">а также тесно работать с теми, кто уже прибыл в Европу.</segment>
		<segment id="213" parent="214" relname="concession">"Хотя мы неспособны искоренить эту проблему здесь и сейчас,</segment>
		<segment id="214" parent="456" relname="span">мы уже можем работать в тех местах, где находятся люди.</segment>
		<segment id="215" parent="455" relname="joint">Нам нужно максимально быстро активизировать работу соответствующих организаций</segment>
		<segment id="216" parent="455" relname="joint">и поднять обеспечение беженцев на достойный уровень",</segment>
		<segment id="217" parent="458" relname="attribution">- заявила политик.</segment>
		<segment id="218" parent="468" relname="span">На эту проблему также обратил внимание</segment>
		<segment id="219" parent="218" relname="attribution">директор программы по правам беженцев организации Human Rights Watch Билл Фрелик (Bill Frelick).</segment>
		<segment id="220" parent="465" relname="joint">"Я лично повторил путь беженцев и мигрантов, которые сотнями и тысячами прибывают в Европу.</segment>
		<segment id="221" parent="464" relname="span">[&hellip;] Людей очень много,</segment>
		<segment id="222" parent="463" relname="span">и они вынуждены подолгу ждать в очередях,</segment>
		<segment id="223" parent="461" relname="joint">нередко под палящим солнцем,</segment>
		<segment id="224" parent="461" relname="joint">без возможности укрыться в тени или достать воды.</segment>
		<segment id="225" parent="465" relname="joint">Ситуация тяжелая.</segment>
		<segment id="226" parent="465" relname="joint">Я своими глазами видел, как люди падают в обморок от истощения и обезвоживания",</segment>
		<segment id="227" parent="466" relname="attribution">- отметил правозащитник.</segment>
		<segment id="228" parent="229" relname="attribution">По его словам,</segment>
		<segment id="229" parent="471" relname="span">поток беженцев составляют преимущественно люди, которые не смогли найти убежище в переполненных лагерях в Иордании, Ливане и Турции.</segment>
		<segment id="230" parent="469" relname="span">"Сейчас у ООН есть только треть суммы, необходимой для предоставления гуманитарной помощи.</segment>
		<segment id="231" parent="230" relname="elaboration">Она была вынуждена сократить объемы поставок продуктов питания в Ливан и другие страны.</segment>
		<segment id="232" parent="470" relname="span">Поэтому неудивительно, что люди, на которых не хватает еды, одежды и лекарств, отправляются в Европу",</segment>
		<segment id="233" parent="470" relname="attribution">- констатировал Билл Фрелик.</segment>
		<segment id="234" parent="235" relname="attribution">По его словам,</segment>
		<segment id="235" parent="491" relname="span">многие сирийцы, с которыми он познакомился на пограничных пунктах в Греции, Македонии и Сербии, покинули страну меньше месяца тому назад.</segment>
		<segment id="236" parent="473" relname="joint">"Они очень любят свою родину</segment>
		<segment id="237" parent="473" relname="joint">и готовы вернуться туда при первой же возможности.</segment>
		<segment id="238" parent="474" relname="span">Однако сейчас,</segment>
		<segment id="239" parent="238" relname="attribution">по их словам,</segment>
		<segment id="240" parent="475" relname="same-unit">другого выхода просто нет.</segment>
		<segment id="241" parent="522" relname="attribution">Я считаю,</segment>
		<segment id="242" parent="522" relname="span">это конкретный сигнал международному сообществу:</segment>
		<segment id="243" parent="244" relname="effect">сами граждане уже не хотят продолжения этой войны</segment>
		<segment id="244" parent="476" relname="span">- ее нужно остановить. [&hellip;]</segment>
		<segment id="245" parent="482" relname="joint">Смерть есть смерть,</segment>
		<segment id="246" parent="481" relname="span">и неважно, от чего гибнет человек</segment>
		<segment id="247" parent="477" relname="span">- от баррельных бомб,</segment>
		<segment id="248" parent="247" relname="elaboration">сброшенных с вертолета сирийских вооруженных сил,</segment>
		<segment id="249" parent="478" relname="span">от атак беспилотников Вашингтона,</segment>
		<segment id="250" parent="249" relname="elaboration">недавно появившихся в небе над страной,</segment>
		<segment id="251" parent="479" relname="joint">или от ножа головореза "Исламского государства",</segment>
		<segment id="252" parent="494" relname="attribution">- подчеркнул правозащитник</segment>
		<segment id="253" parent="496" relname="span">и призвал мировых лидеров объединиться,</segment>
		<segment id="254" parent="253" relname="purpose">чтобы прекратить кровопролитие в горячих точках.</segment>
		<segment id="255" parent="498" relname="joint">"[Беженцы] хотят жить нормальной мирной жизнью,</segment>
		<segment id="256" parent="498" relname="joint">растить своих детей,</segment>
		<segment id="257" parent="498" relname="joint">безбоязненно провожать их в школу.</segment>
		<segment id="258" parent="501" relname="condition">Когда мы говорим о правах человека,</segment>
		<segment id="259" parent="501" relname="span">на самом деле мы имеем в виду весьма бесхитростные вещи:</segment>
		<segment id="260" parent="499" relname="comparison">людям необходимо позволить ощутить себя в безопасности,</segment>
		<segment id="261" parent="499" relname="comparison">а их детям обеспечить будущее.</segment>
		<segment id="262" parent="509" relname="span">На мой взгляд, именно эту идею нужно донести до лидера каждой страны</segment>
		<segment id="263" parent="262" relname="elaboration">- независимо от веры и национальности.</segment>
		<segment id="264" parent="506" relname="joint">Главам государств необходимо отвлечься от политических игр</segment>
		<segment id="265" parent="503" relname="span">и признать, что насилие и опустошительные бои</segment>
		<segment id="266" parent="265" relname="purpose">ради чьей-то победы</segment>
		<segment id="267" parent="502" relname="joint">приводят лишь к деградации</segment>
		<segment id="268" parent="502" relname="joint">и слепой жестокости", -</segment>
		<segment id="269" parent="513" relname="attribution">резюмировал представитель Human Rights Watch.</segment>
		<group id="270" type="multinuc" parent="271" relname="span"/>
		<group id="271" type="span" parent="272" relname="span"/>
		<group id="272" type="span" parent="2" relname="elaboration"/>
		<group id="273" type="span" parent="274" relname="joint"/>
		<group id="274" type="multinuc" parent="275" relname="span"/>
		<group id="275" type="span" />
		<group id="276" type="span" parent="279" relname="span"/>
		<group id="277" type="span" parent="278" relname="same-unit"/>
		<group id="278" type="multinuc" parent="281" relname="span"/>
		<group id="279" type="span" parent="280" relname="joint"/>
		<group id="280" type="multinuc" />
		<group id="281" type="span" parent="280" relname="joint"/>
		<group id="282" type="multinuc" parent="286" relname="span"/>
		<group id="283" type="span" parent="284" relname="same-unit"/>
		<group id="284" type="multinuc" parent="285" relname="span"/>
		<group id="285" type="span" parent="282" relname="contrast"/>
		<group id="286" type="span" parent="15" relname="elaboration"/>
		<group id="287" type="multinuc" parent="288" relname="span"/>
		<group id="288" type="span" parent="23" relname="effect"/>
		<group id="289" type="span" parent="22" relname="elaboration"/>
		<group id="290" type="multinuc" parent="291" relname="span"/>
		<group id="291" type="span" parent="296" relname="span"/>
		<group id="292" type="span" parent="293" relname="same-unit"/>
		<group id="293" type="multinuc" parent="294" relname="span"/>
		<group id="294" type="span" parent="295" relname="span"/>
		<group id="295" type="span" parent="297" relname="joint"/>
		<group id="296" type="span" parent="297" relname="joint"/>
		<group id="297" type="multinuc" parent="299" relname="span"/>
		<group id="298" type="span" />
		<group id="299" type="span" parent="298" relname="elaboration"/>
		<group id="300" type="span" parent="301" relname="same-unit"/>
		<group id="301" type="multinuc" parent="302" relname="span"/>
		<group id="302" type="span" parent="305" relname="span"/>
		<group id="303" type="multinuc" parent="304" relname="span"/>
		<group id="304" type="span" parent="307" relname="span"/>
		<group id="305" type="span" parent="308" relname="joint"/>
		<group id="306" type="span" parent="308" relname="joint"/>
		<group id="307" type="span" parent="308" relname="joint"/>
		<group id="308" type="multinuc" />
		<group id="309" type="multinuc" parent="310" relname="span"/>
		<group id="310" type="span" parent="312" relname="span"/>
		<group id="311" type="span" />
		<group id="312" type="span" parent="311" relname="elaboration"/>
		<group id="313" type="multinuc" parent="314" relname="span"/>
		<group id="314" type="span" />
		<group id="315" type="multinuc" parent="316" relname="span"/>
		<group id="316" type="span" parent="317" relname="span"/>
		<group id="317" type="span" parent="319" relname="joint"/>
		<group id="318" type="span" parent="319" relname="joint"/>
		<group id="319" type="multinuc" parent="320" relname="span"/>
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" />
		<group id="322" type="multinuc" parent="323" relname="span"/>
		<group id="323" type="span" parent="324" relname="span"/>
		<group id="324" type="span" parent="325" relname="joint"/>
		<group id="325" type="multinuc" parent="326" relname="span"/>
		<group id="326" type="span" parent="328" relname="comparison"/>
		<group id="327" type="span" parent="328" relname="comparison"/>
		<group id="328" type="multinuc" parent="329" relname="span"/>
		<group id="329" type="span" parent="332" relname="joint"/>
		<group id="330" type="span" parent="332" relname="joint"/>
		<group id="331" type="span" parent="332" relname="joint"/>
		<group id="332" type="multinuc" parent="333" relname="span"/>
		<group id="333" type="span" parent="335" relname="span"/>
		<group id="334" type="span" parent="333" relname="attribution"/>
		<group id="335" type="span" parent="336" relname="elaboration"/>
		<group id="336" type="span" />
		<group id="337" type="multinuc" parent="338" relname="span"/>
		<group id="338" type="span" parent="80" relname="condition"/>
		<group id="339" type="span" parent="340" relname="span"/>
		<group id="340" type="span" />
		<group id="341" type="multinuc" parent="346" relname="span"/>
		<group id="342" type="multinuc" parent="343" relname="span"/>
		<group id="343" type="span" parent="85" relname="purpose"/>
		<group id="344" type="multinuc" parent="345" relname="span"/>
		<group id="345" type="span" parent="88" relname="elaboration"/>
		<group id="346" type="span" parent="349" relname="joint"/>
		<group id="347" type="span" parent="349" relname="joint"/>
		<group id="348" type="span" parent="349" relname="joint"/>
		<group id="349" type="multinuc" parent="350" relname="span"/>
		<group id="350" type="span" parent="351" relname="span"/>
		<group id="351" type="span" parent="82" relname="elaboration"/>
		<group id="352" type="span" parent="355" relname="span"/>
		<group id="353" type="multinuc" parent="354" relname="span"/>
		<group id="354" type="span" parent="352" relname="purpose"/>
		<group id="355" type="span" parent="357" relname="span"/>
		<group id="356" type="span" />
		<group id="357" type="span" parent="356" relname="elaboration"/>
		<group id="358" type="span" />
		<group id="359" type="span" parent="358" relname="elaboration"/>
		<group id="360" type="multinuc" parent="362" relname="span"/>
		<group id="361" type="span" parent="360" relname="joint"/>
		<group id="362" type="span" parent="104" relname="effect"/>
		<group id="363" type="span" />
		<group id="364" type="multinuc" parent="376" relname="span"/>
		<group id="365" type="span" />
		<group id="366" type="span" />
		<group id="367" type="span" parent="117" relname="attribution"/>
		<group id="369" type="multinuc" parent="518" relname="span"/>
		<group id="371" type="multinuc" parent="373" relname="span"/>
		<group id="372" type="span" parent="371" relname="comparison"/>
		<group id="373" type="span" parent="114" relname="elaboration"/>
		<group id="374" type="span" />
		<group id="375" type="multinuc" parent="364" relname="contrast"/>
		<group id="376" type="span" parent="365" relname="span"/>
		<group id="377" type="multinuc" parent="378" relname="span"/>
		<group id="378" type="span" parent="123" relname="purpose"/>
		<group id="379" type="span" />
		<group id="380" type="multinuc" parent="381" relname="span"/>
		<group id="381" type="span" parent="132" relname="condition"/>
		<group id="382" type="multinuc" parent="384" relname="span"/>
		<group id="383" type="span" parent="382" relname="joint"/>
		<group id="384" type="span" parent="386" relname="span"/>
		<group id="385" type="span" />
		<group id="386" type="span" parent="385" relname="elaboration"/>
		<group id="387" type="multinuc" parent="388" relname="span"/>
		<group id="388" type="span" parent="389" relname="span"/>
		<group id="389" type="span" />
		<group id="390" type="multinuc" parent="391" relname="span"/>
		<group id="391" type="span" />
		<group id="392" type="multinuc" parent="394" relname="span"/>
		<group id="393" type="span" parent="392" relname="joint"/>
		<group id="394" type="span" parent="142" relname="elaboration"/>
		<group id="395" type="span" parent="141" relname="elaboration"/>
		<group id="396" type="span" parent="397" relname="span"/>
		<group id="397" type="span" parent="398" relname="joint"/>
		<group id="398" type="multinuc" />
		<group id="399" type="span" parent="400" relname="same-unit"/>
		<group id="400" type="multinuc" parent="404" relname="span"/>
		<group id="401" type="multinuc" parent="402" relname="span"/>
		<group id="402" type="span" parent="403" relname="contrast"/>
		<group id="403" type="multinuc" parent="406" relname="span"/>
		<group id="404" type="span" parent="403" relname="contrast"/>
		<group id="405" type="span" parent="407" relname="span"/>
		<group id="406" type="span" parent="405" relname="elaboration"/>
		<group id="407" type="span" parent="409" relname="span"/>
		<group id="408" type="span" />
		<group id="409" type="span" parent="408" relname="elaboration"/>
		<group id="410" type="span" parent="160" relname="elaboration"/>
		<group id="411" type="span" parent="412" relname="span"/>
		<group id="412" type="span" parent="414" relname="joint"/>
		<group id="413" type="span" parent="414" relname="joint"/>
		<group id="414" type="multinuc" parent="415" relname="span"/>
		<group id="415" type="span" />
		<group id="416" type="multinuc" parent="417" relname="span"/>
		<group id="417" type="span" parent="418" relname="span"/>
		<group id="418" type="span" parent="419" relname="span"/>
		<group id="419" type="span" parent="420" relname="joint"/>
		<group id="420" type="multinuc" parent="421" relname="span"/>
		<group id="421" type="span" />
		<group id="422" type="span" parent="423" relname="span"/>
		<group id="423" type="span" parent="425" relname="joint"/>
		<group id="424" type="span" parent="425" relname="joint"/>
		<group id="425" type="multinuc" />
		<group id="426" type="multinuc" parent="427" relname="span"/>
		<group id="427" type="span" parent="514" relname="span"/>
		<group id="429" type="span" parent="430" relname="span"/>
		<group id="430" type="span" parent="432" relname="contrast"/>
		<group id="431" type="span" parent="432" relname="contrast"/>
		<group id="432" type="multinuc" />
		<group id="433" type="multinuc" parent="434" relname="span"/>
		<group id="434" type="span" parent="435" relname="span"/>
		<group id="435" type="span" />
		<group id="436" type="span" parent="521" relname="span"/>
		<group id="439" type="span" />
		<group id="440" type="multinuc" parent="441" relname="span"/>
		<group id="441" type="span" parent="443" relname="span"/>
		<group id="442" type="span" />
		<group id="443" type="span" parent="442" relname="elaboration"/>
		<group id="444" type="multinuc" parent="446" relname="span"/>
		<group id="445" type="multinuc" parent="447" relname="span"/>
		<group id="446" type="span" parent="448" relname="span"/>
		<group id="447" type="span" parent="446" relname="elaboration"/>
		<group id="448" type="span" parent="449" relname="span"/>
		<group id="449" type="span" />
		<group id="450" type="span" parent="449" relname="evaluation"/>
		<group id="451" type="span" parent="208" relname="effect"/>
		<group id="452" type="span" />
		<group id="453" type="multinuc" parent="460" relname="span"/>
		<group id="454" type="span" />
		<group id="455" type="multinuc" parent="457" relname="span"/>
		<group id="456" type="span" parent="458" relname="span"/>
		<group id="457" type="span" parent="456" relname="elaboration"/>
		<group id="458" type="span" />
		<group id="459" type="multinuc" parent="453" relname="joint"/>
		<group id="460" type="span" parent="454" relname="span"/>
		<group id="461" type="multinuc" parent="462" relname="span"/>
		<group id="462" type="span" parent="222" relname="elaboration"/>
		<group id="463" type="span" parent="221" relname="elaboration"/>
		<group id="464" type="span" parent="465" relname="joint"/>
		<group id="465" type="multinuc" parent="466" relname="span"/>
		<group id="466" type="span" parent="467" relname="span"/>
		<group id="467" type="span" parent="468" relname="elaboration"/>
		<group id="468" type="span" />
		<group id="469" type="span" parent="232" relname="effect"/>
		<group id="470" type="span" parent="472" relname="span"/>
		<group id="471" type="span" parent="490" relname="span"/>
		<group id="472" type="span" parent="471" relname="elaboration"/>
		<group id="473" type="multinuc" parent="483" relname="span"/>
		<group id="474" type="span" parent="475" relname="same-unit"/>
		<group id="475" type="multinuc" parent="484" relname="span"/>
		<group id="476" type="span" parent="242" relname="elaboration"/>
		<group id="477" type="span" parent="479" relname="joint"/>
		<group id="478" type="span" parent="479" relname="joint"/>
		<group id="479" type="multinuc" parent="480" relname="span"/>
		<group id="480" type="span" parent="246" relname="elaboration"/>
		<group id="481" type="span" parent="482" relname="joint"/>
		<group id="482" type="multinuc" parent="489" relname="span"/>
		<group id="483" type="span" parent="485" relname="contrast"/>
		<group id="484" type="span" parent="485" relname="contrast"/>
		<group id="485" type="multinuc" parent="487" relname="span"/>
		<group id="487" type="span" parent="488" relname="span"/>
		<group id="488" type="span" parent="493" relname="joint"/>
		<group id="489" type="span" parent="493" relname="joint"/>
		<group id="490" type="span" parent="492" relname="joint"/>
		<group id="491" type="span" parent="492" relname="joint"/>
		<group id="492" type="multinuc" />
		<group id="493" type="multinuc" parent="494" relname="span"/>
		<group id="494" type="span" parent="495" relname="span"/>
		<group id="495" type="span" parent="497" relname="joint"/>
		<group id="496" type="span" parent="497" relname="joint"/>
		<group id="497" type="multinuc" />
		<group id="498" type="multinuc" parent="507" relname="span"/>
		<group id="499" type="multinuc" parent="500" relname="span"/>
		<group id="500" type="span" parent="259" relname="elaboration"/>
		<group id="501" type="span" parent="508" relname="span"/>
		<group id="502" type="multinuc" parent="504" relname="span"/>
		<group id="503" type="span" parent="504" relname="effect"/>
		<group id="504" type="span" parent="505" relname="span"/>
		<group id="505" type="span" parent="506" relname="joint"/>
		<group id="506" type="multinuc" parent="510" relname="span"/>
		<group id="507" type="span" parent="511" relname="span"/>
		<group id="508" type="span" parent="507" relname="elaboration"/>
		<group id="509" type="span" parent="512" relname="span"/>
		<group id="510" type="span" parent="509" relname="elaboration"/>
		<group id="511" type="span" parent="512" relname="preparation"/>
		<group id="512" type="span" parent="513" relname="span"/>
		<group id="513" type="span" />
		<group id="514" type="span" parent="429" relname="attribution"/>
		<group id="515" type="span" parent="274" relname="joint"/>
		<group id="516" type="span" parent="284" relname="same-unit"/>
		<group id="517" type="span" parent="371" relname="comparison"/>
		<group id="518" type="span" parent="372" relname="span"/>
		<group id="519" type="span" parent="398" relname="joint"/>
		<group id="520" type="span" parent="436" relname="attribution"/>
		<group id="521" type="span" parent="439" relname="elaboration"/>
		<group id="522" type="span" parent="523" relname="span"/>
		<group id="523" type="span" parent="487" relname="evaluation"/>
	</body>
</rst>