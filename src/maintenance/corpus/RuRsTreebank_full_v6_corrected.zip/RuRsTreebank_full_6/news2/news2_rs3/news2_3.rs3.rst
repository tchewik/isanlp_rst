<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >Новость: Победитель республиканской олимпиады «Родной край – 2012»</segment>
		<segment id="2" parent="51" relname="preparation">Уже стало традицией в конце каждого учебного года проводить олимпиаду «Родной край».</segment>
		<segment id="3" parent="46" relname="sequence">Первоначально в ней участвовали только ученики чебоксарских школ.</segment>
		<segment id="4" parent="46" relname="sequence">В последнее время она проводится среди учащихся образовательных учреждений городов и районов республики.</segment>
		<segment id="5" parent="47" relname="span">Цель олимпиады:</segment>
		<segment id="6" parent="5" relname="purpose">воспитание патриотически настроенной, творчески мыслящей и интеллектуально развитой молодежи, актуализация и популяризация истории и культуры Чувашской Республики.</segment>
		<segment id="7" parent="48" relname="span">Олимпиада ставит перед собой такие задачи,</segment>
		<segment id="8" parent="7" relname="purpose">как  актуализация функционирования курса истории и культуры родного края в учебно-воспитательной деятельности  образовательных учреждений республики, стимулирование креативной направленности педагогической деятельности учителей культуры родного края, выявление, развитие и поддержка наиболее одаренных учащихся.</segment>
		<segment id="9" parent="53" relname="joint">Организаторами олимпиады вот уже который год выступают БОУ ДПО (ПК) С «Чувашский республиканский институт образования» Минобразования Чувашии, кафедра общественных дисциплин и управления, кафедра начального образования.</segment>
		<segment id="10" parent="53" relname="joint">В составе оргкомитета заведующий кафедрой общественных дисциплин и управления БОУ ДПО (ПК) С «Чувашский республиканский институт образования» Минобразования Чувашии Лебедев Ю.Б. (председатель), заведующий кафедрой начального образования Кульева А.Р. (сопредседатель), старший преподаватель кафедры общественных дисциплин и управления Александрова Е.В., методисты кафедры Волкова Р.А. и Иголкина Л.М., методист управления учебной и кадровой работы Чернова Л.А., ведущий специалист управления учебной и кадровой работы Егорова Л.В.</segment>
		<segment id="11" parent="58" relname="preparation">В олимпиаде могут принимать участие 4, 5, 6-7 классов общеобразовательных школ.</segment>
		<segment id="12" parent="58" relname="span">Она проводится в два этапа.</segment>
		<segment id="13" parent="54" relname="sequence">На первом школьном этапе  с 9 по 21 апреля выявлялись по два победителя в трех группах: среди 4 классов, 5 классов и 6-7 классов.</segment>
		<segment id="14" parent="54" relname="sequence">В итоге на втором этапе от каждой школы могли быть представлены по шесть участников.</segment>
		<segment id="15" parent="55" relname="span">12 мая победители первого этапа со всей республики собрались в Чувашском республиканском институте образования</segment>
		<segment id="16" parent="15" relname="purpose">для участия во втором этапе.</segment>
		<segment id="17" parent="68" relname="span">Вначале в актовом зале состоялось открытие олимпиады.</segment>
		<segment id="18" parent="19" relname="attribution">С приветственным словом выступила Е.В.Александрова</segment>
		<segment id="19" parent="83" relname="span">и пожелала всем участникам успехов.</segment>
		<segment id="20" parent="61" relname="span">Задания второго этапа составлены из  трех частей,</segment>
		<segment id="21" parent="60" relname="sequence">где в первой части нужно выбрать один верный ответ;</segment>
		<segment id="22" parent="60" relname="sequence">во второй части даны задания аналитического характера;</segment>
		<segment id="23" parent="60" relname="sequence">в третьей части – написание эссе.</segment>
		<segment id="24" parent="62" relname="span">Всем участникам олимпиады,</segment>
		<segment id="25" parent="24" relname="elaboration">а в этом году их было 251,</segment>
		<segment id="26" parent="63" relname="same-unit">сразу после выполнения заданий вручили именные сертификаты.</segment>
		<segment id="27" parent="64" relname="joint">Затем комиссия, проверив</segment>
		<segment id="28" parent="64" relname="joint">и оценив все работы,</segment>
		<segment id="29" parent="65" relname="span">подвела итоги</segment>
		<segment id="30" parent="66" relname="same-unit">и</segment>
		<segment id="31" parent="66" relname="same-unit">опубликовала их на сайте ЧРИО.</segment>
		<segment id="32" parent="72" relname="span">Из нашего МБОУ «Сюрбей-Токаевская ООШ» Комсомольского района в олимпиаде участвовали четверо учеников, двое пятиклассников – Белков Никита и Исаева Анастасия, и двое семиклассников – Минин Максим и Хлебникова Татьяна.</segment>
		<segment id="33" parent="70" relname="joint">Все они постарались не ударить лицом в грязь и</segment>
		<segment id="34" parent="70" relname="joint">дать верные и полные ответы.</segment>
		<segment id="35" parent="71" relname="span">Удача улыбнулась Минину Максиму,</segment>
		<segment id="36" parent="35" relname="background">который принимает участие в данной олимпиаде во второй раз.</segment>
		<segment id="37" parent="73" relname="span">Он занял заслуженное первое место среди более, чем сотни своих сверстников.</segment>
		<segment id="38" parent="39" relname="evaluation">Известно, что</segment>
		<segment id="39" parent="84" relname="span">такой успех не может быть случайным.</segment>
		<segment id="40" parent="84" relname="cause">Он сопутствует лишь тем, кто действительно усердно и систематически занимается.</segment>
		<segment id="41" parent="76" relname="joint">Также призовые места заняли ученики МБОУ «Нюргечинская СОШ» нашего района.</segment>
		<segment id="42" parent="43" relname="evidence">Отрадно отметить, что количество участников олимпиады с каждым годом растет.</segment>
		<segment id="43" parent="79" relname="span">Это – яркое свидетельство тому, что история и культура нашего чувашского народа не оставляет равнодушным подрастающее поколение.</segment>
		<segment id="44" parent="80" relname="joint">А изучение школьного предмета культура родного края действительно помогает учащимся понять</segment>
		<segment id="45" parent="80" relname="joint">и осмыслить значимость родного чувашского языка и культуры.</segment>
		<group id="46" type="multinuc" parent="50" relname="span"/>
		<group id="47" type="span" parent="49" relname="joint"/>
		<group id="48" type="span" parent="49" relname="joint"/>
		<group id="49" type="multinuc" parent="50" relname="elaboration"/>
		<group id="50" type="span" parent="51" relname="span"/>
		<group id="51" type="span" parent="52" relname="span"/>
		<group id="52" type="span" />
		<group id="53" type="multinuc" />
		<group id="54" type="multinuc" parent="56" relname="span"/>
		<group id="55" type="span" parent="56" relname="elaboration"/>
		<group id="56" type="span" parent="57" relname="span"/>
		<group id="57" type="span" parent="12" relname="elaboration"/>
		<group id="58" type="span" parent="59" relname="span"/>
		<group id="59" type="span" />
		<group id="60" type="multinuc" parent="20" relname="elaboration"/>
		<group id="61" type="span" parent="69" relname="sequence"/>
		<group id="62" type="span" parent="63" relname="same-unit"/>
		<group id="63" type="multinuc" parent="69" relname="sequence"/>
		<group id="64" type="multinuc" parent="29" relname="condition"/>
		<group id="65" type="span" parent="67" relname="joint"/>
		<group id="66" type="multinuc" parent="67" relname="joint"/>
		<group id="67" type="multinuc" parent="69" relname="sequence"/>
		<group id="68" type="span" parent="69" relname="sequence"/>
		<group id="69" type="multinuc" />
		<group id="70" type="multinuc" parent="32" relname="evaluation"/>
		<group id="71" type="span" parent="75" relname="span"/>
		<group id="72" type="span" parent="77" relname="preparation"/>
		<group id="73" type="span" parent="71" relname="elaboration"/>
		<group id="75" type="span" parent="76" relname="joint"/>
		<group id="76" type="multinuc" parent="82" relname="span"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" />
		<group id="79" type="span" parent="81" relname="span"/>
		<group id="80" type="multinuc" parent="79" relname="elaboration"/>
		<group id="81" type="span" parent="82" relname="evaluation"/>
		<group id="82" type="span" parent="77" relname="span"/>
		<group id="83" type="span" parent="17" relname="elaboration"/>
		<group id="84" type="span" parent="85" relname="span"/>
		<group id="85" type="span" parent="37" relname="evaluation"/>
	</body>
</rst>