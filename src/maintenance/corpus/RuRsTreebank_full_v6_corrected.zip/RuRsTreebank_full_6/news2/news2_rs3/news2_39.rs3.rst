<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="198" relname="span">Вероятность отмены виз между Евросоюзом и Турцией близка к нулю</segment>
		<segment id="2" parent="1" relname="attribution">— эксперты</segment>
		<segment id="3" parent="195" relname="span">Европейский союз готов ускорить переговоры о послаблении визового режима с Турцией</segment>
		<segment id="4" parent="3" relname="condition">в обмен на помощь в решении миграционного кризиса.</segment>
		<segment id="5" parent="196" relname="span">Об этом заявил глава Еврокомиссии Жан-Клод Юнкер (Jean-Claude Juncker)</segment>
		<segment id="6" parent="194" relname="span">по итогам очередного саммита глав государств и правительств стран ЕС,</segment>
		<segment id="7" parent="6" relname="elaboration">завершившегося в Брюсселе 15 октября 2015 года.</segment>
		<segment id="8" parent="200" relname="concession">"Мы договорились с турецкими партнерами, что процесс визовой либерализации будет ускорен.</segment>
		<segment id="9" parent="200" relname="span">Это не означает, что мы отступим от базовых критериев, которые являются правилами.</segment>
		<segment id="10" parent="199" relname="span">Не будет других критериев для Турции,</segment>
		<segment id="11" parent="10" relname="elaboration">мы будем оценивать достигнутый прогресс весной 2016 года",</segment>
		<segment id="12" parent="201" relname="attribution">- сказал он в беседе с журналистами.</segment>
		<segment id="13" parent="202" relname="attribution">В свою очередь канцлер ФРГ Ангела Меркель (Angela Merkel) заявила,</segment>
		<segment id="14" parent="202" relname="span">что ЕС намерен выделить около 3 млрд. евро</segment>
		<segment id="15" parent="14" relname="purpose">на помощь Турции в сдерживании потока сирийских беженцев в Европу.</segment>
		<segment id="16" parent="203" relname="joint">"Турция взяла на себя большую ответственность за прием беженцев.</segment>
		<segment id="17" parent="203" relname="joint">Мы знаем, что она не получала достаточной финансовой помощи от ЕС.</segment>
		<segment id="18" parent="203" relname="joint">Мы готовы разделить с Турцией это бремя",</segment>
		<segment id="19" parent="204" relname="attribution">- сказала немецкий политик.</segment>
		<segment id="20" parent="21" relname="attribution">Между тем, по словам турецкого премьер-министра Ахмета Давутоглу (Ahmet Davutoglu),</segment>
		<segment id="21" parent="212" relname="span">Анкара рассматривает предложение Евросоюза о предоставлении этой суммы как приемлемое лишь на начальном уровне.</segment>
		<segment id="22" parent="205" relname="contrast">"Сейчас идет речь о 3 млрд. евро.</segment>
		<segment id="23" parent="205" relname="contrast">Но мы говорим о такой сумме лишь на первом этапе.</segment>
		<segment id="24" parent="209" relname="span">Мы не хотим ее фиксировать,</segment>
		<segment id="25" parent="206" relname="joint">поскольку потребности могут увеличиваться,</segment>
		<segment id="26" parent="206" relname="joint">и они должны оцениваться ежегодно",</segment>
		<segment id="27" parent="210" relname="attribution">― заявил он.</segment>
		<segment id="28" parent="29" relname="attribution">Вместе с тем Анкара надеется,</segment>
		<segment id="29" parent="215" relname="span">что турецкие граждане смогут посещать государства Евросоюза без виз уже будущим летом.</segment>
		<segment id="30" >"Мы рассчитываем, что договоры о безвизовых поездках граждан Турции в страны Шенгенской зоны и соглашение о реадмиссии одновременно вступят в силу в июле 2016 года",</segment>
		<segment id="31" parent="32" relname="attribution">- заявил Ахмет Давутоглу,</segment>
		<segment id="32" parent="350" relname="span">добавив, что Турция также планирует занять место на "семейной фотографии ЕС".</segment>
		<segment id="33" parent="34" relname="attribution">Комментируя сложившуюся ситуацию, глава берлинского офиса Европейского совета по международным отношениям Йозеф Яннинг (Josef Janning) отметил,</segment>
		<segment id="34" parent="227" relname="span">что шансы на отмену визового режима между двумя сторонами "довольно туманны".</segment>
		<segment id="35" parent="219" relname="span">"Для этого</segment>
		<segment id="36" parent="217" relname="joint">Турция должна будет поставить под жесткий контроль поток беженцев</segment>
		<segment id="37" parent="217" relname="joint">и твердо придерживаться этого курса.</segment>
		<segment id="38" parent="220" relname="joint">Кроме того, регулироваться должен и приток мигрантов из других стран.</segment>
		<segment id="39" parent="222" relname="span">При этом роль турецкой политики может быть в значительной степени ослаблена,</segment>
		<segment id="40" parent="39" relname="condition">если беженцы будут использовать иные маршруты, чтобы попасть в Европу.</segment>
		<segment id="41" parent="224" relname="evaluation">Скорее всего, [к 2016 году] могут быть достигнуты договоренности о послаблении визового режима для представителей ряда профессий",</segment>
		<segment id="42" parent="225" relname="attribution">― сказал он в интервью ИА "PenzaNews".</segment>
		<segment id="43" parent="229" relname="attribution">Между тем, по словам аналитика,</segment>
		<segment id="44" parent="228" relname="attribution">Евросоюз недвусмысленно дал понять,</segment>
		<segment id="45" parent="228" relname="span">что готов рассматривать довольно обширный комплекс мер</segment>
		<segment id="46" parent="45" relname="purpose">в обмен на улучшение контроля миграционных потоков на турецкой границе.</segment>
		<segment id="47" parent="239" relname="span">"Частью этих мероприятий стала финансовая помощь Анкаре</segment>
		<segment id="48" parent="47" relname="purpose">в борьбе с бременем беженцев.</segment>
		<segment id="49" parent="231" relname="joint">Европа хотела бы, чтобы Турция открыла для них свой рынок труда</segment>
		<segment id="50" parent="230" relname="span">и продумала программу натурализации</segment>
		<segment id="51" parent="50" relname="purpose">с целью получения ими турецкого гражданства.</segment>
		<segment id="52" parent="235" relname="joint">Внутри государства оба эти пункта не поддерживаются.</segment>
		<segment id="53" parent="232" relname="joint">Между тем утверждение собственного статуса,</segment>
		<segment id="54" parent="232" relname="joint">а также получение финансовой помощи</segment>
		<segment id="55" parent="233" relname="purpose">― популярные меры, которые заставят правительство страны двигаться в данном направлении",</segment>
		<segment id="56" parent="240" relname="attribution">― пояснил собеседник агентства.</segment>
		<segment id="57" parent="58" relname="attribution">Он добавил,</segment>
		<segment id="58" parent="245" relname="span">что решение визового вопроса займет гораздо более длительный срок.</segment>
		<segment id="59" parent="60" relname="effect">"Поскольку это касается Шенгенской зоны в целом,</segment>
		<segment id="60" parent="241" relname="span">изменение визового режима должно быть одобрено всеми странами, входящими в ее состав.</segment>
		<segment id="61" parent="242" relname="contrast">Пока Евросоюз сигнализировал о готовности двигаться по данному вопросу лишь в рамках действующей визовой политики",</segment>
		<segment id="62" parent="243" relname="attribution">― уточнил Йозеф Яннинг.</segment>
		<segment id="63" parent="246" relname="attribution">По его мнению,</segment>
		<segment id="64" parent="246" relname="span">ситуация осложняется тем,</segment>
		<segment id="65" parent="64" relname="effect">что Анкара ожидает от Европы большего, чем просто равноценный "обмен" по беженцам.</segment>
		<segment id="66" parent="249" relname="joint">"Реджеп Тайип Эрдоган (Recep Tayyip Erdogan) хочет добиться того, чтобы Турция играла важную роль в любых обсуждениях и переговорах по войне в Сирии.</segment>
		<segment id="67" parent="248" relname="span">Кроме того, страна стремится получить признание Европы и поддержку в качестве региональной державы</segment>
		<segment id="68" parent="247" relname="span">в возникающей борьбе с Ираном и Саудовской Аравией</segment>
		<segment id="69" parent="68" relname="purpose">за влияние на Ближнем Востоке",</segment>
		<segment id="70" parent="250" relname="attribution">― отметил эксперт.</segment>
		<segment id="71" parent="252" relname="attribution">В свою очередь политолог, востоковед, экономист, президент Института Ближнего Востока Евгений Сатановский (Yevgeny Satanovsky) высказал мысль о том,</segment>
		<segment id="72" parent="251" relname="contrast">что главной задачей турецкого правительства является не открытие границ,</segment>
		<segment id="73" parent="251" relname="contrast">а получение финансовой помощи.</segment>
		<segment id="74" parent="253" relname="span">"Речь не об отмене виз,</segment>
		<segment id="75" parent="74" relname="elaboration">что крайне маловероятно с учетом текущей ситуации на Ближнем Востоке.</segment>
		<segment id="76" parent="255" relname="span">Анкаре нужно выбить из Европы деньги под беженцев,</segment>
		<segment id="77" parent="76" relname="elaboration">шантажируя ими ЕС,</segment>
		<segment id="78" parent="256" relname="evaluation">― поток мигрантов через Грецию организован Турцией",</segment>
		<segment id="79" parent="257" relname="attribution">― сказал аналитик.</segment>
		<segment id="80" parent="81" relname="attribution">Однако, по его словам,</segment>
		<segment id="81" parent="261" relname="span">на практике это ни к чему не приведет.</segment>
		<segment id="82" parent="258" relname="joint">"Никакого ускорения отмены виз с Евросоюзом у Турции не будет.</segment>
		<segment id="83" parent="258" relname="joint">Хотеть можно чего угодно.</segment>
		<segment id="84" parent="258" relname="joint">Вероятность близка к нулю",</segment>
		<segment id="85" parent="259" relname="attribution">― подчеркнул политолог.</segment>
		<segment id="86" parent="87" relname="attribution">Более того, на его взгляд,</segment>
		<segment id="87" parent="266" relname="span">перспективы Анкары в вопросе вступления в Евросоюз также невелики.</segment>
		<segment id="88" parent="354" relname="sequence">"После недавнего визита Реджепа Тайипа Эрдогана в Брюссель</segment>
		<segment id="89" parent="90" relname="attribution">Ангела Меркель в очередной раз сказала,</segment>
		<segment id="90" parent="262" relname="span">что не видит Турцию членом ЕС.</segment>
		<segment id="91" parent="355" relname="evaluation">Вопрос де-факто закрыт надолго, если не навсегда",</segment>
		<segment id="92" parent="356" relname="attribution">― отметил Евгений Сатановский.</segment>
		<segment id="93" parent="268" relname="attribution">По мнению научного сотрудника Аналитического центра МГИМО МИД РФ, адвоката, эксперта Российского совета по международным делам Шарбатулло Содикова (Sharbatullo Sodikov),</segment>
		<segment id="94" parent="267" relname="contrast">вхождение в Евросоюз для Турции является не долгосрочной стратегией или дипломатической игрой,</segment>
		<segment id="95" parent="267" relname="contrast">а политическим выпадом антироссийского характера.</segment>
		<segment id="96" parent="270" relname="effect">"Массированная борьба против терроризма на Ближнем Востоке послужила началом тому,</segment>
		<segment id="97" parent="269" relname="joint">что президент Турции открыл новое дыхание политике двойных стандартов в стране</segment>
		<segment id="98" parent="269" relname="joint">и захотел поблажек со стороны Евросоюза.</segment>
		<segment id="99" parent="100" relname="purpose">Так, как бы в обмен на строительство лагерей для беженцев с территорий, занятых "Исламским государством" (ИГ),</segment>
		<segment id="100" parent="274" relname="span">он не против безвизового режима со странами ЕС.</segment>
		<segment id="101" parent="275" relname="span">Данное положение новейшей политики Турции, скорее всего,</segment>
		<segment id="102" parent="101" relname="effect">своими корнями уходит в интересы раздутой турецкой бюрократии.</segment>
		<segment id="103" parent="271" relname="joint">Необыкновенное растяжение "пирамиды власти"</segment>
		<segment id="104" parent="271" relname="joint">― вместе с потерей российского рынка для стран ЕС</segment>
		<segment id="105" parent="272" relname="span">― есть рождение нового политико-дипломатического контакта Турции и Евросоюза,</segment>
		<segment id="106" parent="105" relname="elaboration">связанного с проблемой членства страны в ЕС",</segment>
		<segment id="107" parent="280" relname="attribution">― сказал Шарбатулло Содиков.</segment>
		<segment id="108" parent="284" relname="attribution">При этом, по его словам,</segment>
		<segment id="109" parent="282" relname="span">тесные экономические связи Турции с Россией,</segment>
		<segment id="110" parent="281" relname="span">против которой первая выступила</segment>
		<segment id="111" parent="110" relname="background">после начала точечных ударов ВВС РФ в Сирии по военным объектам ИГ,</segment>
		<segment id="112" parent="283" relname="same-unit">будут непростительны для Евросоюза.</segment>
		<segment id="113" parent="114" relname="attribution">Тем не менее, комментируя заявление премьер-министра Турции о возможной отмене виз с ЕС в 2016 году, эксперт подчеркнул,</segment>
		<segment id="114" parent="351" relname="span">что такое развитие событий маловероятно.</segment>
		<segment id="115" parent="116" relname="concession">"Переговоры продолжаются,</segment>
		<segment id="116" parent="288" relname="span">но я убежден, что в ближайшие пять лет перейти к безвизовому режиму с Европейским союзом Турции не удастся.</segment>
		<segment id="117" parent="287" relname="span">Слова Ахмета Давутоглу ― всего лишь нереалистичное обещание перед выборами,</segment>
		<segment id="118" parent="117" relname="elaboration">похожее на сказки Шехерезады",</segment>
		<segment id="119" parent="289" relname="attribution">― отметил Шарбатулло Содиков.</segment>
		<segment id="120" parent="121" relname="attribution">Между тем журналист, политолог, декан факультета телевидения МГУ имени М.В. Ломоносова Виталий Третьяков (Vitaly Tretyakov) предположил,</segment>
		<segment id="121" parent="295" relname="span">что Турция вряд ли будет готова увеличить число лагерей для беженцев из стран Ближнего Востока и Африки.</segment>
		<segment id="122" parent="291" relname="contrast">"Не верю, что Турция готова будет разместить у себя всех или большинство тех, кто пытается бежать в ЕС.</segment>
		<segment id="123" parent="124" relname="condition">А если это произойдет,</segment>
		<segment id="124" parent="290" relname="span">то в любой момент из этих лагерей людей можно будет выпустить по направлению той же Европы.</segment>
		<segment id="125" parent="292" relname="evaluation">То есть Анкара приобретает в таком случае гигантский рычаг давления на Брюссель",</segment>
		<segment id="126" parent="293" relname="attribution">― пояснил он.</segment>
		<segment id="127" parent="296" relname="span">При этом вероятность отмены визового режима между Турцией и Евросоюзом в обозримом будущем,</segment>
		<segment id="128" parent="127" relname="attribution">по мнению политолога,</segment>
		<segment id="129" parent="297" relname="same-unit">практически равна нулю.</segment>
		<segment id="130" parent="298" relname="joint">"В Европе и так много турок.</segment>
		<segment id="131" parent="298" relname="joint">Думаю, что большинство немцев не поймут Ангелу Меркель",</segment>
		<segment id="132" parent="299" relname="attribution">― сказал эксперт.</segment>
		<segment id="133" parent="304" relname="attribution">Кроме того, по его мнению,</segment>
		<segment id="134" parent="304" relname="span">развитие ситуации будет зависеть от того,</segment>
		<segment id="135" parent="302" relname="joint">какое правительство в 2016 году будет стоять во главе Турции,</segment>
		<segment id="136" parent="302" relname="joint">а также от того, как пойдут дела у действующего канцлера ФРГ.</segment>
		<segment id="137" parent="310" relname="span">"Шансы вступления Турции в Европейский союз минимальны.</segment>
		<segment id="138" parent="305" relname="joint">Во-первых, это решение наверняка заблокируют несколько стран.</segment>
		<segment id="139" parent="305" relname="joint">Во-вторых, ЕС и так уже не может переварить всех, кого в себя вобрал.</segment>
		<segment id="140" parent="307" relname="span">В-третьих, в ближайшие годы он станет рассыпаться</segment>
		<segment id="141" parent="140" relname="elaboration">― из него начнут уходить некоторые страны.</segment>
		<segment id="142" parent="306" relname="span">И тут уж точно не до нового расширения,</segment>
		<segment id="143" parent="142" relname="elaboration">да еще такого проблемного, как в случае с Турцией",</segment>
		<segment id="144" parent="310" relname="attribution">― отметил Виталий Третьяков.</segment>
		<segment id="145" parent="312" relname="attribution">В свою очередь эксперт Международного института стратегических исследований в Турции Фатьма Йылмаз Элмас (Fatma Yılmaz Elmas) напомнила,</segment>
		<segment id="146" parent="312" relname="span">что лидеры Евросоюза и Турции уже согласовали план действий,</segment>
		<segment id="147" parent="311" relname="span">призванный усилить сотрудничество,</segment>
		<segment id="148" parent="147" relname="purpose">направленное на ограничение потока мигрантов между двумя странами.</segment>
		<segment id="149" parent="314" relname="joint">"План основывается на диалоге о послаблении визового режима</segment>
		<segment id="150" parent="313" relname="span">и обязательствах Евросоюза</segment>
		<segment id="151" parent="150" relname="purpose">по дальнейшему финансированию инициатив Анкары.</segment>
		<segment id="152" parent="320" relname="span">В сущности, данная материальная поддержка представляется платой</segment>
		<segment id="153" parent="152" relname="purpose">в обмен на обязательства Турции не допустить беженцев к европейским границам.</segment>
		<segment id="154" parent="321" relname="span">Таким образом, лидеры ЕС очень заинтересованы в этом сотрудничестве в особенности потому,</segment>
		<segment id="155" parent="315" relname="comparison">что это политически и экономически дешевле,</segment>
		<segment id="156" parent="315" relname="comparison">чем решать проблему у себя дома.</segment>
		<segment id="157" parent="322" relname="span">Ангела Меркель вынуждена была отказаться от своей "политики гостеприимства" для беженцев после того,</segment>
		<segment id="158" parent="317" relname="joint">как ей пришлось столкнуться с жесткой критикой</segment>
		<segment id="159" parent="317" relname="joint">и ожиданием наплыва мигрантов к концу 2015 года",</segment>
		<segment id="160" parent="324" relname="attribution">― сказала аналитик.</segment>
		<segment id="161" parent="327" relname="attribution">Однако, на ее взгляд,</segment>
		<segment id="162" parent="325" relname="span">политика Евросоюза по беженцам,</segment>
		<segment id="163" parent="162" relname="elaboration">ориентированная на контроль,</segment>
		<segment id="164" parent="326" relname="same-unit">будет оказывать негативное влияние на нормы и ценности, положенные в основу объединения с момента его создания.</segment>
		<segment id="165" parent="328" relname="span">"Только прямое проецирование европейских ценностей и идеалов на управление миграционным кризисом способно положительно повлиять на роль ЕС в мировом масштабе",</segment>
		<segment id="166" parent="165" relname="attribution">―подчеркнула эксперт.</segment>
		<segment id="167" parent="168" relname="attribution">Фатьма Йылмаз Элмас добавила также,</segment>
		<segment id="168" parent="329" relname="span">что безвизовый режим между сторонами не будет достигнут в краткосрочной перспективе.</segment>
		<segment id="169" parent="331" relname="joint">"Ни принятие совместного плана действий, ни слова Ангелы Меркель не могут привнести ясность относительно точных сроков отмены виз.</segment>
		<segment id="170" parent="331" relname="joint">Лидеры обсуждают ускорение переговоров по данному вопросу, а также преграды, которые предстоит преодолеть.</segment>
		<segment id="171" parent="332" relname="span">Кроме того, внутри европейского общества следует ожидать жесткой дискуссии по вопросу открытия границ для Турции,</segment>
		<segment id="172" parent="171" relname="elaboration">которая предоставила временное убежище около 2,5 млн. сирийцев.</segment>
		<segment id="173" parent="331" relname="joint">Между тем греческий Кипр уже дал понять, что будет блокировать такой шаг",</segment>
		<segment id="174" parent="333" relname="attribution">― пояснила эксперт.</segment>
		<segment id="175" parent="334" relname="attribution">При этом, по ее словам,</segment>
		<segment id="176" parent="177" relname="concession">сам процесс по вхождению Турции в ЕС зашел в тупик,</segment>
		<segment id="177" parent="334" relname="span">но перекладывать всю ответственность только на Анкару неправильно.</segment>
		<segment id="178" parent="179" relname="effect">"Ввиду неясной политической и экономической обстановки</segment>
		<segment id="179" parent="341" relname="span">Европейский союз долгое время не мог посылать Турции правильные сигналы, которые способствовали бы продвижению по данному вопросу.</segment>
		<segment id="180" parent="336" relname="span">Недавнее соглашение о сотрудничестве</segment>
		<segment id="181" parent="335" relname="span">в условиях кризиса,</segment>
		<segment id="182" parent="181" relname="effect">вызванного наплывам беженцев,</segment>
		<segment id="183" parent="337" relname="same-unit">может показаться позитивным,</segment>
		<segment id="184" parent="339" relname="contrast">но также не исключает коварную перспективу изменения самой основы европейско-турецких отношений и статуса Турции с кандидата в члены ЕС на буферное государство",</segment>
		<segment id="185" parent="343" relname="attribution">― резюмировала Фатьма Йылмаз Элмас.</segment>
		<segment id="186" parent="344" relname="sequence">Соглашение об ассоциации между ЕС и Турцией было подписано в 1963 году.</segment>
		<segment id="187" parent="344" relname="sequence">Заявку на членство в ЕС Анкара подала в 1987 году.</segment>
		<segment id="188" parent="344" relname="sequence">Переговоры о вступлении начались в 2005 году.</segment>
		<segment id="189" parent="348" relname="span">С тех пор стороны согласовали 14 из 35 технических пунктов,</segment>
		<segment id="190" parent="345" relname="span">которые должна выполнить Турция,</segment>
		<segment id="191" parent="190" relname="purpose">чтобы достичь необходимых для членства в ЕС стандартов.</segment>
		<segment id="192" parent="346" relname="comparison">17 пунктов остаются заблокированными,</segment>
		<segment id="193" parent="346" relname="comparison">по четырем ведутся переговоры.</segment>
		<group id="194" type="span" parent="5" relname="background"/>
		<group id="195" type="span" parent="197" relname="span"/>
		<group id="196" type="span" parent="195" relname="attribution"/>
		<group id="197" type="span" />
		<group id="198" type="span" parent="197" relname="preparation"/>
		<group id="199" type="span" parent="9" relname="elaboration"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" />
		<group id="202" type="span" />
		<group id="203" type="multinuc" parent="204" relname="span"/>
		<group id="204" type="span" />
		<group id="205" type="multinuc" parent="208" relname="span"/>
		<group id="206" type="multinuc" parent="207" relname="span"/>
		<group id="207" type="span" parent="24" relname="cause"/>
		<group id="208" type="span" parent="210" relname="span"/>
		<group id="209" type="span" parent="208" relname="elaboration"/>
		<group id="210" type="span" parent="211" relname="span"/>
		<group id="211" type="span" parent="212" relname="attribution"/>
		<group id="212" type="span" parent="213" relname="span"/>
		<group id="213" type="span" parent="214" relname="joint"/>
		<group id="214" type="multinuc" />
		<group id="215" type="span" parent="214" relname="joint"/>
		<group id="217" type="multinuc" parent="218" relname="span"/>
		<group id="218" type="span" parent="35" relname="condition"/>
		<group id="219" type="span" parent="220" relname="joint"/>
		<group id="220" type="multinuc" parent="221" relname="span"/>
		<group id="221" type="span" parent="223" relname="joint"/>
		<group id="222" type="span" parent="223" relname="joint"/>
		<group id="223" type="multinuc" parent="224" relname="span"/>
		<group id="224" type="span" parent="225" relname="span"/>
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" parent="227" relname="elaboration"/>
		<group id="227" type="span" />
		<group id="228" type="span" parent="229" relname="span"/>
		<group id="229" type="span" />
		<group id="230" type="span" parent="231" relname="joint"/>
		<group id="231" type="multinuc" parent="234" relname="span"/>
		<group id="232" type="multinuc" parent="233" relname="span"/>
		<group id="233" type="span" parent="236" relname="span"/>
		<group id="234" type="span" parent="235" relname="joint"/>
		<group id="235" type="multinuc" parent="237" relname="span"/>
		<group id="236" type="span" parent="238" relname="span"/>
		<group id="237" type="span" parent="236" relname="effect"/>
		<group id="238" type="span" parent="239" relname="elaboration"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" />
		<group id="241" type="span" parent="242" relname="contrast"/>
		<group id="242" type="multinuc" parent="243" relname="span"/>
		<group id="243" type="span" parent="244" relname="span"/>
		<group id="244" type="span" parent="245" relname="elaboration"/>
		<group id="245" type="span" />
		<group id="246" type="span" />
		<group id="247" type="span" parent="67" relname="background"/>
		<group id="248" type="span" parent="249" relname="joint"/>
		<group id="249" type="multinuc" parent="250" relname="span"/>
		<group id="250" type="span" />
		<group id="251" type="multinuc" parent="252" relname="span"/>
		<group id="252" type="span" />
		<group id="253" type="span" parent="254" relname="contrast"/>
		<group id="254" type="multinuc" parent="256" relname="span"/>
		<group id="255" type="span" parent="254" relname="contrast"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" />
		<group id="258" type="multinuc" parent="259" relname="span"/>
		<group id="259" type="span" parent="260" relname="span"/>
		<group id="260" type="span" parent="261" relname="elaboration"/>
		<group id="261" type="span" />
		<group id="262" type="span" parent="354" relname="sequence"/>
		<group id="266" type="span" parent="358" relname="span"/>
		<group id="267" type="multinuc" parent="268" relname="span"/>
		<group id="268" type="span" />
		<group id="269" type="multinuc" parent="270" relname="span"/>
		<group id="270" type="span" parent="277" relname="span"/>
		<group id="271" type="multinuc" parent="273" relname="span"/>
		<group id="272" type="span" parent="273" relname="evaluation"/>
		<group id="273" type="span" parent="279" relname="span"/>
		<group id="274" type="span" parent="276" relname="span"/>
		<group id="275" type="span" parent="274" relname="evaluation"/>
		<group id="276" type="span" parent="277" relname="evidence"/>
		<group id="277" type="span" parent="278" relname="span"/>
		<group id="278" type="span" parent="280" relname="span"/>
		<group id="279" type="span" parent="278" relname="evaluation"/>
		<group id="280" type="span" />
		<group id="281" type="span" parent="109" relname="elaboration"/>
		<group id="282" type="span" parent="283" relname="same-unit"/>
		<group id="283" type="multinuc" parent="284" relname="span"/>
		<group id="284" type="span" />
		<group id="287" type="span" parent="288" relname="elaboration"/>
		<group id="288" type="span" parent="289" relname="span"/>
		<group id="289" type="span" parent="352" relname="span"/>
		<group id="290" type="span" parent="291" relname="contrast"/>
		<group id="291" type="multinuc" parent="292" relname="span"/>
		<group id="292" type="span" parent="293" relname="span"/>
		<group id="293" type="span" parent="294" relname="span"/>
		<group id="294" type="span" parent="295" relname="elaboration"/>
		<group id="295" type="span" />
		<group id="296" type="span" parent="297" relname="same-unit"/>
		<group id="297" type="multinuc" parent="301" relname="span"/>
		<group id="298" type="multinuc" parent="299" relname="span"/>
		<group id="299" type="span" parent="300" relname="span"/>
		<group id="300" type="span" parent="301" relname="elaboration"/>
		<group id="301" type="span" />
		<group id="302" type="multinuc" parent="303" relname="span"/>
		<group id="303" type="span" parent="134" relname="effect"/>
		<group id="304" type="span" />
		<group id="305" type="multinuc" parent="309" relname="span"/>
		<group id="306" type="span" parent="307" relname="evaluation"/>
		<group id="307" type="span" parent="308" relname="span"/>
		<group id="308" type="span" parent="305" relname="joint"/>
		<group id="309" type="span" parent="137" relname="evidence"/>
		<group id="310" type="span" />
		<group id="311" type="span" parent="146" relname="purpose"/>
		<group id="312" type="span" />
		<group id="313" type="span" parent="314" relname="joint"/>
		<group id="314" type="multinuc" parent="319" relname="span"/>
		<group id="315" type="multinuc" parent="316" relname="span"/>
		<group id="316" type="span" parent="154" relname="effect"/>
		<group id="317" type="multinuc" parent="318" relname="span"/>
		<group id="318" type="span" parent="157" relname="effect"/>
		<group id="319" type="span" parent="323" relname="joint"/>
		<group id="320" type="span" parent="323" relname="joint"/>
		<group id="321" type="span" parent="323" relname="joint"/>
		<group id="322" type="span" parent="323" relname="joint"/>
		<group id="323" type="multinuc" parent="324" relname="span"/>
		<group id="324" type="span" />
		<group id="325" type="span" parent="326" relname="same-unit"/>
		<group id="326" type="multinuc" parent="327" relname="span"/>
		<group id="327" type="span" />
		<group id="328" type="span" parent="330" relname="joint"/>
		<group id="329" type="span" parent="330" relname="joint"/>
		<group id="330" type="multinuc" />
		<group id="331" type="multinuc" parent="333" relname="span"/>
		<group id="332" type="span" parent="331" relname="joint"/>
		<group id="333" type="span" />
		<group id="334" type="span" />
		<group id="335" type="span" parent="180" relname="background"/>
		<group id="336" type="span" parent="337" relname="same-unit"/>
		<group id="337" type="multinuc" parent="338" relname="span"/>
		<group id="338" type="span" parent="339" relname="contrast"/>
		<group id="339" type="multinuc" parent="340" relname="span"/>
		<group id="340" type="span" parent="342" relname="joint"/>
		<group id="341" type="span" parent="342" relname="joint"/>
		<group id="342" type="multinuc" parent="343" relname="span"/>
		<group id="343" type="span" />
		<group id="344" type="multinuc" />
		<group id="345" type="span" parent="189" relname="elaboration"/>
		<group id="346" type="multinuc" parent="347" relname="span"/>
		<group id="347" type="span" parent="349" relname="comparison"/>
		<group id="348" type="span" parent="349" relname="comparison"/>
		<group id="349" type="multinuc" />
		<group id="350" type="span" parent="30" relname="attribution"/>
		<group id="351" type="span" parent="353" relname="span"/>
		<group id="352" type="span" parent="351" relname="elaboration"/>
		<group id="353" type="span" />
		<group id="354" type="multinuc" parent="355" relname="span"/>
		<group id="355" type="span" parent="356" relname="span"/>
		<group id="356" type="span" parent="357" relname="span"/>
		<group id="357" type="span" parent="266" relname="elaboration"/>
		<group id="358" type="span" />
	</body>
</rst>