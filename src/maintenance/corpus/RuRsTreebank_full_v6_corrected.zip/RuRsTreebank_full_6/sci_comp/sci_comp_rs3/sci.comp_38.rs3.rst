<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >﻿ФИНАНСЫ, КРЕДИТ, СТРАХОВАНИЕ</segment>
		<segment id="2" parent="3" relname="attribution">А. А. Кудрявцев</segment>
		<segment id="3" parent="275" relname="span">МОДЕЛЬ ВЫБОРА ИНВЕСТИЦИОННОГО ПОРТФЕЛЯ НА ОСНОВЕ КВАНТИЛЬНЫХ МЕР РИСКА</segment>
		<segment id="4" parent="431" relname="preparation">Теория выбора портфеля является основой современных представлений о научном принятии инвестиционных решений.</segment>
		<segment id="5" parent="276" relname="joint">Ее изучение включено в программы всех университетов, предлагающих образование в области экономики и финансов.</segment>
		<segment id="6" parent="276" relname="joint">Она широко используется в практике различных финансовых компаний.</segment>
		<segment id="7" parent="276" relname="joint">Имеется обширная научная литература, посвященная разработке данного подхода1.</segment>
		<segment id="8" parent="444" relname="preparation">Теория была предложена Г. Марковицем в 50-х годах прошлого века2.</segment>
		<segment id="9" parent="277" relname="joint">Ее суть состоит в формировании инвестиционного портфеля на основе соотношений ожидаемой доходности и дисперсии доходности как меры риска.</segment>
		<segment id="10" parent="277" relname="joint">Именно в ее рамках разработаны такие понятия, как «эффективная граница» и «линия рынка капитала».</segment>
		<segment id="11" parent="442" relname="span">Теория Марковица базируется на идее выпуклого программирования,</segment>
		<segment id="12" parent="11" relname="purpose">что гарантирует оптимальность выбора.</segment>
		<segment id="13" parent="443" relname="elaboration">Обычно речь идет о минимизации дисперсии при ограничении на среднюю доходность по портфелю или об эквивалентной постановке максимизации средней доходности при ограничении на дисперсию портфеля.</segment>
		<segment id="14" parent="283" relname="span">Далее в рамках данной статьи будем придерживаться второй формулировки указанной задачи выбора портфеля:</segment>
		<segment id="15" parent="282" relname="span">[формула],</segment>
		<segment id="16" parent="279" relname="span">где x — вектор-строка (размерности n) долей активов в портфеле с компонентами,</segment>
		<segment id="17" parent="16" relname="condition">которые удовлетворяют условиям [формула],</segment>
		<segment id="18" parent="280" relname="joint">г — вектор- столбец случай ных доходностей индивидуальных активов,</segment>
		<segment id="19" parent="20" relname="cause">[формула] — ковариационная матрица доходностей (размерности n*n),</segment>
		<segment id="20" parent="281" relname="span">так что [формула] представляет собой дисперсию доходности портфеля,</segment>
		<segment id="21" parent="280" relname="joint">cq — максимально допустимая дисперсия портфеля.</segment>
		<segment id="22" parent="413" relname="span">Распространение идей Марковица и их всеобщее признание было связано,</segment>
		<segment id="23" parent="22" relname="cause">по- видимому, с несколькими причинами, среди которых можно назвать следующие:</segment>
		<segment id="24" parent="428" relname="span">относительная простота подхода,</segment>
		<segment id="25" parent="24" relname="purpose">что позволило широкому кругу практиков понять лежащие в основе идеи;</segment>
		<segment id="26" parent="285" relname="span">выбор хорошо согласующихся друг с другом статистических показателей,</segment>
		<segment id="27" parent="284" relname="joint">в  частности, тот факт, что дисперсия является минимальной мерой квадратичного разброса,</segment>
		<segment id="28" parent="284" relname="joint">а сам минимум достигается на математическом ожидании;</segment>
		<segment id="29" parent="287" relname="span">наличие простых и удобных методов оценки выборочных среднего и дисперсии,</segment>
		<segment id="30" parent="286" relname="joint">которые легко могут быть применены на практике</segment>
		<segment id="31" parent="286" relname="joint">и дают эффективную и несмещенную оценку теоретических значений;</segment>
		<segment id="32" parent="429" relname="span">возможность использования идеи оптимизации,</segment>
		<segment id="33" parent="288" relname="joint">что обеспечивало идеологическое обоснование подхода</segment>
		<segment id="34" parent="288" relname="joint">и ориентировало на модное в середине XX в. направление экономико-математического моделирования и применение вычислительной техники.</segment>
		<segment id="35" parent="290" relname="span">Наиболее известным вариантом рассматриваемой теории является модель ценообразования финансовых активов (Capital Asset Pricing Model — CAPM)3,</segment>
		<segment id="36" parent="35" relname="attribution">предложенная в середине 1960-х годов У. Шарпом, Дж. Линтнером и Я. Моссеном4.</segment>
		<segment id="37" parent="291" relname="joint">К настоящему времени разработано несколько вариантов модели.</segment>
		<segment id="38" parent="39" relname="cause">Кроме того, под нее подведены микроэкономические основания,</segment>
		<segment id="39" parent="292" relname="span">что делает ее важным «мостом» между экономической теорией и финансовой практикой.</segment>
		<segment id="40" parent="299" relname="preparation">Как правило, дискуссия в литературе ведется относительно особенностей применения именно модели CAPM.</segment>
		<segment id="41" parent="42" relname="concession">Несмотря на высокую популярность среди финансистов,</segment>
		<segment id="42" parent="297" relname="span">она подвергалась довольно сильным упрекам в недостаточной обоснованности и неадекватности практике.</segment>
		<segment id="43" parent="44" relname="attribution">Достаточно упомянуть критику Р. Ролла5,</segment>
		<segment id="44" parent="293" relname="span">который подверг сомнению реалистичность предпосылок, заложенных в модель, или проблему границы Хансена-Джаганнатана6.</segment>
		<segment id="45" parent="294" relname="joint">На взгляд автора, подобная дискуссия может быть распространена и на теорию выбора портфеля в целом.</segment>
		<segment id="46" parent="450" relname="span">Кроме того, можно привести аргументы против выбора показателей, лежащих в основе модели Марковица, в частности, дисперсии как меры риска7.</segment>
		<segment id="47" parent="296" relname="span">Действительно, она измеряет отклонения как в положительную, так и в отрицательную стороны,</segment>
		<segment id="48" parent="295" relname="restatement">хотя на практике реальным риском будет недостаточно высокая доходность,</segment>
		<segment id="49" parent="295" relname="restatement">т. е. измерять необходимо только отрицательные отклонения.</segment>
		<segment id="50" parent="449" relname="contrast">Далее, этот статистический показатель адекватно характеризует отклонения только для симметричных распределений (идеально — для нормального распределения).</segment>
		<segment id="51" parent="414" relname="span">В случае сильной асимметрии рассуждения в терминах дисперсии могут приводить к абсурдным выводам, особенно при наличии нерегулярного поведения на «хвостах» распределений,</segment>
		<segment id="52" parent="51" relname="evaluation">что весьма характерно для ряда практических ситуаций.</segment>
		<segment id="53" parent="427" relname="span">До конца 1990-х годов это не было особой проблемой практических приложений,</segment>
		<segment id="54" parent="53" relname="cause">так как недостатки с лихвой компенсировались достоинствами и простотой модели.</segment>
		<segment id="55" parent="301" relname="joint">При этом работы, исследующие альтернативные подходы к измерению риска, оставались, скорее, чисто теоретическими</segment>
		<segment id="56" parent="301" relname="joint">и не имели влияния на финансовую практику8.</segment>
		<segment id="57" parent="467" relname="span">Тем не менее ситуация изменилась</segment>
		<segment id="58" parent="57" relname="cause">в связи с появлением новых надзорных требований, а именно рекомендаций Базельского комитета по банковскому надзору9.</segment>
		<segment id="59" parent="415" relname="span">В частности, в апреле 1995 г. в рамках совершенствования нормативных требований к капиталу, известных как «Базель I», комитет рекомендовал использовать подход, основанный на внутренних моделях (internal models approach).</segment>
		<segment id="60" parent="432" relname="span">В его рамках возникла необходимость использования так называемого рискового капитала (Value-at-Risk — VaR)</segment>
		<segment id="61" parent="60" relname="purpose">для анализа рыночного риска и определения минимального размера капитала10.</segment>
		<segment id="62" parent="304" relname="span">В июне 1999 г. комитетом были приняты рекомендации, получившие неформальное название «Базель II»,</segment>
		<segment id="63" parent="62" relname="elaboration">где сфера применения этого показателя была расширена на кредитный и операционный риски11.</segment>
		<segment id="64" parent="65" relname="attribution">Таким образом, применение альтернативной меры риска было признано надзорными органами</segment>
		<segment id="65" parent="498" relname="span">обязательным.</segment>
		<segment id="66" parent="452" relname="span">Под рисковым капиталом понимают наибольший ущерб, полученный с фиксированной вероятностью в нормальных условиях функционирования бизнеса в течение определенного периода12.</segment>
		<segment id="67" parent="453" relname="span">Математически он представляет собой квантиль распределения подходящего агрегированного показателя, характеризующего соответствующий бизнес, при априорно фиксированной вероятности.</segment>
		<segment id="68" parent="309" relname="span">Квантилью называют величину</segment>
		<segment id="69" parent="308" relname="span">[формула],</segment>
		<segment id="70" parent="305" relname="restatement">где а — допустимая вероятность превышения рискового капитала,</segment>
		<segment id="71" parent="306" relname="span">иногда называемая вероятностью разорения,</segment>
		<segment id="72" parent="71" relname="concession">хотя к разорению в экономическом смысле она отношения не имеет,</segment>
		<segment id="73" parent="307" relname="joint">а Fy(.) — функция распределения анализируемой случайной величины у.</segment>
		<segment id="74" parent="75" relname="condition">Если рассматриваемая случайная величина имеет непрерывную монотонную функцию распределения без отрезков с постоянными значениями,</segment>
		<segment id="75" parent="310" relname="span">то квантиль распределения можно задавать как [формула].</segment>
		<segment id="76" parent="311" relname="span">Основные технические проблемы оценки данного показателя связаны с распространенной на практике ситуацией,</segment>
		<segment id="77" parent="76" relname="condition">когда функция распределения неизвестна.</segment>
		<segment id="78" parent="452" relname="elaboration">Стандартное обозначение рискового капитала в экономико-математических работах — VaRa (~).</segment>
		<segment id="79" parent="457" relname="span">Подход к измерению и анализу риска на основе рискового капитала был предложен в 1993 г. в отчете авторитетной исследовательской группы, известной как «группа тридцати» (G-30),</segment>
		<segment id="80" parent="79" relname="elaboration">которая занималась изучением методов управления риском производных ценных бумаг13.</segment>
		<segment id="81" parent="312" relname="span">Одним из членов этой группы был представитель банка J. P. Morgan, в котором соответствующие идеи разрабатывались с конца 1980-х годов под руководством Т. Гулдиманна (T. Guldimann)14.</segment>
		<segment id="82" parent="313" relname="span">Особенно известна методика RiskMetrics,</segment>
		<segment id="83" parent="82" relname="elaboration">родившаяся в стенах указанного банка.</segment>
		<segment id="84" parent="459" relname="span">С тех пор данный подход завоевал много поклонников в среде бизнесменов и особенно надзорных органов.</segment>
		<segment id="85" parent="314" relname="joint">Соответствующие идеи используются надзорными органами таких стран, как Австралия, Канада, США, Швейцария.</segment>
		<segment id="86" parent="314" relname="joint">Кроме того, следует упомянуть проект Европейского союза Solvency II.</segment>
		<segment id="87" parent="433" relname="span">В области бизнеса рисковый капитал завоевал популярность как инструмент измерения риска в качестве:</segment>
		<segment id="88" parent="318" relname="preparation">базы сравнения.</segment>
		<segment id="89" parent="462" relname="span">Рисковый капитал широко распространен в качестве инструмента сравнения рисков на уровне компании,</segment>
		<segment id="90" parent="89" relname="elaboration">причем такое сравнение может осуществляться как во времени, так и для разных типов рисков (рыночный, кредитный и т. п.) или для различных подразделений.</segment>
		<segment id="91" parent="316" relname="span">Выбор уровня значимости и периода не важен,</segment>
		<segment id="92" parent="315" relname="joint">если только они одинаковы для сравниваемых рисков,</segment>
		<segment id="93" parent="315" relname="joint">и выполнены все требования к аккуратности оценки;</segment>
		<segment id="94" parent="322" relname="preparation">меры ущерба.</segment>
		<segment id="95" parent="463" relname="span">Этот вариант состоит в определении наибольшего ущерба, который может потерпеть фирма.</segment>
		<segment id="96" parent="468" relname="span">Подобный анализ необходим,</segment>
		<segment id="97" parent="96" relname="purpose">например, для финансирования риска или распределения ресурсов с учетом риска.</segment>
		<segment id="98" parent="472" relname="evaluation">Выбор периода является ключевым аспектом:</segment>
		<segment id="99" parent="100" relname="purpose">для оценки риска ликвидности</segment>
		<segment id="100" parent="472" relname="span">необходимо выбрать период, связанный с продолжительностью продажи активов,</segment>
		<segment id="101" parent="469" relname="purpose">для анализа портфельного риска</segment>
		<segment id="102" parent="469" relname="span">период должен быть таков,</segment>
		<segment id="103" parent="102" relname="condition">чтобы портфель в течение него не менялся,</segment>
		<segment id="104" parent="105" relname="purpose">для изучения текущего (рыночного) риска</segment>
		<segment id="105" parent="471" relname="span">он может быть равен одному дню, неделе или 10 дням.</segment>
		<segment id="106" parent="321" relname="joint">Уровень значимости сам по себе не важен;</segment>
		<segment id="107" parent="327" relname="preparation">оценки потребности в капитале.</segment>
		<segment id="108" parent="464" relname="span">Методики данного типа подразумевают единообразное исследование разных видов рисков — рыночного, кредитного, операционного и т. д.</segment>
		<segment id="109" parent="434" relname="span">Каждый из них обеспечивает свою оценку потребности в капитале</segment>
		<segment id="110" parent="109" relname="purpose">для финансирования соответствующих убытков,</segment>
		<segment id="111" parent="325" relname="sequence">а затем эти оценки объединяются с учетом диверсификации.</segment>
		<segment id="112" parent="326" relname="restatement">Выбор параметров,</segment>
		<segment id="113" parent="326" relname="restatement">т. е. уровня значимости и периода,</segment>
		<segment id="114" parent="465" relname="cause">связан с особенностями политики компании, в первую очередь склонностью к риску (риск дефолта, привязка к рейтингам и т. п.).</segment>
		<segment id="115" parent="474" relname="preparation">В этой связи почти сразу же возникла идея построения модели выбора инвестиционного портфеля на основе рискового капитала15.</segment>
		<segment id="116" parent="330" relname="span">Все попытки такого рода оказались безуспешными.</segment>
		<segment id="117" parent="118" relname="cause">Объяснение состоит в том, что рисковый капитал для портфеля как функция смешивающего параметра, как правило, не является вогнутой,</segment>
		<segment id="118" parent="425" relname="span">что при ее использовании в ограничении или в качестве целевой функции выводит задачу за рамки выпуклого программирования.</segment>
		<segment id="119" parent="331" relname="joint">В подобной задаче наличие решения или его устойчивость не гарантированы.</segment>
		<segment id="120" parent="332" relname="span">Поэтому часто требуется наличие дополнительных регуляризирующих условий, например, вида распределения или специальной формы оценки рискового капитала16.</segment>
		<segment id="121" parent="122" relname="purpose">Для того чтобы соответствующий показатель можно было признать подходящей мерой риска,</segment>
		<segment id="122" parent="430" relname="span">он должен удовлетворять некоторым общим свойствам.</segment>
		<segment id="123" parent="430" relname="elaboration">Наиболее популярно определение так называемых когерентных мер риска, обозначаемых далее p (.).</segment>
		<segment id="124" parent="339" relname="span">Оно основывается на выполнении следующих априорных свойств ( у и z — случайные величины) 17:</segment>
		<segment id="125" parent="336" relname="span">A. Положительная однородность,</segment>
		<segment id="126" parent="125" relname="elaboration">т. е. [формула] для всех л&gt;0.</segment>
		<segment id="127" parent="335" relname="span">Б. Субаддитивность:</segment>
		<segment id="128" parent="127" relname="elaboration">[формула].</segment>
		<segment id="129" parent="334" relname="span">B. Инвариантность сдвигу:</segment>
		<segment id="130" parent="333" relname="span">[формула],</segment>
		<segment id="131" parent="130" relname="elaboration">где с — константа.</segment>
		<segment id="132" parent="337" relname="span">Г. Монотонность:</segment>
		<segment id="133" parent="132" relname="elaboration">упорядочение [формула] влечет [формула].</segment>
		<segment id="134" parent="341" relname="same-unit">Иногда свойства а) и б) ослабляются</segment>
		<segment id="135" parent="340" relname="restatement">до требования выпуклости вниз меры риска,</segment>
		<segment id="136" parent="340" relname="restatement">т. е. сублинейности:</segment>
		<segment id="137" parent="342" relname="elaboration">[формула] для любого [формула].</segment>
		<segment id="138" parent="344" relname="span">В таком случае это условие в совокупности со свойствами в) и г) обеспечивают так называемую слабую когерентность.</segment>
		<segment id="139" parent="345" relname="restatement">Сублинейность (или положительная однородность в совокупности с субаддитивностью) соответствует одному из основных свойств выпуклого множества, которое можно рассматривать как его определение.</segment>
		<segment id="140" parent="345" relname="restatement">Иными словами, когерентная (или слабо когерентная) мера риска порождает выпуклое множество.</segment>
		<segment id="141" parent="347" relname="same-unit">Таким образом, можно построить</segment>
		<segment id="142" parent="346" relname="span">ограничение вида [формула],</segment>
		<segment id="143" parent="142" relname="elaboration">которое легко использовать в задаче выпуклого программирования вида [формула].</segment>
		<segment id="144" parent="348" relname="span">Эта задача имеет на уровне интерпретации ту же структуру (максимизация ожидаемой доходности по портфелю при ограничении на риск), что и задача (1),</segment>
		<segment id="145" parent="144" relname="concession">хотя дисперсия не является когерентной мерой18.</segment>
		<segment id="146" parent="349" relname="joint">Фактически задача (2) может рассматриваться как обобщение теории портфеля Марковица.</segment>
		<segment id="147" parent="352" relname="span">К сожалению, рисковый капитал VaRa(у) также не является когерентной мерой риска.</segment>
		<segment id="148" parent="479" relname="span">Для данного показателя субаддитивность не выполняется как общее условие.</segment>
		<segment id="149" parent="351" relname="same-unit">Оно гарантированно нарушается</segment>
		<segment id="150" parent="350" relname="span">для случайных величин,</segment>
		<segment id="151" parent="150" relname="elaboration">подчиненных распределениям с тяжелыми «хвостами» или характеризующихся сильной асимметрией,</segment>
		<segment id="152" parent="351" relname="same-unit">а также при наличии некоторых форм зависимости.</segment>
		<segment id="153" parent="148" relname="concession">Тем не менее субаддитивность выполняется для некоторых типов распределений (прежде всего, нормального19), а также для точной функциональной зависимости между компонентами портфеля.</segment>
		<segment id="154" parent="353" relname="span">Именно поэтому ограничение вида не гарантирует выпуклости множества допустимых портфелей.</segment>
		<segment id="155" parent="423" relname="span">Вместе с тем заранее сужать сферу применения модели предопределенными типами распределений и априорными формами зависимости кажется неразумным с точки зрения практических приложений.</segment>
		<segment id="156" parent="421" relname="cause">Тем не менее подобное ограничение удачно отражает особенности надзорных требований в экономически развитых странах (прежде всего, в контексте рекомендаций Базельского комитета) и некоторые методики измерения и ограничения финансовых рисков, принятые в крупных банках, страховых компаниях и транснациональных корпорациях.</segment>
		<segment id="157" parent="421" relname="span">Это объясняет, почему важен поиск возможного варианта построения относительно простой оптимизационной модели,</segment>
		<segment id="158" parent="159" relname="cause">позволяющей учесть указанное ограничение</segment>
		<segment id="159" parent="420" relname="span">и тем самым непосредственно включить соответствующие нормативные предписания в такую модель.</segment>
		<segment id="160" parent="356" relname="purpose">Обойти проблемы с нарушением выпуклости помогает</segment>
		<segment id="161" parent="356" relname="span">модификация рискового капитала,</segment>
		<segment id="162" parent="355" relname="restatement">называемая условной (conditional VaR — CVaR),</segment>
		<segment id="163" parent="355" relname="restatement">или хвостовой (tail VaR — TVaR),</segment>
		<segment id="164" parent="355" relname="restatement">или ожидаемым дефицитом (Expected Shortfall — ESF)20.</segment>
		<segment id="165" parent="481" relname="span">Она задается формулой21</segment>
		<segment id="166" parent="165" relname="elaboration">где [формула] представляет популярное преобразование в области финансов и страхования.</segment>
		<segment id="167" parent="357" relname="cause">Условный рисковый капитал характеризует поведение всего «хвоста» распределения,</segment>
		<segment id="168" parent="357" relname="span">так что это — уже интегральная характеристика:</segment>
		<segment id="169" parent="168" relname="cause">она определяет площадь между функцией распределения, абсциссой рискового капитала и горизонтальной линией на единичном уровне.</segment>
		<segment id="170" parent="358" relname="joint">Данный показатель является когерентной мерой риска22.</segment>
		<segment id="171" parent="172" relname="cause">С учетом сказанного</segment>
		<segment id="172" parent="438" relname="span">частным случаем модели (2) может быть следующая задача выпуклого программирования:</segment>
		<segment id="173" parent="483" relname="preparation">Максимизация линейного функционала на выпуклом множестве, ограниченном сверху, гарантирует наличие решения.</segment>
		<segment id="174" parent="359" relname="joint">В качестве дополнительного преимущества можно отметить тот факт, что по аналогии с дисперсией условный рисковый капитал является минимальной мерой.</segment>
		<segment id="175" parent="360" relname="span">Кроме того, эта модель имеет явные преимущества на уровне интерпретации.</segment>
		<segment id="176" parent="362" relname="span">С учетом очевидного неравенства [формула]</segment>
		<segment id="177" parent="178" relname="cause">ограничение этой задачи гарантирует выполнение неравенства (3),</segment>
		<segment id="178" parent="361" relname="span">так что ее использование хорошо вписывается в контекст базельских требований.</segment>
		<segment id="179" parent="439" relname="span">При этом она так же, как и задача (1),</segment>
		<segment id="180" parent="179" relname="purpose">позволяет максимизировать ожидаемую доходность при ограничении на условный рисковый капитал.</segment>
		<segment id="181" parent="485" relname="span">Иными словами, задача (4) представляет собой специальную форму теории портфеля, учитывающую требования Базельского комитета и надзорных органов ряда стран.</segment>
		<segment id="182" parent="496" relname="span">В явной форме подобная модель была сформулирована, по-видимому, Р. Т. Рокафелла-ром и С. Урязевым в начале 2000-х годов,</segment>
		<segment id="183" parent="182" relname="concession">хотя они предпочитали формулировку мини мизации риска при линейном или выпуклом ограничении.</segment>
		<segment id="184" parent="364" relname="preparation">Данная версия модели нуждается во всестороннем изучении.</segment>
		<segment id="185" parent="363" relname="span">Прежде всего речь должна идти об особенностях практического использования в условиях дефицита информации.</segment>
		<segment id="186" parent="187" relname="condition">Действительно, при отсутствии сведений о типе распределения</segment>
		<segment id="187" parent="497" relname="span">возникают определенные проблемы расчетного характера по оценке квантилей и связанных с ними показателей.</segment>
		<segment id="188" parent="486" relname="concession">Хотя к настоящему времени в финансовой сфере разработано достаточно много методик приближенного оценивания рискового капитала,</segment>
		<segment id="189" parent="486" relname="span">большинство из них базируется на идее нормальной аппроксимации,</segment>
		<segment id="190" parent="426" relname="span">что может иметь смысл только при достаточно большом объеме статистики</segment>
		<segment id="191" parent="190" relname="elaboration">(как это обычно имеет место при анализе рыночного риска).</segment>
		<segment id="192" parent="436" relname="span">Для условного рискового капитала, который выступает интегральной характеристикой, статистических проблем будет намного больше.</segment>
		<segment id="193" parent="435" relname="joint">Эти вопросы являются до сих пор открытыми</segment>
		<segment id="194" parent="435" relname="joint">и все еще ждут своего разрешения.</segment>
		<segment id="195" parent="490" relname="span">Интересное решение указанных статистических проблем было предложено в рамках подхода, известного как условный рисковый капитал в наихудшем случае (worst- case CVaR), или робастный условный рисковый капитал (robust CVaR)25.</segment>
		<segment id="196" parent="195" relname="elaboration">Соответствующий показатель принято обозначать WCVaRa(у).</segment>
		<segment id="197" parent="365" relname="joint">Идея состоит в том, чтобы брать за основу некоторое «наихудшее» распределение из априорного класса допустимых вероятностных распределений 3.</segment>
		<segment id="198" parent="365" relname="joint">Излишняя «консервативность» подобной формулировки компенсируется относительно простым априорным решением проблемы оценивания распределения.</segment>
		<segment id="199" parent="365" relname="joint">Кроме того, такой подход хорошо согласуется с низко рисковой инвестиционной стратегией.</segment>
		<segment id="200" parent="492" relname="span">Тем не менее свойства условного рискового капитала на основе данного «наихудшего» распределения требуют отдельного исследования</segment>
		<segment id="201" parent="200" relname="purpose">для анализа качества получаемых решений.</segment>
		<segment id="202" parent="411" relname="preparation">Возможны различные постановки задачи выбора портфеля на основе робастного условного рискового капитала.</segment>
		<segment id="203" parent="369" relname="span">Во-первых, можно рассмотреть двухуровневую постановку,</segment>
		<segment id="204" parent="368" relname="sequence">когда сначала определяется вид WCVaRa (у) как функции параметров случайной величины у,</segment>
		<segment id="205" parent="368" relname="sequence">а затем формируется ограничение вида [формула].</segment>
		<segment id="206" parent="370" relname="span">Во-вторых, можно рассматривать минимаксные критерии,</segment>
		<segment id="207" parent="206" relname="elaboration">фактически комбинируя теорию портфеля с теорией игр.</segment>
		<segment id="208" parent="493" relname="evaluation">Особенности подобных постановок еще полностью не выявлены и не исследованы.</segment>
		<segment id="209" parent="376" relname="span">Таким образом, в последнее время появилась новая версия оптимизационной задачи, лежащей в основе теории портфеля,</segment>
		<segment id="210" parent="373" relname="same-unit">которая,</segment>
		<segment id="211" parent="212" relname="cause">обладая достаточно «красивыми» математическими свойствами,</segment>
		<segment id="212" parent="372" relname="span">хорошо согласуется с новыми идеями в области надзорных требований.</segment>
		<segment id="213" parent="374" relname="span">В этом смысле данная версия лучше приспособлена к потребностям практического финансового бизнеса, чем классическая постановка Марковица,</segment>
		<segment id="214" parent="213" relname="elaboration">основанная на противопоставлении математического ожидания и дисперсии.</segment>
		<segment id="215" parent="375" relname="concession">Тем не менее ряд вопросов теоретического и статистического характера все еще остается неразрешенным.</segment>
		<segment id="216" parent="378" relname="span">Не претендуя на полноту, можно сослаться на две обзорные работы:</segment>
		<segment id="217" parent="377" relname="joint">1. Cochrane J. H. Asset Pricing: 2nd (revised) ed. Princeton University Press, 2005;</segment>
		<segment id="218" parent="377" relname="joint">Коростелева М. В. Методы анализа рынка капитала. СПб., 2003.</segment>
		<segment id="219" parent="379" relname="span">2. Первой работой в этой области исследования считается статья:</segment>
		<segment id="220" parent="219" relname="elaboration">Markowitz H. Portfolio Selection // Journal of Finance. 1952. Vol. 7. N 1. P. 77-91.</segment>
		<segment id="221" parent="380" relname="span">Более систематическое изложение содержится в книге:</segment>
		<segment id="222" parent="221" relname="elaboration">Markowitz H. Portfolio Selection: Efficient Diversification of Investments. New York, Wiley, 1959.</segment>
		<segment id="223" parent="381" relname="joint">3. Строго говоря, речь должна идти не только о финансовых активах, но и о любых активах, приносящих доход.</segment>
		<segment id="224" parent="383" relname="span">Это отражено в английском названии (capital assets), но не в русском.</segment>
		<segment id="225" parent="382" relname="joint">4. Sharpe W. F. Capital Asset Prices: A Theory of Market Equilibrium Under Conditions of Risk // Journal of Finance. 1964. Vol. 19. N 3. P. 425-442; Lintner J. The Valuation of Risk Assets and the Selection of Risky Investments in Stock Portfolios and Capital Budgets // Review of Economics and Statistics. 1965. Vol. 47. N 1. P. 13-37; MossinJ. Equilibrium in a Capital Asset Market // Econometrica. 1966. Vol. 34. N 4. P. 768-783.</segment>
		<segment id="226" parent="382" relname="joint">5. Roll R. A Critique of the Asset Pricing Theory’s Tests. Part I. On Past and Potential Testability of the Theory // Journal of Financial Economics. 1977. Vol. 4. N 2. P. 129-176.</segment>
		<segment id="227" parent="385" relname="joint">6. Оригинальная статья: Hansen L, Jagannathan R. Restriction on Intertemporal Marginal Rates of Substitution Implied by Asset Returns // Journal of Political Economy. 1991. Vol. 99. P. 225-262.</segment>
		<segment id="228" parent="384" relname="span">Проблема статистической проверки представлена, в частности, в работе:</segment>
		<segment id="229" parent="228" relname="elaboration">Burnside C. Hansen-Jagannathan Bounds as Classical tests of Asset Pricing Models // Journal of Business and Economic Statistics. 1994. Vol. 12. P. 57-79.</segment>
		<segment id="230" parent="385" relname="joint">Обсуждение статистических инструментов проверки можно найти в многочисленных книгах по финансовой эконометрике.</segment>
		<segment id="231" parent="388" relname="same-unit">7. Характерно, что в своей фундаментальной работе 1959 г.</segment>
		<segment id="232" parent="233" relname="elaboration">(Markowitz H. Op. cit. 1959)</segment>
		<segment id="233" parent="386" relname="span">Марковиц</segment>
		<segment id="234" parent="387" relname="span">исследовал возможности использования альтернативных мер риска,</segment>
		<segment id="235" parent="389" relname="contrast">но они не прижились на практике.</segment>
		<segment id="236" parent="390" relname="span">8. Соответствующие ссылки можно найти, например, в обзорном докладе:</segment>
		<segment id="237" parent="236" relname="elaboration">Lohre H, Neumann Th., Winter-feldt Th. Portfolio Construction with Asymmetric Risk Measures. 2007 / FMA European Conference. May 30 - June 1, 2007. Barcelona, Spain.</segment>
		<segment id="238" parent="392" relname="joint">9. Базельский комитет по банковскому надзору образован в конце 1974 г. при Банке международных расчетов представителями центральных банков ряда экономически развитых стран.</segment>
		<segment id="239" parent="392" relname="joint">В настоящее время его участниками являются Бельгия, Великобритания, Германия, Италия, Канада, Люксембург, Нидерланды, США, Франция, Швеция, Япония и с февраля 2001 г. Испания.</segment>
		<segment id="240" parent="391" relname="contrast">Рекомендации Базельского комитета обязательны для стран-участниц.</segment>
		<segment id="241" parent="391" relname="contrast">Но они стали de facto отраслевыми стандартами для банковской сферы всего мира.</segment>
		<segment id="242" parent="393" relname="elaboration">Подробности работы комитета можно найти на официальном сайте www.bis.com.</segment>
		<segment id="243" parent="410" relname="joint">10 Gallati R. Risk Management and Capital Adequacy. New York, McGraw-Hill, 2003.</segment>
		<segment id="244" parent="410" relname="joint">11 Подробности можно найти, например, в следующих изданиях: Crouhy M, Galai D, Mark R. Risk Management. New York, McGraw-Hill, 2001; Gallati R. Op. cit.; Jorion Ph. Value-at-Risk: The New Benchmark for Managing Financial Risk: 2nd ed. New York: McGraw-Hill, 2001.</segment>
		<segment id="245" parent="410" relname="joint">12. Jorion Ph. Op. cit.</segment>
		<segment id="246" parent="395" relname="joint">13 Речь, разумеется, идет о начале регулярного использования данного подхода для целей бизнеса.</segment>
		<segment id="247" parent="395" relname="joint">В научной литературе можно найти множество ссылок на подобную идею до указанных дат.</segment>
		<segment id="248" parent="410" relname="joint">14 Jorion Ph. Op.cit.</segment>
		<segment id="249" parent="410" relname="joint">15. См., напр.: Gaivoronski A., Pflug G. Value at Risk in portfolio optimization: properties and computational approach // NTNU Working paper. 2000; Campbell R, Huisman R, Koedijk K. Optimal portfolio selection in a Value-at-Risk framework // Journal of Banking and Finance. 2001. Vol. 25. P. 1789-1804; Consigli G. The estimation and mean-VaR portfolio selection in markets subject to financial stability // Journal of Banking and Finance. 2002. Vol. 26. P. 1355-1382.</segment>
		<segment id="250" parent="396" relname="span">16. В частности, в работе:</segment>
		<segment id="251" parent="250" relname="attribution">Campbell R, Huisman R, Koedijk K. Op. cit.</segment>
		<segment id="252" parent="397" relname="same-unit">предполагается t-распределение Стьюдента, а</segment>
		<segment id="253" parent="398" relname="joint">Гайворонский</segment>
		<segment id="254" parent="398" relname="joint">и Пфлуг</segment>
		<segment id="255" parent="399" relname="span">вводят специальную «сглаженную» версию рискового капитала</segment>
		<segment id="256" parent="399" relname="elaboration">(Gaivoronski A., Pflug G. Op.cit.).</segment>
		<segment id="257" parent="402" relname="span">17. Определение когерентной меры риска дано в статье:</segment>
		<segment id="258" parent="257" relname="elaboration">Artzner Ph. et al. Coherent Measures of Risk // Mathematical Finance. 1999. Vol. 9. N 3. P. 223-228.</segment>
		<segment id="259" parent="260" relname="cause">18. Для дисперсии нарушаются практически все свойства когерентных мер риска,</segment>
		<segment id="260" parent="403" relname="span">что добавляет аргументы против ее практического использования.</segment>
		<segment id="261" parent="403" relname="concession">Тем не менее для стандартного отклонения выполняется положительная однородность и субаддитивность.</segment>
		<segment id="262" parent="410" relname="joint">19. Строго говоря, это свойство выполняется для всех эллиптических распределений, к множеству которых принадлежит и нормальное (Гаусса - Лапласа).</segment>
		<segment id="263" parent="405" relname="joint">20. В некоторых работах эти показатели отличаются друг от друга за счет введения определенных линейных преобразований.</segment>
		<segment id="264" parent="405" relname="joint">В актуарном контексте подобные показатели принято называть «ожидаемой продолжительностью предстоящей жизни».</segment>
		<segment id="265" parent="406" relname="joint">21. Эта формула гарантированно выполняется, если функция распределения гладкая</segment>
		<segment id="266" parent="406" relname="joint">и строго возрастает на носителе распределения.</segment>
		<segment id="267" parent="268" relname="condition">Если она имеет скачки или участки постоянства,</segment>
		<segment id="268" parent="407" relname="span">то в формулу требуется внести некоторые поправки,</segment>
		<segment id="269" parent="407" relname="elaboration">обсуждение которых выходит за рамки данной работы.</segment>
		<segment id="270" parent="409" relname="span">22. Доказательство этого факта содержится, например, в работе:</segment>
		<segment id="271" parent="270" relname="elaboration">Acerbi C, Tasche D. On the coherence of expected shortfall // Journal of Banking and Finance. 2002. Vol. 26. P. 1487-1503.</segment>
		<segment id="272" parent="410" relname="joint">23. RockafellarR.T., Uryasev St. Optimization of conditional value-at-risk // Journal of Risk. 2000. Vol. 2. P. 21-41; Rockafellar R. T, Uryasev St. Conditional value-at-risk for general loss distributions // Journal of Banking and Finance. 2002. Vol. 26. P. 1443-1471.</segment>
		<segment id="273" parent="410" relname="joint">24 Jorion Ph. Op. cit. 25 См., напр., статью: Huang D. et al. Portfolio selection with uncertain exit time: A robust CVaR approach // Journal of Economic Dynamics &amp; Control. 2008. Vol. 32. P. 594-623.</segment>
		<segment id="274" >Статья поступила в редакцию 25 сентября 2008 г.</segment>
		<group id="275" type="span" parent="278" relname="preparation"/>
		<group id="276" type="multinuc" parent="431" relname="span"/>
		<group id="277" type="multinuc" parent="443" relname="span"/>
		<group id="278" type="span" />
		<group id="279" type="span" parent="280" relname="joint"/>
		<group id="280" type="multinuc" parent="15" relname="elaboration"/>
		<group id="281" type="span" parent="280" relname="joint"/>
		<group id="282" type="span" parent="14" relname="elaboration"/>
		<group id="283" type="span" />
		<group id="284" type="multinuc" parent="26" relname="elaboration"/>
		<group id="285" type="span" parent="289" relname="joint"/>
		<group id="286" type="multinuc" parent="29" relname="elaboration"/>
		<group id="287" type="span" parent="289" relname="joint"/>
		<group id="288" type="multinuc" parent="32" relname="purpose"/>
		<group id="289" type="multinuc" parent="23" relname="elaboration"/>
		<group id="290" type="span" parent="446" relname="preparation"/>
		<group id="291" type="multinuc" parent="446" relname="span"/>
		<group id="292" type="span" parent="291" relname="joint"/>
		<group id="293" type="span" parent="294" relname="joint"/>
		<group id="294" type="multinuc" parent="297" relname="elaboration"/>
		<group id="295" type="multinuc" parent="47" relname="concession"/>
		<group id="296" type="span" parent="46" relname="evidence"/>
		<group id="297" type="span" parent="448" relname="span"/>
		<group id="298" type="multinuc" parent="299" relname="span"/>
		<group id="299" type="span" parent="300" relname="span"/>
		<group id="300" type="span" />
		<group id="301" type="multinuc" parent="302" relname="span"/>
		<group id="302" type="span" parent="303" relname="span"/>
		<group id="303" type="span" parent="427" relname="elaboration"/>
		<group id="304" type="span" parent="416" relname="sequence"/>
		<group id="305" type="multinuc" parent="307" relname="joint"/>
		<group id="306" type="span" parent="305" relname="restatement"/>
		<group id="307" type="multinuc" parent="69" relname="elaboration"/>
		<group id="308" type="span" parent="68" relname="elaboration"/>
		<group id="309" type="span" parent="455" relname="span"/>
		<group id="310" type="span" parent="456" relname="joint"/>
		<group id="311" type="span" parent="456" relname="joint"/>
		<group id="312" type="span" parent="458" relname="span"/>
		<group id="313" type="span" parent="312" relname="elaboration"/>
		<group id="314" type="multinuc" parent="84" relname="elaboration"/>
		<group id="315" type="multinuc" parent="91" relname="condition"/>
		<group id="316" type="span" parent="317" relname="joint"/>
		<group id="317" type="multinuc" parent="318" relname="span"/>
		<group id="318" type="span" parent="319" relname="span"/>
		<group id="319" type="span" parent="329" relname="same-unit"/>
		<group id="320" type="multinuc" parent="321" relname="joint"/>
		<group id="321" type="multinuc" parent="322" relname="span"/>
		<group id="322" type="span" parent="323" relname="span"/>
		<group id="323" type="span" parent="329" relname="same-unit"/>
		<group id="324" type="multinuc" parent="327" relname="span"/>
		<group id="325" type="multinuc" parent="108" relname="elaboration"/>
		<group id="326" type="multinuc" parent="465" relname="span"/>
		<group id="327" type="span" parent="328" relname="span"/>
		<group id="328" type="span" parent="329" relname="same-unit"/>
		<group id="329" type="multinuc" parent="87" relname="elaboration"/>
		<group id="330" type="span" parent="331" relname="joint"/>
		<group id="331" type="multinuc" parent="120" relname="evidence"/>
		<group id="332" type="span" parent="474" relname="span"/>
		<group id="333" type="span" parent="129" relname="elaboration"/>
		<group id="334" type="span" parent="338" relname="joint"/>
		<group id="335" type="span" parent="338" relname="joint"/>
		<group id="336" type="span" parent="338" relname="joint"/>
		<group id="337" type="span" parent="338" relname="joint"/>
		<group id="338" type="multinuc" parent="124" relname="elaboration"/>
		<group id="339" type="span" parent="476" relname="elaboration"/>
		<group id="340" type="multinuc" parent="341" relname="same-unit"/>
		<group id="341" type="multinuc" parent="342" relname="span"/>
		<group id="342" type="span" parent="343" relname="span"/>
		<group id="343" type="span" parent="138" relname="condition"/>
		<group id="344" type="span" />
		<group id="345" type="multinuc" parent="418" relname="evidence"/>
		<group id="346" type="span" parent="347" relname="same-unit"/>
		<group id="347" type="multinuc" parent="418" relname="span"/>
		<group id="348" type="span" parent="349" relname="joint"/>
		<group id="349" type="multinuc" />
		<group id="350" type="span" parent="351" relname="same-unit"/>
		<group id="351" type="multinuc" parent="352" relname="elaboration"/>
		<group id="352" type="span" parent="478" relname="span"/>
		<group id="353" type="span" parent="354" relname="span"/>
		<group id="354" type="span" />
		<group id="355" type="multinuc" parent="161" relname="elaboration"/>
		<group id="356" type="span" parent="480" relname="span"/>
		<group id="357" type="span" parent="424" relname="span"/>
		<group id="358" type="multinuc" parent="440" relname="span"/>
		<group id="359" type="multinuc" parent="483" relname="span"/>
		<group id="360" type="span" parent="500" relname="span"/>
		<group id="361" type="span" parent="176" relname="evaluation"/>
		<group id="362" type="span" parent="175" relname="condition"/>
		<group id="363" type="span" parent="364" relname="span"/>
		<group id="364" type="span" parent="488" relname="span"/>
		<group id="365" type="multinuc" parent="366" relname="span"/>
		<group id="366" type="span" parent="367" relname="span"/>
		<group id="367" type="span" parent="491" relname="span"/>
		<group id="368" type="multinuc" parent="203" relname="elaboration"/>
		<group id="369" type="span" parent="371" relname="joint"/>
		<group id="370" type="span" parent="371" relname="joint"/>
		<group id="371" type="multinuc" parent="493" relname="span"/>
		<group id="372" type="span" parent="373" relname="same-unit"/>
		<group id="373" type="multinuc" parent="209" relname="elaboration"/>
		<group id="374" type="span" parent="375" relname="span"/>
		<group id="375" type="span" parent="494" relname="span"/>
		<group id="376" type="span" parent="495" relname="span"/>
		<group id="377" type="multinuc" parent="216" relname="elaboration"/>
		<group id="378" type="span" parent="410" relname="joint"/>
		<group id="379" type="span" parent="410" relname="joint"/>
		<group id="380" type="span" parent="410" relname="joint"/>
		<group id="381" type="multinuc" parent="410" relname="joint"/>
		<group id="382" type="multinuc" parent="224" relname="elaboration"/>
		<group id="383" type="span" parent="381" relname="joint"/>
		<group id="384" type="span" parent="385" relname="joint"/>
		<group id="385" type="multinuc" parent="410" relname="joint"/>
		<group id="386" type="span" parent="234" relname="attribution"/>
		<group id="387" type="span" parent="388" relname="same-unit"/>
		<group id="388" type="multinuc" parent="389" relname="contrast"/>
		<group id="389" type="multinuc" parent="410" relname="joint"/>
		<group id="390" type="span" parent="410" relname="joint"/>
		<group id="391" type="multinuc" parent="392" relname="joint"/>
		<group id="392" type="multinuc" parent="393" relname="span"/>
		<group id="393" type="span" parent="394" relname="span"/>
		<group id="394" type="span" parent="410" relname="joint"/>
		<group id="395" type="multinuc" parent="410" relname="joint"/>
		<group id="396" type="span" parent="397" relname="same-unit"/>
		<group id="397" type="multinuc" parent="401" relname="comparison"/>
		<group id="398" type="multinuc" parent="255" relname="attribution"/>
		<group id="399" type="span" parent="400" relname="span"/>
		<group id="400" type="span" parent="401" relname="comparison"/>
		<group id="401" type="multinuc" parent="410" relname="joint"/>
		<group id="402" type="span" parent="410" relname="joint"/>
		<group id="403" type="span" parent="404" relname="span"/>
		<group id="404" type="span" parent="410" relname="joint"/>
		<group id="405" type="multinuc" parent="410" relname="joint"/>
		<group id="406" type="multinuc" parent="410" relname="joint"/>
		<group id="407" type="span" parent="408" relname="span"/>
		<group id="408" type="span" parent="406" relname="joint"/>
		<group id="409" type="span" parent="410" relname="joint"/>
		<group id="410" type="multinuc" />
		<group id="411" type="span" parent="412" relname="span"/>
		<group id="412" type="span" />
		<group id="413" type="span" />
		<group id="414" type="span" parent="449" relname="contrast"/>
		<group id="415" type="span" parent="416" relname="sequence"/>
		<group id="416" type="multinuc" parent="498" relname="evidence"/>
		<group id="418" type="span" parent="419" relname="span"/>
		<group id="419" type="span" />
		<group id="420" type="span" parent="157" relname="cause"/>
		<group id="421" type="span" parent="422" relname="span"/>
		<group id="422" type="span" parent="155" relname="concession"/>
		<group id="423" type="span" parent="353" relname="evaluation"/>
		<group id="424" type="span" parent="358" relname="joint"/>
		<group id="425" type="span" parent="116" relname="cause"/>
		<group id="426" type="span" parent="189" relname="condition"/>
		<group id="427" type="span" parent="451" relname="span"/>
		<group id="428" type="span" parent="289" relname="joint"/>
		<group id="429" type="span" parent="289" relname="joint"/>
		<group id="430" type="span" parent="476" relname="span"/>
		<group id="431" type="span" parent="278" relname="span"/>
		<group id="432" type="span" parent="59" relname="elaboration"/>
		<group id="433" type="span" />
		<group id="434" type="span" parent="325" relname="sequence"/>
		<group id="435" type="multinuc" parent="192" relname="elaboration"/>
		<group id="436" type="span" parent="488" relname="evaluation"/>
		<group id="438" type="span" parent="440" relname="elaboration"/>
		<group id="439" type="span" parent="360" relname="elaboration"/>
		<group id="440" type="span" parent="441" relname="span"/>
		<group id="441" type="span" />
		<group id="442" type="span" parent="277" relname="joint"/>
		<group id="443" type="span" parent="444" relname="span"/>
		<group id="444" type="span" parent="445" relname="span"/>
		<group id="445" type="span" />
		<group id="446" type="span" parent="447" relname="span"/>
		<group id="447" type="span" />
		<group id="448" type="span" parent="298" relname="joint"/>
		<group id="449" type="multinuc" parent="298" relname="joint"/>
		<group id="450" type="span" parent="298" relname="joint"/>
		<group id="451" type="span" />
		<group id="452" type="span" parent="454" relname="span"/>
		<group id="453" type="span" parent="66" relname="elaboration"/>
		<group id="454" type="span" />
		<group id="455" type="span" parent="67" relname="elaboration"/>
		<group id="456" type="multinuc" parent="309" relname="elaboration"/>
		<group id="457" type="span" parent="460" relname="preparation"/>
		<group id="458" type="span" parent="460" relname="span"/>
		<group id="459" type="span" parent="458" relname="elaboration"/>
		<group id="460" type="span" parent="461" relname="span"/>
		<group id="461" type="span" />
		<group id="462" type="span" parent="317" relname="joint"/>
		<group id="463" type="span" parent="321" relname="joint"/>
		<group id="464" type="span" parent="324" relname="joint"/>
		<group id="465" type="span" parent="466" relname="span"/>
		<group id="466" type="span" parent="324" relname="joint"/>
		<group id="467" type="span" parent="302" relname="concession"/>
		<group id="468" type="span" parent="95" relname="elaboration"/>
		<group id="469" type="span" parent="470" relname="span"/>
		<group id="470" type="span" parent="320" relname="joint"/>
		<group id="471" type="span" parent="320" relname="joint"/>
		<group id="472" type="span" parent="473" relname="span"/>
		<group id="473" type="span" parent="321" relname="joint"/>
		<group id="474" type="span" parent="475" relname="span"/>
		<group id="475" type="span" />
		<group id="476" type="span" parent="477" relname="span"/>
		<group id="477" type="span" />
		<group id="478" type="span" parent="154" relname="evidence"/>
		<group id="479" type="span" parent="147" relname="elaboration"/>
		<group id="480" type="span" parent="482" relname="span"/>
		<group id="481" type="span" parent="480" relname="elaboration"/>
		<group id="482" type="span" />
		<group id="483" type="span" parent="484" relname="span"/>
		<group id="484" type="span" />
		<group id="485" type="span" />
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" parent="363" relname="elaboration"/>
		<group id="488" type="span" parent="489" relname="span"/>
		<group id="489" type="span" />
		<group id="490" type="span" parent="367" relname="preparation"/>
		<group id="491" type="span" />
		<group id="492" type="span" parent="366" relname="concession"/>
		<group id="493" type="span" parent="411" relname="span"/>
		<group id="494" type="span" parent="376" relname="elaboration"/>
		<group id="495" type="span" />
		<group id="496" type="span" parent="181" relname="elaboration"/>
		<group id="497" type="span" parent="185" relname="evidence"/>
		<group id="498" type="span" parent="499" relname="span"/>
		<group id="499" type="span" />
		<group id="500" type="span" parent="359" relname="joint"/>
	</body>
</rst>