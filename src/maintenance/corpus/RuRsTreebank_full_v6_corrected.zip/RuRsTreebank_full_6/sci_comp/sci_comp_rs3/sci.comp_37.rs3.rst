<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="75" relname="span">﻿ Какунина Анна Станиславовна Мазурова Ульяна Сергеевна</segment>
		<segment id="2" parent="1" relname="elaboration">Университет ИТМО г. Санкт-Петербург E-mail: kakuninaanna@rambler.ru</segment>
		<segment id="3" parent="76" relname="span">ВОЗМОЖНОСТИ ФРАКТАЛЬНОЙ РАЗМЕРНОСТИ ДЛЯ АНАЛИЗА ИЗОБРАЖЕНИЙ РАЗЛИЧНОЙ ПРИРОДЫ</segment>
		<segment id="4" >Аннотация В статье проанализированы возможности фрактального анализа для оценки объектов различной природы по их изображениям, показана зависимость фрактальной размерности от свойств объекта. Сформулированы условия анализа томограмм для минимизации погрешности расчета размерности. Ключевые слова: анализ изображений, фрактальная размерность; диагностика.</segment>
		<segment id="5" parent="78" relname="preparation">Одним из новых методов получения дополнительной информации об объекте исследование является фрактальный анализ, позволяющий оценить степень самоподобия объекта или цикличность процесса.</segment>
		<segment id="6" parent="77" relname="span">Мультифрактальный подход позволяет разделить изучаемый объект на части,</segment>
		<segment id="7" parent="6" relname="elaboration">каждая из которых обладает свойствами самоподобия</segment>
		<segment id="8" parent="78" relname="span">и таким образом использовать теорию практически к любому типу данных.</segment>
		<segment id="9" parent="80" relname="same-unit">В большинстве задач оценка самоподобия базируется на расчете фрактальной размерности или</segment>
		<segment id="10" parent="79" relname="span">параметра Херста (Н),</segment>
		<segment id="11" parent="10" relname="elaboration">значение которого лежит в интервале [формула].</segment>
		<segment id="12" parent="81" relname="joint">Для случайного процесса (классическое броуновское движение) параметр Херста H=0,5.</segment>
		<segment id="13" parent="81" relname="joint">Системы, проявляющие цикличность имеют значения Н=0,5;</segment>
		<segment id="14" parent="15" relname="condition">чем ближе параметр Херста к 1,</segment>
		<segment id="15" parent="100" relname="span">тем более ярко проявляются фрактальные свойства.</segment>
		<segment id="16" parent="81" relname="joint">Для двумерного случая величина фрактальной размеренности рассчитывается как D = 2 — H.</segment>
		<segment id="17" parent="106" relname="span">Данный подход нашел наибольшее распространение</segment>
		<segment id="18" parent="17" relname="purpose">для описания свойств материалов.</segment>
		<segment id="19" parent="107" relname="joint">Для сварных металлических конструкций, характер борозд усталостных трещин зависит от скорости их распространения,</segment>
		<segment id="20" parent="107" relname="joint">и геометрия излома может быть описана фрактальной размерностью.</segment>
		<segment id="21" parent="85" relname="evidence">Как показали исследования [10],</segment>
		<segment id="22" parent="84" relname="comparison">грубой поверхности излома соответствует размерность 1,79.. .1,82;</segment>
		<segment id="23" parent="84" relname="comparison">для гладкой поверхности D=1,87.. .1,89.</segment>
		<segment id="24" parent="86" relname="elaboration">В случае анализа макроструктуры материалов, фрактальная размерность мало зависит от изменения марки наполнителя при его постоянной концентрации [2].</segment>
		<segment id="25" parent="90" relname="joint">При анализе слабых или зашумленных сигналов в радиоэлектронике или физике, фрактальный анализ позволяет устранить влияние помех в радиолокации,</segment>
		<segment id="26" parent="90" relname="joint">выявить особенности поверхностей различной природы.</segment>
		<segment id="27" parent="88" relname="evidence">В результате серии исследований [9], показано,</segment>
		<segment id="28" parent="88" relname="span">что фрактальная размерность для изображений различных объектов лежит в достаточно узких диапазонах</segment>
		<segment id="29" parent="87" relname="joint">(например, для радиолокационных изображений Земли D= 2,55-2,65;</segment>
		<segment id="30" parent="87" relname="joint">Венеры D=2,20-2,50;</segment>
		<segment id="31" parent="87" relname="joint">Марса D=2,40-2,55).</segment>
		<segment id="32" parent="125" relname="span">Изучение активных областей, порождающих солнечные вспышки,</segment>
		<segment id="33" parent="32" relname="condition">показывает уменьшение размерности D за несколько минут до вспышек [4],</segment>
		<segment id="34" parent="125" relname="purpose">что позволяет оценить временные вариации поля.</segment>
		<segment id="35" parent="36" relname="condition">При исследовании внутренней структуры древесных материалов,</segment>
		<segment id="36" parent="128" relname="span">фрактальный анализ позволит выявить наличие скрытых дефектов, например, областей с различной плотностью [12].</segment>
		<segment id="37" parent="127" relname="span">Сложной задачей является оценка качества изображений</segment>
		<segment id="38" parent="37" relname="condition">при отсутствии эталона,</segment>
		<segment id="39" parent="127" relname="elaboration">особенно если данные получены в различных условиях.</segment>
		<segment id="40" parent="92" relname="span">В этом случае расчет количественных критериев качества изображений (соотношение сигнал/шум, разрешение, контрастность [6]) может быть дополнен фрактальным анализом,</segment>
		<segment id="41" parent="40" relname="elaboration">результаты которого хорошо коррелируют с экспертной оценкой [8].</segment>
		<segment id="42" parent="94" relname="span">Одной из областей применения фрактального анализа изображений является медицина,</segment>
		<segment id="43" parent="131" relname="joint">где фрактальная оценка позволяет выявить специфические свойства, неразличимые обычными средствами</segment>
		<segment id="44" parent="131" relname="joint">и может служить вспомогательным средством диагностики,</segment>
		<segment id="45" parent="132" relname="condition">например, при необходимости сопоставления анатомических картин, полученных различными методами [11].</segment>
		<segment id="46" parent="135" relname="span">Ряд анатомических структур обладает фрактальными свойствами, в том числе гиппокампы головного мозга [1].</segment>
		<segment id="47" parent="114" relname="span">Их визуальный анализ для оценки симметричности и толщины коры на различных участках</segment>
		<segment id="48" parent="47" relname="cause">затруднен из-за небольшого размера и зависимости от ориентации плоскости среза.</segment>
		<segment id="49" parent="119" relname="span">В этом случае фрактальная размерность</segment>
		<segment id="50" parent="49" relname="purpose">позволяет оценить анатомическую схожесть симметричных областей</segment>
		<segment id="51" parent="134" relname="joint">и для здоровых добровольцев составляет 0,44-1,04 [3].</segment>
		<segment id="52" parent="115" relname="span">Фрактальную размерность можно использовать</segment>
		<segment id="53" parent="116" relname="span">для анализа природы шума томограмм [7],</segment>
		<segment id="54" parent="53" relname="cause">который может быть связан как с объектом или методикой исследования, так и с присутствием внешней помехи.</segment>
		<segment id="55" parent="56" relname="condition">Если для томограмм тестовых объектов фрактальная размерность шума лежит в диапазоне 1,31-1,42,</segment>
		<segment id="56" parent="95" relname="span">то присутствие внешней помехи приводит к снижению размерности до 1,18.</segment>
		<segment id="57" parent="102" relname="span">Данный критерий может служить для оценки технического состояния оборудования [5],</segment>
		<segment id="58" parent="57" relname="purpose">позволяя выявить скрытые аппаратные неисправности.</segment>
		<segment id="59" parent="117" relname="preparation">Одним из средств расчета фрактальных характеристик изображений любого типа является модуль Fraclab пакета MatLab.</segment>
		<segment id="60" parent="96" relname="span">Точность расчета критериев зависит от возможности использовать формат исходных данных,</segment>
		<segment id="61" parent="60" relname="elaboration">реализованной в Fraclab для данных различного типа.</segment>
		<segment id="62" parent="97" relname="joint">Пакет позволяет выбрать способ расчета фрактальных характеристик, размер анализируемого фрагмента, количество точек, вид зависимости (линейная, экспоненциальная), тип регрессии,</segment>
		<segment id="63" parent="97" relname="joint">использовать нормализацию данных.</segment>
		<segment id="64" parent="103" relname="span">Расчет размерности по строкам и столбцам матрицы позволяет оценить зависимость результата от методики анализа,</segment>
		<segment id="65" parent="64" relname="elaboration">в частности в ряде случаев избежать трудностей, связанных с выбором точки отсчета, размеров, ориентации исходных изображений.</segment>
		<segment id="66" parent="121" relname="same-unit">Для фрактального анализа магнитно-резонансных томограмм головного мозга,</segment>
		<segment id="67" parent="68" relname="condition">полученных в различных условиях для здоровых добровольцев,</segment>
		<segment id="68" parent="120" relname="span">выявлено,</segment>
		<segment id="69" parent="122" relname="span">что требуемая точность достигается для изображений с матрицей более 256x256 при выборе не менее 40 ячеек и регресси по методу наименьших квадратов.</segment>
		<segment id="70" parent="99" relname="span">На графике рассчитанной оценки задается участок линейного изменения (постоянное приращение), для которого рассчитывается размерность.</segment>
		<segment id="71" parent="101" relname="comparison">В этом случае результат расчета фрактальной размерности слабо зависит от шума изображений,</segment>
		<segment id="72" parent="101" relname="comparison">в то время как использование вейвлет-фильтров снижает чувствительность метода.</segment>
		<segment id="73" parent="74" relname="preparation">Список использованной литературы:</segment>
		<segment id="74" >1\. Ананьева Н.И., Ежова Р.В. и др. Гиппокамп: лучевая анатомия, варианты строения // Лучевая диагностика и терапия. 2015. № 1(6). С. 39-44. 2\. Бортников А.Ю., Минакова Н.Н. Текстурно-фрактальный анализ микроскопических срезов образцов композиционных материалов, наполненных техническим углеродом // Известия ТПУ. 2006. Т. 309 (6). С. 64-67. 3\. Виноградова А.А., Казначеева А.О., Мусалимов В.М. Фрактальный анализ томограмм головного мозга // Известия высших учебных заведений. Приборостроение. 2013. Т. 56. № 12. С. 14-19. 4\. Головко А.А., Салахутдинова И.И., Хлыстова А.И. Фрактальные свойства активной области и вспышки // Солнечно-земная физика. 2006. №9. С. 47-55. 5\. Казначеева А.О. Обеспечение качества исследований в магнитно-резонансной томографии // Альманах современной науки и образования. 2015. №5 (95). С. 78-82. 6\. Казначеева А.О. Разработка методов и средств шумоподавления в томографии : автореф. дисс. ... канд. техн. наук. СПб., 2006. 19 с. 7\. Казначеева А.О. Фрактальный анализ зашумленности магнитно-резонансных томограмм // Альманах современной науки и образования. 2013. №2 (69). С. 73-76. 8\. Какунина А.С. Оценка качества томограмм при отсутствии эталона // Альманах современной науки и образования. 2014. №10 (88). С. 74-76. 9\. Потапов А.А. Фракталы, скейлинг и дробные операторы в физике и радиотехнике // РЭНСИТ. 2009. № 12. С. 64-107. 10\. Рудакова О.А. Фрактальный подход к анализу усталостного разрушения сварных швов // Вестник ПНИПУ. 2012. Т. 14. №4. С. 102-107. 11\. Трофимова Т.Н., Медведев Ю.А., Ананьева Н.И. и др. Использование посмертной магнитно-резонансной томографии головного мозга при патолого- анатомическом исследовании // Архив патологии. 2008. Т. 70. № 3. С. 23-28. 12.\ Чубинский А.Н., Тамби А.А., Теппоев А.В. и др. Физические неразрушающие методы испытания и оценка структуры древесных материалов // Дефектоскопия. 2014. №11. С. 76-84. © А С. Какунина, У.С. Мазурова, 2015 УДК 621.753.2 Леонов Олег Альбертович д.т.н., профессор РГАУ - МСХА имени К.А. Тимирязева, г. Москва, РФ E-mail: oaleonov@nm.ru</segment>
		<group id="75" type="span" parent="3" relname="attribution"/>
		<group id="76" type="span" parent="83" relname="preparation"/>
		<group id="77" type="span" parent="8" relname="evidence"/>
		<group id="78" type="span" parent="124" relname="span"/>
		<group id="79" type="span" parent="80" relname="same-unit"/>
		<group id="80" type="multinuc" parent="81" relname="joint"/>
		<group id="81" type="multinuc" parent="82" relname="span"/>
		<group id="82" type="span" parent="83" relname="span"/>
		<group id="83" type="span" />
		<group id="84" type="multinuc" parent="85" relname="span"/>
		<group id="85" type="span" parent="86" relname="span"/>
		<group id="86" type="span" parent="108" relname="span"/>
		<group id="87" type="multinuc" parent="28" relname="elaboration"/>
		<group id="88" type="span" parent="89" relname="span"/>
		<group id="89" type="span" parent="91" relname="joint"/>
		<group id="90" type="multinuc" parent="112" relname="preparation"/>
		<group id="91" type="multinuc" parent="112" relname="span"/>
		<group id="92" type="span" parent="129" relname="elaboration"/>
		<group id="93" type="span" parent="128" relname="evaluation"/>
		<group id="94" type="span" parent="136" relname="preparation"/>
		<group id="95" type="span" parent="138" relname="span"/>
		<group id="96" type="span" parent="98" relname="joint"/>
		<group id="97" type="multinuc" parent="104" relname="span"/>
		<group id="98" type="multinuc" parent="117" relname="span"/>
		<group id="99" type="span" parent="122" relname="elaboration"/>
		<group id="100" type="span" parent="81" relname="joint"/>
		<group id="101" type="multinuc" parent="70" relname="elaboration"/>
		<group id="102" type="span" parent="95" relname="elaboration"/>
		<group id="103" type="span" parent="104" relname="purpose"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" parent="98" relname="joint"/>
		<group id="106" type="span" parent="111" relname="preparation"/>
		<group id="107" type="multinuc" parent="111" relname="span"/>
		<group id="108" type="span" parent="109" relname="span"/>
		<group id="109" type="span" />
		<group id="110" type="span" parent="108" relname="preparation"/>
		<group id="111" type="span" parent="110" relname="span"/>
		<group id="112" type="span" parent="113" relname="span"/>
		<group id="113" type="span" />
		<group id="114" type="span" parent="46" relname="elaboration"/>
		<group id="115" type="span" parent="138" relname="preparation"/>
		<group id="116" type="span" parent="52" relname="purpose"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" />
		<group id="119" type="span" parent="134" relname="joint"/>
		<group id="120" type="span" parent="121" relname="same-unit"/>
		<group id="121" type="multinuc" parent="69" relname="evidence"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" />
		<group id="124" type="span" parent="82" relname="preparation"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="91" relname="joint"/>
		<group id="127" type="span" parent="93" relname="span"/>
		<group id="128" type="span" parent="129" relname="span"/>
		<group id="129" type="span" parent="130" relname="span"/>
		<group id="130" type="span" />
		<group id="131" type="multinuc" parent="132" relname="span"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" parent="42" relname="elaboration"/>
		<group id="134" type="multinuc" parent="135" relname="elaboration"/>
		<group id="135" type="span" parent="136" relname="span"/>
		<group id="136" type="span" parent="137" relname="span"/>
		<group id="137" type="span" />
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" />
	</body>
</rst>