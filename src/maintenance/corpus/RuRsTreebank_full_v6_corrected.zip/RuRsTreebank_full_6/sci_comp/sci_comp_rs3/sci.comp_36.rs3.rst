<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="145" relname="span">﻿ ОЦЕНИВАНИЕ ЭФФЕКТИВНОСТИ ФУНКЦИОНИРОВАНИЯ ИНФОРМАЦИОННОЙ СИСТЕМЫ В УСЛОВИЯХ ТЕХНОГЕННОГО РИСКА</segment>
		<segment id="2" parent="254" relname="span">И. Ю. Парамонов, В. А. Смагин, В. Н. Харин</segment>
		<segment id="3" parent="2" relname="elaboration">Военно-космическая академия им. А. Ф. Можайского, 197198, Санкт-Петербург, Россия E-mail: ivan_paramonov@mail.ru</segment>
		<segment id="4" >Исследуется простейшая восстанавливаемая информационная система и оценивается эффективность ее функционирования в условиях техногенного риска. Ключевые слова: информационная система, эффективность, риск, вероятность, процесс восстановления, количество информационной работы, стационарная информационная рентабельность.</segment>
		<segment id="5" parent="152" relname="preparation">Введение.</segment>
		<segment id="6" parent="146" relname="span">В научно-технической литературе рассматриваются различные модели информационных систем,</segment>
		<segment id="7" parent="6" relname="elaboration">при построении которых учитывается фактор риска [1, 2].</segment>
		<segment id="8" parent="149" relname="joint">Так, в монографии [1] представлен логико-вероятностный метод исследования таких систем.</segment>
		<segment id="9" parent="151" relname="span">Метод оценивания качества систем с использованием показателя эффективности функционирования и показателя риска с привлечением различных методов оптимизации предложен в работе [3],</segment>
		<segment id="10" parent="150" relname="span">где целевая функция системы определена как функция от двух указанных показателей;</segment>
		<segment id="11" parent="10" relname="condition">при этом необходимо, чтобы показатель риска был аргументом эффективности функционирования наряду с другими первичными показателями качества.</segment>
		<segment id="12" parent="271" relname="preparation">Постановка задачи.</segment>
		<segment id="13" parent="255" relname="span">Структура системы,</segment>
		<segment id="14" parent="13" relname="purpose">предназначенной для сбора и обработки информации,</segment>
		<segment id="15" parent="147" relname="restatement">неизбыточная,</segment>
		<segment id="16" parent="147" relname="restatement">т.е. не содержит резервных элементов.</segment>
		<segment id="17" parent="154" relname="sequence">В случае технического отказа система мгновенно начинает восстанавливаться в течение случайного времени,</segment>
		<segment id="18" parent="154" relname="sequence">после чего вновь продолжает функционировать с заданным качеством.</segment>
		<segment id="19" parent="160" relname="joint">Заданы функции распределения времени работы системы до ее отказа (A(t)) и времени восстановления (G(t)).</segment>
		<segment id="20" parent="158" relname="span">Граф состояний системы показан на рис. 1,</segment>
		<segment id="21" parent="157" relname="joint">где a(t) — плотность распределения вероятности времени работы системы до отказа,</segment>
		<segment id="22" parent="157" relname="joint">g(t) — плотность вероятности времени восстановления.</segment>
		<segment id="23" parent="158" relname="elaboration">[Рисунок 1].</segment>
		<segment id="24" parent="161" relname="span">В исправном состоянии "0" система выполняет информационную работу с производительностью I/0 операций/ч,</segment>
		<segment id="25" parent="24" relname="condition">если внешнее воздействие отсутствует.</segment>
		<segment id="26" parent="162" relname="sequence">В состоянии восстановления „l“ количество выполненной работы расходуется с производительностью I/1 операций/ч.</segment>
		<segment id="27" parent="162" relname="sequence">После восстановления системы процесс повторяется.</segment>
		<segment id="28" parent="249" relname="purpose">Требуется определить количество выполненной информационной работы в зависимости от времени функционирования системы.</segment>
		<segment id="29" parent="256" relname="preparation">Общее решение.</segment>
		<segment id="30" parent="164" relname="sequence">Рассмотрим процесс функционирования системы, представленный в виде последовательных циклов „работа — восстановление“.</segment>
		<segment id="31" parent="164" relname="sequence">Определим количество выполненной информационной работы и количество „потерянной“ работы в каждом цикле.</segment>
		<segment id="32" parent="174" relname="preparation">Первый цикл.</segment>
		<segment id="33" parent="168" relname="span">Количество выполненной информационной работы определяется выражением</segment>
		<segment id="34" parent="167" relname="span">WY(t) = I/0 P(t), (1),</segment>
		<segment id="35" parent="34" relname="elaboration">где P(t) = 1 - A(t) — вероятность нахождения системы в работоспособном состоянии „0“ в течение времени t;</segment>
		<segment id="36" parent="165" relname="span">количество „потерянной“ информационной работы определяется выражением</segment>
		<segment id="37" parent="166" relname="span">[формула], (2),</segment>
		<segment id="38" parent="37" relname="elaboration">где a(z) = a(t), g(u) = g(t).</segment>
		<segment id="39" parent="172" relname="span">Для краткости представим выражения (1) и (2), используя преобразование Лапласа (s):</segment>
		<segment id="40" parent="169" relname="joint">[формула],</segment>
		<segment id="41" parent="169" relname="joint">[ формула],</segment>
		<segment id="42" parent="170" relname="elaboration">здесь „штрих“ означает производную от функции по s.</segment>
		<segment id="43" parent="180" relname="preparation">Второй цикл.</segment>
		<segment id="44" parent="176" relname="joint">В этом цикле [формула] (3),</segment>
		<segment id="45" parent="176" relname="joint">[формула] (4).</segment>
		<segment id="46" parent="178" relname="span">В преобразовании Лапласа формулы (3) и (4) принимают вид</segment>
		<segment id="47" parent="177" relname="joint">[формула],</segment>
		<segment id="48" parent="177" relname="joint">[формула].</segment>
		<segment id="49" parent="183" relname="preparation">Третий цикл.</segment>
		<segment id="50" parent="183" relname="span">По аналогии со вторым циклом получим:</segment>
		<segment id="51" parent="182" relname="joint">[формула],</segment>
		<segment id="52" parent="182" relname="joint">[формула].</segment>
		<segment id="53" parent="274" relname="joint">Аналогично можно получить преобразования Лапласа для величин W(t) и Q(t) в любых циклах процесса.</segment>
		<segment id="54" parent="251" relname="sequence">Суммируя преобразования раздельно по всем циклам,</segment>
		<segment id="55" parent="252" relname="span">окончательно получаем:</segment>
		<segment id="56" parent="184" relname="joint">[формула] (5),</segment>
		<segment id="57" parent="184" relname="joint">[формула] (6).</segment>
		<segment id="58" parent="190" relname="preparation">Пример.</segment>
		<segment id="59" parent="190" relname="span">Для параметров системы заданы следующие значения:</segment>
		<segment id="60" parent="186" relname="joint">I/0 = 10 операций/ч,</segment>
		<segment id="61" parent="186" relname="joint">I/1 = 3 операций/ч,</segment>
		<segment id="62" parent="186" relname="joint">л = 0,01 ч^-1,</segment>
		<segment id="63" parent="186" relname="joint">м = 0,1 ч^-1,</segment>
		<segment id="64" parent="186" relname="joint">a(t) = лe^-лt,</segment>
		<segment id="65" parent="186" relname="joint">g(t) = мe^-мt,</segment>
		<segment id="66" parent="186" relname="joint">P(t) = e^л-t,</segment>
		<segment id="67" parent="187" relname="elaboration">где л и м — интенсивность отказа и восстановления системы соответственно.</segment>
		<segment id="68" parent="193" relname="span">С учетом заданных значений согласно формулам (1) и (2) построены графические зависимости Wi(t), Qi(t):</segment>
		<segment id="69" parent="189" relname="span">см. рис. 2 — кривые 1 и 2 соответственно.</segment>
		<segment id="70" parent="69" relname="elaboration">[Рисунок 2]</segment>
		<segment id="71" parent="192" relname="span">Далее по формулам (3) и (4) построены зависимости Wii(t) и Qii(t:</segment>
		<segment id="72" parent="191" relname="span">см. рис. 3 — кривые 1 и 2 соответственно.</segment>
		<segment id="73" parent="72" relname="elaboration">[Рисунок 3]</segment>
		<segment id="74" parent="196" relname="span">Сравнительный анализ графиков (см. рис. 2, 3) показывает, что с увеличением номера цикла количество „эффективной“ информационной работы уменьшается.</segment>
		<segment id="75" parent="215" relname="preparation">Оценивание эффективности системы в стационарном состоянии.</segment>
		<segment id="76" parent="204" relname="span">На основе предельной теоремы тауберова типа для экспоненциальных распределений получим</segment>
		<segment id="77" parent="197" relname="restatement">[формула] (7),</segment>
		<segment id="78" parent="199" relname="span">что эквивалентно IoTK ,</segment>
		<segment id="79" parent="198" relname="joint">где [формула] — среднее время безотказной работы системы,</segment>
		<segment id="80" parent="198" relname="joint">K — коэффициент готовности системы;</segment>
		<segment id="81" parent="201" relname="span">[формула],</segment>
		<segment id="82" parent="81" relname="condition">если м^2 + лм /= 0,</segment>
		<segment id="83" parent="200" relname="span">[формула],</segment>
		<segment id="84" parent="83" relname="condition">если м^2 + лм = 0 (8).</segment>
		<segment id="85" parent="209" relname="span">Первая строка в выражении (8) эквивалентна</segment>
		<segment id="86" parent="208" relname="span">[формула],</segment>
		<segment id="87" parent="207" relname="joint">где Тв — среднее время восстановления системы,</segment>
		<segment id="88" parent="207" relname="joint">а (1 - K) — коэффициент простоя системы.</segment>
		<segment id="89" parent="90" relname="cause">Вычисление предельных соотношений вида (7) и (8) при неэкспоненциальных законах распределения более сложно,</segment>
		<segment id="90" parent="210" relname="span">поэтому примем полученные формулы в качестве приближенных для любых распределений вероятностей.</segment>
		<segment id="91" parent="211" relname="span">На основе предельных стационарных оценок (7), (8) можно оценить и так называемую „предельную стационарную рентабельность" информационной системы путем вычисления отношения „эффективной“ информационной работы к количеству выполненной за весь период функционирования системы:</segment>
		<segment id="92" parent="264" relname="span">[формула] (9).</segment>
		<segment id="93" parent="213" relname="joint">Подставив численные значения параметров, принятые в примере,</segment>
		<segment id="94" parent="212" relname="joint">и учитывая, что K = T / (T + Тв) = 0,9,</segment>
		<segment id="95" parent="212" relname="joint">IоTK = 900 операций,</segment>
		<segment id="96" parent="212" relname="joint">(IоT + I/1Тв )К - 11Тв = 0,897 операций,</segment>
		<segment id="97" parent="214" relname="span">получим: С = 0,997.</segment>
		<segment id="98" parent="265" relname="preparation">Оценивание эффективности системы с учетом риска.</segment>
		<segment id="99" parent="100" relname="cause">Влияние внешних воздействий на работу системы может привести</segment>
		<segment id="100" parent="276" relname="span">к снижению показателя ее информационной эффективности.</segment>
		<segment id="101" parent="247" relname="span">Положим, что негативные факторы оказывают влияние на систему,</segment>
		<segment id="102" parent="101" relname="condition">только когда она находится в работоспособном состоянии.</segment>
		<segment id="103" parent="217" relname="joint">Пусть злоумышленник многократно воздействует на систему в процессе ее функционирования.</segment>
		<segment id="104" parent="217" relname="joint">Предположим, что он обладает информацией о начальных моментах и продолжительности „продуктивной работы системы.</segment>
		<segment id="105" parent="218" relname="span">Рассмотрим первый цикл функционирования системы.</segment>
		<segment id="106" parent="219" relname="restatement">Примем, что момент начала цикла и момент внешнего воздействия на систему совпадают,</segment>
		<segment id="107" parent="219" relname="restatement">т. е. оба процесса синхронизированы.</segment>
		<segment id="108" parent="220" relname="sequence">Обозначим через R(t) вероятность недостижения цели злоумышленником.</segment>
		<segment id="109" parent="221" relname="span">Тогда выражение (1) преобразуется к виду</segment>
		<segment id="110" parent="109" relname="elaboration">Wi(t) = lotP(t)R(t) (10).</segment>
		<segment id="111" parent="223" relname="span">В качестве примера рассмотрим случай,</segment>
		<segment id="112" parent="111" relname="condition">когда R(t) = R = const.</segment>
		<segment id="113" parent="224" relname="span">Для первого и второго циклов выражения (1) и (3) примут следующий вид:</segment>
		<segment id="114" parent="113" relname="elaboration">[формула].</segment>
		<segment id="115" parent="226" relname="span">На рис. 4 представлен график, построенный в соответствии выражением (10)</segment>
		<segment id="116" parent="225" relname="joint">для стационарного случая при R = 1</segment>
		<segment id="117" parent="225" relname="joint">и R = 0,5 (кривые 1 и 2 соответственно).</segment>
		<segment id="118" parent="226" relname="elaboration">[Рисунок 4]</segment>
		<segment id="119" parent="232" relname="joint">Для стационарного случая при произвольных зависимостях P(t) и R(t) необходимо выполнить достаточно сложные вычисления.</segment>
		<segment id="120" parent="232" relname="joint">Приведем здесь алгоритм вычислений лишь в схематическом виде.</segment>
		<segment id="121" parent="229" relname="sequence">В начале следует произвести преобразование Лапласа произведения P(t).R(t) по формуле [формула].</segment>
		<segment id="122" parent="229" relname="sequence">Затем необходимо использовать оператор [формула]</segment>
		<segment id="123" parent="229" relname="sequence">и полученный результат умножить на величину Iо.</segment>
		<segment id="124" parent="229" relname="sequence">Далее следует воспользоваться выражениями (5) и (6) для нахождения стационарных значений W и Q при s -&gt; 0 по формулам (7) и (8).</segment>
		<segment id="125" parent="229" relname="sequence">И лишь после этого можно вывести выражение, аналогичное формуле (9), для определения „предельной стационарной рентабельности" системы.</segment>
		<segment id="126" parent="239" relname="preparation">Оценивание эффективности функционирования информационной системы.</segment>
		<segment id="127" parent="238" relname="preparation">Замечание.</segment>
		<segment id="128" parent="234" relname="span">В статье исследуется такая характеристика восстанавливаемой системы, как количество информационной работой,</segment>
		<segment id="129" parent="128" relname="condition">при этом не учитывается, что „стареющие“ системы не являются полностью восстанавливаемыми, контроль за возможными состояниями не является идеальным и т.д.</segment>
		<segment id="130" parent="235" relname="span">Интерес к данной тематике вызван тем,</segment>
		<segment id="131" parent="236" relname="contrast">что современные сетецентрические системы состоят из восстанавливаемых информационных элементов, связанных друг с другом и обладающих возможностью выполнять информационную работу даже при снижении пропускной способности.</segment>
		<segment id="132" parent="236" relname="contrast">Однако взаимная связь элементов в таких системах позволяет достаточно долго сохранять их устойчивость.</segment>
		<segment id="133" parent="244" relname="preparation">Заключение.</segment>
		<segment id="134" parent="240" relname="span">Рассмотрена простейшая восстанавливаемая информационная система,</segment>
		<segment id="135" parent="134" relname="elaboration">имеющая два состояния — исправное и неисправное — при произвольных распределениях времени в обоих состояниях.</segment>
		<segment id="136" parent="241" relname="joint">Контроль состояний идеальный,</segment>
		<segment id="137" parent="241" relname="joint">восстановление системы полное.</segment>
		<segment id="138" parent="243" relname="joint">Особенность данного исследования заключается в том, что при заданных пропускных способностях узлов системы определяется количество информационной работы, выполненной в одном состоянии и израсходованной в другом.</segment>
		<segment id="139" parent="253" relname="span">Введен показатель „предельной стационарной рентабельности системы",</segment>
		<segment id="140" parent="139" relname="purpose">позволяющий оценить ее эффективность при изменении основных параметров.</segment>
		<segment id="141" parent="242" relname="joint">Предложена модель функционирования информационной системы с учетом техногенного риска</segment>
		<segment id="142" parent="242" relname="joint">и оценены показатели ее эффективности в этих условиях.</segment>
		<segment id="143" parent="144" relname="preparation">СПИСОК ЛИТЕРАТУРЫ</segment>
		<segment id="144" >1\. Соложенцев Е. Д. Сценарное логико-вероятностное управление риском в бизнесе и технике. СПб: Изд. дом „Бизнес-пресса“, 2006. 530 с. 2\. Половко А. М., Гуров С. В. Основы теории надежности. СПб: „БХВ-Петербург“, 2006. 704 с. 3\. Горелик В. А., Золотова Т. В. Общий подход к моделированию процедур управления риском и его применение к стохастическим и иерархическим системам // Управление большими системами. 2012. Вып. 37. С. 5—24. Сведения об авторах Иван Юрьевич Парамонов — канд. техн. наук, докторант; ВКА им. А. Ф. Можайского, кафедра метро логического обеспечения; E-mail: ivan_paramonov@mail.ru  Владимир Александрович Смагин — д-р техн. наук, профессор; ВКА им. А. Ф. Можайского, кафедра метрологического обеспечения; E-mail: va_smagin@mail.ru Виталий Николаевич Харин — канд. техн. наук, доцент; ВКА им. А. Ф. Можайского, кафедра метрологического обеспечения; E-mail: vitaliy76@inbox.ru Рекомендована кафедрой метрологического обеспечения Поступила в редакцию 01.04.14 г. Ссылка для цитирования: Парамонов И. Ю., Смагин В. А., Харин В. Н. Оценивание эффективности функционирования информационной системы в условиях техногенного риска // Изв. вузов. Приборостроение. 2015. Т. 58, № 3. С. 167—172. ASSESSING THE OPERATION EFFICIENCY OF INFORMATION SYSTEM UNDER TECHNOGENIC RISK CONDITIONS I. Yu. Paramonov, V. A. Smagin, V. N. Kharin A. F. Mozhaysky Military Space Academy, 197198, Saint Petersburg, Russia E-mail: ivan_paramonov@mail.ru A simple restorable information system is studied; operation efficiency of the system under technogenic risk conditions is estimated. Keywords: information system, efficiency, risk, probability, restoration process, information work quantity, stationary information profitability. Paramonov Data on authors — PhD, Doctoral Cand.; A. F. Mozhaysky Military Space Academy, Department of Metrological Support; E-mail: ivan_paramonov@mail.ru Vladimir A. Smagin — Dr. Sci., Professor; A. F. Mozhaysky Military Space Academy, Department of Metrological Support; E-mail: va_smagin@mail.ru Vitaly N. Kharin — PhD, Assosiate Professor; A. F. Mozhaysky Military Space Academy, Department of Metrological Support; Head of the Department; E-mail: vitaliy76@inbox.ru Reference for citation: Paramonov I. Yu., Smagin V. A., Kharin V. N. Assessing the operation efficiency of information system under technogenic risk conditions // Izvestiya Vysshikh Uchebnykh Zavedeniy. Pri-borostroenie. 2015. Vol. 58, N 3. P. 167—172.</segment>
		<group id="145" type="span" parent="153" relname="preparation"/>
		<group id="146" type="span" parent="270" relname="preparation"/>
		<group id="147" type="multinuc" parent="148" relname="same-unit"/>
		<group id="148" type="multinuc" parent="155" relname="span"/>
		<group id="149" type="multinuc" parent="270" relname="span"/>
		<group id="150" type="span" parent="9" relname="elaboration"/>
		<group id="151" type="span" parent="149" relname="joint"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" />
		<group id="154" type="multinuc" parent="155" relname="elaboration"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="271" relname="span"/>
		<group id="157" type="multinuc" parent="20" relname="elaboration"/>
		<group id="158" type="span" parent="159" relname="span"/>
		<group id="159" type="span" parent="160" relname="joint"/>
		<group id="160" type="multinuc" parent="156" relname="elaboration"/>
		<group id="161" type="span" parent="163" relname="joint"/>
		<group id="162" type="multinuc" parent="163" relname="joint"/>
		<group id="163" type="multinuc" parent="249" relname="span"/>
		<group id="164" type="multinuc" parent="256" relname="span"/>
		<group id="165" type="span" parent="173" relname="joint"/>
		<group id="166" type="span" parent="36" relname="elaboration"/>
		<group id="167" type="span" parent="33" relname="elaboration"/>
		<group id="168" type="span" parent="173" relname="joint"/>
		<group id="169" type="multinuc" parent="170" relname="span"/>
		<group id="170" type="span" parent="171" relname="span"/>
		<group id="171" type="span" parent="39" relname="elaboration"/>
		<group id="172" type="span" parent="173" relname="joint"/>
		<group id="173" type="multinuc" parent="174" relname="span"/>
		<group id="174" type="span" parent="175" relname="span"/>
		<group id="175" type="span" parent="185" relname="sequence"/>
		<group id="176" type="multinuc" parent="179" relname="joint"/>
		<group id="177" type="multinuc" parent="46" relname="elaboration"/>
		<group id="178" type="span" parent="179" relname="joint"/>
		<group id="179" type="multinuc" parent="180" relname="span"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="185" relname="sequence"/>
		<group id="182" type="multinuc" parent="50" relname="elaboration"/>
		<group id="183" type="span" parent="273" relname="span"/>
		<group id="184" type="multinuc" parent="55" relname="elaboration"/>
		<group id="185" type="multinuc" parent="195" relname="span"/>
		<group id="186" type="multinuc" parent="187" relname="span"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" parent="59" relname="elaboration"/>
		<group id="189" type="span" parent="68" relname="elaboration"/>
		<group id="190" type="span" parent="260" relname="span"/>
		<group id="191" type="span" parent="71" relname="elaboration"/>
		<group id="192" type="span" parent="194" relname="sequence"/>
		<group id="193" type="span" parent="194" relname="sequence"/>
		<group id="194" type="multinuc" parent="74" relname="evidence"/>
		<group id="195" type="span" parent="245" relname="span"/>
		<group id="196" type="span" parent="259" relname="span"/>
		<group id="197" type="multinuc" parent="203" relname="joint"/>
		<group id="198" type="multinuc" parent="78" relname="elaboration"/>
		<group id="199" type="span" parent="197" relname="restatement"/>
		<group id="200" type="span" parent="202" relname="joint"/>
		<group id="201" type="span" parent="202" relname="joint"/>
		<group id="202" type="multinuc" parent="203" relname="joint"/>
		<group id="203" type="multinuc" parent="76" relname="elaboration"/>
		<group id="204" type="span" parent="275" relname="span"/>
		<group id="205" type="span" parent="206" relname="joint"/>
		<group id="206" type="multinuc" parent="215" relname="span"/>
		<group id="207" type="multinuc" parent="86" relname="elaboration"/>
		<group id="208" type="span" parent="85" relname="elaboration"/>
		<group id="209" type="span" parent="275" relname="elaboration"/>
		<group id="210" type="span" parent="262" relname="evidence"/>
		<group id="211" type="span" parent="262" relname="span"/>
		<group id="212" type="multinuc" parent="213" relname="joint"/>
		<group id="213" type="multinuc" parent="97" relname="condition"/>
		<group id="214" type="span" parent="92" relname="elaboration"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" />
		<group id="217" type="multinuc" parent="105" relname="condition"/>
		<group id="218" type="span" parent="220" relname="sequence"/>
		<group id="219" type="multinuc" parent="220" relname="sequence"/>
		<group id="220" type="multinuc" parent="221" relname="condition"/>
		<group id="221" type="span" parent="222" relname="span"/>
		<group id="222" type="span" parent="265" relname="span"/>
		<group id="223" type="span" parent="228" relname="joint"/>
		<group id="224" type="span" parent="228" relname="joint"/>
		<group id="225" type="multinuc" parent="115" relname="elaboration"/>
		<group id="226" type="span" parent="227" relname="span"/>
		<group id="227" type="span" parent="228" relname="joint"/>
		<group id="228" type="multinuc" parent="233" relname="comparison"/>
		<group id="229" type="multinuc" parent="230" relname="span"/>
		<group id="230" type="span" parent="231" relname="span"/>
		<group id="231" type="span" parent="233" relname="comparison"/>
		<group id="232" type="multinuc" parent="230" relname="preparation"/>
		<group id="233" type="multinuc" parent="222" relname="elaboration"/>
		<group id="234" type="span" parent="237" relname="joint"/>
		<group id="235" type="span" parent="237" relname="joint"/>
		<group id="236" type="multinuc" parent="130" relname="cause"/>
		<group id="237" type="multinuc" parent="238" relname="span"/>
		<group id="238" type="span" parent="239" relname="span"/>
		<group id="239" type="span" parent="246" relname="span"/>
		<group id="240" type="span" parent="269" relname="joint"/>
		<group id="241" type="multinuc" parent="269" relname="joint"/>
		<group id="242" type="multinuc" parent="243" relname="joint"/>
		<group id="243" type="multinuc" parent="268" relname="span"/>
		<group id="244" type="span" parent="267" relname="span"/>
		<group id="245" type="span" parent="258" relname="span"/>
		<group id="246" type="span" />
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" parent="217" relname="joint"/>
		<group id="249" type="span" parent="250" relname="span"/>
		<group id="250" type="span" />
		<group id="251" type="multinuc" parent="274" relname="joint"/>
		<group id="252" type="span" parent="251" relname="sequence"/>
		<group id="253" type="span" parent="243" relname="joint"/>
		<group id="254" type="span" parent="1" relname="attribution"/>
		<group id="255" type="span" parent="148" relname="same-unit"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" parent="245" relname="preparation"/>
		<group id="258" type="span" />
		<group id="259" type="span" parent="261" relname="span"/>
		<group id="260" type="span" parent="259" relname="preparation"/>
		<group id="261" type="span" />
		<group id="262" type="span" parent="263" relname="span"/>
		<group id="263" type="span" parent="206" relname="joint"/>
		<group id="264" type="span" parent="91" relname="elaboration"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" />
		<group id="267" type="span" />
		<group id="268" type="span" parent="244" relname="span"/>
		<group id="269" type="multinuc" parent="268" relname="preparation"/>
		<group id="270" type="span" parent="152" relname="span"/>
		<group id="271" type="span" parent="272" relname="span"/>
		<group id="272" type="span" />
		<group id="273" type="span" parent="185" relname="sequence"/>
		<group id="274" type="multinuc" parent="185" relname="sequence"/>
		<group id="275" type="span" parent="205" relname="span"/>
		<group id="276" type="span" parent="247" relname="preparation"/>
	</body>
</rst>