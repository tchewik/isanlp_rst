<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >МЕТОДЫ И АЛГОРИТМЫ РАЗРАБОТКИ АВТОМАТИЗИРОВАННОГО РАБОЧЕГО МЕСТА ПРОЕКТИРОВЩИКА ТЕХНОЛОГИЧЕСКИХ СИСТЕМ</segment>
		<segment id="2" >А.С. Федотов</segment>
		<segment id="3" >Научный руководитель - д.т.н., профессор Ю.А. Гатчин</segment>
		<segment id="4" >В статье рассказывается о методах и алгоритмах позволяющих</segment>
		<segment id="5" >разработать автоматизированное рабочее место проектировщика технологических систем.</segment>
		<segment id="6" >Приводится комплекс необходимых программных продуктов, их анализ и качество работы.</segment>
		<segment id="7" parent="207" relname="preparation">Введение</segment>
		<segment id="8" parent="9" relname="cause">Современные технологические системы отличает большое многообразие компонентов и элементов,</segment>
		<segment id="9" parent="204" relname="span">что увеличивает время проектирования,</segment>
		<segment id="10" parent="205" relname="span">а как следствие - и их стоимость.</segment>
		<segment id="11" parent="205" relname="evaluation">Темпы проектирования таких систем являются основным сдерживающим фактором их разработки и внедрения.</segment>
		<segment id="12" parent="403" relname="span">Решение этой задачи приводит к необходимости создания системы автоматизированного проектирования.</segment>
		<segment id="13" parent="403" relname="solutionhood">Автоматизирование проектирования технологических систем предполагает разработку специализированных технических средств, обеспечивающих ввод и вывод информации, разработку автоматизированных рабочих мест проектировщика, содержащих комплексы оборудования, а также разработку математического обеспечения: методов, алгоритмов и программ.</segment>
		<segment id="14" parent="209" relname="joint">Традиционные методы проектирования технологических систем имеют низкую степень формализации</segment>
		<segment id="15" parent="209" relname="joint">и в основном ориентированы на принятие решений проектировщиком,</segment>
		<segment id="16" parent="211" relname="joint">они включают большой объем вычислительных операций,</segment>
		<segment id="17" parent="215" relname="span">характеризуются низкой точностью,</segment>
		<segment id="18" parent="17" relname="cause">так как очень часто автоматизированное рабочее место проектировщика организовано не на должном уровне.</segment>
		<segment id="19" parent="216" relname="span">Все это ограничивает их применение.</segment>
		<segment id="20" parent="217" relname="span">В связи с этим совершенствование традиционных методов, разработка новых методов зачастую неэффективно.</segment>
		<segment id="21" parent="221" relname="preparation">В последние годы появилось много новых методов и программ для проектирования технологических систем.</segment>
		<segment id="22" parent="218" relname="joint">Эти методы отличаются от классических более высокой сложностью,</segment>
		<segment id="23" parent="218" relname="joint">они формализованы,</segment>
		<segment id="24" parent="218" relname="joint">их исполнение связано с большим объемом вычислений,</segment>
		<segment id="25" parent="389" relname="span">что делает полезным</segment>
		<segment id="26" parent="389" relname="condition">при решении практических задач</segment>
		<segment id="27" parent="388" relname="same-unit">наличие в них библиотеки стандартных подпрограмм.</segment>
		<segment id="28" parent="391" relname="span">Однако даже наличие таких библиотек требует от проектировщика значительных усилий в программировании</segment>
		<segment id="29" parent="28" relname="purpose">для решения конкретной задачи.</segment>
		<segment id="30" parent="227" relname="span">Высококачественная, хорошо отлаженная программа, написанная программистом высокой квалификации специально для некоторого проекта, наиболее оптимальна.</segment>
		<segment id="31" parent="225" relname="joint">Развитие технологических систем на таком высоком уровне требует нового подхода к методам и алгоритмам разработки автоматизированных рабочих мест проектировщика,</segment>
		<segment id="32" parent="225" relname="joint">способствует использования последних новинок в области программных продуктов для разработки автоматизированных рабочих мест.</segment>
		<segment id="33" parent="232" relname="preparation">Структура и назначение автоматизированного рабочего места</segment>
		<segment id="34" parent="229" relname="span">Автоматизированное рабочее место (АРМ) (рис. 1) - индивидуальный комплекс аппаратных и программных средств,</segment>
		<segment id="35" parent="34" relname="purpose">предназначенный для автоматизации профессионального труда специалиста - картографа, проектировщика электронных схем, оператора системы дальнего радиолокационного обнаружения и пр.</segment>
		<segment id="36" parent="230" relname="joint">Обычно в АРМ входит персональный компьютер или рабочая станция с графическим или текстовым дисплеем, графопостроитель и другие периферийные устройства.</segment>
		<segment id="37" parent="230" relname="joint">АРМ работает в составе локальной или территориальной сети или в автономном режиме [1].</segment>
		<segment id="38" parent="34" relname="elaboration">[Рис. 1. Схема автоматизированного рабочего места]</segment>
		<segment id="39" parent="40" relname="cause">В настоящее время всестороннее развитие технологии приводят к необходимости</segment>
		<segment id="40" parent="392" relname="span">выживания промышленных предприятий в новых экономических условиях, осуществляя глубокую конверсию основного производства.</segment>
		<segment id="41" parent="237" relname="joint">Возникают задачи проектирования все более сложных технических объектов в сжатые сроки, требующие специфического оборудования, новых технологий и программных продуктов, а также увеличения численности проектировщиков.</segment>
		<segment id="42" parent="236" relname="span">Удовлетворить противоречивые требования с помощью простого увеличения численности проектировщиков нельзя,</segment>
		<segment id="43" parent="234" relname="joint">так как возможность параллельного проведения проектных работ ограничена,</segment>
		<segment id="44" parent="234" relname="joint">а численность инженерно- технических работников в проектных организациях не может быть сколько-нибудь заметно увеличена [2].</segment>
		<segment id="45" parent="241" relname="span">Выходом из этого положения является широкое применение методов развития и усовершенствования АРМ.</segment>
		<segment id="46" parent="242" relname="span">Все это приводит нас к автоматизации системы проектирования.</segment>
		<segment id="47" parent="250" relname="span">Автоматизированная система проектирования технологий представляет собой одну из составных частей АРМ технолога-проектировщика,</segment>
		<segment id="48" parent="243" relname="joint">главными элементами которой являются, с одной стороны, проектировщик,</segment>
		<segment id="49" parent="246" relname="restatement">а с другой стороны - система автоматизации проектирования,</segment>
		<segment id="50" parent="247" relname="span">т. е. система,</segment>
		<segment id="51" parent="50" relname="purpose">предназначенная для совершенствования процесса проектирования,</segment>
		<segment id="52" parent="248" relname="same-unit">основанная на взаимодействие технического, алгоритмического, программного и информационного обеспечения.</segment>
		<segment id="53" parent="252" relname="cause">Построение автоматизированной системы проектирования на основе современных информационных технологий и технологий программирования даст возможность</segment>
		<segment id="54" parent="251" relname="joint">расширения программного обеспечения за счет соответствия стандартам построения открытых систем,</segment>
		<segment id="55" parent="251" relname="joint">ведения единой информационной модели для решения технологических задач,</segment>
		<segment id="56" parent="251" relname="joint">интеграции решения задач разного направления,</segment>
		<segment id="57" parent="251" relname="joint">автоматического создания и адаптации математической модели задачи и исходных данных под реальные ситуации,</segment>
		<segment id="58" parent="251" relname="joint">использования графического интерфейса пользователя, упрощающего взаимодействие пользователя с ЭВМ.</segment>
		<segment id="59" parent="256" relname="span">Особый интерес в настоящее время вызывает подход,</segment>
		<segment id="60" parent="254" relname="joint">при котором проектировщик технологических систем в процессе диалога с системой осуществляет творческое конструирование</segment>
		<segment id="61" parent="254" relname="joint">и выбирает наилучшее проектное решение.</segment>
		<segment id="62" parent="258" relname="span">Для этого ему необходимо создать АРМ, полностью удовлетворяющее его критериям.</segment>
		<segment id="63" parent="268" relname="span">АРМ должно отвечать следующим требованиям:</segment>
		<segment id="64" parent="260" relname="joint">• своевременное удовлетворение информационной и вычислительной потребности специалиста;</segment>
		<segment id="65" parent="260" relname="joint">• минимальное время ответа на запросы пользователя;</segment>
		<segment id="66" parent="260" relname="joint">• адаптация к уровню подготовки пользователя и его профессиональным запросам;</segment>
		<segment id="67" parent="261" relname="joint">• простота освоения приемов работы на АРМ</segment>
		<segment id="68" parent="261" relname="joint">и легкость общения,</segment>
		<segment id="69" parent="262" relname="joint">надежность</segment>
		<segment id="70" parent="262" relname="joint">и простота обслуживания;</segment>
		<segment id="71" parent="269" relname="joint">• терпимость по отношению к пользователю;</segment>
		<segment id="72" parent="269" relname="joint">возможность быстрого обучения пользователя;</segment>
		<segment id="73" parent="269" relname="joint">возможность работы в составе вычислительной сети.</segment>
		<segment id="74" parent="281" relname="preparation">Новые возможности в свете последних достижений</segment>
		<segment id="75" parent="280" relname="span">Один из методов облегчения работы проектировщика связан с созданием различных автоматизированных баз данных.</segment>
		<segment id="76" parent="271" relname="span">Специалистам часто приходится работать с большими объемами данных,</segment>
		<segment id="77" parent="76" relname="purpose">чтобы найти требуемые сведения для подготовки различных документов.</segment>
		<segment id="78" parent="79" relname="purpose">Для облегчения такого рода работ</segment>
		<segment id="79" parent="272" relname="span">были созданы системы управления базами данных (СУБД: DBASE, RBASE, ORACLE и др.).</segment>
		<segment id="80" parent="276" relname="joint">СУБД позволяют хранить большие объемы информации,</segment>
		<segment id="81" parent="273" relname="same-unit">и,</segment>
		<segment id="82" parent="83" relname="evaluation">что самое главное,</segment>
		<segment id="83" parent="274" relname="span">быстро находить нужные данные.</segment>
		<segment id="84" parent="278" relname="span">Так, например, при работе с картотекой постоянно нужно перерывать большие архивы данных для поиска нужной информации,</segment>
		<segment id="85" parent="84" relname="condition">особенно если карточки отсортированы не по нужному признаку.</segment>
		<segment id="86" parent="278" relname="evaluation">СУБД справится с этой задачей за считанные секунды [2].</segment>
		<segment id="87" parent="287" relname="span">Методом разработки АРМ проектировщика технологических систем можно считать метод использования различных программных комплексов.</segment>
		<segment id="88" parent="284" relname="span">Программный комплекс LCAD (от Layout CAD - расстановка оборудования с помощью компьютера) предназначен</segment>
		<segment id="89" parent="402" relname="span">для создания АРМ проектировщика, осуществляющего технологическое проектирование новых производственных помещений (рис. 2), а также технологическую реорганизацию существующего производства.</segment>
		<segment id="90" parent="288" relname="span">Комплекс может быть также использован</segment>
		<segment id="91" parent="90" relname="purpose">для получения различной справочной информации по установленному на производстве и введенному в базу данных системы оборудованию.</segment>
		<segment id="92" parent="89" relname="elaboration">[Рис. 2. Проектирование новых производственных помещений]</segment>
		<segment id="93" parent="407" relname="span">Программный комплекс ЬСАБ позволяет автоматизировать процесс формирования: строительной подосновы (планов этажей зданий) по одноэтажным и многоэтажным промышленным помещениям</segment>
		<segment id="94" parent="93" relname="purpose">для последующего размещения технологического оборудования;</segment>
		<segment id="95" parent="406" relname="same-unit">а также административно-бытовым зданиям; графической и текстовой документации по технологической планировке производственных помещений.</segment>
		<segment id="96" parent="291" relname="span">LCAD обеспечивает создание и ведение базы данных (БД), содержащей массивы текстовой и графической информации.</segment>
		<segment id="97" parent="289" relname="joint">Структура массивов БД позволяет загружать</segment>
		<segment id="98" parent="289" relname="joint">и использовать при проектировании следующие виды информации:</segment>
		<segment id="99" parent="292" relname="joint">• характеристики оборудования (наименование и модель, габариты, масса, установленная мощность электродвигателя и некоторая дополнительная информация), с обеспечением поиска и выбора информации по классам и группам оборудования;</segment>
		<segment id="100" parent="292" relname="joint">• дополнительная графическая информация по оборудованию: размеры, установочные планы, планы опор, точки подключения электропитания, воздуха и т.п.;</segment>
		<segment id="101" parent="292" relname="joint">• темплеты («габаритки», «фишки») оборудования;</segment>
		<segment id="102" parent="292" relname="joint">• спецификации по установленному оборудованию;</segment>
		<segment id="103" parent="292" relname="joint">• принятые условные графические обозначения для нанесения на планировки;</segment>
		<segment id="104" parent="292" relname="joint">• структура производства (промышленная площадка - производственный корпус -цех - участок);</segment>
		<segment id="105" parent="295" relname="span">• генплан предприятия</segment>
		<segment id="106" parent="105" relname="purpose">(для обеспечения быстрого выхода на нужную планировку производственных корпусов, цехов, участков);</segment>
		<segment id="107" parent="292" relname="joint">• любая информация по цехам и участкам предприятия (виды и размеры площадей и т.д.);</segment>
		<segment id="108" parent="292" relname="joint">• справочные данные по нормам и требованиям к размещению оборудования.</segment>
		<segment id="109" parent="298" relname="joint">LCAD предполагает создание и хранение в БД технологических планировок на строительной подоснове производственного корпуса (здания) в целом.</segment>
		<segment id="110" parent="296" relname="joint">Спецификация установленного оборудования (рис. 3) создается</segment>
		<segment id="111" parent="296" relname="joint">и хранится в БД в целом по предприятию.</segment>
		<segment id="112" parent="298" relname="joint">Оформление и вывод на печать графической (чертежи планировок) и текстовой (спецификации оборудования) документации может производиться как в целом по производственным корпусам, так и по отдельным цехам и участкам, запрашиваемым в БД.</segment>
		<segment id="113" >[Рис. 3. Спецификация установленного оборудования]</segment>
		<segment id="114" parent="300" relname="joint">LCAD использует</segment>
		<segment id="115" parent="300" relname="joint">и расширяет возможности пакета AutoCAD фирмы Autodesk за счет наличия дополнительного набора специальных приложений, обеспечивающих основные функции проектирования технологических планировок цехов и участков предприятии [3].</segment>
		<segment id="116" parent="302" relname="joint">Комплекс можно использовать в технологических подразделениях и технических отделах как крупных предприятий, так и небольших производственных организаций, применяющих АРМ технологов-проектировщиков на базе персональных компьютеров.</segment>
		<segment id="117" parent="118" relname="background">Великолепные достижения современной информатики, большое количество и значительный ассортимент программных продуктов позволяют строить процесс проектирования на новом, совсем недавно недоступном, уровне.</segment>
		<segment id="118" parent="304" relname="span">Обобщая доступные знания о современных достижений, можно попробовать виртуально синтезировать АРМ проектировщика.</segment>
		<segment id="119" parent="306" relname="span">Рассмотрим АРМ проектировщика изделий электронной техники.</segment>
		<segment id="120" parent="305" relname="span">Основной метод создания такого АРМ, как и многих других, основан на внедрении последних программных продуктов.</segment>
		<segment id="121" parent="120" relname="elaboration">Необходимыми составными частями предлагаемого АРМ являются графический, топологический и текстовый редакторы, а также пакет программ схемотехнического моделирования.</segment>
		<segment id="122" parent="308" relname="span">Сердцем виртуального АРМ выбираем графический редактор, а именно AutoCAD200X фирмы AutoDesk.</segment>
		<segment id="123" parent="309" relname="span">Дружеское и квалифицированное присутствие его создателей ощущается в процессе всей работы.</segment>
		<segment id="124" parent="310" relname="span">Действительно, трудно найти такой режим работы конструктора,</segment>
		<segment id="125" parent="124" relname="elaboration">который бы не предусмотрели специалисты AutoDesk.</segment>
		<segment id="126" parent="404" relname="span">Интерфейсное окно одного из замечательных продуктов AutoDesk, а именно - AutoDesk Mechanical Desktop 2004, с примером трехмерного отображения сборочного чертежа платы, приведено на рис. 4.</segment>
		<segment id="127" parent="126" relname="elaboration">[Рис. 4. Интерфейсное окно AutoDesk Mechanical Desktop 2004 с примером трехмерного отображения сборочного чертежа платы]</segment>
		<segment id="128" parent="311" relname="span">Руками нашего создания будут являться топологический и текстовый редакторы.</segment>
		<segment id="129" parent="312" relname="span">Правой рукой назначаем топологический редактор, а конкретно PCAD200X.</segment>
		<segment id="130" parent="314" relname="span">Основным и несомненным достоинством в его работе является наличие функции автотрассировки (особенно при наличии программы SPECCTRA).</segment>
		<segment id="131" parent="130" relname="evidence">Действительно, получение готовой топологии платы на основе схемы электрической принципиальной и грамотно составленного задания является значительным шагом в автоматизации и, соответственно, облегчении работы тополога, тем более в таком рутинном сегменте разработки.</segment>
		<segment id="132" parent="317" relname="span">Левой рукой у нас будет текстовый редактор.</segment>
		<segment id="133" parent="134" relname="cause">Несомненным лидером в этой номинации является Microsoft Word,</segment>
		<segment id="134" parent="316" relname="span">его и возьмем в помощники.</segment>
		<segment id="135" parent="322" relname="span">Ну а головой, конечно же, является пакет программ схемотехнического моделирования.</segment>
		<segment id="136" parent="320" relname="span">С середины 90-х годов прошлого века автор успешно эксплуатировал пакет Design Lab, добиваясь значительно большей производительности, чем в современных OrCAD 9.X, OrCAD 10, причем на менее мощных компьютерах.</segment>
		<segment id="137" parent="136" relname="concession">Приходится только мириться с некоторыми «дикими» зигзагами развития рынка.</segment>
		<segment id="138" parent="320" relname="evaluation">Безусловно, достоинством семейства OrCAD является наличие программы схемотехнического и функционального моделирования Capture OrCAD [4].</segment>
		<segment id="139" parent="323" relname="contrast">Описанные выше функциональные возможности отсутствуют в каждой из составных частей нашего АРМ,</segment>
		<segment id="140" parent="323" relname="contrast">однако они присутствуют в пакетах программ некоторых машинных станций и платформ типа UNIX, Hewlett-Packard и других.</segment>
		<segment id="141" parent="327" relname="concession">И хотя их стоимость и стоимость предлагаемого комплекса разнятся многократно,</segment>
		<segment id="142" parent="327" relname="span">ставится задача осуществления таких функциональных возможностей,</segment>
		<segment id="143" parent="325" relname="joint">которые бы не только превосходили аналоги,</segment>
		<segment id="144" parent="325" relname="joint">но и переводили бы систему на качественно новую ступень.</segment>
		<segment id="145" parent="331" relname="span">За теоретическую основу примем статью [5].</segment>
		<segment id="146" parent="145" relname="elaboration">Действительно, производительность современных персональных компьютеров позволяют наделить уже не электронные устройства, а рассматриваемый программный комплекс абсолютно новыми свойствами.</segment>
		<segment id="147" parent="331" relname="elaboration">Определим появление комплекса новых свойств как «интеллектуализация программного продукта».</segment>
		<segment id="148" parent="334" relname="purpose">С целью построения алгоритмов действия</segment>
		<segment id="149" parent="333" relname="joint">промоделируем процесс разработки, осуществляемый человеком,</segment>
		<segment id="150" parent="333" relname="joint">и попробуем перенести выявленные закономерности в деятельность создаваемого продукта.</segment>
		<segment id="151" parent="168" relname="elaboration">[Рис. 5. Алгоритм процесса идентификации]</segment>
		<segment id="152" parent="337" relname="span">Начнем с этапа получения задания.</segment>
		<segment id="153" parent="348" relname="sequence">Получив задание,</segment>
		<segment id="154" parent="348" relname="sequence">человек ищет в памяти (своей базе данных) аналоги заданию,</segment>
		<segment id="155" parent="347" relname="purpose">с целью его возможного выполнения путем модернизации.</segment>
		<segment id="156" parent="350" relname="span">Рассмотрим программное осуществление данного этапа.</segment>
		<segment id="157" parent="338" relname="sequence">Дополнив графическое обозначение кратким формализованным описанием,</segment>
		<segment id="158" parent="356" relname="span">мы получим элемент идентификации для АРМ.</segment>
		<segment id="159" parent="343" relname="joint">Этот элемент будет использоваться не только при вводе задания, но и для краткого формализованного описания разработанных продуктов.</segment>
		<segment id="160" parent="341" relname="joint">Храниться он будет в отдельной библиотеке,</segment>
		<segment id="161" parent="405" relname="span">а задействован будет для идентификации разработок.</segment>
		<segment id="162" parent="351" relname="span">Механизм идентификации на начальном этапе будет несовершенен</segment>
		<segment id="163" parent="162" relname="cause">из-за недостаточной формализации задействованных в процессе данных.</segment>
		<segment id="164" parent="354" relname="span">Но попробуем обойти эти трудности, используя информационную избыточность:</segment>
		<segment id="165" parent="166" relname="condition">если не удается идентифицировать разработ- ку с помощью системы графических обозначений,</segment>
		<segment id="166" parent="345" relname="span">то используется система формализованного описания.</segment>
		<segment id="167" parent="355" relname="span">Алгоритм предлагаемого процесса проиллюстрирован</segment>
		<segment id="168" parent="167" relname="elaboration">рис. 5.</segment>
		<segment id="169" parent="357" relname="sequence">После процесса идентификации</segment>
		<segment id="170" parent="357" relname="sequence">наступает этап конкретного сопоставления полученных в задании данных и параметров идентифицированной разработки.</segment>
		<segment id="171" parent="359" relname="span">С этой целью мы переходим от функциональных моделей к иным моделям.</segment>
		<segment id="172" parent="367" relname="span">Эти модели могут предоставить нам интересующие нас данные.</segment>
		<segment id="173" parent="364" relname="span">Вот тут мы сразу же вспоминаем, что рабочее место у нас автоматизированное, а не автоматическое.</segment>
		<segment id="174" parent="175" relname="cause">Дело в том, что огромный объем используемой информации различного вида, и сложнейшие алгоритмы действий</segment>
		<segment id="175" parent="361" relname="span">не позволяют автоматизировать этот процесс на современном этапе.</segment>
		<segment id="176" parent="362" relname="joint">Да и, в конце концов, разработчик должен продемонстрировать творческое начало.</segment>
		<segment id="177" parent="368" relname="span">Но и в этом случае современные программные продукты могут оказать неоценимую помощь.</segment>
		<segment id="178" parent="177" relname="elaboration">Одним из таких инструментов является директива вариации параметров программы Spice.</segment>
		<segment id="179" parent="397" relname="contrast">Но целью статьи является не обучение пользователей,</segment>
		<segment id="180" parent="397" relname="contrast">а стремление показать возможность создания высококачественного АРМ [5].</segment>
		<segment id="181" parent="371" relname="preparation">Заключение</segment>
		<segment id="182" parent="183" relname="condition">Если обратить внимание на достижения данного направления,</segment>
		<segment id="183" parent="370" relname="span">то подавляющее место в нем занимают зарубежные продукты,</segment>
		<segment id="184" parent="370" relname="evaluation">что весьма обидно.</segment>
		<segment id="185" parent="383" relname="span">Предлагаемое АРМ окажется полезным системотехникам, схемотехникам, конструкторам, топологам и технологам.</segment>
		<segment id="186" parent="372" relname="restatement">Пользователю не обязательно устанавливать четыре-пять редакторов.</segment>
		<segment id="187" parent="372" relname="elaboration">Можно обойтись минимально количеством, необходимым для работы.</segment>
		<segment id="188" parent="374" relname="joint">Но сами закладываемые в предлагаемый программный продукт принципы не только адекватны возникающим в процессе разработки задачам,</segment>
		<segment id="189" parent="374" relname="joint">но и переводят процесс разработки на более высокий уровень.</segment>
		<segment id="190" parent="378" relname="joint">Внедрение проекта позволит не просто значительно автоматизировать процесс разработки</segment>
		<segment id="191" parent="378" relname="joint">и создавать интегрированные библиотеки разработок,</segment>
		<segment id="192" parent="380" relname="joint">но и создать рынок разработок, не имеющий аналогов.</segment>
		<segment id="193" parent="384" relname="span">Анализируя сущность АРМ, специалисты определяют их чаще всего как профессионально-ориентированные малые вычислительные системы, расположенные непосредственно на рабочих местах специалистов</segment>
		<segment id="194" parent="193" relname="purpose">и предназначенные для автоматизации их работ.</segment>
		<segment id="195" parent="385" relname="contrast">Для каждого объекта управления нужно предусмотреть АРМ, соответствующие их функциональному назначению.</segment>
		<segment id="196" parent="385" relname="contrast">Однако принципы создания АРМ должны быть общими: системность, гибкость, устойчивость, эффективность.</segment>
		<segment id="197" >Литература</segment>
		<segment id="198" >1\. Словарь по естественным наукам. http://slovari.yandex.ru/</segment>
		<segment id="199" >2\. Козлова Е.В., Когутенко В.А. Модифицированный метод структурного распараллеливания В. А. Костенко для линейных и разветвляющихся участков схемы технологического процесса сборочного производства.</segment>
		<segment id="200" >3\. www.cad.ru</segment>
		<segment id="201" >4\. Силкин В. Трехмерное отображение в электронике - варианты использования и возможные направления развития. // Компоненты и технологии. 2005. №5. С. 26-28.</segment>
		<segment id="202" >5\. Силкин В. «Интеллектуализация» электронных устройств. // Компоненты и технологии. 2005. №3. С. 37-39.</segment>
		<group id="204" type="span" parent="10" relname="cause"/>
		<group id="205" type="span" parent="206" relname="span"/>
		<group id="206" type="span" parent="12" relname="cause"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" />
		<group id="209" type="multinuc" parent="210" relname="span"/>
		<group id="210" type="span" parent="212" relname="joint"/>
		<group id="211" type="multinuc" parent="213" relname="span"/>
		<group id="212" type="multinuc" parent="214" relname="span"/>
		<group id="213" type="span" parent="212" relname="joint"/>
		<group id="214" type="span" parent="19" relname="cause"/>
		<group id="215" type="span" parent="211" relname="joint"/>
		<group id="216" type="span" parent="20" relname="cause"/>
		<group id="217" type="span" />
		<group id="218" type="multinuc" parent="219" relname="span"/>
		<group id="219" type="span" parent="221" relname="span"/>
		<group id="220" type="span" parent="388" relname="same-unit"/>
		<group id="221" type="span" parent="222" relname="span"/>
		<group id="222" type="span" parent="25" relname="cause"/>
		<group id="223" type="multinuc" parent="224" relname="span"/>
		<group id="224" type="span" parent="30" relname="cause"/>
		<group id="225" type="multinuc" parent="226" relname="span"/>
		<group id="226" type="span" parent="227" relname="evaluation"/>
		<group id="227" type="span" parent="228" relname="span"/>
		<group id="228" type="span" />
		<group id="229" type="span" parent="232" relname="span"/>
		<group id="230" type="multinuc" parent="231" relname="span"/>
		<group id="231" type="span" parent="229" relname="elaboration"/>
		<group id="232" type="span" parent="233" relname="span"/>
		<group id="233" type="span" />
		<group id="234" type="multinuc" parent="235" relname="span"/>
		<group id="235" type="span" parent="42" relname="cause"/>
		<group id="236" type="span" parent="239" relname="elaboration"/>
		<group id="237" type="multinuc" parent="238" relname="span"/>
		<group id="238" type="span" parent="239" relname="span"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" parent="45" relname="solutionhood"/>
		<group id="241" type="span" parent="46" relname="cause"/>
		<group id="242" type="span" />
		<group id="243" type="multinuc" parent="244" relname="span"/>
		<group id="244" type="span" parent="47" relname="elaboration"/>
		<group id="245" type="span" parent="243" relname="joint"/>
		<group id="246" type="multinuc" parent="245" relname="span"/>
		<group id="247" type="span" parent="248" relname="same-unit"/>
		<group id="248" type="multinuc" parent="249" relname="span"/>
		<group id="249" type="span" parent="246" relname="restatement"/>
		<group id="250" type="span" />
		<group id="251" type="multinuc" parent="252" relname="span"/>
		<group id="252" type="span" parent="253" relname="span"/>
		<group id="253" type="span" parent="257" relname="span"/>
		<group id="254" type="multinuc" parent="255" relname="span"/>
		<group id="255" type="span" parent="59" relname="elaboration"/>
		<group id="256" type="span" parent="62" relname="purpose"/>
		<group id="257" type="span" parent="259" relname="span"/>
		<group id="258" type="span" parent="257" relname="elaboration"/>
		<group id="259" type="span" />
		<group id="260" type="multinuc" parent="267" relname="span"/>
		<group id="261" type="multinuc" parent="263" relname="span"/>
		<group id="262" type="multinuc" parent="264" relname="span"/>
		<group id="263" type="span" parent="265" relname="joint"/>
		<group id="264" type="span" parent="265" relname="joint"/>
		<group id="265" type="multinuc" parent="266" relname="span"/>
		<group id="266" type="span" parent="260" relname="joint"/>
		<group id="267" type="span" parent="63" relname="elaboration"/>
		<group id="268" type="span" />
		<group id="269" type="multinuc" parent="270" relname="span"/>
		<group id="270" type="span" parent="260" relname="joint"/>
		<group id="271" type="span" parent="272" relname="background"/>
		<group id="272" type="span" parent="279" relname="span"/>
		<group id="273" type="multinuc" parent="275" relname="span"/>
		<group id="274" type="span" parent="273" relname="same-unit"/>
		<group id="275" type="span" parent="276" relname="joint"/>
		<group id="276" type="multinuc" parent="277" relname="span"/>
		<group id="277" type="span" parent="283" relname="span"/>
		<group id="278" type="span" parent="282" relname="span"/>
		<group id="279" type="span" parent="75" relname="elaboration"/>
		<group id="280" type="span" parent="281" relname="span"/>
		<group id="281" type="span" parent="393" relname="span"/>
		<group id="282" type="span" parent="277" relname="evidence"/>
		<group id="283" type="span" parent="280" relname="elaboration"/>
		<group id="284" type="span" parent="285" relname="joint"/>
		<group id="285" type="multinuc" parent="286" relname="span"/>
		<group id="286" type="span" parent="87" relname="elaboration"/>
		<group id="287" type="span" />
		<group id="288" type="span" parent="285" relname="joint"/>
		<group id="289" type="multinuc" parent="290" relname="span"/>
		<group id="290" type="span" parent="294" relname="span"/>
		<group id="291" type="span" />
		<group id="292" type="multinuc" parent="293" relname="span"/>
		<group id="293" type="span" parent="290" relname="elaboration"/>
		<group id="294" type="span" parent="96" relname="elaboration"/>
		<group id="295" type="span" parent="292" relname="joint"/>
		<group id="296" type="multinuc" parent="297" relname="span"/>
		<group id="297" type="span" parent="298" relname="joint"/>
		<group id="298" type="multinuc" parent="299" relname="span"/>
		<group id="299" type="span" />
		<group id="300" type="multinuc" parent="301" relname="span"/>
		<group id="301" type="span" parent="302" relname="joint"/>
		<group id="302" type="multinuc" parent="303" relname="span"/>
		<group id="303" type="span" />
		<group id="304" type="span" parent="307" relname="span"/>
		<group id="305" type="span" parent="394" relname="span"/>
		<group id="306" type="span" parent="305" relname="preparation"/>
		<group id="307" type="span" parent="395" relname="span"/>
		<group id="308" type="span" />
		<group id="309" type="span" parent="122" relname="evaluation"/>
		<group id="310" type="span" parent="396" relname="span"/>
		<group id="311" type="span" parent="318" relname="joint"/>
		<group id="312" type="span" parent="313" relname="joint"/>
		<group id="313" type="multinuc" parent="315" relname="span"/>
		<group id="314" type="span" parent="129" relname="evaluation"/>
		<group id="315" type="span" parent="128" relname="elaboration"/>
		<group id="316" type="span" parent="132" relname="elaboration"/>
		<group id="317" type="span" parent="313" relname="joint"/>
		<group id="318" type="multinuc" parent="319" relname="span"/>
		<group id="319" type="span" />
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" parent="135" relname="elaboration"/>
		<group id="322" type="span" parent="318" relname="joint"/>
		<group id="323" type="multinuc" parent="324" relname="span"/>
		<group id="324" type="span" parent="328" relname="background"/>
		<group id="325" type="multinuc" parent="326" relname="span"/>
		<group id="326" type="span" parent="142" relname="elaboration"/>
		<group id="327" type="span" parent="328" relname="span"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="330" relname="span"/>
		<group id="330" type="span" />
		<group id="331" type="span" parent="332" relname="span"/>
		<group id="332" type="span" parent="329" relname="elaboration"/>
		<group id="333" type="multinuc" parent="334" relname="span"/>
		<group id="334" type="span" parent="335" relname="span"/>
		<group id="335" type="span" />
		<group id="336" type="span" parent="152" relname="elaboration"/>
		<group id="337" type="span" parent="349" relname="span"/>
		<group id="338" type="multinuc" parent="339" relname="span"/>
		<group id="339" type="span" parent="340" relname="span"/>
		<group id="340" type="span" parent="156" relname="elaboration"/>
		<group id="341" type="multinuc" parent="342" relname="span"/>
		<group id="342" type="span" parent="343" relname="joint"/>
		<group id="343" type="multinuc" parent="344" relname="span"/>
		<group id="344" type="span" parent="158" relname="elaboration"/>
		<group id="345" type="span" parent="164" relname="elaboration"/>
		<group id="346" type="span" parent="352" relname="contrast"/>
		<group id="347" type="span" parent="336" relname="span"/>
		<group id="348" type="multinuc" parent="347" relname="span"/>
		<group id="349" type="span" />
		<group id="350" type="span" parent="337" relname="elaboration"/>
		<group id="351" type="span" parent="352" relname="contrast"/>
		<group id="352" type="multinuc" parent="353" relname="span"/>
		<group id="353" type="span" parent="161" relname="elaboration"/>
		<group id="354" type="span" parent="346" relname="span"/>
		<group id="355" type="span" parent="354" relname="elaboration"/>
		<group id="356" type="span" parent="338" relname="sequence"/>
		<group id="357" type="multinuc" parent="358" relname="span"/>
		<group id="358" type="span" parent="171" relname="purpose"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="369" relname="span"/>
		<group id="361" type="span" parent="362" relname="joint"/>
		<group id="362" type="multinuc" parent="363" relname="span"/>
		<group id="363" type="span" parent="173" relname="elaboration"/>
		<group id="364" type="span" parent="365" relname="contrast"/>
		<group id="365" type="multinuc" parent="366" relname="span"/>
		<group id="366" type="span" parent="400" relname="span"/>
		<group id="367" type="span" parent="359" relname="elaboration"/>
		<group id="368" type="span" parent="365" relname="contrast"/>
		<group id="369" type="span" />
		<group id="370" type="span" parent="371" relname="span"/>
		<group id="371" type="span" parent="399" relname="span"/>
		<group id="372" type="multinuc" parent="373" relname="span"/>
		<group id="373" type="span" parent="376" relname="contrast"/>
		<group id="374" type="multinuc" parent="375" relname="span"/>
		<group id="375" type="span" parent="376" relname="contrast"/>
		<group id="376" type="multinuc" parent="377" relname="span"/>
		<group id="377" type="span" parent="382" relname="span"/>
		<group id="378" type="multinuc" parent="379" relname="span"/>
		<group id="379" type="span" parent="380" relname="joint"/>
		<group id="380" type="multinuc" parent="381" relname="span"/>
		<group id="381" type="span" parent="377" relname="evaluation"/>
		<group id="382" type="span" parent="185" relname="elaboration"/>
		<group id="383" type="span" />
		<group id="384" type="span" parent="387" relname="span"/>
		<group id="385" type="multinuc" parent="386" relname="span"/>
		<group id="386" type="span" parent="384" relname="elaboration"/>
		<group id="387" type="span" />
		<group id="388" type="multinuc" parent="390" relname="span"/>
		<group id="389" type="span" parent="220" relname="span"/>
		<group id="390" type="span" parent="223" relname="contrast"/>
		<group id="391" type="span" parent="223" relname="contrast"/>
		<group id="392" type="span" parent="237" relname="joint"/>
		<group id="393" type="span" />
		<group id="394" type="span" parent="307" relname="elaboration"/>
		<group id="395" type="span" />
		<group id="396" type="span" parent="123" relname="elaboration"/>
		<group id="397" type="multinuc" parent="398" relname="span"/>
		<group id="398" type="span" parent="366" relname="elaboration"/>
		<group id="399" type="span" />
		<group id="400" type="span" parent="401" relname="span"/>
		<group id="401" type="span" parent="172" relname="elaboration"/>
		<group id="402" type="span" parent="88" relname="purpose"/>
		<group id="403" type="span" parent="207" relname="span"/>
		<group id="404" type="span" parent="310" relname="elaboration"/>
		<group id="405" type="span" parent="341" relname="joint"/>
		<group id="406" type="multinuc" parent="408" relname="span"/>
		<group id="407" type="span" parent="406" relname="same-unit"/>
		<group id="408" type="span" parent="285" relname="joint"/>
	</body>
</rst>