<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="131" relname="span">МЕТОДЫ ПОСТРОЕНИЯ АДАПТИВНОЙ РАСПРЕДЕЛЕННОЙ ОПТИКО-ЭЛЕКТРОННОЙ СИСТЕМЫ НЕРАЗРУШАЮЩЕГО КОНТРОЛЯ ДЕФОРМАЦИИ КРУПНОГАБАРИТНЫХ СООРУЖЕНИЙ</segment>
		<segment id="2" parent="1" relname="attribution">А.Г. Анисимов, В.В. Коротаев, А.В. Краснящих</segment>
		<segment id="3" >Рассматриваются принципы и схемы построения адаптивных распределенных оптико- электронных систем (РОЭС). Сформулированы основные требования, предъявляемые к блокам, входящим в состав РОЭС, выделены основные функции, выполняемые блоками системы. Приведен принцип действия и устройство одного из измерительных каналов системы.</segment>
		<segment id="4" parent="209" relname="preparation">Введение</segment>
		<segment id="5" parent="132" relname="joint">Обеспечение безаварийной эксплуатации зданий, безотказной работы крупногабаритных конструкций и инженерных сооружений, а также экологически опасных объектов является одной из важнейших проблем нашего времени.</segment>
		<segment id="6" parent="132" relname="joint">Непрерывный мониторинг их состояния с помощью распределенных оптико- электронных систем позволит обеспечить не только постоянное наблюдение за деформационной картиной указанных объектов, но и выработку необходимых решений при различных состояниях технической и физической среды.</segment>
		<segment id="7" parent="132" relname="joint">Данная задача может быть реализована с помощью оптико-электронных систем контроля деформаций (ОЭСКД), в том числе и с применением телевизионных датчиков на основе фоточувствительных приборов с зарядовой связью (ФПЗС)[1].</segment>
		<segment id="8" parent="133" relname="span">Для обеспечения непрерывного наблюдения за объектом необходимо,</segment>
		<segment id="9" parent="8" relname="condition">чтобы контролирующая система имела возможность адаптироваться к изменяющимся внешним воздействиям.</segment>
		<segment id="10" parent="11" relname="evidence">Для решения задач адаптации и выбора режимов работы системы предлагается использовать нейроподобные структуры, которые обладают возможностью обучения, выработки решения в нетипичных ситуациях.</segment>
		<segment id="11" parent="207" relname="span">Такие свойства нейронных сетей, на данном этапе позволяют сделать вывод о возможности их применения к созданию адаптивных ОЭСКД.</segment>
		<segment id="12" parent="135" relname="joint">Решение задачи автоматизированного контроля положения отдельных элементов контролируемых объектов представляется возможным на основе системы контрольных элементов, жестко связанных с исследуемым объектом.</segment>
		<segment id="13" parent="135" relname="joint">Деформация объекта вызывает их смещение</segment>
		<segment id="14" parent="136" relname="joint">Картина, создаваемая точечными объектами, регистрируется оптико-электронными датчиками с матричным ФПЗС</segment>
		<segment id="15" parent="136" relname="joint">и анализируется с привлечением числовой обработки на ЭВМ.</segment>
		<segment id="16" parent="200" relname="span">При этом предварительная обработка измерительной информации осуществляется в непосредственной близости от приемника оптического излучения,</segment>
		<segment id="17" parent="190" relname="joint">что позволяет увеличить помехозащищенность системы в целом</segment>
		<segment id="18" parent="190" relname="joint">и исключить избыточность информации.</segment>
		<segment id="19" parent="138" relname="joint">Для обеспечения автоматизированного пространственного контроля деформации крупногабаритных инженерных сооружений предлагается реализовать распределенную оптико-электронную систему (РОЭС).</segment>
		<segment id="20" parent="201" relname="span">РОЭС обеспечит многоточечный непрерывный контроль,</segment>
		<segment id="21" parent="20" relname="purpose">что позволит получать более полную информацию о состоянии объекта.</segment>
		<segment id="22" parent="211" relname="preparation">Принцип построения РОЭС</segment>
		<segment id="23" parent="139" relname="span">Под РОЭС предложено понимать совокупность функционально объединенных оптико- электронных преобразователей (ОЭП),</segment>
		<segment id="24" parent="23" relname="elaboration">определенным образом распределенных в пространстве, во времени, по спектральному диапазону используемого излучения, воспринимающих часть информации, содержащейся в оптическом сигнале об измеряемом объекте, преобразующих ее в электрический сигнал, передаваемый по каналу передачи данных (КПД) на центральный управляющий прибор (ЦУП).</segment>
		<segment id="25" parent="143" relname="joint">Информация о распределении ОЭП и о взаимосвязи между ними известна до начала измерения.</segment>
		<segment id="26" parent="140" relname="same-unit">ЦУП,</segment>
		<segment id="27" parent="28" relname="cause">используя информацию о распределении ОЭП,</segment>
		<segment id="28" parent="141" relname="span">восстанавливает общую информационную картину из частей, полученных от ОЭП,</segment>
		<segment id="29" parent="142" relname="joint">а также осуществляет управление процессом собора, хранения и отображения измерительной информации.</segment>
		<segment id="30" parent="202" relname="span">РОЭС необходимо строить по блочно-модульному принципу,</segment>
		<segment id="31" parent="144" relname="joint">что позволит создать универсальную систему, способную решать различные измерительные задачи путем изменения набора блоков,</segment>
		<segment id="32" parent="144" relname="joint">а также обеспечит экономию времени при ее разработке и обслуживании.</segment>
		<segment id="33" parent="145" relname="joint">В дальнейшем ОЭП, входящий в РОЭС, в связке с источником оптического излучения будем называть измерительным каналом (ИК).</segment>
		<segment id="34" parent="145" relname="joint">Помимо этого, в состав ИК должны входить блоки интерфейса (БИ), обеспечивающие двухстороннюю связь ИК с КПД.</segment>
		<segment id="35" parent="146" relname="joint">ЦУП, помимо блоков, обеспечивающих сбор, отображение и хранение измерительной информации, должен обладать и БИ для подключения к КПД.</segment>
		<segment id="36" parent="146" relname="joint">Дополнительные источники информации (ДИИ) могут подключаться напрямую к ЦУП или (и) через БИ к КПД.</segment>
		<segment id="37" parent="146" relname="joint">Количество и принцип действия ДИИ определяется из задач, поставленных перед РОЭС.</segment>
		<segment id="38" parent="147" relname="span">Данная схема реализации РОЭС представлена на рис.1.</segment>
		<segment id="39" parent="38" relname="elaboration">[Рис. 1. Схема РОЭС]</segment>
		<segment id="40" parent="149" relname="purpose">В качестве ЦУП удобно использовать персональные электронно-вычислительные машины (ПЭВМ),</segment>
		<segment id="41" parent="148" relname="joint">что обеспечит гибкость настройки параметров системы</segment>
		<segment id="42" parent="148" relname="joint">и позволит конфигурировать систему для решения различных измерительных задач.</segment>
		<segment id="43" parent="150" relname="elaboration">На ПЭВМ в общем случае возлагается выбор режима работы ИК, сбор измерительной информации, восстановление общей измерительной картины, хранение полученных данных и др.</segment>
		<segment id="44" parent="45" relname="cause">Накопление и обработка измерительной информации производятся по управляющим командам, поступающим с ЦУП.</segment>
		<segment id="45" parent="151" relname="span">В связи с этим каждый ИК должен получить команду на накопление, обработку измерительной информации, а также пересылку результатов измерений.</segment>
		<segment id="46" parent="47" relname="cause">В связи с тем, что задачи, решаемые РОЭС, чрезвычайно разнообразны,</segment>
		<segment id="47" parent="192" relname="span">трудно составить универсальную схему ИК.</segment>
		<segment id="48" parent="152" relname="span">Однако должны быть предусмотрены узлы,</segment>
		<segment id="49" parent="48" relname="elaboration">обеспечивающие необходимый набор операций обработки информационного сигнала,</segment>
		<segment id="50" parent="153" relname="span">а также узлы,</segment>
		<segment id="51" parent="154" relname="restatement">позволяющие при переходе от одного режима работы к другому изменять структуру РОЭС,</segment>
		<segment id="52" parent="154" relname="restatement">т. е. изменять набор операций и их последовательность.</segment>
		<segment id="53" parent="194" relname="contrast">В качестве приемников оптического излучения в ИК можно использовать различные приборы,</segment>
		<segment id="54" parent="195" relname="span">однако применение телевизионных датчиков (ТВД) на базе ФПЗС предпочтительнее,</segment>
		<segment id="55" parent="54" relname="cause">так как для ФПЗС характерна жесткая геометрическая привязка фоточувствительных элементов растра к приборной системе координат,</segment>
		<segment id="56" parent="195" relname="purpose">что облегчает задачу построения измерительной аппаратуры с высокой стабильностью метрологических характеристик.</segment>
		<segment id="57" parent="58" relname="concession">Несмотря на дискретный характер ФПЗС,</segment>
		<segment id="58" parent="156" relname="span">в плоскости анализа изображения возможна регистрация координат объекта с точностью до сотых долей элемента ФПЗС [2, 3].</segment>
		<segment id="59" parent="217" relname="span">Во всех современных ТИС,</segment>
		<segment id="60" parent="216" relname="joint">независимо от их типа</segment>
		<segment id="61" parent="216" relname="joint">и назначения,</segment>
		<segment id="62" parent="218" relname="same-unit">на начальном этапе предполагается преобразование аналоговых входных информационных оптических сигналов в совокупность дискретных электрических сигналов, пригодных для осуществления дальнейшей цифровой обработки изображений с применением средств вычислительной техники [4].</segment>
		<segment id="63" parent="208" relname="span">Таким образом, в структурной схеме ТИС должны быть предусмотрены узлы, обеспечивающие необходимый набор операций обработки видеосигнала при каждом режиме работы системы.</segment>
		<segment id="64" parent="65" relname="purpose">Для объединения ИК в измерительную сеть</segment>
		<segment id="65" parent="219" relname="span">необходим набор протоколов, обеспечивающих связь различных сегментов РОЭС с ЦУП посредством канала передачи данных.</segment>
		<segment id="66" parent="220" relname="span">Под протоколом будем понимать алгоритм взаимодействия устройств и подсистем обработки информации.</segment>
		<segment id="67" parent="66" relname="elaboration">При этом протокол определяет форму сообщений или пакетов сообщений, виды сигналов об ошибках и отказах, способы обмена.</segment>
		<segment id="68" parent="221" relname="span">Под интерфейсом в данном случае следует понимать физическую совокупность аппаратных и программных средств, обеспечивающих совместимость взаимодействующих объектов.</segment>
		<segment id="69" parent="68" relname="elaboration">При этом интерфейс определяет протокол передачи данных, а также параметры канала связи.</segment>
		<segment id="70" parent="225" relname="preparation">Канал связи представляет собой совокупность устройств для передачи сигналов.</segment>
		<segment id="71" parent="159" relname="joint">При передаче сигналы всегда затухают вследствие поглощения и рассеяния энергии в среде,</segment>
		<segment id="72" parent="159" relname="joint">а также искажаются.</segment>
		<segment id="73" parent="161" relname="span">Кроме того, к сигналам примешиваются помехи различной природы.</segment>
		<segment id="74" parent="160" relname="joint">Затухание может быть компенсировано усилением сигналов в приемо-передающей аппаратуре или в ретрансляторах.</segment>
		<segment id="75" parent="227" relname="span">Значительно труднее ослабить помехи и искажения.</segment>
		<segment id="76" parent="75" relname="elaboration">Удается добиться лишь частичной их компенсации, применяя сложные методы и технические средства.</segment>
		<segment id="77" parent="188" relname="span">Описать построение канала связи при данной реализации РОЭС довольно сложно,</segment>
		<segment id="78" parent="77" relname="cause">так как его формирование обусловливается условиями работы системы в целом.</segment>
		<segment id="79" parent="162" relname="joint">Стоит отметить, что канал передачи данных системы может представлять собой набор фрагментов с различными линиями передачи данных,</segment>
		<segment id="80" parent="162" relname="joint">а также включать в себя уже существующие системы передачи данных, например, локальные сети, сеть Internet, систему спутниковой связи.</segment>
		<segment id="81" parent="82" relname="cause">Бурное развитие элементной базы и современных ПЭВМ</segment>
		<segment id="82" parent="229" relname="span">в целом позволяет довольно легко реализовать РОЭС по программному принципу,</segment>
		<segment id="83" parent="230" relname="joint">исключив при этом проблемы, связанные с проектированием аппаратной части.</segment>
		<segment id="84" parent="165" relname="sequence">ПЭВМ под управлением специального программного обеспечения производит обработку полученного сигнала со всех ИК, извлекая из него измерительную информацию.</segment>
		<segment id="85" parent="164" relname="same-unit">Далее ЦУП,</segment>
		<segment id="86" parent="87" relname="condition">используя заранее известные данные о распределении измерительных каналов системы,</segment>
		<segment id="87" parent="163" relname="span">производит восстановление полной информационной картины состояния объекта измерений, обработку информации, запись в базу данных, выдачу управляющих команд, результатов.</segment>
		<segment id="88" parent="231" relname="contrast">К достоинствам РОЭС, построенной на базе ПЭВМ, следует отнести: промышленное производство аппаратных средств; возможность реализации различных алгоритмов обработки измерительной информации и гибкой их модернизации без изменения аппаратной части; возможность построения как автоматической, так и автоматизированной системы; возможность удаленного управления системой.</segment>
		<segment id="89" parent="232" relname="span">К недостаткам рассматриваемого принципа построения РОЭС следует отнести большое энергопотребление, большие габаритные характеристики и дороговизну системы в целом.</segment>
		<segment id="90" parent="166" relname="span">Скомпенсировать недостатки РОЭС, построенной на базе ПЭВМ, можно,</segment>
		<segment id="91" parent="90" relname="condition">заменив ПЭВМ однокристальной электронно-вычислительной машиной (ОЭВМ),</segment>
		<segment id="92" parent="167" relname="span">что позволит существенно снизить энергопотребление системы в целом, габариты устройств, входящих в состав системы, и уменьшить ее себестоимость.</segment>
		<segment id="93" parent="94" relname="cause">Однако стоит учесть, что аппаратные возможности ОЭВМ гораздо уже, чем у ПЭВМ,</segment>
		<segment id="94" parent="197" relname="span">что может привести к снижению быстродействия измерительных каналов системы и всей системы в целом.</segment>
		<segment id="95" parent="169" relname="span">В качестве ЦУП может выступать особый блок, разработанный на базе ОЭВМ,</segment>
		<segment id="96" parent="95" relname="evaluation">однако использование для этих целей ПЭВМ, очевидно, предпочтительнее.</segment>
		<segment id="97" parent="189" relname="span">Стоит особо отметить то, что систему, построенную на базе ОЭВМ, на аппаратном уровне сложнее модернизировать,</segment>
		<segment id="98" parent="97" relname="cause">так как весь комплекс аппаратных средств блока обработки измерительной информации при его реализации будет жестко связан с возможностями ОЭВМ.</segment>
		<segment id="99" parent="175" relname="preparation">Исследование свойств ИК РОЭС</segment>
		<segment id="100" parent="233" relname="span">ОСКД предназначена</segment>
		<segment id="101" parent="100" relname="purpose">для измерения величины линейных смещений контролируемого объекта в вертикальной и горизонтальной плоскостях.</segment>
		<segment id="102" parent="233" relname="elaboration">Авторефлексионная схема оптической части ИК приведена на рис. 2.</segment>
		<segment id="103" parent="173" relname="joint">На ФПЗС 1, находящийся в приемном блоке 2, через объектив 3 и съемный светофильтр излучающей головки 5 проектируются изображения двух полупроводниковых излучающих диодов 4, закрепленных в ИГ.</segment>
		<segment id="104" parent="173" relname="joint">В качестве КЭ используется трипельпризма 6 [4].</segment>
		<segment id="105" parent="174" relname="elaboration">[Рис. 2. Схема автоколлимационной экспериментальной установки]</segment>
		<segment id="106" parent="181" relname="joint">ОЭСКД включает в себя телевизионный датчик (ТВД) (рис. 3), контрольный элемент (КЭ), блок управления источниками излучения (БУИИ), блок предварительной обработки информации (БПИО), источник излучения (ИИ), персональный компьютер (ПЭВМ).</segment>
		<segment id="107" parent="235" relname="span">БУИИ используется</segment>
		<segment id="108" parent="107" relname="purpose">для управления источником излучения (ИИ).</segment>
		<segment id="109" parent="235" relname="elaboration">В состав БУИИ входят микроконтроллер (МК2), модуль интерфейса (МИ2) и схема реализации широт-но-импульсной модуляции (ШИМ).</segment>
		<segment id="110" parent="236" relname="span">БПОИ предназначен</segment>
		<segment id="111" parent="110" relname="purpose">для формирования видеокадра и получения промежуточных измерительных данных.</segment>
		<segment id="112" parent="179" relname="same-unit">В состав БПОИ входят аналого-цифровой преобразователь (АЦП), преобразующий аналоговый сигнал с ТВД в цифровой для последующей обработки, оперативное запоминающее устройство (ОЗУ), предназначенное для хранения видеоданных,</segment>
		<segment id="113" parent="178" relname="span">блок управления памятью (БУП)</segment>
		<segment id="114" parent="177" relname="span">(введен в схему,</segment>
		<segment id="115" parent="114" relname="cause">так как используемый управляющий микроконтроллер (МК1) не имеет возможности обращения к внешней памяти),</segment>
		<segment id="116" parent="179" relname="same-unit">модуль интерфейса (МИ1).</segment>
		<segment id="117" parent="180" relname="joint">В рассматриваемой системе ОЭИП осуществляет предварительную обработку изображения, сформированного оптическим излучением, отраженным от КЭ, и передачу измерительной информации по последовательному каналу передачи в ПЭВМ.</segment>
		<segment id="118" parent="180" relname="joint">КЭ подсвечивается ИИ, управляемой через БУИИ ПЭВМ.</segment>
		<segment id="119" parent="214" relname="elaboration">[Рис. 3. Структурная схема ОЭСКД]</segment>
		<segment id="120" parent="121" relname="evidence">Проведенные исследования показали,</segment>
		<segment id="121" parent="239" relname="span">что экспериментальные значения погрешности хорошо согласуются с расчетными [5].</segment>
		<segment id="122" parent="182" relname="joint">Систематическая составляющая погрешности составляет 0,221 мм на дистанции 2 м и 0,0153 мм на дистанции 5,8 м.</segment>
		<segment id="123" parent="182" relname="joint">Вариация показаний прибора на дистанции 2 м составляет 0,0027 мм и 0,004 мм на дистанции 5,8 м.</segment>
		<segment id="124" parent="182" relname="joint">СКО случайной составляющей основной погрешности составляет 0,0017 мм и 0,003 мм на дистанции 2 м и 5,8 м, соответственно [5].</segment>
		<segment id="125" parent="183" relname="elaboration">Данная работа выполнена в рамках гранта молодых кандидатов наук вузов и академических институтов, расположенных на территории Санкт-Петербурга, 2005 г.</segment>
		<segment id="126" parent="186" relname="preparation">Заключение</segment>
		<segment id="127" parent="185" relname="joint">Изложены принципы построения распределенных оптико-электронных систем, обеспечивающих автоматизированный многоточечный непрерывный контроль параметров наблюдаемого объекта.</segment>
		<segment id="128" parent="185" relname="joint">Проведены экспериментальные исследования макетов измерительных каналов распределенных ОЭСКД.</segment>
		<segment id="129" >Литература</segment>
		<segment id="130" >1\. Андреев А.Л., Коняхин И.А., Коротаев В.В., Мусяков В.Л., Панков Э.Д., Тимофеев А.Н. Проблемы создания оптико-электронных систем для определения взаимного положения разнесенных в пространстве объектов или их элементов. // Оптический журнал. 1995. № 5. С.8-12. 2\. Иванов А.Г., Коротаев В.В., Краснящих А.В. О построении оптико-электронных систем контроля прогиба. // Научно-технический вестник СПб ГИТМО (ТУ). Выпуск 5. Оптические приборы, системы и технологии / Главный редактор В.Н. Васильев. СПб: СПб ГИТМО(ТУ), 2002. С. 100-104. 3\. Краснящих А.В. Исследование возможности создания адаптивной оптико- электронной системы измерения деформаций крупногабаритных инженерных сооружений. // Седьмая Санкт-Петербургская ассамблея молодых ученых и специалистов. Аннотации работ по грантам Санкт-Петербургского конкурса 2002 г. СПб: Изд-во С.-Петерб. ун-та, 2002. 120 с. 4\. Крайлюк А.Д., Краснящих А.В., Мусяков В.Л., Тимофеев А.Н., Ярышев С.Н. Оптико-электронная система контроля положения центра корпусных деталей турбоагрегатов относительно оптической оси. // Изв. вузов. Приборостроение. 2003. Т. 46. №8. С. 61-63. 5\. Коротаев В.В, Краснящих А.В. Исследование макета оптико-электронной системы контроля деформации крупногабаритных инженерных сооружений. // V Международная конференция «Прикладная оптика» 15-17 октября 2002 г. Санкт- Петербург. Россия. Сборник трудов. Т.1. Оптическое приборостроение. СПб: Труды оптического общества им. Д.С. Рождественского, 2002. С. 70-74.</segment>
		<group id="131" type="span" parent="210" relname="preparation"/>
		<group id="132" type="multinuc" parent="209" relname="span"/>
		<group id="133" type="span" parent="134" relname="joint"/>
		<group id="134" type="multinuc" />
		<group id="135" type="multinuc" parent="137" relname="joint"/>
		<group id="136" type="multinuc" parent="137" relname="joint"/>
		<group id="137" type="multinuc" parent="198" relname="span"/>
		<group id="138" type="multinuc" />
		<group id="139" type="span" parent="143" relname="joint"/>
		<group id="140" type="multinuc" parent="142" relname="joint"/>
		<group id="141" type="span" parent="140" relname="same-unit"/>
		<group id="142" type="multinuc" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="172" relname="joint"/>
		<group id="144" type="multinuc" parent="30" relname="purpose"/>
		<group id="145" type="multinuc" parent="172" relname="joint"/>
		<group id="146" type="multinuc" parent="204" relname="span"/>
		<group id="147" type="span" parent="204" relname="elaboration"/>
		<group id="148" type="multinuc" parent="149" relname="span"/>
		<group id="149" type="span" parent="150" relname="span"/>
		<group id="150" type="span" parent="205" relname="span"/>
		<group id="151" type="span" />
		<group id="152" type="span" parent="155" relname="same-unit"/>
		<group id="153" type="span" parent="155" relname="same-unit"/>
		<group id="154" type="multinuc" parent="50" relname="elaboration"/>
		<group id="155" type="multinuc" parent="193" relname="contrast"/>
		<group id="156" type="span" parent="157" relname="joint"/>
		<group id="157" type="multinuc" />
		<group id="158" type="multinuc" parent="225" relname="span"/>
		<group id="159" type="multinuc" parent="158" relname="joint"/>
		<group id="160" type="multinuc" parent="73" relname="elaboration"/>
		<group id="161" type="span" parent="158" relname="joint"/>
		<group id="162" type="multinuc" parent="228" relname="joint"/>
		<group id="163" type="span" parent="164" relname="same-unit"/>
		<group id="164" type="multinuc" parent="165" relname="sequence"/>
		<group id="165" type="multinuc" parent="171" relname="joint"/>
		<group id="166" type="span" parent="92" relname="purpose"/>
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="196" relname="contrast"/>
		<group id="169" type="span" parent="170" relname="joint"/>
		<group id="170" type="multinuc" parent="89" relname="elaboration"/>
		<group id="171" type="multinuc" />
		<group id="172" type="multinuc" parent="211" relname="span"/>
		<group id="173" type="multinuc" parent="174" relname="span"/>
		<group id="174" type="span" parent="175" relname="span"/>
		<group id="175" type="span" parent="215" relname="span"/>
		<group id="176" type="span" parent="181" relname="joint"/>
		<group id="177" type="span" parent="113" relname="elaboration"/>
		<group id="178" type="span" parent="179" relname="same-unit"/>
		<group id="179" type="multinuc" parent="236" relname="elaboration"/>
		<group id="180" type="multinuc" parent="214" relname="span"/>
		<group id="181" type="multinuc" />
		<group id="182" type="multinuc" parent="183" relname="span"/>
		<group id="183" type="span" parent="184" relname="span"/>
		<group id="184" type="span" parent="238" relname="span"/>
		<group id="185" type="multinuc" parent="186" relname="span"/>
		<group id="186" type="span" parent="187" relname="span"/>
		<group id="187" type="span" />
		<group id="188" type="span" parent="228" relname="joint"/>
		<group id="189" type="span" parent="170" relname="joint"/>
		<group id="190" type="multinuc" parent="191" relname="span"/>
		<group id="191" type="span" parent="16" relname="purpose"/>
		<group id="192" type="span" parent="193" relname="contrast"/>
		<group id="193" type="multinuc" />
		<group id="194" type="multinuc" parent="157" relname="joint"/>
		<group id="195" type="span" parent="206" relname="span"/>
		<group id="196" type="multinuc" parent="170" relname="joint"/>
		<group id="197" type="span" parent="196" relname="contrast"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" />
		<group id="200" type="span" parent="198" relname="elaboration"/>
		<group id="201" type="span" parent="138" relname="joint"/>
		<group id="202" type="span" parent="172" relname="joint"/>
		<group id="203" type="span" parent="172" relname="joint"/>
		<group id="204" type="span" parent="203" relname="span"/>
		<group id="205" type="span" />
		<group id="206" type="span" parent="194" relname="contrast"/>
		<group id="207" type="span" parent="134" relname="joint"/>
		<group id="208" type="span" />
		<group id="209" type="span" parent="210" relname="span"/>
		<group id="210" type="span" />
		<group id="211" type="span" parent="212" relname="span"/>
		<group id="212" type="span" />
		<group id="213" type="span" parent="181" relname="joint"/>
		<group id="214" type="span" parent="213" relname="span"/>
		<group id="215" type="span" />
		<group id="216" type="multinuc" parent="59" relname="concession"/>
		<group id="217" type="span" parent="218" relname="same-unit"/>
		<group id="218" type="multinuc" parent="63" relname="evidence"/>
		<group id="219" type="span" parent="223" relname="preparation"/>
		<group id="220" type="span" parent="222" relname="joint"/>
		<group id="221" type="span" parent="222" relname="joint"/>
		<group id="222" type="multinuc" parent="223" relname="span"/>
		<group id="223" type="span" parent="224" relname="span"/>
		<group id="224" type="span" />
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" />
		<group id="227" type="span" parent="160" relname="joint"/>
		<group id="228" type="multinuc" parent="171" relname="joint"/>
		<group id="229" type="span" parent="230" relname="joint"/>
		<group id="230" type="multinuc" parent="171" relname="joint"/>
		<group id="231" type="multinuc" />
		<group id="232" type="span" parent="231" relname="contrast"/>
		<group id="233" type="span" parent="234" relname="span"/>
		<group id="234" type="span" parent="173" relname="joint"/>
		<group id="235" type="span" parent="176" relname="span"/>
		<group id="236" type="span" parent="237" relname="span"/>
		<group id="237" type="span" parent="181" relname="joint"/>
		<group id="238" type="span" />
		<group id="239" type="span" parent="184" relname="preparation"/>
	</body>
</rst>