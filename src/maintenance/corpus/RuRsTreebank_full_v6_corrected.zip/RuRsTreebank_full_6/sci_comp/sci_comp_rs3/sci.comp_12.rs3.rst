<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >ИНФОРМАТИКА В ТЕХНИЧЕСКИХ СИСТЕМАХ</segment>
		<segment id="2" >УДК 62.50:681.2(045)</segment>
		<segment id="3" parent="4" relname="attribution">Н. А. Дударенко, О. С. Нуйя-Осипцева, А. В. Ушаков, М. И. Филиппов</segment>
		<segment id="4" parent="128" relname="span">УПРАВЛЕНИЕ ОДНОКАНАЛЬНЫМИ ОБЪЕКТАМИ С ПОМОЩЬЮ СКАЛЯРНОГО ДВОИЧНОГО КАНАЛА СВЯЗИ</segment>
		<segment id="5" >Рассмотрены способы формирования модельных представлений в задачах построения цифрового дистанционного управления техническими объектами типа „многомерный вход—многомерный выход". Представлены методики и перспективные направления решения указанных проблем. Ключевые слова: цифровое дистанционное управление, канал связи, размерность системы.</segment>
		<segment id="6" parent="158" relname="joint">Введение.</segment>
		<segment id="7" parent="158" relname="joint">Постановка задачи.</segment>
		<segment id="8" parent="9" relname="preparation">В задачах дистанционного управления используются современные сетевые технологии.</segment>
		<segment id="9" parent="204" relname="span">На пути проектировщиков таких систем встает ряд довольно сложных проблем.</segment>
		<segment id="10" parent="131" relname="background">В настоящей статье рассматриваются проблемы цифрового дистанционного управления линейными непрерывными объектами, связанными c регулятором цифровой сетью произвольной структуры.</segment>
		<segment id="11" parent="129" relname="joint">Предполагается использование сетевой технологии Industrial Ethernet или близкой к ней по характеристикам.</segment>
		<segment id="12" parent="129" relname="joint">Представленные в статье варианты построения цифрового дистанционного управления (ЦДУ) позволят создавать дискретные модели процессов, протекающих в системах автоматического управления дистанционно рассредоточенными объектами типа „многомерный вход—многомерный выход" (МВМВ).</segment>
		<segment id="13" parent="206" relname="preparation">Будем рассматривать системы управления множеством дистанционно рассредоточенных объектов, связанных с регулятором посредством цифрового дистанционного последовательного (скалярного) канала связи типа „дуплекс".</segment>
		<segment id="14" parent="133" relname="sequence">Начнем рассмотрение с объектов управления типа „одномерный вход—одномерный выход" (ОВОВ),</segment>
		<segment id="15" parent="133" relname="sequence">затем, модифицировав полученные результаты,</segment>
		<segment id="16" parent="133" relname="sequence">перенесем их на объекты МВМВ-типа.</segment>
		<segment id="17" parent="134" relname="span">Определим проблемы, возникающие при синтезе ЦДУ и модельных представлений.</segment>
		<segment id="18" parent="135" relname="span">Структура рассматриваемой системы представлена на рис. 1</segment>
		<segment id="19" parent="18" relname="elaboration">(здесь ОУ — объект управления, Н — наблюдатель, Р — регулятор, ПК — преобразователь кодов, ОКС — обратный канал связи, ПКС — прямой канал связи).</segment>
		<segment id="20" parent="208" relname="preparation">ЦДУ в системе „одномерный вход—одномерный выход".</segment>
		<segment id="21" parent="208" relname="span">При цифровом дистанционном управлении могут возникать следующие проблемы.</segment>
		<segment id="22" parent="192" relname="span">1\. Необходимость использовать наблюдатель вектора состояния объекта.</segment>
		<segment id="23" parent="24" relname="condition">Даже если состояние объекта управления полностью измеримо,</segment>
		<segment id="24" parent="136" relname="span">скалярное описание дискретного канала связи (ДКС) позволяет использовать наблюдатель.</segment>
		<segment id="25" parent="26" relname="cause">Еще одной причиной использования подобной структуры системы управления</segment>
		<segment id="26" parent="137" relname="span">является упрощение конструкции,</segment>
		<segment id="27" parent="137" relname="cause">так как в ином случае для каждого состояния объекта управления потребовался бы отдельный канал связи.</segment>
		<segment id="28" parent="210" relname="span">2\. Увеличение размерности дискретной модели среды ЦДУ</segment>
		<segment id="29" parent="212" relname="span">в связи с необходимостью преобразования двоичных кодов типа „параллельный—последовательный", и наоборот (рис. 2).</segment>
		<segment id="30" parent="211" relname="span">3\. Необходимость использования помехозащищенных кодов (ПЗК) в режиме исправления ошибок</segment>
		<segment id="31" parent="30" relname="cause">из-за наличия помех в прямом и обратном каналах связи системы управления.</segment>
		<segment id="32" parent="29" relname="elaboration">[формула] [Рис. 1] [Рис. 2]</segment>
		<segment id="33" parent="151" relname="background">Системы с подобной структурой и их модельные представления были рассмотрены в статье [1].</segment>
		<segment id="34" parent="146" relname="joint">Преобразование аналоговых сигналов в цифровые и обратно, кодирование этих сигналов с использованием ПЗК требует времени.</segment>
		<segment id="35" parent="213" relname="span">Для учета временных затрат</segment>
		<segment id="36" parent="35" relname="purpose">вводится агрегированный интервал дискретности</segment>
		<segment id="37" parent="141" relname="span">[формула],</segment>
		<segment id="38" parent="37" relname="elaboration">где [символ] — длительность бита кода, [символ] и [символ] — число информационных и проверочных разрядов соответственно.</segment>
		<segment id="39" parent="143" relname="span">Размерность объекта управления в целом возрастает,</segment>
		<segment id="40" parent="142" relname="sequence">так как требуется построить модели прямого и обратного каналов связи,</segment>
		<segment id="41" parent="145" relname="span">после чего получить общее модельное представление „канальная среда—объект управления" размерностью</segment>
		<segment id="42" parent="144" relname="span">п+2,</segment>
		<segment id="43" parent="42" relname="elaboration">где п — размерность исходного непрерывного линейного объекта.</segment>
		<segment id="44" parent="150" relname="span">Таким образом, система становится совокупностью прямого канала связи, дискретного представления объекта управления и обратного канала связи:</segment>
		<segment id="45" parent="147" relname="joint">[формула] (1)</segment>
		<segment id="46" parent="149" relname="span">[формула] (2)</segment>
		<segment id="47" parent="148" relname="span">где матрицы А, В, С рассчитываются в соответствии со следующими соотношениями:</segment>
		<segment id="48" parent="47" relname="elaboration">[формула], (3)</segment>
		<segment id="49" parent="214" relname="joint">А, В, С — матрицы исходной непрерывной модели в форме „вход—состояние—выход".</segment>
		<segment id="50" parent="150" relname="elaboration">Отметим, что передаточные функции для ПКС и ОКС представляют собой простейшую задержку [символ] на интервал дискретности, равный [символ].</segment>
		<segment id="51" parent="153" relname="span">Полученная таким образом агрегированная дискретная система управления будет иметь следующий вид:</segment>
		<segment id="52" parent="154" relname="span">[формула],  (4)</segment>
		<segment id="53" parent="52" relname="elaboration">для которой вектор состояния [формула] размерности [формула].</segment>
		<segment id="54" parent="156" relname="span">Матрицы Аа, Ва, Са, Са формируются в следующем виде:</segment>
		<segment id="55" parent="155" relname="joint">[формула], (5)</segment>
		<segment id="56" parent="155" relname="joint">[формула]  (6)</segment>
		<segment id="57" parent="217" relname="joint">На основе данной модели формируется модальное управление в форме матрицы линейных стационарных обратных связей.</segment>
		<segment id="58" parent="218" relname="span">Задача учета фактора помех в каналах связи решается стандартными средствами теории помехозащитного кодирования из условия задания допустимой вероятности искажения бита посылки и кратности исправляемой ошибки.</segment>
		<segment id="59" parent="60" relname="condition">Расширяя код посылки за счет введения проверочных разрядов,</segment>
		<segment id="60" parent="157" relname="span">можно увеличить агрегированный интервал дискретности [символ] полученной модели.</segment>
		<segment id="61" parent="202" relname="preparation">ЦДУ в системе „многомерный вход—многомерный выход".</segment>
		<segment id="62" parent="195" relname="contrast">Следует отметить, что проблемы, освещенные ранее, актуальны и для систем управления класса МВМВ- типа.</segment>
		<segment id="63" parent="195" relname="contrast">Однако возникают и некоторые другие проблемы, связанные с особенностями данных систем.</segment>
		<segment id="64" parent="199" relname="preparation">Для начала рассмотрим возможность организации передачи вектора управляющих воздействий с помощью последовательного (скалярного) канала связи.</segment>
		<segment id="65" parent="198" relname="evidence">По определению, объекты МВМВ-типа имеют несколько точек приложения управляющих воздействий,</segment>
		<segment id="66" parent="197" relname="comparison">следовательно, передавать необходимо не скалярное управление и,</segment>
		<segment id="67" parent="197" relname="comparison">как это было в предыдущем случае,</segment>
		<segment id="68" parent="162" relname="same-unit">а вектор управления [формула].</segment>
		<segment id="69" parent="220" relname="span">Простейший способ организации передачи вектора управления по последовательному каналу связи заключается в разделении сеанса (времени) доступа к линии связи между его элементами.</segment>
		<segment id="70" parent="69" relname="elaboration">Данная структура посылки без служебной информации, присущей конкретному протоколу, представлена на рис. 3.</segment>
		<segment id="71" parent="219" relname="comparison">Таким же образом следует организовать обратный канал связи к наблюдателю.</segment>
		<segment id="72" parent="163" relname="joint">Если одной посылки не хватает для передачи всего вектора управления</segment>
		<segment id="73" parent="163" relname="joint">или если требуется доставить управляющее воздействие различным адресатам (при маршрутизации посылки),</segment>
		<segment id="74" parent="164" relname="span">то следует передавать его за несколько сеансов,</segment>
		<segment id="75" parent="165" relname="span">что приводит к увеличению времени, за которое объект отреагирует на сигнал.</segment>
		<segment id="76" parent="75" relname="elaboration">[Рис. 3]</segment>
		<segment id="77" parent="222" relname="span">Рассмотрим вопросы модельного представления системы управления с ОУ МВМВ-типа.</segment>
		<segment id="78" parent="221" relname="contrast">Как и при представлении системы „одномерный вход—одномерный выход", будем агрегировать канал связи и дискретное описание ОУ.</segment>
		<segment id="79" parent="223" relname="span">Однако в данном случае имеет место более сложная структура цифровой сети и самого ОУ.</segment>
		<segment id="80" parent="167" relname="condition">Если бы речь шла о соединении регулятора и ОУ типа „точка в точку",</segment>
		<segment id="81" parent="167" relname="span">можно было бы представлять систему так же,</segment>
		<segment id="82" parent="81" relname="elaboration">как это делается для случая ОВОВ.</segment>
		<segment id="83" parent="170" relname="joint">Однако в многомерных распределенных системах управления имеет место сложная структура цифровой сети, требующая маршрутизации посылки для доставки управляющих воздействий нужному адресату.</segment>
		<segment id="84" parent="235" relname="same-unit">Более того,</segment>
		<segment id="85" parent="233" relname="attribution">как отмечалось ранее,</segment>
		<segment id="86" parent="233" relname="span">вполне вероятным кажется вариант,</segment>
		<segment id="87" parent="86" relname="condition">когда весь управляющий вектор не поместится в одну „посылку".</segment>
		<segment id="88" parent="171" relname="span">Таким образом, очевидно, что предыдущее модельное представление неадекватно.</segment>
		<segment id="89" parent="90" relname="purpose">Для представления каждого канала управления многомерной распределенной системы</segment>
		<segment id="90" parent="225" relname="span">будем использовать модель, учитывающую запаздывание ЭВМ [2].</segment>
		<segment id="91" parent="172" relname="span">В данной модели управляющее воздействие остается в памяти канала на один такт:</segment>
		<segment id="92" parent="173" relname="span">[формула],  (7)</segment>
		<segment id="93" parent="92" relname="elaboration">где [формула] — значение i-го управляющего воздействия, принятого в момент времени [формула], [символ] — запаздывание, с которым управляющее воздействие поступает в канал управления, [символ] — интервал дискретности.</segment>
		<segment id="94" parent="174" relname="span">Будем считать [формула],</segment>
		<segment id="95" parent="94" relname="elaboration">что соответствует запоминанию управляющего воздействия на один такт.</segment>
		<segment id="96" parent="175" relname="joint">Интервал дискретности Т задается как медианная составляющая интервала [символ] оценок задержек на передачу и обработку информации в прямом и обратном каналах связи.</segment>
		<segment id="97" parent="176" relname="span">Задавая таким образом управляющее воздействие, запишем основное уравнение для одного канала управления многомерной системы:</segment>
		<segment id="98" parent="97" relname="elaboration">[формула], (8) [формула], (9) [формула], (10) [формула], (11) [формула]. (12)</segment>
		<segment id="99" parent="177" relname="span">Таким образом, разностное уравнение для одного канала агрегированного ОУ примет следующий вид:</segment>
		<segment id="100" parent="178" relname="span">[формула] (13) или [формула]. (14)</segment>
		<segment id="101" parent="179" relname="span">Уравнение (13) описывает канал управления с запаздыванием, структурная схема которого представлена на рис. 4.</segment>
		<segment id="102" parent="101" relname="elaboration">[Рис. 4]</segment>
		<segment id="103" parent="184" relname="background">Обратим внимание на увеличение размерности и проблему вычислительной устойчивости матричного уравнения подобия (Сильвестра).</segment>
		<segment id="104" parent="181" relname="evidence">Из уравнений (11), (12) видно, что каждый агрегированный канал многомерного ОУ увеличивает размерность.</segment>
		<segment id="105" parent="181" relname="span">Таким образом, после учета свойств канальной среды в ПКС и агрегирования с ОКС размерность модели многомерного ОУ станет больше на r,</segment>
		<segment id="106" parent="105" relname="elaboration">где r — размерность вектора управления исходного объекта.</segment>
		<segment id="107" parent="183" relname="span">В связи с этим встает проблема решения уравнения подобия типа Сильвестра для формирования модального управления</segment>
		<segment id="108" parent="107" relname="elaboration">(математические пакеты типа MatLab дают адекватное решение уравнения Сильвестра для систем размерностью [формула].</segment>
		<segment id="109" parent="187" relname="joint">Рассмотрим теперь проблему задержек в каналах связи и возможность ее минимизации.</segment>
		<segment id="110" parent="111" relname="purpose">Для минимизации задержек в ПКС и ОКС</segment>
		<segment id="111" parent="224" relname="span">требуется сократить размеры передаваемой информации.</segment>
		<segment id="112" parent="186" relname="same-unit">В работах [3, 4] предлагается ряд приемов по решению данной проблемы: передача не полных значений управляющих воздействий [символ], а только их приращений [символ] (к  примеру, по три бита); создание специальных конечномерных наблюдателей, определяющих попадание параметров в определенный интервал из конечного множества интервалов значений; спорадический характер передачи в ОКС и ПКС; динамическое перераспределение</segment>
		<segment id="113" parent="188" relname="restatement">управляющих воздействий,</segment>
		<segment id="114" parent="188" relname="restatement">т. е. передача тех воздействий, которые более важны на данный момент.</segment>
		<segment id="115" parent="226" relname="span">Еще одним возможным решением задачи сокращения трафика может быть перенос управляющей логики ближе к ОУ и передача не вектора управляющих воздействий, а программы управления для локального регулятора, скажем, в виде вектора собственных чисел эталонной системы.</segment>
		<segment id="116" parent="115" relname="elaboration">Размер данных при этом остается тем же, но частота сеансов связи значительно уменьшается.</segment>
		<segment id="117" parent="229" relname="preparation">Заключение.</segment>
		<segment id="118" parent="227" relname="span">Минимизация задержек отмеченными способами в каналах связи</segment>
		<segment id="119" parent="118" relname="purpose">позволят улучшить качество синтезированного управления.</segment>
		<segment id="120" parent="231" relname="evidence">Анализ задачи построения ЦДУ дистанционно рассредоточенными многомерными объектами показал,</segment>
		<segment id="121" parent="231" relname="span">что для решения выявленных проблем</segment>
		<segment id="122" parent="121" relname="purpose">достаточно возможностей аппарата пространства состояний.</segment>
		<segment id="123" parent="124" relname="preparation">список литературы</segment>
		<segment id="124" >1\. Боженкова Н. Ю., Осипцева О. С., Ушаков А. В. Фактор канальной среды в задаче синтеза цифрового дистанционного управления непрерывным объектом // Изв. вузов. Приборостроение. 2008. Т. 51, № 3. С. 21—25. 2\. Синтез дискретных регуляторов при помощи ЭВМ / В. В. Григорьев, В. Н. Дроздов, В. В. Лаврентьев, А. В. Ушаков. Л.: Машиностроение, 1983. 3\. Goodwin G. C., Haimovich H., Quevedo D. E., Welsh J. S. A moving horizon approach to networked control system design // IEEE Transact. on Automatic Control. 2004. Помехозащитное декодирование систематических кодов 77 4\. Quevedo D. E., Goodwin G. C., Welsh J. S. Minimizing down-link traffic in networked control systems via optimal control techniques // Proc. of 42nd IEEE Conf. on Decision and Control. Maui, Hawaii, USA, 2003.</segment>
		<segment id="125" parent="190" relname="span">Наталия Александровна Дударенко Ольга Святославовна Нуйя-Осипцева Анатолий Владимирович Ушаков Максим Игоревич Филиппов</segment>
		<segment id="126" parent="125" relname="elaboration">Рекомендована кафедрой систем управления и информатики</segment>
		<segment id="127" parent="190" relname="elaboration">Сведения об авторах канд. техн. наук, доцент; Санкт-Петербургский государственный университет информационных технологий, механики и оптики, кафедра систем управления и информатики; E-mail: dudarenko@yandex.ru канд. техн. наук; фирма Siemens, Санкт-Петербург; ведущий специалист д-р техн. наук, профессор; Санкт-Петербургский государственный университет информационных технологий, механики и оптики, кафедра систем управления и информатики; E-mail:Ushakov-AVG@yandex.ru студент; Санкт-Петербургский государственный университет информационных технологий, механики и оптики, кафедра систем управления и информатики Поступила в редакцию 01.07.09 г.</segment>
		<group id="128" type="span" parent="161" relname="preparation"/>
		<group id="129" type="multinuc" parent="131" relname="span"/>
		<group id="130" type="multinuc" parent="206" relname="span"/>
		<group id="131" type="span" parent="132" relname="span"/>
		<group id="132" type="span" parent="159" relname="joint"/>
		<group id="133" type="multinuc" parent="130" relname="joint"/>
		<group id="134" type="span" parent="130" relname="joint"/>
		<group id="135" type="span" parent="17" relname="elaboration"/>
		<group id="136" type="span" parent="193" relname="joint"/>
		<group id="137" type="span" parent="194" relname="span"/>
		<group id="138" type="span" parent="139" relname="joint"/>
		<group id="139" type="multinuc" parent="21" relname="elaboration"/>
		<group id="140" type="span" parent="146" relname="joint"/>
		<group id="141" type="span" parent="213" relname="elaboration"/>
		<group id="142" type="multinuc" parent="39" relname="cause"/>
		<group id="143" type="span" parent="215" relname="evidence"/>
		<group id="144" type="span" parent="41" relname="elaboration"/>
		<group id="145" type="span" parent="142" relname="sequence"/>
		<group id="146" type="multinuc" parent="151" relname="span"/>
		<group id="147" type="multinuc" parent="44" relname="elaboration"/>
		<group id="148" type="span" parent="214" relname="joint"/>
		<group id="149" type="span" parent="147" relname="joint"/>
		<group id="150" type="span" parent="215" relname="span"/>
		<group id="151" type="span" parent="152" relname="span"/>
		<group id="152" type="span" />
		<group id="153" type="span" parent="217" relname="joint"/>
		<group id="154" type="span" parent="51" relname="elaboration"/>
		<group id="155" type="multinuc" parent="54" relname="elaboration"/>
		<group id="156" type="span" parent="217" relname="joint"/>
		<group id="157" type="span" parent="58" relname="elaboration"/>
		<group id="158" type="multinuc" parent="204" relname="preparation"/>
		<group id="159" type="multinuc" parent="160" relname="span"/>
		<group id="160" type="span" parent="161" relname="span"/>
		<group id="161" type="span" />
		<group id="162" type="multinuc" parent="198" relname="span"/>
		<group id="163" type="multinuc" parent="74" relname="condition"/>
		<group id="164" type="span" parent="165" relname="cause"/>
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" />
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="196" relname="contrast"/>
		<group id="170" type="multinuc" parent="196" relname="contrast"/>
		<group id="171" type="span" parent="79" relname="elaboration"/>
		<group id="172" type="span" parent="175" relname="joint"/>
		<group id="173" type="span" parent="91" relname="elaboration"/>
		<group id="174" type="span" parent="175" relname="joint"/>
		<group id="175" type="multinuc" />
		<group id="176" type="span" parent="177" relname="evidence"/>
		<group id="177" type="span" parent="180" relname="span"/>
		<group id="178" type="span" parent="99" relname="elaboration"/>
		<group id="179" type="span" parent="100" relname="elaboration"/>
		<group id="180" type="span" />
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" parent="183" relname="cause"/>
		<group id="183" type="span" parent="184" relname="span"/>
		<group id="184" type="span" parent="185" relname="span"/>
		<group id="185" type="span" />
		<group id="186" type="multinuc" parent="187" relname="joint"/>
		<group id="187" type="multinuc" parent="189" relname="joint"/>
		<group id="188" type="multinuc" parent="186" relname="same-unit"/>
		<group id="189" type="multinuc" />
		<group id="190" type="span" parent="191" relname="span"/>
		<group id="191" type="span" />
		<group id="192" type="span" parent="138" relname="span"/>
		<group id="193" type="multinuc" parent="192" relname="elaboration"/>
		<group id="194" type="span" parent="193" relname="joint"/>
		<group id="195" type="multinuc" parent="202" relname="span"/>
		<group id="196" type="multinuc" parent="88" relname="evidence"/>
		<group id="197" type="multinuc" parent="162" relname="same-unit"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" />
		<group id="202" type="span" parent="203" relname="span"/>
		<group id="203" type="span" parent="200" relname="preparation"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="160" relname="preparation"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="159" relname="joint"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" />
		<group id="210" type="span" parent="139" relname="joint"/>
		<group id="211" type="span" parent="139" relname="joint"/>
		<group id="212" type="span" parent="28" relname="cause"/>
		<group id="213" type="span" parent="140" relname="span"/>
		<group id="214" type="multinuc" parent="46" relname="elaboration"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" />
		<group id="217" type="multinuc" />
		<group id="218" type="span" />
		<group id="219" type="multinuc" />
		<group id="220" type="span" parent="219" relname="comparison"/>
		<group id="221" type="multinuc" parent="77" relname="elaboration"/>
		<group id="222" type="span" />
		<group id="223" type="span" parent="221" relname="contrast"/>
		<group id="224" type="span" parent="187" relname="joint"/>
		<group id="225" type="span" parent="175" relname="joint"/>
		<group id="226" type="span" parent="189" relname="joint"/>
		<group id="227" type="span" parent="228" relname="joint"/>
		<group id="228" type="multinuc" parent="229" relname="span"/>
		<group id="229" type="span" parent="230" relname="span"/>
		<group id="230" type="span" />
		<group id="231" type="span" parent="232" relname="span"/>
		<group id="232" type="span" parent="228" relname="joint"/>
		<group id="233" type="span" parent="234" relname="span"/>
		<group id="234" type="span" parent="235" relname="same-unit"/>
		<group id="235" type="multinuc" parent="170" relname="joint"/>
	</body>
</rst>