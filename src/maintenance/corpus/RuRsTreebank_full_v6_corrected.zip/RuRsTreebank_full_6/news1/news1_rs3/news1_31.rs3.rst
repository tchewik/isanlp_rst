<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >##### Административный суд Кёльна снял с последнего альбома немецкой индастриал-метал группы Rammstein «Liebe ist für alle da» все ограничения на реализацию.</segment>
		<segment id="2" parent="26" relname="span">Суд счёл необоснованными запрет на продажу альбома лицам до восемнадцати лет и цензуру обложки,</segment>
		<segment id="3" parent="2" relname="elaboration">которые были введены осенью прошлого года.</segment>
		<segment id="4" parent="37" relname="span">##### «Liebe ist für alle da» подвергся цензуре в ноябре 2009 года,</segment>
		<segment id="5" parent="6" relname="attribution">когда Немецким Федеральным Комитетом по Оценке СМИ</segment>
		<segment id="6" parent="38" relname="span">обложка диска была названа пропагандирующей садомазохизм.</segment>
		<segment id="7" parent="8" relname="cause-effect">##### К тому же неприличным был объявлен текст песни «Ich tu dir weh»,</segment>
		<segment id="8" >в результате чего композицию запретили для исполнения на публике.</segment>
		<segment id="9" parent="29" relname="span">##### Суд Кёльна выносил вердикт,</segment>
		<segment id="10" parent="9" relname="evidence">ссылаясь на отсутствие в песнях непосредственного упоминания действий насильственного характера.</segment>
		<segment id="11" parent="28" relname="span">Также доводом в пользу снятия запретных мер стало то,</segment>
		<segment id="12" parent="11" relname="evidence">что предыдущее решение не поясняло причин пагубного влияния описания садомазохизма на молодёжь.</segment>
		<segment id="13" parent="27" relname="joint">Таким образом, постановление суда разрешает распространение пластинки в прозрачной упаковке</segment>
		<segment id="14" parent="27" relname="joint">и даёт возможность покупать её детям младше восемнадцати лет.</segment>
		<segment id="15" parent="41" relname="cause-effect">##### Тем не менее, вердикт носит временный характер.</segment>
		<segment id="16" parent="40" relname="same-unit">Это связано с тем,</segment>
		<segment id="17" parent="18" relname="attribution">что Комитет по Оценке СМИ решил</segment>
		<segment id="18" parent="39" relname="span">опротестовать решение Кёльнского суда.</segment>
		<segment id="19" parent="35" relname="span">По предварительным оценкам на процесс может уйти не менее полугода.</segment>
		<segment id="20" parent="33" relname="span">В этот период планируется продавать альбом в обычном режиме,</segment>
		<segment id="21" parent="20" relname="elaboration">т.е без каких бы то ни было ограничений.</segment>
		<segment id="22" >##### Кроме того, стоит отметить, что в феврале 2010 года Rammstein стали объектом жёсткой критики со стороны белорусских властей.</segment>
		<segment id="23" parent="22" relname="elaboration">Тогда в преддверии минского концерта группы Общественный совет по нравственности и Министерство культуры Белоруссии заподозрили немецких металлистов в пропаганде насилия, сексуальных извращений и нацизма.</segment>
		<segment id="24" >##### Тем не менее раннее творчество Rammstein не вызывало столь критичного отношения со стороны государственных органов,</segment>
		<segment id="25" parent="24" relname="concession">несмотря на присутствие в нём темы сексуального насилия.</segment>
		<group id="26" type="span" parent="1" relname="elaboration"/>
		<group id="27" type="multinuc" parent="32" relname="span"/>
		<group id="28" type="span" parent="30" relname="joint"/>
		<group id="29" type="span" parent="30" relname="joint"/>
		<group id="30" type="multinuc" parent="31" relname="span"/>
		<group id="31" type="span" />
		<group id="32" type="span" parent="31" relname="interpretation-evaluation"/>
		<group id="33" type="span" parent="19" relname="elaboration"/>
		<group id="35" type="span" parent="36" relname="joint"/>
		<group id="36" type="multinuc" />
		<group id="37" type="span" />
		<group id="38" type="span" parent="4" relname="elaboration"/>
		<group id="39" type="span" parent="40" relname="same-unit"/>
		<group id="40" type="multinuc" parent="41" relname="span"/>
		<group id="41" type="span" parent="42" relname="span"/>
		<group id="42" type="span" parent="36" relname="joint"/>
	</body>
</rst>