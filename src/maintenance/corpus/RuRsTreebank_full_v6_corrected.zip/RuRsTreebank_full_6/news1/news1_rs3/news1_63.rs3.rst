<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="2" relname="attribution">##### Руководство социальной сети «ВКонтакте» опровергло</segment>
		<segment id="2" parent="110" relname="span">появившуюся в СМИ информацию об уходе Павла Дурова с поста генерального директора.</segment>
		<segment id="3" parent="110" relname="attribution">Об этом в своем твиттере 20 января сообщил пресс-секретарь «ВКонтакте» Георгий Лобушкин.</segment>
		<segment id="4" parent="58" relname="span">##### Павел @durov НЕ покидал пост генерального директора»</segment>
		<segment id="5" parent="4" relname="attribution">написал Лобушкин.</segment>
		<segment id="6" parent="7" relname="attribution">В посте на своей странице во «ВКонтакте» Лобушкин отметил,</segment>
		<segment id="7" parent="59" relname="span">что «любая другая информация по этому поводу не соответствует действительности».</segment>
		<segment id="8" parent="60" relname="span">Позже слова пресс-секретаря подтвердил генеральный директор компании USM Advisors Иван Стрешинский</segment>
		<segment id="9" parent="8" relname="background">(USM Advisors управляет активами одного из крупных акционеров соцсети — бизнесмена Алишера Усманова)</segment>
		<segment id="10" parent="61" relname="joint">Акции "Английское название" Group во "ВКонтакте" остаются под управлением Дурова,</segment>
		<segment id="11" parent="61" relname="joint">а он остается на посту гендиректора социальной сети, пока все так»</segment>
		<segment id="12" parent="75" relname="attribution">приводит слова Стрешинского «ИТАР-ТАСС».</segment>
		<segment id="13" parent="78" relname="span">##### Ранее об уходе Дурова со ссылкой на источник, знакомый с ситуацией,</segment>
		<segment id="14" parent="79" relname="span">сообщила газета «Известия».</segment>
		<segment id="15" parent="14" relname="elaboration">Заметка об отставке Дурова появилась на сайте «Известий» 20 января в 15:00 по московскому времени.</segment>
		<segment id="16" parent="112" relname="attribution">##### Как утверждалось в материале,</segment>
		<segment id="17" parent="62" relname="joint">Дуров ушел с поста генерального директора</segment>
		<segment id="18" parent="62" relname="joint">и сосредоточился на работе над ранее запущенным им сервисом обмена мгновенными сообщениями Telegram.</segment>
		<segment id="19" parent="20" relname="attribution">По сведениям «Известий»,</segment>
		<segment id="20" parent="63" relname="span">вслед за Павлом Дуровым соцсеть покинуло и большинство разработчиков.</segment>
		<segment id="21" parent="74" relname="span">Указывая, что конкретные причины ухода Павла Дурова пока не известны,</segment>
		<segment id="22" parent="23" relname="attribution">газета приводила комментарий пресс-секретаря «ВКонтакте» Георгия Лобушкина, заявившего,</segment>
		<segment id="23" parent="64" relname="span">что по поводу отставки гендиректора ему «пока нечего ответить».</segment>
		<segment id="24" parent="107" relname="sequence">##### Слухи о возможном уходе из «ВКонтакте» основателя и гендиректора соцсети Павла Дурова стали появляться в СМИ</segment>
		<segment id="25" parent="84" relname="span">после продажи 48 процентов акций компании фонду United Capital Partners (UCP).</segment>
		<segment id="26" parent="25" relname="background">Сделка состоялась в апреле 2013 года.</segment>
		<segment id="27" parent="88" relname="span">##### В октябре 2013-го о готовящейся отставке Дурова</segment>
		<segment id="28" parent="27" relname="cause-effect">из-за конфликта с новыми акционерами</segment>
		<segment id="29" parent="88" relname="attribution">сообщил журнал Forbes.</segment>
		<segment id="30" parent="90" relname="span">Представители фонда обвинили Дурова в использовании ресурсов «ВКонтакте»</segment>
		<segment id="31" parent="30" relname="purpose">для развития своих сторонних проектов (в частности, сервиса Telegram).</segment>
		<segment id="32" parent="33" relname="attribution">Как заявил тогда изданию один из партнеров UCP Юрий Качуро,</segment>
		<segment id="33" parent="91" relname="span">действующий гендиректор «сам не знает, что он хочет».</segment>
		<segment id="34" parent="35" relname="attribution">Позже в UCP опровергли</segment>
		<segment id="35" parent="114" relname="span">намерение уволить Дурова.</segment>
		<segment id="36" parent="37" relname="attribution">Сам Дуров заявил,</segment>
		<segment id="37" parent="65" relname="span">что UCP действует в отношении него «исключительно методом угроз и прессинга».</segment>
		<segment id="38" parent="95" relname="span">##### В конце декабря 2013 года о наличии претензий к Павлу Дурову</segment>
		<segment id="39" parent="96" relname="span">также сообщил владелец "Английское название" Group Алишер Усманов</segment>
		<segment id="40" parent="39" relname="background">через "Английское название" Усманов контролирует около 40 процентов акций соцсети)</segment>
		<segment id="41" parent="67" relname="attribution">Тем не менее, Усманов подчеркнул,</segment>
		<segment id="42" parent="66" relname="joint">что его претензии «не носят принципиального характера»,</segment>
		<segment id="43" parent="66" relname="joint">а «Дуров остается пока генеральным директором».</segment>
		<segment id="44" parent="103" relname="background">##### Социальная сеть была основана Павлом Дуровым в 2006 году.</segment>
		<segment id="45" parent="70" relname="joint">Первоначально Дурову принадлежало 20 процентов акций компании.</segment>
		<segment id="46" parent="70" relname="joint">Еще по 20 процентов находилось в руках первых инвесторов стартапа — Вячеслава Мирилашвили и Льва Левиева.</segment>
		<segment id="47" parent="70" relname="joint">Около 40 процентов акций принадлежало деду Вячеслава Мирилашвили.</segment>
		<segment id="48" parent="69" relname="sequence">В 2007 году в число акционеров «ВКонтакте» вошел инвестор Юрий Мильнер.</segment>
		<segment id="49" parent="69" relname="sequence">Позже его доля перешла под контроль "Английское название" Group и Алишера Усманова.</segment>
		<segment id="50" parent="69" relname="sequence">В итоге Усманов стал владельцем 39,9 процента акций «ВКонтакте».</segment>
		<segment id="51" parent="105" relname="span">##### В апреле 2013 года Мирилашвили и Левиев продали свои доли фонду UCP,</segment>
		<segment id="52" parent="106" relname="span">принадлежащему Илье Щербовичу</segment>
		<segment id="53" parent="71" relname="joint">Щербович известен своими связями с нефтегазовой отраслью,</segment>
		<segment id="54" parent="71" relname="joint">он входит в совет директоров таких компаний, как «Роснефть» и «Транснефть»)</segment>
		<segment id="55" parent="72" relname="comparison">В настоящее время UCP принадлежит 48 процентов акций социальной сети.</segment>
		<segment id="56" parent="108" relname="joint">Самому Дурову принадлежит только 12 процентов.</segment>
		<segment id="57" parent="108" relname="joint">При этом за Дуровым остается право голосовать пакетом "Английское название"</segment>
		<group id="58" type="span" parent="77" relname="span"/>
		<group id="59" type="span" parent="58" relname="elaboration"/>
		<group id="60" type="span" parent="76" relname="attribution"/>
		<group id="61" type="multinuc" parent="75" relname="span"/>
		<group id="62" type="multinuc" parent="112" relname="span"/>
		<group id="63" type="span" parent="80" relname="sequence"/>
		<group id="64" type="span" parent="21" relname="interpretation-evaluation"/>
		<group id="65" type="span" parent="99" relname="interpretation-evaluation"/>
		<group id="66" type="multinuc" parent="67" relname="span"/>
		<group id="67" type="span" parent="68" relname="span"/>
		<group id="68" type="span" parent="95" relname="concession"/>
		<group id="69" type="multinuc" parent="102" relname="comparison"/>
		<group id="70" type="multinuc" parent="102" relname="comparison"/>
		<group id="71" type="multinuc" parent="52" relname="background"/>
		<group id="72" type="multinuc" parent="69" relname="sequence"/>
		<group id="74" type="span" parent="81" relname="interpretation-evaluation"/>
		<group id="75" type="span" parent="76" relname="span"/>
		<group id="76" type="span" parent="109" relname="span"/>
		<group id="77" type="span" parent="85" relname="span"/>
		<group id="78" type="span" parent="82" relname="preparation"/>
		<group id="79" type="span" parent="13" relname="attribution"/>
		<group id="80" type="multinuc" parent="81" relname="span"/>
		<group id="81" type="span" parent="82" relname="span"/>
		<group id="82" type="span" parent="83" relname="span"/>
		<group id="83" type="span" />
		<group id="84" type="span" parent="107" relname="sequence"/>
		<group id="85" type="span" parent="87" relname="span"/>
		<group id="87" type="span" />
		<group id="88" type="span" parent="89" relname="span"/>
		<group id="89" type="span" parent="94" relname="span"/>
		<group id="90" type="span" parent="92" relname="span"/>
		<group id="91" type="span" parent="90" relname="elaboration"/>
		<group id="92" type="span" parent="93" relname="span"/>
		<group id="93" type="span" parent="89" relname="cause-effect"/>
		<group id="94" type="span" parent="98" relname="sequence"/>
		<group id="95" type="span" parent="97" relname="span"/>
		<group id="96" type="span" parent="38" relname="attribution"/>
		<group id="97" type="span" />
		<group id="98" type="multinuc" parent="99" relname="span"/>
		<group id="99" type="span" parent="100" relname="span"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" />
		<group id="102" type="multinuc" parent="103" relname="span"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" />
		<group id="105" type="span" parent="69" relname="sequence"/>
		<group id="106" type="span" parent="51" relname="background"/>
		<group id="107" type="multinuc" parent="100" relname="preparation"/>
		<group id="108" type="multinuc" parent="72" relname="comparison"/>
		<group id="109" type="span" parent="77" relname="interpretation"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="85" relname="preparation"/>
		<group id="112" type="span" parent="113" relname="span"/>
		<group id="113" type="span" parent="80" relname="sequence"/>
		<group id="114" type="span" parent="98" relname="sequence"/>
	</body>
</rst>