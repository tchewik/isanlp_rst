<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="35" relname="span">##### Премьер-министр Аргентины Хорхе Капитанич обвинил нефтяную компанию Shell в заговоре против национальной экономики,</segment>
		<segment id="2" parent="1" relname="attribution">пишет El Universal.</segment>
		<segment id="3" parent="35" relname="interpretation-evaluation">Таким образом он отреагировал на 12-процентное повышение цен на бензин на принадлежащих компании автозаправках страны.</segment>
		<segment id="4" parent="39" relname="attribution">##### По словам Капитанича,</segment>
		<segment id="5" parent="36" relname="span">то, что корпорация приняла такое решение</segment>
		<segment id="6" parent="5" relname="background">в условиях валютного кризиса в Аргентине,</segment>
		<segment id="7" parent="37" relname="same-unit">не является случайным совпадением.</segment>
		<segment id="8" parent="9" relname="attribution">Он добавил,</segment>
		<segment id="9" parent="38" relname="span">что Shell регулярно действует против интересов потребителей в стране.</segment>
		<segment id="10" parent="42" relname="attribution">##### Премьер-министр сказал,</segment>
		<segment id="11" parent="42" relname="span">что компания действует исключительно в интересах краткосрочной прибыльности,</segment>
		<segment id="12" parent="11" relname="evidence">поскольку никакой реальной необходимости в том, чтобы так резко повышать цены, не было.</segment>
		<segment id="13" parent="64" relname="attribution">##### Ранее премьер обвинил Shell в том,</segment>
		<segment id="14" parent="64" relname="span">что она приобрела почти три миллиона долларов у банка HSBC с тем,</segment>
		<segment id="15" parent="14" relname="purpose">чтобы искусственно завысить курс американской валюты в стране.</segment>
		<segment id="16" parent="66" relname="span">Аргентинское песо было девальвировано к доллару в январе более чем на 20 процентов.</segment>
		<segment id="17" parent="46" relname="attribution">##### Представители компании, в свою очередь, заявляют,</segment>
		<segment id="18" parent="46" relname="span">что повышение цен</segment>
		<segment id="19" parent="45" relname="span">стало результатом удорожания сырья,</segment>
		<segment id="20" parent="19" relname="elaboration">вызванного в том числе и девальвацией.</segment>
		<segment id="21" parent="48" relname="attribution">Гендиректор Shell Argentina Хуан Хосе Арангурен подчеркнул,</segment>
		<segment id="22" parent="23" relname="concession">что хотя нефть для компании подорожала на 23 процента за последний месяц,</segment>
		<segment id="23" parent="48" relname="span">цены были повышены только на 12 процентов.</segment>
		<segment id="24" parent="61" relname="preparation">##### Правительство президента страны Кристины Киршнер уже не первый раз конфликтует с нефтяными компаниями.</segment>
		<segment id="25" parent="50" relname="span">В 2012 году разразился скандал с национализацией YPF,</segment>
		<segment id="26" parent="25" relname="elaboration">«дочки» испанской корпорации Repsol,</segment>
		<segment id="27" parent="51" relname="same-unit">занимавшейся разработкой нефти в Патагонии на юге Аргентины.</segment>
		<segment id="28" parent="52" relname="span">Государство первоначально национализировало 51 процент акций YPF,</segment>
		<segment id="29" parent="28" relname="elaboration">принадлежавших Repsol,</segment>
		<segment id="30" parent="53" relname="same-unit">без уплаты каких-либо компенсаций.</segment>
		<segment id="31" parent="32" relname="attribution">В качестве причин в Буэнос-Айресе указали</segment>
		<segment id="32" parent="56" relname="span">отсутствие инвестиций со стороны Repsol.</segment>
		<segment id="33" parent="58" relname="span">В конечном итоге сторонам удалось договориться о сумме возмещения,</segment>
		<segment id="34" parent="33" relname="elaboration">но она до сих пор не разглашается.</segment>
		<group id="35" type="span" parent="44" relname="span"/>
		<group id="36" type="span" parent="37" relname="same-unit"/>
		<group id="37" type="multinuc" parent="39" relname="span"/>
		<group id="38" type="span" parent="41" relname="joint"/>
		<group id="39" type="span" parent="40" relname="span"/>
		<group id="40" type="span" parent="41" relname="joint"/>
		<group id="41" type="multinuc" />
		<group id="42" type="span" parent="43" relname="span"/>
		<group id="43" type="span" />
		<group id="44" type="span" />
		<group id="45" type="span" parent="18" relname="cause-effect"/>
		<group id="46" type="span" parent="47" relname="span"/>
		<group id="47" type="span" parent="63" relname="joint"/>
		<group id="48" type="span" parent="49" relname="span"/>
		<group id="49" type="span" parent="63" relname="joint"/>
		<group id="50" type="span" parent="51" relname="same-unit"/>
		<group id="51" type="multinuc" parent="55" relname="span"/>
		<group id="52" type="span" parent="53" relname="same-unit"/>
		<group id="53" type="multinuc" parent="54" relname="span"/>
		<group id="54" type="span" parent="57" relname="span"/>
		<group id="55" type="span" parent="61" relname="span"/>
		<group id="56" type="span" parent="54" relname="cause-effect"/>
		<group id="57" type="span" parent="59" relname="joint"/>
		<group id="58" type="span" parent="59" relname="joint"/>
		<group id="59" type="multinuc" parent="60" relname="span"/>
		<group id="60" type="span" parent="55" relname="elaboration"/>
		<group id="61" type="span" parent="62" relname="span"/>
		<group id="62" type="span" />
		<group id="63" type="multinuc" />
		<group id="64" type="span" parent="65" relname="span"/>
		<group id="65" type="span" parent="16" relname="cause-effect"/>
		<group id="66" type="span" />
	</body>
</rst>