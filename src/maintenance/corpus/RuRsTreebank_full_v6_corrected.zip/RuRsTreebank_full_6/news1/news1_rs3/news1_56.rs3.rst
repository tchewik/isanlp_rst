<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="43" relname="span">##### В одном из районов Киева оппозиция запретила правящую Партию регионов, а также Компартию Украины.</segment>
		<segment id="2" parent="1" relname="attribution">Об этом сообщил в Facebook депутат от оппозиционной националистической партии «Свобода» Андрей Ильенко.</segment>
		<segment id="3" parent="42" relname="span">Решение о запрете приняла так называемая «народная рада» Деснянского района,</segment>
		<segment id="4" parent="3" relname="elaboration">созданная сторонниками оппозиции.</segment>
		<segment id="5" parent="6" relname="attribution">##### Как сообщили в партии «Свобода»,</segment>
		<segment id="6" parent="45" relname="span">в понедельник, 3 февраля, ее сторонники провели пикет возле администрации Деснянского района.</segment>
		<segment id="7" parent="8" relname="attribution">Депутат Ильенко, принимавший участие в пикете, обвинил</segment>
		<segment id="8" parent="75" relname="span">чиновников в коррупции</segment>
		<segment id="9" parent="65" relname="joint">и потребовал, чтобы администрация «прекратила свою деятельность».</segment>
		<segment id="10" parent="77" relname="cause-effect">##### После того, как требования пикетчиков выполнены не были,</segment>
		<segment id="11" parent="12" relname="attribution">они объявили</segment>
		<segment id="12" parent="77" relname="span">о создании «народной рады».</segment>
		<segment id="13" parent="68" relname="span">Ее заседание состоялось в приемной депутата Ильенко.</segment>
		<segment id="14" parent="47" relname="joint">В ходе этого заседания и было решено запретить партию власти на территории района,</segment>
		<segment id="15" parent="46" relname="span">кроме того, решено было создать «отряды самообороны»,</segment>
		<segment id="16" parent="15" relname="purpose">которые будут противостоять «титушкам» (провокаторам) и «бандитам в погонах».</segment>
		<segment id="17" parent="70" relname="joint">##### В чем конкретно будет выражаться запрет на деятельность Партии регионов и Компартии Украины, не уточняется.</segment>
		<segment id="18" parent="70" relname="joint">Неясно также, как оппозиция планирует следить за его соблюдением.</segment>
		<segment id="19" parent="50" relname="span">##### Ранее ПР и КПУ запретили в Тернопольской и Ивано-Франковской областях.</segment>
		<segment id="20" parent="49" relname="span">Соответствующие решения были приняты областными советами,</segment>
		<segment id="21" parent="20" relname="elaboration">состоящими в том числе из представителей «Свободы».</segment>
		<segment id="22" parent="79" relname="span">Кроме того, в Хмельницкой и Полтавской областях о запрете</segment>
		<segment id="23" parent="22" relname="attribution">объявили так называемые «народные рады» — альтернативные структуры, созданные сторонниками оппозиции.</segment>
		<segment id="24" parent="51" relname="sequence">##### В Киеве оппозиционеры в конце прошлого года захватили часть здания мэрии</segment>
		<segment id="25" parent="81" relname="same-unit">позднее</segment>
		<segment id="26" parent="27" relname="attribution">они объявили</segment>
		<segment id="27" parent="80" relname="span">о создании в столице «народной рады»)</segment>
		<segment id="28" parent="53" relname="span">В новом году протестующие стали захватывать здания областных администраций.</segment>
		<segment id="29" parent="52" relname="span">Главным образом, это происходило на западе страны,</segment>
		<segment id="30" parent="29" relname="cause-effect">где протестное движение пользуется существенной поддержкой.</segment>
		<segment id="31" parent="55" relname="same-unit">##### В Крыму, в свою очередь, местные власти,</segment>
		<segment id="32" parent="33" relname="cause-effect">осудившие протестное движение,</segment>
		<segment id="33" parent="74" relname="span">запретили партию «Свобода».</segment>
		<segment id="34" parent="56" relname="sequence">Позднее это решение было обжаловано прокуратурой.</segment>
		<segment id="35" parent="61" relname="joint">##### Оппозиционная кампания под лозунгами евроинтеграции и смены власти на Украине продолжается уже более двух месяцев.</segment>
		<segment id="36" parent="57" relname="joint">В столкновениях между сторонниками оппозиции и правоохранителями пострадали сотни людей,</segment>
		<segment id="37" parent="57" relname="joint">с обеих сторон также есть погибшие.</segment>
		<segment id="38" parent="60" relname="joint">Власти на этом фоне пытаются вести переговоры с оппозицией,</segment>
		<segment id="39" parent="59" relname="span">они пошли на определенные уступки</segment>
		<segment id="40" parent="39" relname="elaboration">в частности, было отправлено в отставку правительство)</segment>
		<segment id="41" parent="58" relname="contrast">но добиться прекращения противостояния не смогли.</segment>
		<group id="42" type="span" parent="43" relname="elaboration"/>
		<group id="43" type="span" parent="44" relname="span"/>
		<group id="44" type="span" />
		<group id="45" type="span" parent="71" relname="preparation"/>
		<group id="46" type="span" parent="47" relname="joint"/>
		<group id="47" type="multinuc" parent="67" relname="span"/>
		<group id="49" type="span" parent="19" relname="elaboration"/>
		<group id="50" type="span" parent="73" relname="joint"/>
		<group id="51" type="multinuc" parent="54" relname="sequence"/>
		<group id="52" type="span" parent="28" relname="elaboration"/>
		<group id="53" type="span" parent="54" relname="sequence"/>
		<group id="54" type="multinuc" parent="64" relname="comparison"/>
		<group id="55" type="multinuc" parent="56" relname="sequence"/>
		<group id="56" type="multinuc" parent="64" relname="comparison"/>
		<group id="57" type="multinuc" parent="61" relname="joint"/>
		<group id="58" type="multinuc" parent="60" relname="joint"/>
		<group id="59" type="span" parent="58" relname="contrast"/>
		<group id="60" type="multinuc" parent="76" relname="joint"/>
		<group id="61" type="multinuc" parent="76" relname="joint"/>
		<group id="64" type="multinuc" />
		<group id="65" type="multinuc" parent="69" relname="sequence"/>
		<group id="66" type="span" parent="13" relname="elaboration"/>
		<group id="67" type="span" parent="66" relname="span"/>
		<group id="68" type="span" parent="69" relname="sequence"/>
		<group id="69" type="multinuc" parent="71" relname="span"/>
		<group id="70" type="multinuc" parent="67" relname="interpretation-evaluation"/>
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" />
		<group id="73" type="multinuc" parent="69" relname="sequence"/>
		<group id="74" type="span" parent="55" relname="same-unit"/>
		<group id="75" type="span" parent="65" relname="joint"/>
		<group id="76" type="multinuc" />
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" parent="69" relname="sequence"/>
		<group id="79" type="span" parent="73" relname="joint"/>
		<group id="80" type="span" parent="81" relname="same-unit"/>
		<group id="81" type="multinuc" parent="51" relname="sequence"/>
	</body>
</rst>