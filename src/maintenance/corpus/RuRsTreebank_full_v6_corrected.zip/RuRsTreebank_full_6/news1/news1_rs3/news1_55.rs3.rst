<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="67" relname="span">##### Установлена личность молодого человека,</segment>
		<segment id="2" parent="1" relname="background">захватившего заложников в московской школе номер 263:</segment>
		<segment id="3" parent="67" relname="elaboration">это ученик 11 или 10 класса той же школы.</segment>
		<segment id="4" parent="71" relname="attribution">Об этом 3 февраля сообщается на сайте газеты «Коммерсантъ».</segment>
		<segment id="5" parent="6" relname="attribution">##### В МВД заявили,</segment>
		<segment id="6" parent="41" relname="span">что преступник задержан.</segment>
		<segment id="7" parent="54" relname="joint">Все заложники (от 20 до 29 учеников 10 класса) освобождены,</segment>
		<segment id="8" parent="54" relname="joint">никто из них не пострадал.</segment>
		<segment id="9" parent="10" relname="attribution">Источник в правоохранительных органах сообщил агентству «Интерфакс»,</segment>
		<segment id="10" parent="55" relname="span">что мотивом преступления, по предварительным данным, стал конфликт в школе.</segment>
		<segment id="11" parent="43" relname="attribution">##### При этом один из школьников рассказал телеканалу Life News,</segment>
		<segment id="12" parent="42" relname="joint">что захватчик заложников был лучшим учеником в классе.</segment>
		<segment id="13" parent="42" relname="joint">Ни в какие конфликты он вовлечен не был.</segment>
		<segment id="14" parent="74" relname="attribution">Также ученики рассказали,</segment>
		<segment id="15" parent="74" relname="span">что на входе в школу размещен турникет</segment>
		<segment id="16" parent="15" relname="purpose">для входа по карточкам.</segment>
		<segment id="17" parent="73" relname="sequence">Некоторое время назад карточки поменяли,</segment>
		<segment id="18" parent="19" relname="cause-effect">ученикам не дали новых карточек,</segment>
		<segment id="19" parent="45" relname="span">и турникет не работал.</segment>
		<segment id="20" parent="63" relname="preparation">##### Точной информации о погибших и пострадавших полицейских и учителе пока нет.</segment>
		<segment id="21" parent="60" relname="comparison">Некоторые источники сообщают о двух раненых полицейских,</segment>
		<segment id="22" parent="60" relname="comparison">другие источники — об убитом полицейском, его раненом коллеге и раненом учителе.</segment>
		<segment id="23" parent="60" relname="comparison">Также сообщалось, что раненый учитель якобы скончался.</segment>
		<segment id="24" parent="25" relname="attribution">Журналистам Life News стало известно</segment>
		<segment id="25" parent="59" relname="span">имя предположительно погибшего полицейского, это старший сержант Сергей Бусюев или Бушуев.</segment>
		<segment id="26" parent="48" relname="span">Имя погибшего или раненого учителя — Андрей Кириллов,</segment>
		<segment id="27" parent="26" relname="background">он преподавал географию.</segment>
		<segment id="28" parent="49" relname="joint">Ученики отзываются о нем хорошо,</segment>
		<segment id="29" parent="49" relname="joint">конфликтов с захватчиком заложников у него не было.</segment>
		<segment id="30" parent="53" relname="sequence">##### Старшеклассник ворвался в школу в районе Отрадное днем 3 февраля.</segment>
		<segment id="31" parent="32" relname="condition">Угрожая оружием охраннику,</segment>
		<segment id="32" parent="51" relname="span">он заставил его пройти вместе с ним в кабинет биологии,</segment>
		<segment id="33" parent="32" relname="background">где проходил урок у десятого класса.</segment>
		<segment id="34" parent="53" relname="sequence">Охранник успел вызвать полицию с помощью «тревожной кнопки».</segment>
		<segment id="35" parent="52" relname="joint">Преступник открыл огонь из окна по прибывшим полицейским</segment>
		<segment id="36" parent="52" relname="joint">и взял в заложники учеников.</segment>
		<segment id="37" parent="53" relname="sequence">На место прибыли дополнительные наряды полиции, скорой помощи, вертолет МЧС, спасатели с бронещитом, защищающим от взрывов, машина Следственного комитета РФ и лично глава МВД РФ Владимир Колокольцев.</segment>
		<segment id="38" parent="66" relname="span">Учеников из школы эвакуировали.</segment>
		<segment id="39" parent="65" relname="comparison">По одним данным, их разместили в соседней школе номер 1459.</segment>
		<segment id="40" parent="65" relname="comparison">По другим данным, эта школа, наоборот, на всякий случай также была эвакуирована.</segment>
		<group id="41" type="span" parent="56" relname="joint"/>
		<group id="42" type="multinuc" parent="43" relname="span"/>
		<group id="43" type="span" parent="44" relname="span"/>
		<group id="44" type="span" parent="47" relname="joint"/>
		<group id="45" type="span" parent="73" relname="sequence"/>
		<group id="47" type="multinuc" />
		<group id="48" type="span" parent="50" relname="span"/>
		<group id="49" type="multinuc" parent="48" relname="interpretation-evaluation"/>
		<group id="50" type="span" parent="61" relname="joint"/>
		<group id="51" type="span" parent="53" relname="sequence"/>
		<group id="52" type="multinuc" parent="53" relname="sequence"/>
		<group id="53" type="multinuc" parent="64" relname="background"/>
		<group id="54" type="multinuc" parent="56" relname="joint"/>
		<group id="55" type="span" parent="56" relname="joint"/>
		<group id="56" type="multinuc" parent="57" relname="span"/>
		<group id="57" type="span" parent="58" relname="span"/>
		<group id="58" type="span" />
		<group id="59" type="span" parent="61" relname="joint"/>
		<group id="60" type="multinuc" parent="62" relname="span"/>
		<group id="61" type="multinuc" parent="62" relname="elaboration"/>
		<group id="62" type="span" parent="63" relname="span"/>
		<group id="63" type="span" parent="64" relname="span"/>
		<group id="64" type="span" parent="70" relname="span"/>
		<group id="65" type="multinuc" parent="38" relname="interpretation-evaluation"/>
		<group id="66" type="span" parent="53" relname="sequence"/>
		<group id="67" type="span" parent="71" relname="span"/>
		<group id="70" type="span" />
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" parent="57" relname="preparation"/>
		<group id="73" type="multinuc" parent="75" relname="elaboration"/>
		<group id="74" type="span" parent="75" relname="span"/>
		<group id="75" type="span" parent="76" relname="span"/>
		<group id="76" type="span" parent="47" relname="joint"/>
	</body>
</rst>