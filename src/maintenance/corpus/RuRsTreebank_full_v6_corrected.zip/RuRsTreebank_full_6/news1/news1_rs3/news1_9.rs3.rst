<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="113" relname="span">##### Агрессия НАТО против Югославии,</segment>
		<segment id="2" parent="1" relname="elaboration">случившаяся 10 лет назад (23 марта — 10 июня 1999 года),</segment>
		<segment id="3" parent="114" relname="same-unit">вызвала в России очень сильную эмоциональную реакцию</segment>
		<segment id="4" parent="115" relname="joint">и, как у нас водится, подверглась сильнейшей мифологизации.</segment>
		<segment id="5" parent="216" relname="span">В итоге, как это ни парадоксально, некоторые полезные выводы политического и военного характера не сделаны до сих пор.</segment>
		<segment id="6" parent="121" relname="joint">##### В России до сих пор не принято обсуждать причины этой войны.</segment>
		<segment id="7" parent="8" relname="attribution">Граждане нашей страны почти поголовно убедили самих себя,</segment>
		<segment id="8" parent="217" relname="span">что Запад всегда воюет за нефть.</segment>
		<segment id="9" parent="119" relname="span">Однако югославская война совсем никаким боком не лезет в нефтяную теорию.</segment>
		<segment id="10" parent="9" relname="evidence">Здесь нет ни нефти, ни газа, ни даже какого-нибудь паршивенького транзитного трубопровода.</segment>
		<segment id="11" parent="120" relname="span">Не проходит и вспомогательная теория о получении «плацдарма на Балканах».</segment>
		<segment id="12" parent="117" relname="joint">У НАТО и без Югославии давно нет проблем с плацдармами на Балканах,</segment>
		<segment id="13" parent="117" relname="joint">тем более что территория и инфраструктура Косова в этом плане не дает им абсолютно ничего эксклюзивного.</segment>
		<segment id="14" parent="125" relname="span">##### Из-за этого приходится (за неимением других вариантов) верить в правдивость официальной западной версии — «гуманитарной интервенции».</segment>
		<segment id="15" parent="124" relname="span">Запад сам себя психологически накачал,</segment>
		<segment id="16" parent="123" relname="span">устроив многомесячную истерику по поводу «этнических чисток»,</segment>
		<segment id="17" parent="16" relname="elaboration">совершаемых режимом Милошевича против «беззащитных» албанцев.</segment>
		<segment id="18" parent="129" relname="contrast">Нельзя сказать, что истерика не имела под собой совсем никаких оснований,</segment>
		<segment id="19" parent="126" relname="span">но некоторые особенности противоположной стороны (албанских боевиков,</segment>
		<segment id="20" parent="19" relname="elaboration">представлявших собой смесь наркоторговцев, исламских экстремистов, а главным образом просто бандитов)</segment>
		<segment id="21" parent="128" relname="span">как-то выпали из виду западных политиков и журналистов,</segment>
		<segment id="22" parent="21" relname="elaboration">утративших даже видимость объективности.</segment>
		<segment id="23" parent="130" relname="span">Тем не менее агрессия,</segment>
		<segment id="24" parent="23" relname="elaboration">ставшая ошибкой и преступлением одновременно,</segment>
		<segment id="25" parent="131" relname="same-unit">была совершена из лучших побуждений.</segment>
		<segment id="26" parent="133" relname="same-unit">О том,</segment>
		<segment id="27" parent="132" relname="span">что получилось сегодня из этих побуждений,</segment>
		<segment id="28" parent="27" relname="attribution">«Частный корреспондент» уже писал в статье «Казус Косова».</segment>
		<segment id="29" parent="218" relname="span">##### Кроме того, в России привыкли видеть в НАТО чудовищную военную силу, готовую растерзать всё на своем пути.</segment>
		<segment id="30" parent="29" relname="evidence">Югославская агрессия, казалось бы, стала лучшим подтверждением данного мнения.</segment>
		<segment id="31" parent="219" relname="contrast">Правда, на фоне мифов и эмоций у нас и в этом плане кое-чего не заметили.</segment>
		<segment id="32" parent="153" relname="span">##### Во-первых, агрессии бы не случилось,</segment>
		<segment id="33" parent="32" relname="condition">если бы Югославия имела возможность дать достойный ответ.</segment>
		<segment id="34" parent="137" relname="span">Очень показательно, что Венгрия</segment>
		<segment id="35" parent="34" relname="elaboration">(единственная на тот момент страна — член НАТО, имевшая с Югославией общую сухопутную границу)</segment>
		<segment id="36" parent="138" relname="same-unit">лишь допустила на свои аэродромы американские самолеты-заправщики и спасательные вертолеты (то есть вспомогательные, но не боевые силы)</segment>
		<segment id="37" parent="141" relname="span">, а также вытребовала эскадрилью американских истребителей</segment>
		<segment id="38" parent="140" relname="same-unit">для выполнения</segment>
		<segment id="39" parent="40" relname="evidence">(это было специально подчеркнуто венгерскими официальными лицами)</segment>
		<segment id="40" parent="139" relname="span">исключительно задач ПВО.</segment>
		<segment id="41" parent="144" relname="joint">Венгрия вступила в НАТО всего за месяц до агрессии.</segment>
		<segment id="42" parent="143" relname="contrast">Как и все остальные новые члены альянса, она хотела, чтобы ее защищали,</segment>
		<segment id="43" parent="143" relname="contrast">но не имела ни малейшего желания подвергать себя опасности.</segment>
		<segment id="44" parent="151" relname="span">##### Не одни венгры страдали отсутствием энтузиазма.</segment>
		<segment id="45" parent="148" relname="joint">Например, экипаж одного из норвежских тральщиков отказался отправляться к югославским берегам.</segment>
		<segment id="46" parent="47" relname="cause-effect">Хотя никакой войны на море в 1999 году не было вообще,</segment>
		<segment id="47" parent="146" relname="span">поэтому поход тральщика в Адриатику больше напоминал бы круиз,</segment>
		<segment id="48" parent="147" relname="contrast">но даже теоретическая опасность возмутила «викингов».</segment>
		<segment id="49" parent="152" relname="span">В целом, правда, старые члены НАТО вроде бы воевали активно.</segment>
		<segment id="50" parent="149" relname="joint">Именно потому, что достать их территории югославы не могли,</segment>
		<segment id="51" parent="149" relname="joint">да и ПВО сербов оказалась почти бессильной.</segment>
		<segment id="52" parent="157" relname="span">По нашим СМИ до сих пор гуляет масса альтернативных списков огромных потерь,</segment>
		<segment id="53" parent="52" relname="elaboration">которые ВВС НАТО якобы понесли в югославском небе.</segment>
		<segment id="54" parent="156" relname="span">У этих списков есть, увы, один небольшой недостаток — полное отсутствие доказательств. Хотя бы в виде фотографий сбитых самолетов и вертолетов.</segment>
		<segment id="55" parent="158" relname="span">Объяснения отсутствия этих фотографий настолько смехотворны,</segment>
		<segment id="56" parent="55" relname="elaboration">что нет смысла их повторять.</segment>
		<segment id="57" parent="220" relname="span">И здесь, как ни печально, приходится верить официальным данным НАТО о потере непосредственно над Югославией всего двух самолетов (F-117А и F-16С ВВС США).</segment>
		<segment id="58" parent="166" relname="preparation">Причем даже в гибели этих машин роль югославской ПВО неочевидна.</segment>
		<segment id="59" parent="159" relname="contrast">Пляски сербов на обломках «невидимки» F-117 видел весь мир,</segment>
		<segment id="60" parent="159" relname="contrast">однако до сих пор, по прошествии 10 лет, остается неясным, кто его сбил: то ли ЗРК С-125, то ли ЗРК «Куб», то ли истребитель МиГ-29.</segment>
		<segment id="61" parent="161" relname="span">Поскольку времени для окончательного решения данного вопроса прошло более чем достаточно</segment>
		<segment id="62" parent="61" relname="evaluation">(неужели у югославов совсем отсутствовала аппаратура боевого документирования?) ,</segment>
		<segment id="63" parent="160" relname="span">появляется подозрение, что и здесь верна официальная американская версия</segment>
		<segment id="64" parent="63" relname="elaboration">— самолет упал сам.</segment>
		<segment id="65" parent="66" relname="cause-effect">F-117 обладает отвратительными аэродинамическими качествами,</segment>
		<segment id="66" parent="163" relname="span">поэтому до десятка «невидимок» (из всего 59 серийных машин) разбилось без всякой войны</segment>
		<segment id="67" parent="164" relname="span">(недаром в конце прошлого года этот самолет был снят с вооружения ВВС США).</segment>
		<segment id="68" parent="170" relname="span">##### Однако даже такая низкая эффективность ПВО противника не обеспечила высокой эффективности натовской авиации</segment>
		<segment id="69" parent="168" relname="joint">(причем эта не слишком высокая эффективность — «заслуга» в первую очередь ВВС США,</segment>
		<segment id="70" parent="169" relname="span">а применительно к европейцам термин «эффективность» просто не имел смысла:</segment>
		<segment id="71" parent="70" relname="elaboration">война в Югославии показала, что без американцев европейцы в военном плане не могут вообще ничего) .</segment>
		<segment id="72" parent="172" relname="contrast">Если гражданские объекты (в первую очередь инфраструктуру) она бомбила успешно,</segment>
		<segment id="73" parent="171" relname="span">то вооруженные силы Югославии (особенно сухопутные войска) практически никак не пострадали,</segment>
		<segment id="74" parent="73" relname="evidence">что через год после окончания войны официально признало командование США</segment>
		<segment id="75" parent="171" relname="evidence">(потери югославов в тяжелой технике составили менее 2%) .</segment>
		<segment id="76" parent="77" relname="condition">И если бы НАТО начало наземную операцию,</segment>
		<segment id="77" parent="177" relname="span">мясорубка получилась бы страшная.</segment>
		<segment id="78" parent="176" relname="span">Однако натовцев спас обожествленный нашей патриотической общественностью Милошевич</segment>
		<segment id="79" parent="175" relname="joint">(ныне покойный),</segment>
		<segment id="80" parent="175" relname="joint">капитулировавший в самый неудачный момент.</segment>
		<segment id="81" parent="181" relname="joint">##### К началу июня 1999 года США и компания были в очевидном тупике.</segment>
		<segment id="82" parent="180" relname="contrast">Они уничтожили большинство назначенных целей,</segment>
		<segment id="83" parent="179" relname="span">однако югославская армия уверенно контролировала Косово,</segment>
		<segment id="84" parent="83" relname="cause-effect">практически выбив оттуда албанских боевиков.</segment>
		<segment id="85" parent="182" relname="span">Надо было либо свертывать операцию,</segment>
		<segment id="86" parent="85" relname="elaboration">не добившись поставленных задач,</segment>
		<segment id="87" parent="183" relname="joint">либо начинать наземное вторжение.</segment>
		<segment id="88" parent="185" relname="contrast">Первый вариант, видимо, привел бы к отставке всех правительств стран альянса.</segment>
		<segment id="89" parent="185" relname="contrast">Второй означал бы бойню.</segment>
		<segment id="90" parent="91" relname="cause-effect">Как уже было сказано, югославская армия почти не пострадала от воздушных атак,</segment>
		<segment id="91" parent="206" relname="span">горно-лесистая местность очень способствовала бы успешной обороне.</segment>
		<segment id="92" parent="186" relname="joint">Именно в этот момент Милошевич капитулировал.</segment>
		<segment id="93" parent="208" relname="span">##### С военной точки зрения капитуляцию в такой ситуации нельзя назвать иначе как преступлением.</segment>
		<segment id="94" parent="188" relname="span">Либо надо было сдаваться сразу,</segment>
		<segment id="95" parent="94" relname="elaboration">в марте, когда страна еще не была разрушена,</segment>
		<segment id="96" parent="187" relname="joint">либо стоять до конца.</segment>
		<segment id="97" parent="189" relname="sequence">Но Милошевич сначала загнал противника в тупик,</segment>
		<segment id="98" parent="189" relname="sequence">а затем сам же его оттуда вывел, попутно дав ему окончательно разрушить Сербию.</segment>
		<segment id="99" parent="192" relname="attribution">##### Через две недели после окончания югославской кампании итальянский адмирал Гвидо Вентурони честно сказал,</segment>
		<segment id="100" parent="191" relname="joint">что в начале июня НАТО было уже на пределе своих возможностей,</segment>
		<segment id="101" parent="191" relname="joint">а европейцы без США вообще не способны проводить самостоятельные операции.</segment>
		<segment id="102" parent="195" relname="joint">##### Страны НАТО превосходили Югославию по суммарному экономическому потенциалу в 700 раз</segment>
		<segment id="103" parent="195" relname="joint">(а военные потенциалы были просто несопоставимы)</segment>
		<segment id="104" parent="196" relname="contrast">, однако через 2,5 месяца войны были на пределе возможностей!</segment>
		<segment id="105" parent="198" relname="contrast">Они практически не понесли потерь в ходе войны,</segment>
		<segment id="106" parent="197" relname="comparison">однако их материальные расходы на эту войну оказались почти такими же,</segment>
		<segment id="107" parent="197" relname="comparison">какой ущерб они нанесли Югославии.</segment>
		<segment id="108" parent="200" relname="evaluation">В этом — обратная сторона высокотехнологичной войны и желания воевать без потерь.</segment>
		<segment id="109" parent="203" relname="span">История с броском российских десантников в Приштину,</segment>
		<segment id="110" parent="109" relname="elaboration">заслуживающая отдельного описания,</segment>
		<segment id="111" parent="202" relname="same-unit">война в Афганистане лишь подтвердили выводы о крайне ограниченной дееспособности самого мощного в мире военного блока.</segment>
		<segment id="112" parent="204" relname="evaluation">##### Хотя провести мир в ад по дороге, вымощенной благими намерениями, он еще может.</segment>
		<group id="113" type="span" parent="114" relname="same-unit"/>
		<group id="114" type="multinuc" parent="115" relname="joint"/>
		<group id="115" type="multinuc" parent="116" relname="span"/>
		<group id="116" type="span" parent="5" relname="cause-effect"/>
		<group id="117" type="multinuc" parent="11" relname="evidence"/>
		<group id="118" type="multinuc" parent="122" relname="contrast"/>
		<group id="119" type="span" parent="118" relname="joint"/>
		<group id="120" type="span" parent="118" relname="joint"/>
		<group id="121" type="multinuc" parent="122" relname="contrast"/>
		<group id="122" type="multinuc" />
		<group id="123" type="span" parent="15" relname="cause-effect"/>
		<group id="124" type="span" parent="134" relname="joint"/>
		<group id="125" type="span" parent="135" relname="preparation"/>
		<group id="126" type="span" parent="127" relname="same-unit"/>
		<group id="127" type="multinuc" parent="129" relname="contrast"/>
		<group id="128" type="span" parent="127" relname="same-unit"/>
		<group id="129" type="multinuc" parent="134" relname="joint"/>
		<group id="130" type="span" parent="131" relname="same-unit"/>
		<group id="131" type="multinuc" parent="134" relname="joint"/>
		<group id="132" type="span" parent="133" relname="same-unit"/>
		<group id="133" type="multinuc" parent="134" relname="joint"/>
		<group id="134" type="multinuc" parent="135" relname="span"/>
		<group id="135" type="span" parent="136" relname="span"/>
		<group id="136" type="span" />
		<group id="137" type="span" parent="138" relname="same-unit"/>
		<group id="138" type="multinuc" parent="142" relname="joint"/>
		<group id="139" type="span" parent="140" relname="same-unit"/>
		<group id="140" type="multinuc" parent="37" relname="purpose"/>
		<group id="141" type="span" parent="142" relname="joint"/>
		<group id="142" type="multinuc" parent="145" relname="joint"/>
		<group id="143" type="multinuc" parent="144" relname="joint"/>
		<group id="144" type="multinuc" parent="145" relname="joint"/>
		<group id="145" type="multinuc" parent="154" relname="span"/>
		<group id="146" type="span" parent="147" relname="contrast"/>
		<group id="147" type="multinuc" parent="148" relname="joint"/>
		<group id="148" type="multinuc" parent="44" relname="evidence"/>
		<group id="149" type="multinuc" parent="49" relname="evidence"/>
		<group id="150" type="multinuc" />
		<group id="151" type="span" parent="150" relname="joint"/>
		<group id="152" type="span" parent="150" relname="joint"/>
		<group id="153" type="span" parent="154" relname="preparation"/>
		<group id="154" type="span" parent="155" relname="span"/>
		<group id="155" type="span" />
		<group id="156" type="span" parent="209" relname="span"/>
		<group id="157" type="span" parent="211" relname="preparation"/>
		<group id="158" type="span" parent="156" relname="elaboration"/>
		<group id="159" type="multinuc" parent="165" relname="joint"/>
		<group id="160" type="span" parent="162" relname="span"/>
		<group id="161" type="span" parent="160" relname="cause-effect"/>
		<group id="162" type="span" parent="165" relname="joint"/>
		<group id="163" type="span" parent="67" relname="cause-effect"/>
		<group id="164" type="span" parent="165" relname="joint"/>
		<group id="165" type="multinuc" parent="166" relname="span"/>
		<group id="166" type="span" parent="167" relname="span"/>
		<group id="167" type="span" parent="57" relname="elaboration"/>
		<group id="168" type="multinuc" parent="68" relname="elaboration"/>
		<group id="169" type="span" parent="168" relname="joint"/>
		<group id="170" type="span" parent="174" relname="joint"/>
		<group id="171" type="span" parent="173" relname="span"/>
		<group id="172" type="multinuc" parent="174" relname="joint"/>
		<group id="173" type="span" parent="172" relname="contrast"/>
		<group id="174" type="multinuc" parent="213" relname="joint"/>
		<group id="175" type="multinuc" parent="78" relname="elaboration"/>
		<group id="176" type="span" parent="178" relname="contrast"/>
		<group id="177" type="span" parent="178" relname="contrast"/>
		<group id="178" type="multinuc" parent="213" relname="joint"/>
		<group id="179" type="span" parent="180" relname="contrast"/>
		<group id="180" type="multinuc" parent="181" relname="joint"/>
		<group id="181" type="multinuc" parent="184" relname="span"/>
		<group id="182" type="span" parent="183" relname="joint"/>
		<group id="183" type="multinuc" parent="215" relname="span"/>
		<group id="184" type="span" />
		<group id="185" type="multinuc" parent="186" relname="joint"/>
		<group id="186" type="multinuc" parent="215" relname="elaboration"/>
		<group id="187" type="multinuc" parent="190" relname="contrast"/>
		<group id="188" type="span" parent="187" relname="joint"/>
		<group id="189" type="multinuc" parent="190" relname="contrast"/>
		<group id="190" type="multinuc" parent="207" relname="span"/>
		<group id="191" type="multinuc" parent="192" relname="span"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" />
		<group id="194" type="multinuc" />
		<group id="195" type="multinuc" parent="196" relname="contrast"/>
		<group id="196" type="multinuc" parent="199" relname="joint"/>
		<group id="197" type="multinuc" parent="198" relname="contrast"/>
		<group id="198" type="multinuc" parent="199" relname="joint"/>
		<group id="199" type="multinuc" parent="200" relname="span"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" parent="194" relname="joint"/>
		<group id="202" type="multinuc" parent="204" relname="span"/>
		<group id="203" type="span" parent="202" relname="same-unit"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="194" relname="joint"/>
		<group id="206" type="span" parent="186" relname="joint"/>
		<group id="207" type="span" parent="93" relname="evaluation"/>
		<group id="208" type="span" />
		<group id="209" type="span" parent="210" relname="joint"/>
		<group id="210" type="multinuc" parent="211" relname="span"/>
		<group id="211" type="span" parent="212" relname="span"/>
		<group id="212" type="span" />
		<group id="213" type="multinuc" />
		<group id="214" type="span" parent="181" relname="joint"/>
		<group id="215" type="span" parent="214" relname="span"/>
		<group id="216" type="span" />
		<group id="217" type="span" parent="121" relname="joint"/>
		<group id="218" type="span" parent="219" relname="contrast"/>
		<group id="219" type="multinuc" />
		<group id="220" type="span" parent="210" relname="joint"/>
	</body>
</rst>