<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="48" relname="span">##### В религиозном квартале «Варшавских домов» («Батей Ворша») в центре Иерусалима ежедневно и еженочно происходят самые настоящие погромы,</segment>
		<segment id="2" parent="1" relname="attribution">сообщает корреспондент «Маарив» Шломо Иерушалми.</segment>
		<segment id="3" parent="49" relname="joint">##### Верующие иудеи ворвалась в дом Мирьям и Авраама Гиршман с молотками и топорами,</segment>
		<segment id="4" parent="49" relname="joint">погромили всю мебель,</segment>
		<segment id="5" parent="49" relname="joint">облили дом керосином,</segment>
		<segment id="6" parent="49" relname="joint">жестоко избили ее саму</segment>
		<segment id="7" parent="49" relname="joint">и облили керосином ее полугодовалую дочку.</segment>
		<segment id="8" parent="50" relname="span">Все это сделали,</segment>
		<segment id="9" parent="8" relname="attribution">по словам Мирьям,</segment>
		<segment id="10" parent="51" relname="same-unit">Гурские хасиды.</segment>
		<segment id="11" parent="63" relname="span">##### Женщина обратилась к журналистам светского издания</segment>
		<segment id="12" parent="64" relname="span">от отчаяния</segment>
		<segment id="13" parent="90" relname="attribution">— она сказала,</segment>
		<segment id="14" parent="90" relname="span">что больше никто помогать не желает</segment>
		<segment id="15" parent="14" relname="cause-effect">— полиция с гурскими хасидами не связывается.</segment>
		<segment id="16" parent="67" relname="same-unit">Жители квартала,</segment>
		<segment id="17" parent="18" relname="condition">куда человеку без кипы на голове обычно лучше не заходить,</segment>
		<segment id="18" parent="66" relname="span">пошли на беспрецедентный шаг</segment>
		<segment id="19" parent="68" relname="span">— пригласили светских журналистов.</segment>
		<segment id="20" parent="21" relname="attribution">##### Шломо Иерушалми утверждает</segment>
		<segment id="21" parent="70" relname="span">что видел разгромленную квартиру Гиршманов и запах керосина.</segment>
		<segment id="22" parent="70" relname="elaboration">Фотографий с места погрома журналист не публикует.</segment>
		<segment id="23" parent="71" relname="span">Большинство других жителей Варшавских домов согласились разговаривать с журналистом только</segment>
		<segment id="24" parent="72" relname="span">на условиях анонимности,</segment>
		<segment id="25" parent="24" relname="cause-effect">боясь новых «акций возмездия».</segment>
		<segment id="26" parent="74" relname="attribution">##### Шломо Иерушалми рассказывает,</segment>
		<segment id="27" parent="52" relname="sequence">что еще в детстве как-то зашел в квартал без кипы</segment>
		<segment id="28" parent="52" relname="sequence">и сразу получил камнем в голову,</segment>
		<segment id="29" parent="73" relname="concession">хотя был еще ребенком.</segment>
		<segment id="30" parent="53" relname="span">##### Пострадавшие в один голос обвиняют в погромах гурских хасидов,</segment>
		<segment id="31" parent="30" relname="cause-effect">которые, якобы, хотят выгнать из квартала всех его обитателей</segment>
		<segment id="32" parent="54" relname="span">и построить там гигантский торговый центр,</segment>
		<segment id="33" parent="32" relname="elaboration">который принесет общине огромные прибыли.</segment>
		<segment id="34" parent="76" relname="joint">Гурские хасиды отрицают свою причастность к погромам</segment>
		<segment id="35" parent="36" relname="attribution">и заявляют,</segment>
		<segment id="36" parent="92" relname="span">что все это дело рук ультраортодоксальной общины Нетурей карта.</segment>
		<segment id="37" parent="77" relname="comparison">Иерушалми не смог выяснить истинные обстоятельства и подоплеку событий в закрытом мире ультраортодоксальных общин.</segment>
		<segment id="38" parent="79" relname="attribution">##### В официальном комментарии полиции говорится,</segment>
		<segment id="39" parent="58" relname="span">что трое участников «драки»,</segment>
		<segment id="40" parent="39" relname="background">случившейся в квартале в минувшее воскресенье,</segment>
		<segment id="41" parent="78" relname="same-unit">арестованы.</segment>
		<segment id="42" parent="56" relname="joint">«С другой стороны, полиция пытается успокоить конфликтующие стороны путем переговоров</segment>
		<segment id="43" parent="56" relname="joint">и продолжит обеспечивать порядок в этом районе»</segment>
		<segment id="44" parent="57" relname="attribution">, — гласит официальный полицейский документ.</segment>
		<segment id="45" parent="83" relname="same-unit">##### Особенно любопытен факт, что в последнее время религиозные иудеи</segment>
		<segment id="46" parent="47" relname="condition">при нападении на нерелигиозных</segment>
		<segment id="47" parent="82" relname="span">используют опасные химические вещества.</segment>
		<group id="48" type="span" parent="61" relname="preparation"/>
		<group id="49" type="multinuc" parent="60" relname="span"/>
		<group id="50" type="span" parent="51" relname="same-unit"/>
		<group id="51" type="multinuc" parent="60" relname="elaboration"/>
		<group id="52" type="multinuc" parent="73" relname="span"/>
		<group id="53" type="span" parent="55" relname="joint"/>
		<group id="54" type="span" parent="55" relname="joint"/>
		<group id="55" type="multinuc" parent="77" relname="comparison"/>
		<group id="56" type="multinuc" parent="57" relname="span"/>
		<group id="57" type="span" parent="59" relname="span"/>
		<group id="58" type="span" parent="78" relname="same-unit"/>
		<group id="59" type="span" parent="81" relname="joint"/>
		<group id="60" type="span" parent="61" relname="span"/>
		<group id="61" type="span" parent="62" relname="span"/>
		<group id="62" type="span" />
		<group id="63" type="span" parent="68" relname="cause-effect"/>
		<group id="64" type="span" parent="11" relname="cause-effect"/>
		<group id="66" type="span" parent="67" relname="same-unit"/>
		<group id="67" type="multinuc" parent="19" relname="interpretation-evaluation"/>
		<group id="68" type="span" parent="69" relname="span"/>
		<group id="69" type="span" />
		<group id="70" type="span" parent="86" relname="span"/>
		<group id="71" type="span" parent="86" relname="elaboration"/>
		<group id="72" type="span" parent="23" relname="condition"/>
		<group id="73" type="span" parent="74" relname="span"/>
		<group id="74" type="span" parent="75" relname="span"/>
		<group id="75" type="span" parent="87" relname="background"/>
		<group id="76" type="multinuc" parent="77" relname="comparison"/>
		<group id="77" type="multinuc" parent="88" relname="interpretation-evaluation"/>
		<group id="78" type="multinuc" parent="79" relname="span"/>
		<group id="79" type="span" parent="80" relname="span"/>
		<group id="80" type="span" parent="81" relname="joint"/>
		<group id="81" type="multinuc" parent="84" relname="span"/>
		<group id="82" type="span" parent="83" relname="same-unit"/>
		<group id="83" type="multinuc" parent="84" relname="background"/>
		<group id="84" type="span" parent="85" relname="span"/>
		<group id="85" type="span" />
		<group id="86" type="span" parent="87" relname="span"/>
		<group id="87" type="span" parent="88" relname="span"/>
		<group id="88" type="span" parent="89" relname="span"/>
		<group id="89" type="span" />
		<group id="90" type="span" parent="91" relname="span"/>
		<group id="91" type="span" parent="12" relname="elaboration"/>
		<group id="92" type="span" parent="76" relname="joint"/>
	</body>
</rst>