<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="2" relname="attribution">##### Президент России Владимир Путин пообещал</segment>
		<segment id="2" parent="81" relname="span">обеспечить безопасность гостей и участников Олимпиады в Сочи.</segment>
		<segment id="3" parent="81" relname="attribution">Об этом глава государства заявил в ходе интервью ряду российских и иностранных СМИ в Красной Поляне.</segment>
		<segment id="4" parent="5" relname="attribution">##### Надеюсь,</segment>
		<segment id="5" parent="93" relname="span">что все, что мы делаем, с пониманием, с ясным пониманием оперативной обстановки, которая складывается вокруг Сочи и вообще в этом регионе.</segment>
		<segment id="6" parent="49" relname="joint">У нас есть прекрасное понимание того, что это такое,</segment>
		<segment id="7" parent="49" relname="joint">какова эта угроза,</segment>
		<segment id="8" parent="49" relname="joint">как ее купировать,</segment>
		<segment id="9" parent="49" relname="joint">как с этим бороться»</segment>
		<segment id="10" parent="94" relname="attribution">сказал президент.</segment>
		<segment id="11" parent="55" relname="attribution">##### Глава государства рассказал,</segment>
		<segment id="12" parent="53" relname="same-unit">что</segment>
		<segment id="13" parent="14" relname="purpose">для обеспечения безопасности Игр</segment>
		<segment id="14" parent="54" relname="span">будет задействовано 40 тысяч сотрудников правоохранительных органов и спецслужб.</segment>
		<segment id="15" parent="58" relname="joint">Мы будем защищать и воздушное пространство, и морскую акваторию, и горный кластер.</segment>
		<segment id="16" parent="96" relname="attribution">Надеюсь,</segment>
		<segment id="17" parent="96" relname="span">что это будет организовано таким образом,</segment>
		<segment id="18" parent="83" relname="joint">что это не будет бросаться в глаза,</segment>
		<segment id="19" parent="83" relname="joint">не будет давить на участников Олимпиады»</segment>
		<segment id="20" parent="60" relname="attribution">сказал Путин.</segment>
		<segment id="21" parent="98" relname="attribution">##### По его словам</segment>
		<segment id="22" parent="98" relname="span">к обеспечению безопасности будут привлечены силы и средства «главным образом такие,</segment>
		<segment id="23" parent="85" relname="span">которые не задействованы</segment>
		<segment id="24" parent="23" relname="condition">при обеспечении безопасности в других регионах Российской Федерации».</segment>
		<segment id="25" parent="64" relname="span">Нам хватает таких средств и по линии Федеральной службы безопасности, по линии Министерства внутренних дел, армейских подразделений»</segment>
		<segment id="26" parent="25" relname="attribution">заверил Путин.</segment>
		<segment id="27" parent="28" relname="attribution">##### Он добавил,</segment>
		<segment id="28" parent="92" relname="span">что «экстремисты всегда пытаются заявить о себе, особенно в преддверии каких-то крупных мероприятий, и не только спортивных, но и политических».</segment>
		<segment id="29" parent="71" relname="interpretation-evaluation">Очень жаль, я уже высказывался по этому поводу, хочу повторить:</segment>
		<segment id="30" parent="70" relname="joint">люди, настроенные экстремистски, они, как правило, люди ограниченные</segment>
		<segment id="31" parent="67" relname="same-unit">и не отдают себе отчет в том, что</segment>
		<segment id="32" parent="68" relname="concession">даже если, как они думают, они ставят перед собой благородные цели,</segment>
		<segment id="33" parent="88" relname="same-unit">то,</segment>
		<segment id="34" parent="35" relname="condition">совершая террористические акты,</segment>
		<segment id="35" parent="87" relname="span">они отдаляются,</segment>
		<segment id="36" parent="66" relname="joint">все дальше и дальше уходят от достижения тех, на первый взгляд даже благородных, может быть, целей,</segment>
		<segment id="37" parent="69" relname="interpretation-evaluation">вообще уходят за горизонт»</segment>
		<segment id="38" parent="72" relname="attribution">сказал Путин.</segment>
		<segment id="39" parent="40" relname="attribution">##### Президент также выразил надежду,</segment>
		<segment id="40" parent="77" relname="span">что на проведение Олимпиады не повлияют недавние теракты в Волгограде.</segment>
		<segment id="41" parent="74" relname="joint">Потому что если мы позволим себе проявить слабость,</segment>
		<segment id="42" parent="74" relname="joint">показать свой страх,</segment>
		<segment id="43" parent="75" relname="span">то значит, мы будем способствовать этим террористам в достижении их целей»</segment>
		<segment id="44" parent="75" relname="attribution">заявил глава государства.</segment>
		<segment id="45" parent="80" relname="joint">##### В преддверии Олимпиады безопасность жителей и гостей Сочи охраняет 40 тысяч полицейских, а также 400 казаков, которые участвуют в патрулировании.</segment>
		<segment id="46" parent="79" relname="span">С 7 января любой россиянин, не прописанный в Сочи, должен зарегистрироваться в городе по месту временного пребывания,</segment>
		<segment id="47" parent="46" relname="condition">если он находится там более трех дней.</segment>
		<segment id="48" parent="79" relname="concession">Исключение составляют только те, кто останавливается в гостиницах.</segment>
		<group id="49" type="multinuc" parent="93" relname="elaboration"/>
		<group id="53" type="multinuc" parent="55" relname="span"/>
		<group id="54" type="span" parent="53" relname="same-unit"/>
		<group id="55" type="span" parent="56" relname="span"/>
		<group id="56" type="span" parent="84" relname="span"/>
		<group id="57" type="multinuc" parent="62" relname="span"/>
		<group id="58" type="multinuc" parent="60" relname="span"/>
		<group id="60" type="span" parent="61" relname="span"/>
		<group id="61" type="span" parent="56" relname="elaboration"/>
		<group id="62" type="span" parent="90" relname="span"/>
		<group id="63" type="multinuc" parent="57" relname="joint"/>
		<group id="64" type="span" parent="63" relname="joint"/>
		<group id="66" type="multinuc" parent="68" relname="span"/>
		<group id="67" type="multinuc" parent="70" relname="joint"/>
		<group id="68" type="span" parent="69" relname="span"/>
		<group id="69" type="span" parent="91" relname="span"/>
		<group id="70" type="multinuc" parent="71" relname="span"/>
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" parent="73" relname="span"/>
		<group id="73" type="span" parent="86" relname="span"/>
		<group id="74" type="multinuc" parent="43" relname="condition"/>
		<group id="75" type="span" parent="76" relname="span"/>
		<group id="76" type="span" parent="77" relname="elaboration"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" parent="57" relname="joint"/>
		<group id="79" type="span" parent="89" relname="span"/>
		<group id="80" type="multinuc" />
		<group id="81" type="span" parent="82" relname="span"/>
		<group id="82" type="span" parent="62" relname="preparation"/>
		<group id="83" type="multinuc" parent="17" relname="condition"/>
		<group id="84" type="span" parent="57" relname="joint"/>
		<group id="85" type="span" parent="22" relname="elaboration"/>
		<group id="86" type="span" parent="57" relname="joint"/>
		<group id="87" type="span" parent="88" relname="same-unit"/>
		<group id="88" type="multinuc" parent="66" relname="joint"/>
		<group id="89" type="span" parent="80" relname="joint"/>
		<group id="90" type="span" />
		<group id="91" type="span" parent="67" relname="same-unit"/>
		<group id="92" type="span" parent="73" relname="preparation"/>
		<group id="93" type="span" parent="94" relname="span"/>
		<group id="94" type="span" parent="95" relname="span"/>
		<group id="95" type="span" parent="57" relname="joint"/>
		<group id="96" type="span" parent="97" relname="span"/>
		<group id="97" type="span" parent="58" relname="joint"/>
		<group id="98" type="span" parent="99" relname="span"/>
		<group id="99" type="span" parent="63" relname="joint"/>
	</body>
</rst>