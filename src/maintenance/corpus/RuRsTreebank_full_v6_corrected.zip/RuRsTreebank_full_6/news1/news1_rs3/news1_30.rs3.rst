<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="77" relname="preparation">##### Обамомания шагает по планете.</segment>
		<segment id="2" parent="74" relname="joint">Люди самых разных национальностей нашли нового идола,</segment>
		<segment id="3" parent="73" relname="joint">а предприимчивые бизнесмены — отличный способ заработать на этом</segment>
		<segment id="4" parent="73" relname="joint">и остаться на плаву во время мирового финансового кризиса.</segment>
		<segment id="5" parent="79" relname="joint">##### Например, китайские предприниматели вслед за всеми печатными СМИ приветствовали избрание Барака Обамы тиражированием его имени, но не на бумаге, а на всевозможных товарах — от лапши быстрого приготовления до футболок.</segment>
		<segment id="6" parent="75" relname="attribution">Как сообщает газета The Telegraph,</segment>
		<segment id="7" parent="75" relname="span">в городе Вэньчжоу производитель обуви зарегистрировал торговую марку Mei Obama,</segment>
		<segment id="8" parent="7" relname="elaboration">что переводится как «Американский Обама».</segment>
		<segment id="9" parent="114" relname="span">Теперь имя нового президента США красуется на ботинках, босоножках и сапогах.</segment>
		<segment id="10" parent="115" relname="span">##### В Хартуме, столице Судана, накануне инаугурации открылась парикмахерская имени Барака Обамы.</segment>
		<segment id="11" parent="10" relname="elaboration">В небольшом помещении на рынке Аль-Меркези цирюльник за несколько фунтов стрижет любого «под 44-го президента».</segment>
		<segment id="12" parent="80" relname="joint">##### В Японии фабрика Ogawa Rubber Inc. произвела</segment>
		<segment id="13" parent="80" relname="joint">и уже распродала более 2,5 тыс. масок Обамы.</segment>
		<segment id="14" parent="81" relname="sequence">На подходе еще тысяча экземпляров.</segment>
		<segment id="15" parent="116" relname="span">Причем новый «бестселлер» идет почти вровень по популярности с маской бывшего премьер-министра Японии Дзюнъитиро Коидзуми.</segment>
		<segment id="16" parent="15" relname="elaboration">Латексное лицо избранного президента США продается в магазинах Японии по цене примерно 2 тыс. иен (около 24 долларов).</segment>
		<segment id="17" parent="139" relname="span">##### В Израиле среди сувениров можно найти футболки с изображением нового хозяина Белого дома в образе ортодоксального еврея в кипе и с пейсами.</segment>
		<segment id="18" parent="19" relname="attribution">Надпись на ней гласит:</segment>
		<segment id="19" parent="83" relname="span">«Расслабься — будь евреем!»</segment>
		<segment id="20" parent="84" relname="joint">##### В столице Болгарии Софии на центральном открытом рынке с лотков торговцев разлетаются матрешки с изображением Обамы.</segment>
		<segment id="21" parent="22" relname="attribution">Как пишет Esquire,</segment>
		<segment id="22" parent="141" relname="span">на первой, самой большой, президент держит в руках скипетр и державу, на второй — гармонь, на третьей — чарку, на четвертой — хлеб-соль, а на пятой — букет гладиолусов.</segment>
		<segment id="23" parent="117" relname="span">##### В США было запущено производство энергетического напитка под незатейливым названием «Обама».</segment>
		<segment id="24" parent="23" relname="elaboration">Он рекламируется как «первая газировка для всех, кому нужны позитивные перемены».</segment>
		<segment id="25" parent="26" relname="cause-effect">Во время предвыборной кампании каждый покупатель упаковки из 24 банок жертвовал в предвыборный фонд Барака Обамы 1 доллар.</segment>
		<segment id="26" parent="118" relname="span">В итоге кандидат от Демократической партии собрал около 640 млн долларов.</segment>
		<segment id="27" parent="92" relname="joint">##### Американцы также наладили выпуск презервативов с лицом Обамы на упаковке.</segment>
		<segment id="28" parent="90" relname="attribution">Представители компании-производителя заявляют:</segment>
		<segment id="29" parent="85" relname="joint">«Сейчас нестабильные времена.</segment>
		<segment id="30" parent="85" relname="joint">Экономический рост замедлился. ..</segment>
		<segment id="31" parent="88" relname="joint">Но появились презервативы Obama,</segment>
		<segment id="32" parent="87" relname="same-unit">и</segment>
		<segment id="33" parent="34" relname="purpose">для разнообразия</segment>
		<segment id="34" parent="86" relname="span">вы можете теперь верить в них».</segment>
		<segment id="35" parent="97" relname="joint">##### А для тех, кто хочет «почувствовать истинный вкус демократии», продается гигиеническая помада «Барак».</segment>
		<segment id="36" parent="37" relname="attribution">Попробовавшие утверждают,</segment>
		<segment id="37" parent="93" relname="span">что у нее клубнично-мятный аромат.</segment>
		<segment id="38" parent="94" relname="attribution">Продукт был запущен после того, как в сентябре 2008 года Обама заявил:</segment>
		<segment id="39" parent="40" relname="cause-effect">«Если накрасить свинью губной помадой,</segment>
		<segment id="40" parent="94" relname="span">она останется свиньей»,</segment>
		<segment id="41" parent="95" relname="elaboration">намекая на лживую политику Маккейна и его напарницы Сары Пэйлин.</segment>
		<segment id="42" parent="98" relname="contrast">Тогда Барака поспешили обвинить в сексизме,</segment>
		<segment id="43" parent="98" relname="contrast">но, по-видимому, это никак не отразилось на его популярности.</segment>
		<segment id="44" parent="99" relname="joint">##### Образ Обамы не только помогает заработать денег,</segment>
		<segment id="45" parent="99" relname="joint">но и вдохновляет некоторых на создание произведений искусства.</segment>
		<segment id="46" parent="100" relname="joint">Так, в Индии художник Дарла Нагесвара Рао создал портрет нового президента из 33 тыс. цветных наклеек.</segment>
		<segment id="47" parent="101" relname="span">На это у него ушло около 160 часов,</segment>
		<segment id="48" parent="47" relname="attribution">сообщает BBC.</segment>
		<segment id="49" parent="103" relname="span">##### А посетитель сайта "Английское название"</segment>
		<segment id="50" parent="49" relname="elaboration">на котором развлекаются скучающие офисные служащие,</segment>
		<segment id="51" parent="104" relname="same-unit">создал копию знаменитого портрета Барака Обамы.</segment>
		<segment id="52" parent="126" relname="purpose">Для этого он использовал то, что было у него под рукой, — 21 156 канцелярских кнопок и картонную доску.</segment>
		<segment id="53" parent="128" relname="span">##### Барак как произведение искусства с 15 января 2009 года обитает в лондонском Музее мадам Тюссо.</segment>
		<segment id="54" parent="53" relname="elaboration">Специально для нее был воссоздан уголок легендарного Овального кабинета.</segment>
		<segment id="55" parent="105" relname="span">«Теперь у вас есть возможность ближе узнать самого могущественного человека в мире» ,</segment>
		<segment id="56" parent="55" relname="attribution">— говорится в пресс-релизе музея.</segment>
		<segment id="57" parent="132" relname="span">##### Не остались равнодушными к славе Обамы и владельцы ювелирной компании в британском городе Бирмингем.</segment>
		<segment id="58" parent="130" relname="cause-effect">Там выпустили памятную серебряную монету номиналом в 20 долларов с изображением Барака Обамы на фоне Белого дома.</segment>
		<segment id="59" parent="106" relname="cause-effect">Более 300 экземпляров проданы.</segment>
		<segment id="60" parent="106" relname="span">Такой успех заставил владельцев задуматься о более дорогом варианте монеты — из золота,</segment>
		<segment id="61" parent="60" relname="elaboration">каждая из которых обойдется поклоннику Обамы в 4 тыс. долларов.</segment>
		<segment id="62" parent="133" relname="span">##### Барак Обама — суперзвезда.</segment>
		<segment id="63" parent="62" relname="elaboration">Он обладает удивительной способностью нравиться всем — вне зависимости от цвета кожи, вероисповедания, национальности и рода занятий.</segment>
		<segment id="64" parent="110" relname="preparation">Однако преклонение это имеет многовековую предысторию.</segment>
		<segment id="65" parent="107" relname="joint">Любовь к царям, императорам, фараонам и прочим наместникам бога на земле правит умами человечества уже 4 тыс. лет.</segment>
		<segment id="66" parent="108" relname="joint">И особый внешний вид, специфический цвет кожи как был дополнительным фактором обожествления в праязыческие времена,</segment>
		<segment id="67" parent="108" relname="joint">так и остался сегодня.</segment>
		<segment id="68" parent="109" relname="span">Например, в Танзании и Конго кровь негров-альбиносов считается магическим снадобьем,</segment>
		<segment id="69" parent="68" relname="elaboration">дающим бессмертие.</segment>
		<segment id="70" parent="136" relname="span">Таким образом, люди с белой кожей среди темнокожих оказываются жертвой всеобщей жажды потустороннего.</segment>
		<segment id="71" parent="113" relname="joint">##### 44-й президент США, конечно же, воспринимается миллионами людей как избранник, человек особой судьбы.</segment>
		<segment id="72" parent="113" relname="joint">И его африканское происхождение, темная кожа и экзотическое имя добавляют ему не просто шарма, а даже какой-то магической тайны в глазах суеверных поклонников.</segment>
		<group id="73" type="multinuc" parent="74" relname="joint"/>
		<group id="74" type="multinuc" parent="77" relname="span"/>
		<group id="75" type="span" parent="76" relname="span"/>
		<group id="76" type="span" parent="79" relname="joint"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" />
		<group id="79" type="multinuc" parent="9" relname="cause-effect"/>
		<group id="80" type="multinuc" parent="81" relname="sequence"/>
		<group id="81" type="multinuc" parent="82" relname="joint"/>
		<group id="82" type="multinuc" parent="138" relname="joint"/>
		<group id="83" type="span" parent="17" relname="elaboration"/>
		<group id="84" type="multinuc" parent="138" relname="joint"/>
		<group id="85" type="multinuc" parent="89" relname="contrast"/>
		<group id="86" type="span" parent="87" relname="same-unit"/>
		<group id="87" type="multinuc" parent="88" relname="joint"/>
		<group id="88" type="multinuc" parent="89" relname="contrast"/>
		<group id="89" type="multinuc" parent="90" relname="span"/>
		<group id="90" type="span" parent="91" relname="span"/>
		<group id="91" type="span" parent="92" relname="joint"/>
		<group id="92" type="multinuc" />
		<group id="93" type="span" parent="97" relname="joint"/>
		<group id="94" type="span" parent="95" relname="span"/>
		<group id="95" type="span" parent="96" relname="span"/>
		<group id="96" type="span" parent="120" relname="cause-effect"/>
		<group id="97" type="multinuc" parent="122" relname="span"/>
		<group id="98" type="multinuc" parent="120" relname="span"/>
		<group id="99" type="multinuc" parent="124" relname="span"/>
		<group id="100" type="multinuc" parent="102" relname="span"/>
		<group id="101" type="span" parent="100" relname="joint"/>
		<group id="102" type="span" parent="124" relname="elaboration"/>
		<group id="103" type="span" parent="104" relname="same-unit"/>
		<group id="104" type="multinuc" parent="126" relname="span"/>
		<group id="105" type="span" parent="129" relname="joint"/>
		<group id="106" type="span" parent="130" relname="span"/>
		<group id="107" type="multinuc" parent="110" relname="span"/>
		<group id="108" type="multinuc" parent="134" relname="span"/>
		<group id="109" type="span" parent="134" relname="elaboration"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="112" relname="contrast"/>
		<group id="112" type="multinuc" />
		<group id="113" type="multinuc" />
		<group id="114" type="span" parent="137" relname="joint"/>
		<group id="115" type="span" parent="137" relname="joint"/>
		<group id="116" type="span" parent="82" relname="joint"/>
		<group id="117" type="span" parent="119" relname="joint"/>
		<group id="118" type="span" parent="119" relname="joint"/>
		<group id="119" type="multinuc" />
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="123" relname="joint"/>
		<group id="122" type="span" parent="123" relname="joint"/>
		<group id="123" type="multinuc" />
		<group id="124" type="span" parent="125" relname="span"/>
		<group id="125" type="span" parent="140" relname="joint"/>
		<group id="126" type="span" parent="127" relname="span"/>
		<group id="127" type="span" parent="140" relname="joint"/>
		<group id="128" type="span" parent="129" relname="joint"/>
		<group id="129" type="multinuc" />
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" parent="57" relname="elaboration"/>
		<group id="132" type="span" />
		<group id="133" type="span" parent="112" relname="contrast"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="70" relname="cause-effect"/>
		<group id="136" type="span" parent="107" relname="joint"/>
		<group id="137" type="multinuc" />
		<group id="138" type="multinuc" />
		<group id="139" type="span" parent="138" relname="joint"/>
		<group id="140" type="multinuc" />
		<group id="141" type="span" parent="84" relname="joint"/>
	</body>
</rst>