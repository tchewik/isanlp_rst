<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="47" relname="span">##### Северокорейский лидер Ким Чен Ын подобрал замену своему дяде Чан Сон Тхэку,</segment>
		<segment id="2" parent="1" relname="background">казненному в декабре 2013 года за коррупцию.</segment>
		<segment id="3" parent="82" relname="attribution">Как сообщает южнокорейская газета «Чосон ильбо»,</segment>
		<segment id="4" parent="82" relname="span">его место занял О Гык Рёль O Kuk-ryol;</segment>
		<segment id="5" parent="4" relname="background">иногда его имя в соответствии с корейским произношением пишется как О Гын Нёль)</segment>
		<segment id="6" parent="7" relname="attribution">который, по данным Sino-NK,</segment>
		<segment id="7" parent="58" relname="span">считается другом детства прежнего руководителя КНДР Ким Чен Ира.</segment>
		<segment id="8" parent="48" relname="attribution">##### По данным «Чосон ильбо»,</segment>
		<segment id="9" parent="48" relname="span">в обязанности О Гык Рёля войдет управление финансами Государственного комитета обороны (ГКО) — высшего органа военной власти,</segment>
		<segment id="10" parent="9" relname="elaboration">который возглавляет Ким Чен Ын.</segment>
		<segment id="11" parent="74" relname="span">Сам О Гык Рёль является зампредом ГКО.</segment>
		<segment id="12" parent="50" relname="joint">Теперь он будет отвечать за обеспечение экономики валютой,</segment>
		<segment id="13" parent="50" relname="joint">а также за развитие свободной экономической зоны в городе Синыйджу.</segment>
		<segment id="14" parent="75" relname="sequence">Ранее этими проектами занимался Чан Сон Тхэк.</segment>
		<segment id="15" parent="64" relname="same-unit">##### Кроме того,</segment>
		<segment id="16" parent="17" relname="attribution">утверждает издание,</segment>
		<segment id="17" parent="86" relname="span">в ведение О Гык Рёля вернут развитие морского порта</segment>
		<segment id="18" parent="79" relname="span">Расон</segment>
		<segment id="19" parent="63" relname="span">иногда читается как Насон</segment>
		<segment id="20" parent="19" relname="attribution">- прим. «Ленты.ру»)</segment>
		<segment id="21" parent="64" relname="same-unit">на северо-востоке КНДР,</segment>
		<segment id="22" parent="51" relname="joint">а также курирование экспорта морепродуктов и развития золотодобычи.</segment>
		<segment id="23" parent="24" relname="attribution">По сведениям «Чосон ильбо»,</segment>
		<segment id="24" parent="52" relname="span">Чан Сон Тхэк контролировал эти направления с 2010 года.</segment>
		<segment id="25" parent="53" relname="comparison">##### О Гык Рёль занимает тот же пост,</segment>
		<segment id="26" parent="53" relname="comparison">что и Чан Сон Тхэк до своей казни.</segment>
		<segment id="27" parent="66" relname="comparison">В то время как дядю северокорейского лидера в последнее время называли вторым лицом в государстве,</segment>
		<segment id="28" parent="67" relname="span">О Гык Рёлю такую же степень влиятельности приписывали еще в 2010 году</segment>
		<segment id="29" parent="28" relname="attribution">об этом, например, писала The Christian Science Monitor)</segment>
		<segment id="30" parent="69" relname="span">Этот статус О Гык Рёль потерял</segment>
		<segment id="31" parent="30" relname="cause-effect">с ростом влияния Чан Сон Тхэка,</segment>
		<segment id="32" parent="69" relname="attribution">утверждает «Чосон ильбо».</segment>
		<segment id="33" parent="54" relname="span">##### О Гык Рёль родился в 1931 году в семье участника антияпонского подполья О Чжун Хупа (O Jung Hup),</segment>
		<segment id="34" parent="33" relname="background">который, по разным данным, приходился ему отцом или дядей.</segment>
		<segment id="35" parent="55" relname="sequence">Против японских колонизаторов О Чжун Хуп сражался бок о бок с основателем КНДР Ким Ир Сеном.</segment>
		<segment id="36" parent="37" relname="cause-effect">Впоследствии, из-за близости двух семей,</segment>
		<segment id="37" parent="59" relname="span">О Гык Рёль подружился с Ким Чен Иром.</segment>
		<segment id="38" parent="62" relname="sequence">##### В 1979 году О Гык Рёль получил пост начальника генштаба северокорейской армии,</segment>
		<segment id="39" parent="62" relname="sequence">на котором продержался до конца 1980-х.</segment>
		<segment id="40" parent="56" relname="span">В 2009 году он вернулся на политическую сцену,</segment>
		<segment id="41" parent="40" relname="condition">получив должность зампреда ГКО.</segment>
		<segment id="42" parent="57" relname="span">##### О Гык Рёль стал не первым,</segment>
		<segment id="43" parent="42" relname="elaboration">кому перешли полномочия Чан Сон Тхэка.</segment>
		<segment id="44" parent="65" relname="span">Ранее в январе сообщалось, что младшая сестра северокорейского лидера Ким Ё Чжон возглавила 54-й отдел Трудовой партии Кореи.</segment>
		<segment id="45" parent="44" relname="elaboration">Основной задачей этого органа является снабжение армии.</segment>
		<segment id="46" parent="65" relname="interpretation-evaluation">Считается, что курировал его именно дядя Ким Чен Ына.</segment>
		<group id="47" type="span" parent="84" relname="preparation"/>
		<group id="48" type="span" parent="49" relname="span"/>
		<group id="49" type="span" parent="74" relname="preparation"/>
		<group id="50" type="multinuc" parent="75" relname="sequence"/>
		<group id="51" type="multinuc" parent="76" relname="sequence"/>
		<group id="52" type="span" parent="76" relname="sequence"/>
		<group id="53" type="multinuc" parent="71" relname="preparation"/>
		<group id="54" type="span" parent="60" relname="background"/>
		<group id="55" type="multinuc" parent="60" relname="span"/>
		<group id="56" type="span" parent="55" relname="sequence"/>
		<group id="57" type="span" parent="81" relname="span"/>
		<group id="58" type="span" parent="83" relname="elaboration"/>
		<group id="59" type="span" parent="55" relname="sequence"/>
		<group id="60" type="span" parent="61" relname="span"/>
		<group id="61" type="span" />
		<group id="62" type="multinuc" parent="55" relname="sequence"/>
		<group id="63" type="span" parent="18" relname="background"/>
		<group id="64" type="multinuc" parent="51" relname="joint"/>
		<group id="65" type="span" parent="80" relname="span"/>
		<group id="66" type="multinuc" parent="71" relname="span"/>
		<group id="67" type="span" parent="68" relname="span"/>
		<group id="68" type="span" parent="73" relname="span"/>
		<group id="69" type="span" parent="70" relname="span"/>
		<group id="70" type="span" parent="68" relname="elaboration"/>
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" />
		<group id="73" type="span" parent="66" relname="comparison"/>
		<group id="74" type="span" parent="77" relname="span"/>
		<group id="75" type="multinuc" parent="11" relname="elaboration"/>
		<group id="76" type="multinuc" parent="78" relname="joint"/>
		<group id="77" type="span" parent="78" relname="joint"/>
		<group id="78" type="multinuc" />
		<group id="79" type="span" parent="64" relname="same-unit"/>
		<group id="80" type="span" parent="57" relname="evidence"/>
		<group id="81" type="span" />
		<group id="82" type="span" parent="83" relname="span"/>
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" parent="85" relname="span"/>
		<group id="85" type="span" />
		<group id="86" type="span" parent="64" relname="same-unit"/>
	</body>
</rst>