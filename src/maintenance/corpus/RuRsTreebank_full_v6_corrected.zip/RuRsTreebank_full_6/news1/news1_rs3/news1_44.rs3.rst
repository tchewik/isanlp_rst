<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="136" relname="joint">##### В России бизнес на протяжении многих лет поставлен в экстремальные условия</segment>
		<segment id="2" parent="136" relname="joint">и всем собственникам бизнеса приходится в них работать.</segment>
		<segment id="3" parent="153" relname="span">Поэтому не удивительно, что за прошедшие годы реформ и наших тренировок выживания в этих условиях, в бизнесе сформировались свои, российские, принципы управления.</segment>
		<segment id="4" parent="154" relname="span">Но время идет, а способы решения проблем остаются на уровне середины 90-х годов:</segment>
		<segment id="5" parent="137" relname="joint">все хочется верить в то, что достаточно собрать акционеров,</segment>
		<segment id="6" parent="137" relname="joint">заслушать управляющих менеджеров</segment>
		<segment id="7" parent="137" relname="joint">и принять решение по очередной проблеме.</segment>
		<segment id="8" parent="156" relname="elaboration">Рынок же, кроме внутренней проработки проблем требует сил и средств для разведки, сбора и обработки многочисленных источников внешней информации.</segment>
		<segment id="9" parent="217" relname="span">##### Книг, статей написано много,</segment>
		<segment id="10" parent="214" relname="joint">в одной терминологии запутаться можно: конкурентная разведка, промышленный шпионаж, маркетинговая разведка,</segment>
		<segment id="11" parent="214" relname="joint">украинским соседям понравилось английское слово "бенчмаркинг".</segment>
		<segment id="12" parent="159" relname="span">Попробуем расшифровать, что все это значит и,</segment>
		<segment id="13" parent="158" relname="span">возможно, бизнесу не надо прибегать к этим премудростям,</segment>
		<segment id="14" parent="13" relname="cause-effect">жилось ведь и без этого хорошо.</segment>
		<segment id="15" parent="16" relname="preparation">##### Начнем с промышленного шпионажа.</segment>
		<segment id="16" parent="160" relname="span">Что такое "промышленный" - это понятно, а вот "шпионаж"?</segment>
		<segment id="17" parent="161" relname="span">Дело в том, что шпионаж предполагает передачу, похищение или сбор</segment>
		<segment id="18" parent="17" relname="purpose">с целью передачи иностранному государству, или его агентуре, сведений, составляющих государственную или военную тайну,</segment>
		<segment id="19" parent="261" relname="span">поэтому промышленным шпионажем должны заниматься соответствующие органы, уполномоченные на это государством.</segment>
		<segment id="20" parent="163" relname="span">##### Маркетинговая разведка - понятие очень широкое,</segment>
		<segment id="21" parent="138" relname="joint">слово "маркетинг" подразумевает не только изучение конкурентов,</segment>
		<segment id="22" parent="162" relname="span">но и продвижение продукта, ценообразование, рекламу,</segment>
		<segment id="23" parent="22" relname="elaboration">начиная с начальной стадии существования продукта до его продажи.</segment>
		<segment id="24" parent="172" relname="joint">##### "Бенчмаркинг" (benchmarking) в переводе с английского языка подразумевает сравнение эффективности системы, числа, с каким-то установленным, принятым значением.</segment>
		<segment id="25" parent="165" relname="span">##### Конкурентная разведка - это узкое направление, которое должно отвечать</segment>
		<segment id="26" parent="164" relname="restatement">основной цели -- построению системы борьбы с конкурентами,</segment>
		<segment id="27" parent="164" relname="restatement">т.е. создания комплекса мероприятий по получению и обработке данных о конкуренте: имущественных, финансовых и управленческих ресурсах, возможностях и уязвимости, а также о ближайших и стратегических планах.</segment>
		<segment id="28" parent="166" relname="joint">##### Такие данные можно добывать штатными силами и средствами,</segment>
		<segment id="29" parent="166" relname="joint">либо получать от компаний, которые работают в этом направлении.</segment>
		<segment id="30" parent="169" relname="span">Главное одно: чтобы сведения были достоверными.</segment>
		<segment id="31" parent="139" relname="joint">Получить же достоверную информацию о работе предприятий из финансовой отчетности невозможно</segment>
		<segment id="32" parent="170" relname="span">и статистика Госкомстата, Таможенного комитета подходит лишь</segment>
		<segment id="33" parent="32" relname="purpose">для выявления изменений в динамике рынков.</segment>
		<segment id="34" parent="175" relname="span">##### Крупному бизнесу проще,</segment>
		<segment id="35" parent="174" relname="span">он имеет возможность содержать большие информационно-аналитические отделы</segment>
		<segment id="36" parent="35" relname="purpose">для проведения разведки,</segment>
		<segment id="37" parent="140" relname="span">а вот средний и малый такой возможности лишен,</segment>
		<segment id="38" parent="37" relname="cause-effect">нет денег.</segment>
		<segment id="39" parent="142" relname="joint">Но, оказывается, дело не только в недостатке финансов на проведение такой работы,</segment>
		<segment id="40" parent="177" relname="span">а, в большинстве случаев, в оценке видения развития бизнеса.</segment>
		<segment id="41" parent="40" relname="cause-effect">Причины здесь такие.</segment>
		<segment id="42" parent="182" relname="span">##### Причина первая - переоценка собственного опыта.</segment>
		<segment id="43" parent="143" relname="joint">Удачно складывающаяся обстановка в предыдущие годы на незаполненных рынках,</segment>
		<segment id="44" parent="143" relname="joint">быстрое развитие, большие прибыли стали нормой.</segment>
		<segment id="45" parent="178" relname="span">Например, в 90-е годы, торговый бизнес можно было начинать,</segment>
		<segment id="46" parent="45" relname="condition">продавая любой зарубежный товар в России,</segment>
		<segment id="47" parent="179" relname="joint">при этом получать неплохую прибыль.</segment>
		<segment id="48" parent="180" relname="background">Да и кризис 1998 года помог удалить с российского рынка зарубежных производителей-конкурентов.</segment>
		<segment id="49" parent="183" relname="span">Поэтому, для бизнесменов значимость собственного опыта в бизнесе в большинстве случаев становится определяющей.</segment>
		<segment id="50" parent="196" relname="span">##### Вторая причина - завышенная оценка знания рынка.</segment>
		<segment id="51" parent="52" relname="cause-effect">По практике работы с фирмами можно сказать,</segment>
		<segment id="52" parent="144" relname="span">что ошибка в оценке объемов рынков составляет от 20 до 50%.</segment>
		<segment id="53" parent="185" relname="span">Знания о конкурентах чаще всего фирмы получают из СМИ, на выставках, через дилеров,</segment>
		<segment id="54" parent="191" relname="span">а такие сведения иногда бывают достаточно противоречивыми.</segment>
		<segment id="55" parent="264" relname="attribution">Один из дилеров на рынке строительных материалов, например, в доверительной беседе,</segment>
		<segment id="56" parent="57" relname="condition">говоря об объеме продаваемого товара у других дилеров,</segment>
		<segment id="57" parent="186" relname="span">называл цифры заниженные в разы,</segment>
		<segment id="58" parent="145" relname="joint">при этом еще давал неверную информацию по логистике.</segment>
		<segment id="59" parent="265" relname="attribution">Одновременно, другой дилер, на том же рынке,</segment>
		<segment id="60" parent="61" relname="condition">говоря о тех же объемах продаж</segment>
		<segment id="61" parent="265" relname="span">давал прямо противоположную информацию.</segment>
		<segment id="62" parent="189" relname="interpretation-evaluation">При этом один и другой искренне верили в правильность сведений, которыми располагали.</segment>
		<segment id="63" parent="258" relname="solutionhood">Читатель скажет, что это вы про дилеров, вот собственникам бизнеса всё известно.</segment>
		<segment id="64" parent="257" relname="interpretation-evaluation">Хочу разочаровать читателя,</segment>
		<segment id="65" parent="257" relname="span">собственникам бизнеса информация о конкуренте известна в исключительно редких случаях,</segment>
		<segment id="66" parent="65" relname="cause-effect">потому что она устаревает практически еженедельно.</segment>
		<segment id="67" parent="194" relname="joint">Один собственник крупного торгового бизнеса стучал по столу</segment>
		<segment id="68" parent="194" relname="joint">и со словами "у меня вся таможня подкуплена",</segment>
		<segment id="69" parent="193" relname="span">пытался доказать правильность его сведений по импорту.</segment>
		<segment id="70" parent="193" relname="interpretation-evaluation">К сожалению, оказался неправ.</segment>
		<segment id="71" parent="200" relname="joint">##### Третья причина вызвана предыдущими двумя</segment>
		<segment id="72" parent="200" relname="joint">и выражается в нежелании платить высокую цену за информацию.</segment>
		<segment id="73" parent="146" relname="comparison">Казалось бы, простая арифметика - при годовом обороте в $3 млн. в бюджете на поиск информации необходимо выделять примерно $10 тыс.,</segment>
		<segment id="74" parent="146" relname="comparison">а при годовом обороте $30 млн. -- 30-100 тыс.</segment>
		<segment id="75" parent="201" relname="joint">Соберет информацию фирма своими силами</segment>
		<segment id="76" parent="201" relname="joint">или пригласит внешнюю помощь - это другой вопрос.</segment>
		<segment id="77" parent="203" relname="span">Главное, что такие цифры вызывают удивление: "Зачем?</segment>
		<segment id="78" parent="202" relname="contrast">" Затраты на рекламу - понятно,</segment>
		<segment id="79" parent="202" relname="contrast">а за информацию - не понятно.</segment>
		<segment id="80" parent="204" relname="span">Ответ здесь такой: российский рынок очень медленно, но несомненно входит в период,</segment>
		<segment id="81" parent="206" relname="span">который характеризуется наступлением и действием рыночных законов:</segment>
		<segment id="82" parent="147" relname="joint">концентрация продавцов на рынке увеличивается,</segment>
		<segment id="83" parent="147" relname="joint">рыночные барьеры входа растут,</segment>
		<segment id="84" parent="147" relname="joint">конкурентная борьба усиливается,</segment>
		<segment id="85" parent="205" relname="span">а прибыль уже не может составлять 300-1000 % в год,</segment>
		<segment id="86" parent="85" relname="concession">хотя кое-где еще и сохраняется.</segment>
		<segment id="87" parent="212" relname="span">##### Четвертая причина - это причина, которую я бы назвала "молодостью управления",</segment>
		<segment id="88" parent="87" relname="cause-effect">и которая не зависит от стажа управления бизнесом,</segment>
		<segment id="89" parent="213" relname="restatement">-- нежелание терять время на исследование.</segment>
		<segment id="90" parent="218" relname="joint">Приходит в голову идея,</segment>
		<segment id="91" parent="219" relname="span">есть деньги</segment>
		<segment id="92" parent="91" relname="purpose">для ее реализации,</segment>
		<segment id="93" parent="148" relname="joint">почему бы не попробовать</segment>
		<segment id="94" parent="220" relname="span">и побыстрее ее осуществить,</segment>
		<segment id="95" parent="94" relname="cause-effect">а то вдруг конкурент появится.</segment>
		<segment id="96" parent="224" relname="span">А может эту идею не в данный момент, а именно через год запускать надо?</segment>
		<segment id="97" parent="228" relname="span">На такие рассуждения и обоснование идеи бизнесмен уже не хочет тратить время.</segment>
		<segment id="98" parent="150" relname="contrast">Риск, конечно, дело хорошее, куда без него.</segment>
		<segment id="99" parent="227" relname="span">Но риск риску рознь.</segment>
		<segment id="100" parent="225" relname="joint">Хорошая идея должна не только "родиться",</segment>
		<segment id="101" parent="149" relname="span">но и "стать на ноги",</segment>
		<segment id="102" parent="226" relname="span">чтобы сразу "делать уверенные шаги",</segment>
		<segment id="103" parent="102" relname="purpose">а на это необходимо время.</segment>
		<segment id="104" parent="238" relname="span">##### Методов конкурентной разведки очень много.</segment>
		<segment id="105" parent="104" relname="elaboration">На такие исследования иногда уходит месяц, иногда год и более.</segment>
		<segment id="106" parent="107" relname="condition">Для человека, который не знаком с такими методами,</segment>
		<segment id="107" parent="231" relname="span">методы разведки представляются как запрещенные: взлом компьютера, "прослушка", подкуп сотрудников.</segment>
		<segment id="108" parent="232" relname="contrast">Это не так.</segment>
		<segment id="109" parent="151" relname="comparison">Основные методы основаны на логике и сборе легальной информации.</segment>
		<segment id="110" parent="235" relname="same-unit">А вот методы сбора отличаются кардинально: это и беседы с сотрудниками фирмы конкурента (темы любые: о погоде, об учебе и заодно о товаре), беседа по телефону с менеджерами - в большинстве случаев</segment>
		<segment id="111" parent="112" relname="condition">при правильной беседе</segment>
		<segment id="112" parent="233" relname="span">можно узнать сразу половину всей интересующей информации,</segment>
		<segment id="113" parent="235" relname="same-unit">это резюме сотрудников,</segment>
		<segment id="114" parent="234" relname="span">в которых они могут раскрыть часть информации,</segment>
		<segment id="115" parent="114" relname="purpose">чтобы понравиться новому работодателю,</segment>
		<segment id="116" parent="235" relname="same-unit">это интернет, в котором те же менеджеры проводят часы в форумах,</segment>
		<segment id="117" parent="235" relname="same-unit">это и черновики, которые сотнями удаляются из офисов.</segment>
		<segment id="118" parent="236" relname="elaboration">Часть методов основана на наблюдении, которое в исследовании конкурентов применяется широко.</segment>
		<segment id="119" parent="120" relname="purpose">##### Для проверки достоверности собранных результатов</segment>
		<segment id="120" parent="242" relname="span">обязательно необходимо провести встречный сбор информации.</segment>
		<segment id="121" parent="245" relname="same-unit">Например,</segment>
		<segment id="122" parent="243" relname="purpose">для определения реальных объемов перевозимых через таможню товаров,</segment>
		<segment id="123" parent="124" relname="condition">при помощи обработки больших объемов статистической данных,</segment>
		<segment id="124" parent="243" relname="span">необходимо сформировать поправочные коэффициенты укрытия объемов товара.</segment>
		<segment id="125" parent="256" relname="joint">Причем они будут значительно отличаться в зависимости от рынка, от вида товара, от поставщика.</segment>
		<segment id="126" parent="247" relname="span">Поэтому уже не удивительно, когда данные таможни не совпадают с реальными объемами перевозки в 5 и более раз.</segment>
		<segment id="127" parent="260" relname="span">##### В заключение хочется сказать о потребителе,</segment>
		<segment id="128" parent="127" relname="cause-effect">именно потребитель, на которого и нацелен любой бизнес, всегда даст уточняющую информацию по конкурентам.</segment>
		<segment id="129" parent="249" relname="span">И здесь, к великой радости, можно создавать новые методы исследований,</segment>
		<segment id="130" parent="152" relname="joint">потому что потребителя ни один собственник бизнеса не может спрятать,</segment>
		<segment id="131" parent="152" relname="joint">он у всех на виду.</segment>
		<segment id="132" parent="252" relname="joint">Поэтому информация от потребителя завершит круг сбора информации,</segment>
		<segment id="133" parent="251" relname="same-unit">а</segment>
		<segment id="134" parent="135" relname="condition">при умелом использовании всех собранных данных</segment>
		<segment id="135" parent="250" relname="span">можно выйти на реальную стоимость бизнеса конкурента, на инвестиции вложенные в его бизнес, на организационную структуру фирмы, на ежедневный доход конкурента и многое другое.</segment>
		<group id="136" type="multinuc" parent="3" relname="cause-effect"/>
		<group id="137" type="multinuc" parent="4" relname="elaboration"/>
		<group id="138" type="multinuc" parent="20" relname="elaboration"/>
		<group id="139" type="multinuc" parent="30" relname="concession"/>
		<group id="140" type="span" parent="176" relname="contrast"/>
		<group id="141" type="multinuc" />
		<group id="142" type="multinuc" parent="176" relname="contrast"/>
		<group id="143" type="multinuc" parent="42" relname="elaboration"/>
		<group id="144" type="span" parent="50" relname="background"/>
		<group id="145" type="multinuc" parent="264" relname="span"/>
		<group id="146" type="multinuc" parent="207" relname="span"/>
		<group id="147" type="multinuc" parent="81" relname="elaboration"/>
		<group id="148" type="multinuc" parent="221" relname="span"/>
		<group id="149" type="span" parent="225" relname="joint"/>
		<group id="150" type="multinuc" parent="97" relname="interpretation-evaluation"/>
		<group id="151" type="multinuc" parent="239" relname="evidence"/>
		<group id="152" type="multinuc" parent="129" relname="cause-effect"/>
		<group id="153" type="span" parent="155" relname="contrast"/>
		<group id="154" type="span" parent="155" relname="contrast"/>
		<group id="155" type="multinuc" parent="156" relname="span"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="173" relname="span"/>
		<group id="158" type="span" parent="12" relname="interpretation-evaluation"/>
		<group id="159" type="span" parent="215" relname="elaboration"/>
		<group id="160" type="span" parent="261" relname="solutionhood"/>
		<group id="161" type="span" parent="19" relname="cause-effect"/>
		<group id="162" type="span" parent="138" relname="joint"/>
		<group id="163" type="span" parent="172" relname="joint"/>
		<group id="164" type="multinuc" parent="25" relname="purpose"/>
		<group id="165" type="span" parent="171" relname="span"/>
		<group id="166" type="multinuc" parent="167" relname="span"/>
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="165" relname="elaboration"/>
		<group id="169" type="span" parent="167" relname="purpose"/>
		<group id="170" type="span" parent="139" relname="joint"/>
		<group id="171" type="span" />
		<group id="172" type="multinuc" />
		<group id="173" type="span" />
		<group id="174" type="span" parent="34" relname="cause-effect"/>
		<group id="175" type="span" parent="141" relname="contrast"/>
		<group id="176" type="multinuc" parent="141" relname="contrast"/>
		<group id="177" type="span" parent="142" relname="joint"/>
		<group id="178" type="span" parent="179" relname="joint"/>
		<group id="179" type="multinuc" parent="180" relname="span"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="49" relname="cause-effect"/>
		<group id="182" type="span" parent="183" relname="preparation"/>
		<group id="183" type="span" parent="184" relname="span"/>
		<group id="184" type="span" />
		<group id="185" type="span" parent="197" relname="joint"/>
		<group id="186" type="span" parent="145" relname="joint"/>
		<group id="188" type="multinuc" parent="189" relname="span"/>
		<group id="189" type="span" parent="190" relname="span"/>
		<group id="190" type="span" parent="54" relname="elaboration"/>
		<group id="191" type="span" parent="53" relname="concession"/>
		<group id="192" type="span" parent="258" relname="span"/>
		<group id="193" type="span" parent="195" relname="span"/>
		<group id="194" type="multinuc" parent="69" relname="evidence"/>
		<group id="195" type="span" parent="192" relname="elaboration"/>
		<group id="196" type="span" parent="198" relname="preparation"/>
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" />
		<group id="200" type="multinuc" parent="209" relname="preparation"/>
		<group id="201" type="multinuc" parent="207" relname="elaboration"/>
		<group id="202" type="multinuc" parent="77" relname="elaboration"/>
		<group id="203" type="span" parent="204" relname="solutionhood"/>
		<group id="204" type="span" parent="210" relname="span"/>
		<group id="205" type="span" parent="147" relname="joint"/>
		<group id="206" type="span" parent="80" relname="background"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" parent="211" relname="span"/>
		<group id="210" type="span" parent="208" relname="interpretation-evaluation"/>
		<group id="211" type="span" />
		<group id="212" type="span" parent="213" relname="restatement"/>
		<group id="213" type="multinuc" parent="229" relname="preparation"/>
		<group id="214" type="multinuc" parent="215" relname="span"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" parent="9" relname="interpretation-evaluation"/>
		<group id="217" type="span" parent="157" relname="elaboration"/>
		<group id="218" type="multinuc" parent="221" relname="cause-effect"/>
		<group id="219" type="span" parent="218" relname="joint"/>
		<group id="220" type="span" parent="148" relname="joint"/>
		<group id="221" type="span" parent="222" relname="span"/>
		<group id="222" type="span" parent="223" relname="contrast"/>
		<group id="223" type="multinuc" parent="229" relname="span"/>
		<group id="224" type="span" parent="223" relname="contrast"/>
		<group id="225" type="multinuc" parent="99" relname="elaboration"/>
		<group id="226" type="span" parent="101" relname="purpose"/>
		<group id="227" type="span" parent="150" relname="contrast"/>
		<group id="228" type="span" parent="96" relname="elaboration"/>
		<group id="229" type="span" parent="230" relname="span"/>
		<group id="230" type="span" />
		<group id="231" type="span" parent="232" relname="contrast"/>
		<group id="232" type="multinuc" parent="239" relname="span"/>
		<group id="233" type="span" parent="235" relname="same-unit"/>
		<group id="234" type="span" parent="235" relname="same-unit"/>
		<group id="235" type="multinuc" parent="236" relname="span"/>
		<group id="236" type="span" parent="237" relname="span"/>
		<group id="237" type="span" parent="151" relname="comparison"/>
		<group id="238" type="span" parent="240" relname="preparation"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" />
		<group id="242" type="span" parent="247" relname="preparation"/>
		<group id="243" type="span" parent="244" relname="span"/>
		<group id="244" type="span" parent="245" relname="same-unit"/>
		<group id="245" type="multinuc" parent="246" relname="span"/>
		<group id="246" type="span" parent="256" relname="joint"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" />
		<group id="249" type="span" parent="253" relname="cause-effect"/>
		<group id="250" type="span" parent="251" relname="same-unit"/>
		<group id="251" type="multinuc" parent="252" relname="joint"/>
		<group id="252" type="multinuc" parent="253" relname="span"/>
		<group id="253" type="span" parent="254" relname="span"/>
		<group id="254" type="span" parent="255" relname="span"/>
		<group id="255" type="span" />
		<group id="256" type="multinuc" parent="126" relname="evidence"/>
		<group id="257" type="span" parent="192" relname="span"/>
		<group id="258" type="span" parent="259" relname="span"/>
		<group id="259" type="span" parent="197" relname="joint"/>
		<group id="260" type="span" parent="254" relname="preparation"/>
		<group id="261" type="span" parent="262" relname="span"/>
		<group id="262" type="span" parent="172" relname="joint"/>
		<group id="263" type="span" parent="188" relname="comparison"/>
		<group id="264" type="span" parent="263" relname="span"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" parent="188" relname="comparison"/>
	</body>
</rst>