<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="196" relname="span">##### Кольца Урана — система планетных колец, окружающих Уран.</segment>
		<segment id="2" parent="194" relname="joint">Среди других систем колец она занимает промежуточное положение по сложности строения между более развитой системой колец Сатурна и простыми системами колец Юпитера и Нептуна.</segment>
		<segment id="3" parent="194" relname="joint">Кольца Урана были открыты 10 марта 1977 года Джеймсом Элиотом, Эдвардом Данхэмом и Дугласом Минком.</segment>
		<segment id="4" parent="5" relname="attribution">##### За 200 лет до этого Уильям Гершель сообщал</segment>
		<segment id="5" parent="183" relname="span">о наблюдениях колец у Урана,</segment>
		<segment id="6" parent="7" relname="interpretation-evaluation">однако современные астрономы сомневаются</segment>
		<segment id="7" parent="180" relname="span">в возможности такого открытия,</segment>
		<segment id="8" parent="9" relname="cause-effect">так как кольца очень слабые и тёмные</segment>
		<segment id="9" parent="179" relname="span">и не могли быть обнаружены с помощью астрономического оборудования того времени.</segment>
		<segment id="10" parent="182" relname="sequence">Два новых кольца системы Урана были обнаружены «Вояджером-2» в 1986 году,</segment>
		<segment id="11" parent="182" relname="sequence">ещё два внешних кольца были обнаружены телескопом «Хаббл» в 2003—2005 годах.</segment>
		<segment id="12" parent="191" relname="span">##### По состоянию на 2008 год известно 13 отдельных колец.</segment>
		<segment id="13" parent="188" relname="joint">В порядке увеличения расстояния от планеты они расположены так: 1986U2R/ζ, 6, 5, 4, α, β, η, γ, δ, λ, ε, ν и μ.</segment>
		<segment id="14" parent="186" relname="contrast">Минимальный радиус имеет кольцо 1986U2R/ζ (38 000 км),</segment>
		<segment id="15" parent="186" relname="contrast">максимальный — кольцо μ (приблизительно 98 000 км).</segment>
		<segment id="16" parent="188" relname="joint">Между основными кольцами могут находиться слабые пылевые кольцевые скопления и незамкнутые арки.</segment>
		<segment id="17" parent="187" relname="span">Кольца чрезвычайно тёмные,</segment>
		<segment id="18" parent="17" relname="elaboration">альбедо Бонда для входящих в них частиц не превышает 2 %.</segment>
		<segment id="19" parent="188" relname="joint">Вероятно, они состоят из водяного льда с включениями органики.</segment>
		<segment id="20" parent="201" relname="joint">##### Большинство колец Урана непрозрачны,</segment>
		<segment id="21" parent="201" relname="joint">их ширина не больше нескольких километров.</segment>
		<segment id="22" parent="200" relname="span">В целом, кольцевая система содержит немного пыли,</segment>
		<segment id="23" parent="22" relname="elaboration">она состоит в основном из крупных объектов диаметром от 20 сантиметров до 20 метров.</segment>
		<segment id="24" parent="199" relname="span">Однако некоторые кольца оптически тонкие:</segment>
		<segment id="25" parent="197" relname="contrast">широкое тусклое 1986U2R/ζ, μ и ν состоят из мелких частиц пыли,</segment>
		<segment id="26" parent="197" relname="contrast">тогда как узкое тусклое λ содержит крупные тела.</segment>
		<segment id="27" parent="202" relname="span">Относительно небольшое количество пыли в кольцевой системе объясняется</segment>
		<segment id="28" parent="27" relname="cause-effect">аэродинамическим лобовым сопротивлением протяжённой экзосферы — короны Урана.</segment>
		<segment id="29" parent="208" relname="span">##### Считается, что кольца Урана относительно молоды,</segment>
		<segment id="30" parent="29" relname="elaboration">их возраст не превышает 600 миллионов лет.</segment>
		<segment id="31" parent="209" relname="span">Кольцевая система Урана, вероятно, произошла от столкновений спутников, ранее обращавшихся по орбите вокруг планеты.</segment>
		<segment id="32" parent="206" relname="cause-effect">В результате столкновений</segment>
		<segment id="33" parent="206" relname="span">спутники, вероятно, постепенно разбивались на более мелкие частицы,</segment>
		<segment id="34" parent="33" relname="elaboration">которые теперь существуют как кольца в строго ограниченных зонах максимальной гравитационной стабильности.</segment>
		<segment id="35" parent="214" relname="span">##### До сих пор не ясен механизм, удерживающий узкие кольца в их границах.</segment>
		<segment id="36" parent="211" relname="span">Первоначально считалось, что у каждого узкого кольца есть пара «спутников-пастухов»,</segment>
		<segment id="37" parent="36" relname="elaboration">которые и поддерживают его форму,</segment>
		<segment id="38" parent="212" relname="contrast">но в 1986 году Вояджер-2 обнаружил только одну пару таких спутников (Корделию и Офелию) вокруг самого яркого кольца — ε.</segment>
		<segment id="39" parent="258" relname="preparation">##### История наблюдений</segment>
		<segment id="40" parent="226" relname="span">##### В работах первооткрывателя Урана, Уильяма Гершеля, первое упоминание о кольцах встречается в его записи от 22 февраля 1789 года.</segment>
		<segment id="41" parent="42" relname="attribution">В своих примечаниях к наблюдениям он отметил,</segment>
		<segment id="42" parent="215" relname="span">что предполагает наличие колец у Урана.</segment>
		<segment id="43" parent="216" relname="attribution">Гершель предположил,</segment>
		<segment id="44" parent="216" relname="span">что они красного цвета</segment>
		<segment id="45" parent="44" relname="elaboration">(что было подтверждено в 2006 году наблюдениями обсерватории Кек в случае предпоследнего кольца) .</segment>
		<segment id="46" parent="220" relname="contrast">Записи Гершеля попали в журнал Королевского общества в 1797 году.</segment>
		<segment id="47" parent="48" relname="cause-effect">Однако впоследствии, на протяжении почти двух столетий с 1797 по 1979 год, кольца в научной литературе не упоминаются вовсе,</segment>
		<segment id="48" parent="219" relname="span">что, конечно, даёт право подозревать ошибку учёного.</segment>
		<segment id="49" parent="50" relname="cause-effect">Тем не менее, достаточно точные описания увиденного Гершелем</segment>
		<segment id="50" parent="218" relname="span">не дают повода просто так сбрасывать со счетов его наблюдения.</segment>
		<segment id="51" parent="253" relname="span">##### Наличие кольцевой системы у Урана официально было подтверждено лишь 10 марта 1977 года американскими учёными.</segment>
		<segment id="52" parent="251" relname="preparation">Открытие было сделано случайно</segment>
		<segment id="53" parent="250" relname="contrast">— группа учёных планировала провести наблюдения атмосферы Урана при покрытии им звезды SAO 158687.</segment>
		<segment id="54" parent="246" relname="same-unit">Однако,</segment>
		<segment id="55" parent="56" relname="cause-effect">анализируя полученную после проведённых наблюдений информацию,</segment>
		<segment id="56" parent="245" relname="span">они обнаружили покрытие звезды ещё до её покрытия Ураном,</segment>
		<segment id="57" parent="247" relname="elaboration">причём произошло это несколько раз подряд.</segment>
		<segment id="58" parent="59" relname="cause-effect">В результате исследований</segment>
		<segment id="59" parent="249" relname="span">было открыто 9 колец Урана.</segment>
		<segment id="60" parent="235" relname="sequence">##### Когда в окрестности Урана прибыл космический аппарат «Вояджер-2»,</segment>
		<segment id="61" parent="235" relname="sequence">при помощи бортовой оптики было открыто ещё 2 кольца,</segment>
		<segment id="62" parent="237" relname="span">и общее число известных колец возросло до 11.</segment>
		<segment id="63" parent="234" relname="span">В декабре 2005 года космический телескоп «Хаббл» зарегистрировал ещё 2 ранее неизвестных кольца.</segment>
		<segment id="64" parent="65" relname="cause-effect">Они были удалены от планеты на расстояние в два раза большее, чем ранее открытые кольца</segment>
		<segment id="65" parent="233" relname="span">— и поэтому их часто называют «внешней системой колец Урана».</segment>
		<segment id="66" parent="232" relname="span">Помимо колец, «Хаббл» помог открыть два ранее неизвестных небольших спутника,</segment>
		<segment id="67" parent="66" relname="elaboration">один из которых (Маб) имеет ту же орбиту, что и самое внешнее кольцо.</segment>
		<segment id="68" parent="238" relname="joint">Последние два кольца доводят общее количество известных колец Урана до 13.</segment>
		<segment id="69" parent="243" relname="span">В апреле 2006 года изображения новых колец, полученные обсерваторией Кек на Гавайских островах, позволили различить их цвет.</segment>
		<segment id="70" parent="230" relname="contrast">Одно из них было красным,</segment>
		<segment id="71" parent="230" relname="contrast">а другое (самое внешнее) — синим.</segment>
		<segment id="72" parent="231" relname="span">Предполагают, что синий цвет внешнего кольца обусловлен тем,</segment>
		<segment id="73" parent="72" relname="cause-effect">что оно в дополнении к пыли обладает некоторой примесью мелких частиц водяного льда с поверхности Маба.</segment>
		<segment id="74" parent="239" relname="joint">Внутренние кольца планеты выглядят серыми.</segment>
		<segment id="75" parent="228" relname="joint">##### При наблюдениях с Земли можно заметить, что иногда кольца Урана своей плоскостью повёрнуты в сторону наблюдателя.</segment>
		<segment id="76" parent="228" relname="joint">В 2007— 2008 годах кольца были обращены к наблюдателю ребром.</segment>
		<segment id="77" parent="330" relname="preparation">##### Основные сведения</segment>
		<segment id="78" parent="265" relname="span">##### Система колец Урана включает в себя 13 отчётливо различимых колец.</segment>
		<segment id="79" parent="263" relname="joint">По расстоянию от планеты они расположены в следующем порядке: 1986U2R/ζ, 6, 5, 4, α, β, η, γ, δ, λ, ε, ν, и μ кольца.</segment>
		<segment id="80" parent="262" relname="span">Их можно разделить на 3 группы:</segment>
		<segment id="81" parent="260" relname="joint">9 узких главных колец (6, 5, 4, α, β, η, γ, δ, ε),</segment>
		<segment id="82" parent="260" relname="joint">два пылевых кольца (1986U2R/ζ, λ)</segment>
		<segment id="83" parent="260" relname="joint">и два внешних кольца (μ, ν).</segment>
		<segment id="84" parent="274" relname="span">##### Главным образом, кольца Урана состоят из макрочастиц и небольшого количества пыли.</segment>
		<segment id="85" parent="272" relname="joint">Пылевые частицы, как известно, присутствуют в 1986U2R/ζ, η, δ, λ, ν и μ кольцах.</segment>
		<segment id="86" parent="271" relname="span">В дополнение к известным кольцам, скорее всего, существуют почти неразличимые пылевые полосы и весьма слабые и тонкие колечки между ними.</segment>
		<segment id="87" parent="267" relname="joint">Эти слабые кольца и пылевые полосы могут существовать лишь временно</segment>
		<segment id="88" parent="266" relname="span">или состоять из нескольких отдельных дужек,</segment>
		<segment id="89" parent="88" relname="elaboration">которые могут иногда обнаруживаться во время покрытия планетой звезды.</segment>
		<segment id="90" parent="269" relname="joint">Некоторые из них становились заметными во время серии пересечений Землёй плоскости колец в 2007 году.</segment>
		<segment id="91" parent="269" relname="joint">Многие из пылевых полос между кольцами наблюдались при прямом рассеивании света ещё Вояджером-2.</segment>
		<segment id="92" parent="275" relname="joint">Все кольца Урана показывают азимутальные изменения яркости.</segment>
		<segment id="93" parent="280" relname="span">##### Кольца состоят из чрезвычайно тёмного вещества.</segment>
		<segment id="94" parent="277" relname="joint">Геометрическое альбедо частиц составляющих кольца не превышает 5-6 %,</segment>
		<segment id="95" parent="277" relname="joint">а альбедо Бонда и того меньше — около 2 %.</segment>
		<segment id="96" parent="278" relname="span">Частицы колец демонстрируют повышение альбедо при прямом освещении</segment>
		<segment id="97" parent="96" relname="cause-effect">так как частицы составляющие собой кольца — отбрасывают тени.</segment>
		<segment id="98" parent="281" relname="joint">Кольца кажутся немного красноватыми в ультрафиолетовой и видимой части спектра и серыми в ближней инфракрасной.</segment>
		<segment id="99" parent="281" relname="joint">Каких-либо идентифицируемых спектральных особенностей у колец не наблюдается.</segment>
		<segment id="100" parent="289" relname="joint">##### Химический состав частиц колец неизвестен.</segment>
		<segment id="101" parent="284" relname="span">Однако они не могут состоять из чистого водяного льда — как, например кольца Сатурна,</segment>
		<segment id="102" parent="101" relname="evidence">потому что слишком тёмные, даже более тёмные, чем внутренние спутники Урана.</segment>
		<segment id="103" parent="285" relname="span">Это указывает на то, что они являются смесью из льда и тёмного вещества.</segment>
		<segment id="104" parent="286" relname="contrast">Природа этого вещества неизвестна,</segment>
		<segment id="105" parent="286" relname="contrast">но это может быть органика, значительно затемнённая заряженными частицами из магнитосферы Урана.</segment>
		<segment id="106" parent="283" relname="span">Возможно, кольца — это остатки от одного из внутренних спутников Урана,</segment>
		<segment id="107" parent="106" relname="evidence">так как материал колец и внутренних спутников приблизительно схож.</segment>
		<segment id="108" parent="294" relname="span">##### В целом система колец Урана не похожа на слабые, пылевые кольца Юпитера или широкие и сложные кольца Сатурна,</segment>
		<segment id="109" parent="108" relname="elaboration">некоторые из которых состоят из имеющих очень высокую отражательную способность частичек водяного льда.</segment>
		<segment id="110" parent="293" relname="span">Однако с последней упомянутой системой колец у колец Урана есть и общее:</segment>
		<segment id="111" parent="291" relname="joint">кольцо F Сатурна и кольцо ε Урана являются узкими,</segment>
		<segment id="112" parent="291" relname="joint">относительно тёмными</segment>
		<segment id="113" parent="291" relname="joint">и оба «пасутся» парой спутников.</segment>
		<segment id="114" parent="324" relname="joint">Недавно открытые внешние кольца Урана подобны внешним кольцам G и E Сатурна.</segment>
		<segment id="115" parent="324" relname="joint">Небольшие колечки между широкими кольцами Сатурна также напоминают узкие кольца Урана.</segment>
		<segment id="116" parent="324" relname="joint">Помимо этого — пылевые скопления между кольцами Урана могут быть схожи с пылевыми кольцами Юпитера.</segment>
		<segment id="117" parent="322" relname="contrast">Кольцевая система Нептуна, напротив, похожа на кольцевую систему Урана,</segment>
		<segment id="118" parent="290" relname="joint">но менее сложна,</segment>
		<segment id="119" parent="290" relname="joint">более тёмная</segment>
		<segment id="120" parent="290" relname="joint">и содержит больше пыли;</segment>
		<segment id="121" parent="290" relname="joint">кольца Нептуна расположены от планеты дальше, чем у Урана.</segment>
		<segment id="122" parent="123" relname="preparation">##### Узкие главные кольца</segment>
		<segment id="123" parent="362" relname="span">##### ε (эпсилон)</segment>
		<segment id="124" parent="319" relname="joint">##### Кольцо ε (эпсилон) — самое яркое и самое плотное из колец Урана</segment>
		<segment id="125" parent="319" relname="joint">и ответственно примерно за две трети света, отражаемого кольцами.&gt;</segment>
		<segment id="126" parent="319" relname="joint">У этого кольца самый высокий эксцентриситет из всех,</segment>
		<segment id="127" parent="319" relname="joint">оно также обладает незначительным орбитальным наклонением.</segment>
		<segment id="128" parent="129" relname="cause-effect">Эксцентриситет</segment>
		<segment id="129" parent="318" relname="span">является причиной изменений яркости этого кольца.</segment>
		<segment id="130" parent="316" relname="condition">Если создать для него «круговую карту яркости»,</segment>
		<segment id="131" parent="315" relname="span">то можно было бы заметить, что яркость достигает наивысшего значения вблизи апоцентра</segment>
		<segment id="132" parent="131" relname="elaboration">(самой удалённой точки орбиты)</segment>
		<segment id="133" parent="313" relname="span">и уменьшается вблизи перицентра</segment>
		<segment id="134" parent="133" relname="elaboration">(самой близкой к планете точке орбиты).</segment>
		<segment id="135" parent="348" relname="span">##### Максимальный/минимальный яркостный контраст кольца — около 2,5—3,0.</segment>
		<segment id="136" parent="346" relname="span">Эта разница</segment>
		<segment id="137" parent="345" relname="span">связана с изменением ширины кольца,</segment>
		<segment id="138" parent="137" relname="elaboration">которая составляет 19,7 км в перицентре и 96,4 км в апоцентре.</segment>
		<segment id="139" parent="339" relname="condition">По мере того, как кольцо становится шире,</segment>
		<segment id="140" parent="338" relname="joint">уменьшается количество взаимных «затенений» частицами друг друга</segment>
		<segment id="141" parent="142" relname="cause-effect">и можно наблюдать большее их количество,</segment>
		<segment id="142" parent="337" relname="span">что приводит к более высокой интегральной яркости.</segment>
		<segment id="143" parent="340" relname="span">Вариации ширины кольца были измерены непосредственно со снимков, полученных «Вояджером-2»,</segment>
		<segment id="144" parent="143" relname="cause-effect">так как кольцо ε было одним из двух колец, чья ширина различима на камерах «Вояджера».</segment>
		<segment id="145" parent="341" relname="span">Это указывает на то, что кольцо является оптически глубоким.</segment>
		<segment id="146" parent="333" relname="attribution">Действительно, наблюдения покрытия звёзд этим кольцом, проводимые с Земли и «Вояджера-2» показали,</segment>
		<segment id="147" parent="332" relname="joint">что его нормальная «оптическая глубина» варьируется от 0,5 до 2,5,</segment>
		<segment id="148" parent="332" relname="joint">и максимальна вблизи перицентра орбиты кольца.</segment>
		<segment id="149" parent="335" relname="span">«Эквивалентная глубина» кольца ε — около 47 километров.</segment>
		<segment id="150" parent="149" relname="elaboration">Эквивалентная глубина кольца не изменяется на протяжении всей его орбиты.</segment>
		<segment id="151" parent="312" relname="joint">##### Кольца представлены крупным планом (сверху вниз) δ, γ, η, β и α.</segment>
		<segment id="152" parent="312" relname="joint">Различимая ширина кольца η показывает оптически тонкий компонент.</segment>
		<segment id="153" parent="310" relname="contrast">##### Геометрическая толщина кольца ε достоверно неизвестна,</segment>
		<segment id="154" parent="310" relname="contrast">хотя, по некоторым оценкам, составляет примерно 150 метров.</segment>
		<segment id="155" parent="156" relname="concession">Несмотря на столь малую толщину,</segment>
		<segment id="156" parent="309" relname="span">кольцо состоит из нескольких слоёв частиц.</segment>
		<segment id="157" parent="354" relname="span">Кольцо ε — достаточно «переполненное место» с коэффициентом заполнения оценённым различными источниками от 0,008 до 0,06 вблизи апоцентра.&gt;</segment>
		<segment id="158" parent="308" relname="joint">Средний размер частичек в этом кольце 0,2— 20 метров,</segment>
		<segment id="159" parent="308" relname="joint">расстояние между ними составляет в среднем 4,5 их средних радиусов.</segment>
		<segment id="160" parent="161" relname="cause-effect">Из-за своей исключительной тонкости</segment>
		<segment id="161" parent="307" relname="span">кольцо ε исчезает при наблюдении с ребра.</segment>
		<segment id="162" parent="307" relname="elaboration">Такое случилось в 2007 году, во время серии пересечений Землёй плоскости колец.</segment>
		<segment id="163" parent="306" relname="span">Низкое содержание космической пыли в кольце можно объяснить</segment>
		<segment id="164" parent="163" relname="cause-effect">аэродинамическим лобовым сопротивлением расширенной атмосферной короны Урана.</segment>
		<segment id="165" parent="302" relname="span">##### «Вояджер-2» получил странные сигналы от этого кольца при эксперименте «радиопокрытия».</segment>
		<segment id="166" parent="165" relname="elaboration">Сигнал был похож на сильное повышение прямого рассеяния на длине волны в 3,6 см вблизи апоцентра кольца.</segment>
		<segment id="167" parent="301" relname="joint">Такое сильное рассеяние требует наличия когерентной структуры.</segment>
		<segment id="168" parent="301" relname="joint">Такая структура кольца ε была подтверждена многими последующими наблюдениями покрытий.</segment>
		<segment id="169" parent="304" relname="joint">##### Кольцо ε выглядит состоящим из множества узких и оптически плотных колечек.</segment>
		<segment id="170" parent="296" relname="span">У него есть два «спутника-пастуха»</segment>
		<segment id="171" parent="170" relname="elaboration">— Корделия (внутренний) и Офелия (внешний).</segment>
		<segment id="172" parent="295" relname="contrast">Внутренний край кольца находится в орбитальном резонансе 24:25 с Корделией,</segment>
		<segment id="173" parent="295" relname="contrast">а внешний край в 14:13 с Офелией.</segment>
		<segment id="174" parent="297" relname="span">Чтобы эффективно «пасти»</segment>
		<segment id="175" parent="174" relname="elaboration">(удерживать в существующих рамках)</segment>
		<segment id="176" parent="298" relname="same-unit">кольцо,</segment>
		<segment id="177" parent="300" relname="span">масса каждого спутника должна быть как минимум в три раза больше массы кольца.</segment>
		<segment id="178" parent="305" relname="span">Масса кольца ε оценивается около 1016 кг.</segment>
		<group id="179" type="span" parent="180" relname="cause-effect"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="184" relname="contrast"/>
		<group id="182" type="multinuc" parent="192" relname="span"/>
		<group id="183" type="span" parent="184" relname="contrast"/>
		<group id="184" type="multinuc" parent="185" relname="span"/>
		<group id="185" type="span" parent="193" relname="joint"/>
		<group id="186" type="multinuc" parent="189" relname="span"/>
		<group id="187" type="span" parent="188" relname="joint"/>
		<group id="188" type="multinuc" parent="190" relname="span"/>
		<group id="189" type="span" parent="188" relname="joint"/>
		<group id="190" type="span" parent="12" relname="elaboration"/>
		<group id="191" type="span" />
		<group id="192" type="span" parent="193" relname="joint"/>
		<group id="193" type="multinuc" />
		<group id="194" type="multinuc" parent="195" relname="span"/>
		<group id="195" type="span" parent="1" relname="elaboration"/>
		<group id="196" type="span" />
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" parent="24" relname="elaboration"/>
		<group id="199" type="span" parent="203" relname="contrast"/>
		<group id="200" type="span" parent="203" relname="contrast"/>
		<group id="201" type="multinuc" />
		<group id="202" type="span" parent="204" relname="elaboration"/>
		<group id="203" type="multinuc" parent="204" relname="span"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="201" relname="joint"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="31" relname="elaboration"/>
		<group id="208" type="span" parent="210" relname="joint"/>
		<group id="209" type="span" parent="210" relname="joint"/>
		<group id="210" type="multinuc" />
		<group id="211" type="span" parent="212" relname="contrast"/>
		<group id="212" type="multinuc" parent="213" relname="span"/>
		<group id="213" type="span" parent="35" relname="elaboration"/>
		<group id="214" type="span" />
		<group id="215" type="span" parent="224" relname="joint"/>
		<group id="216" type="span" parent="217" relname="span"/>
		<group id="217" type="span" parent="224" relname="joint"/>
		<group id="218" type="span" parent="222" relname="contrast"/>
		<group id="219" type="span" parent="220" relname="contrast"/>
		<group id="220" type="multinuc" parent="221" relname="span"/>
		<group id="221" type="span" parent="222" relname="contrast"/>
		<group id="222" type="multinuc" parent="223" relname="span"/>
		<group id="223" type="span" parent="227" relname="joint"/>
		<group id="224" type="multinuc" parent="225" relname="span"/>
		<group id="225" type="span" parent="40" relname="elaboration"/>
		<group id="226" type="span" parent="227" relname="joint"/>
		<group id="227" type="multinuc" parent="255" relname="span"/>
		<group id="228" type="multinuc" parent="229" relname="span"/>
		<group id="229" type="span" parent="256" relname="joint"/>
		<group id="230" type="multinuc" parent="240" relname="span"/>
		<group id="231" type="span" parent="240" relname="elaboration"/>
		<group id="232" type="span" parent="238" relname="joint"/>
		<group id="233" type="span" parent="63" relname="elaboration"/>
		<group id="234" type="span" parent="238" relname="joint"/>
		<group id="235" type="multinuc" parent="236" relname="span"/>
		<group id="236" type="span" parent="62" relname="cause-effect"/>
		<group id="237" type="span" parent="238" relname="joint"/>
		<group id="238" type="multinuc" parent="244" relname="span"/>
		<group id="239" type="multinuc" parent="242" relname="span"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" parent="239" relname="joint"/>
		<group id="242" type="span" parent="69" relname="elaboration"/>
		<group id="243" type="span" parent="238" relname="joint"/>
		<group id="244" type="span" parent="256" relname="joint"/>
		<group id="245" type="span" parent="246" relname="same-unit"/>
		<group id="246" type="multinuc" parent="247" relname="span"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" parent="250" relname="contrast"/>
		<group id="249" type="span" parent="254" relname="joint"/>
		<group id="250" type="multinuc" parent="251" relname="span"/>
		<group id="251" type="span" parent="252" relname="span"/>
		<group id="252" type="span" parent="51" relname="elaboration"/>
		<group id="253" type="span" parent="254" relname="joint"/>
		<group id="254" type="multinuc" parent="257" relname="span"/>
		<group id="255" type="span" parent="256" relname="joint"/>
		<group id="256" type="multinuc" parent="258" relname="span"/>
		<group id="257" type="span" parent="256" relname="joint"/>
		<group id="258" type="span" parent="259" relname="span"/>
		<group id="259" type="span" />
		<group id="260" type="multinuc" parent="261" relname="span"/>
		<group id="261" type="span" parent="80" relname="elaboration"/>
		<group id="262" type="span" parent="263" relname="joint"/>
		<group id="263" type="multinuc" parent="264" relname="span"/>
		<group id="264" type="span" parent="78" relname="elaboration"/>
		<group id="265" type="span" parent="328" relname="joint"/>
		<group id="266" type="span" parent="267" relname="joint"/>
		<group id="267" type="multinuc" parent="268" relname="span"/>
		<group id="268" type="span" parent="269" relname="joint"/>
		<group id="269" type="multinuc" parent="270" relname="span"/>
		<group id="270" type="span" parent="86" relname="elaboration"/>
		<group id="271" type="span" parent="272" relname="joint"/>
		<group id="272" type="multinuc" parent="273" relname="span"/>
		<group id="273" type="span" parent="84" relname="elaboration"/>
		<group id="274" type="span" parent="275" relname="joint"/>
		<group id="275" type="multinuc" parent="276" relname="span"/>
		<group id="276" type="span" parent="328" relname="joint"/>
		<group id="277" type="multinuc" parent="279" relname="span"/>
		<group id="278" type="span" parent="281" relname="joint"/>
		<group id="279" type="span" parent="93" relname="elaboration"/>
		<group id="280" type="span" parent="281" relname="joint"/>
		<group id="281" type="multinuc" parent="282" relname="span"/>
		<group id="282" type="span" parent="328" relname="joint"/>
		<group id="283" type="span" parent="289" relname="joint"/>
		<group id="284" type="span" parent="103" relname="evidence"/>
		<group id="285" type="span" parent="288" relname="span"/>
		<group id="286" type="multinuc" parent="287" relname="span"/>
		<group id="287" type="span" parent="285" relname="elaboration"/>
		<group id="288" type="span" parent="289" relname="joint"/>
		<group id="289" type="multinuc" parent="329" relname="span"/>
		<group id="290" type="multinuc" parent="321" relname="span"/>
		<group id="291" type="multinuc" parent="292" relname="span"/>
		<group id="292" type="span" parent="110" relname="elaboration"/>
		<group id="293" type="span" parent="325" relname="contrast"/>
		<group id="294" type="span" parent="325" relname="contrast"/>
		<group id="295" type="multinuc" parent="303" relname="span"/>
		<group id="296" type="span" parent="304" relname="joint"/>
		<group id="297" type="span" parent="298" relname="same-unit"/>
		<group id="298" type="multinuc" parent="299" relname="span"/>
		<group id="299" type="span" parent="177" relname="purpose"/>
		<group id="300" type="span" parent="178" relname="preparation"/>
		<group id="301" type="multinuc" parent="357" relname="span"/>
		<group id="302" type="span" parent="301" relname="joint"/>
		<group id="303" type="span" parent="304" relname="joint"/>
		<group id="304" type="multinuc" parent="356" relname="joint"/>
		<group id="305" type="span" parent="304" relname="joint"/>
		<group id="306" type="span" parent="352" relname="joint"/>
		<group id="307" type="span" parent="350" relname="span"/>
		<group id="308" type="multinuc" parent="351" relname="span"/>
		<group id="309" type="span" parent="355" relname="joint"/>
		<group id="310" type="multinuc" parent="311" relname="span"/>
		<group id="311" type="span" parent="355" relname="joint"/>
		<group id="312" type="multinuc" parent="359" relname="span"/>
		<group id="313" type="span" parent="314" relname="contrast"/>
		<group id="314" type="multinuc" parent="316" relname="span"/>
		<group id="315" type="span" parent="314" relname="contrast"/>
		<group id="316" type="span" parent="317" relname="span"/>
		<group id="317" type="span" parent="318" relname="elaboration"/>
		<group id="318" type="span" parent="320" relname="span"/>
		<group id="319" type="multinuc" parent="361" relname="span"/>
		<group id="320" type="span" parent="319" relname="joint"/>
		<group id="321" type="span" parent="322" relname="contrast"/>
		<group id="322" type="multinuc" parent="323" relname="span"/>
		<group id="323" type="span" parent="324" relname="joint"/>
		<group id="324" type="multinuc" parent="327" relname="span"/>
		<group id="325" type="multinuc" parent="326" relname="span"/>
		<group id="326" type="span" parent="324" relname="joint"/>
		<group id="327" type="span" parent="328" relname="joint"/>
		<group id="328" type="multinuc" parent="330" relname="span"/>
		<group id="329" type="span" parent="328" relname="joint"/>
		<group id="330" type="span" parent="331" relname="span"/>
		<group id="331" type="span" />
		<group id="332" type="multinuc" parent="333" relname="span"/>
		<group id="333" type="span" parent="334" relname="span"/>
		<group id="334" type="span" parent="336" relname="joint"/>
		<group id="335" type="span" parent="336" relname="joint"/>
		<group id="336" type="multinuc" parent="342" relname="span"/>
		<group id="337" type="span" parent="338" relname="joint"/>
		<group id="338" type="multinuc" parent="339" relname="span"/>
		<group id="339" type="span" parent="344" relname="span"/>
		<group id="340" type="span" parent="145" relname="evidence"/>
		<group id="341" type="span" parent="349" relname="span"/>
		<group id="342" type="span" parent="341" relname="elaboration"/>
		<group id="343" type="multinuc" parent="360" relname="span"/>
		<group id="344" type="span" parent="346" relname="elaboration"/>
		<group id="345" type="span" parent="136" relname="cause-effect"/>
		<group id="346" type="span" parent="347" relname="span"/>
		<group id="347" type="span" parent="135" relname="elaboration"/>
		<group id="348" type="span" parent="343" relname="joint"/>
		<group id="349" type="span" parent="343" relname="joint"/>
		<group id="350" type="span" parent="352" relname="joint"/>
		<group id="351" type="span" parent="352" relname="joint"/>
		<group id="352" type="multinuc" parent="353" relname="span"/>
		<group id="353" type="span" parent="157" relname="elaboration"/>
		<group id="354" type="span" parent="355" relname="joint"/>
		<group id="355" type="multinuc" parent="358" relname="span"/>
		<group id="356" type="multinuc" parent="363" relname="span"/>
		<group id="357" type="span" parent="356" relname="joint"/>
		<group id="358" type="span" parent="356" relname="joint"/>
		<group id="359" type="span" parent="356" relname="joint"/>
		<group id="360" type="span" parent="356" relname="joint"/>
		<group id="361" type="span" parent="356" relname="joint"/>
		<group id="362" type="span" parent="363" relname="preparation"/>
		<group id="363" type="span" parent="364" relname="span"/>
		<group id="364" type="span" />
	</body>
</rst>