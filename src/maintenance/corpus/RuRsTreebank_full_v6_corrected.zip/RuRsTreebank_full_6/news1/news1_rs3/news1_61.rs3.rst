<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="32" relname="span">##### Адвокат семьи убитого москвича Ивана Агафонова обжаловала в Верховном суде приговор спортсмену Расулу Мирзаеву,</segment>
		<segment id="2" parent="1" relname="elaboration">признанному виновным в убийстве.</segment>
		<segment id="3" parent="32" relname="attribution">Об этом 20 января сообщает агентство «Интерфакс».</segment>
		<segment id="4" parent="35" relname="span">##### Сегодня мы направили жалобу в Верховный суд,</segment>
		<segment id="5" parent="33" relname="span">где просим отменить все судебные решения по делу,</segment>
		<segment id="6" parent="5" relname="elaboration">как приговор, так и кассационное определение.</segment>
		<segment id="7" parent="38" relname="span">Дело просим отправить на новое рассмотрение»</segment>
		<segment id="8" parent="7" relname="attribution">заявила адвокат Оксана Михалкина.</segment>
		<segment id="9" parent="10" relname="attribution">##### 27 ноября 2012 года Замоскворецкий районный суд признал</segment>
		<segment id="10" parent="57" relname="span">Мирзаева виновным по 109-й статье УК РФ (причинение смерти по неосторожности).</segment>
		<segment id="11" parent="39" relname="sequence">Он был приговорен к двум годам ограничения свободы.</segment>
		<segment id="12" parent="40" relname="span">Осужденного освободили в зале суда,</segment>
		<segment id="13" parent="12" relname="cause-effect">так как день содержания в СИЗО засчитывается за два дня ограничения свободы.</segment>
		<segment id="14" parent="42" relname="sequence">В январе 2013 года Мосгорсуд отклонил кассацию Михалкиной.</segment>
		<segment id="15" parent="43" relname="span">##### 25-летний Мирзаев и 19-летний Агафонов поссорились около московского клуба «Гараж» в августе 2011 года.</segment>
		<segment id="16" parent="15" relname="cause-effect">Причиной конфликта стала попытка Агафонова познакомиться с подругой Мирзаева.</segment>
		<segment id="17" parent="44" relname="sequence">Спортсмен ударил юношу кулаком в лицо,</segment>
		<segment id="18" parent="44" relname="sequence">тот упал</segment>
		<segment id="19" parent="44" relname="sequence">и ударился головой об асфальт.</segment>
		<segment id="20" parent="44" relname="sequence">Позднее он умер в больнице.</segment>
		<segment id="21" parent="48" relname="span">##### Юристы долгое время спорили,</segment>
		<segment id="22" parent="21" relname="elaboration">квалифицировать дело по 109-й статье или по более тяжкой четвертой части 111-й статьи (причинение тяжкого вреда здоровью, повлекшего смерть потерпевшего)</segment>
		<segment id="23" parent="47" relname="contrast">Обычно в аналогичных случаях применяется 109-я статья,</segment>
		<segment id="24" parent="25" relname="attribution">однако некоторые эксперты утверждали,</segment>
		<segment id="25" parent="46" relname="span">что как спортсмен Мирзаев обязан был предвидеть последствия своих действий.</segment>
		<segment id="26" parent="50" relname="joint">Обвинение было несколько раз переквалифицировано,</segment>
		<segment id="27" parent="51" relname="span">в рамках расследования провели большое количество экспертиз,</segment>
		<segment id="28" parent="27" relname="elaboration">давших противоречивые результаты о причине смерти (удар головой об асфальт или удар Мирзаева).</segment>
		<segment id="29" parent="52" relname="span">##### В марте 2013 года в Москве был вынесен приговор по делу о разбое,</segment>
		<segment id="30" parent="29" relname="elaboration">фигурантом которого на момент смерти являлся Агафонов.</segment>
		<segment id="31" parent="53" relname="joint">Двое его друзей получили три и четыре с половиной года колонии.</segment>
		<group id="32" type="span" parent="34" relname="span"/>
		<group id="33" type="span" parent="4" relname="elaboration"/>
		<group id="34" type="span" parent="35" relname="preparation"/>
		<group id="35" type="span" parent="36" relname="span"/>
		<group id="36" type="span" parent="37" relname="joint"/>
		<group id="37" type="multinuc" />
		<group id="38" type="span" parent="37" relname="joint"/>
		<group id="39" type="multinuc" parent="41" relname="span"/>
		<group id="40" type="span" parent="39" relname="sequence"/>
		<group id="41" type="span" parent="42" relname="sequence"/>
		<group id="42" type="multinuc" />
		<group id="43" type="span" />
		<group id="44" type="multinuc" parent="45" relname="span"/>
		<group id="45" type="span" parent="43" relname="elaboration"/>
		<group id="46" type="span" parent="47" relname="contrast"/>
		<group id="47" type="multinuc" parent="49" relname="span"/>
		<group id="48" type="span" parent="55" relname="span"/>
		<group id="49" type="span" parent="48" relname="elaboration"/>
		<group id="50" type="multinuc" parent="54" relname="sequence"/>
		<group id="51" type="span" parent="50" relname="joint"/>
		<group id="52" type="span" parent="53" relname="joint"/>
		<group id="53" type="multinuc" parent="54" relname="sequence"/>
		<group id="54" type="multinuc" parent="56" relname="span"/>
		<group id="55" type="span" parent="56" relname="cause-effect"/>
		<group id="56" type="span" />
		<group id="57" type="span" parent="39" relname="sequence"/>
	</body>
</rst>