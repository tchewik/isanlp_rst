<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="77" relname="attribution">##### Как сообщили «Ведомости»,</segment>
		<segment id="2" parent="77" relname="span">правительство внесло в Госдуму пакет поправок в законодательство по помощи регионам</segment>
		<segment id="3" parent="2" relname="cause-effect">в связи с потерями, которые они несут из-за кризиса.</segment>
		<segment id="4" parent="79" relname="contrast">Общая стоимость помощи — около 100 млрд рублей.</segment>
		<segment id="5" parent="94" relname="same-unit">Однако налоговые доходы регионов,</segment>
		<segment id="6" parent="7" relname="attribution">по данным Минфина,</segment>
		<segment id="7" parent="93" relname="span">могут снизиться в 2009 году на 700—800 млрд рублей.</segment>
		<segment id="8" parent="80" relname="joint">##### Доходы от налога на прибыль снизятся на 25—30%, от подоходного — на 5—10% .</segment>
		<segment id="9" parent="99" relname="span">Еще около 100 млрд рублей регионы потеряют</segment>
		<segment id="10" parent="97" relname="same-unit">из-за налоговых нововведений — снижения налога на прибыль с 24 до 20%, увеличения предельной амортизационной премии с 10 до 30% (по 3—7-й амортизационным группам)</segment>
		<segment id="11" parent="98" relname="span">и имущественного вычета</segment>
		<segment id="12" parent="11" relname="condition">при покупке квартиры с 1 млн до 2 млн рублей.</segment>
		<segment id="13" parent="100" relname="span">##### Поправки передают регионам 0,5% налога на прибыль</segment>
		<segment id="14" parent="13" relname="elaboration">(их доля вырастет с 17,5 до 18%)</segment>
		<segment id="15" parent="81" relname="joint">и 100% акцизов на горюче-смазочные материалы (сейчас — 60%).</segment>
		<segment id="16" parent="83" relname="span">Это пополнит региональные бюджеты на 43,1 млрд и 59,4 млрд рублей соответственно,</segment>
		<segment id="17" parent="16" relname="attribution">говорится в пояснительной записке к законопроекту.</segment>
		<segment id="18" parent="102" relname="attribution">##### Губернатор Пермского края Олег Чиркунов</segment>
		<segment id="19" parent="101" relname="contrast">поддерживает передачу налогов,</segment>
		<segment id="20" parent="104" relname="span">«но этих средств не хватит</segment>
		<segment id="21" parent="20" relname="purpose">для восстановления предкризисного уровня».</segment>
		<segment id="22" parent="109" relname="span">Бюджет края на следующий год уже пересмотрен,</segment>
		<segment id="23" parent="107" relname="attribution">отметил Чиркунов:</segment>
		<segment id="24" parent="105" relname="joint">доходная часть снижена на 35%,</segment>
		<segment id="25" parent="106" relname="span">половина этой суммы выпадает</segment>
		<segment id="26" parent="25" relname="cause-effect">из-за снижения поступлений налога на прибыль.</segment>
		<segment id="27" parent="85" relname="attribution">##### Директор Института региональных финансов Булат Столяров допускает,</segment>
		<segment id="28" parent="85" relname="span">что выпадающие доходы регионов могут достигнуть 1,5 трлн рублей.</segment>
		<segment id="29" parent="111" relname="span">В следующем году у предприятий прибыли почти не будет,</segment>
		<segment id="30" parent="29" relname="attribution">говорит он,</segment>
		<segment id="31" parent="152" relname="same-unit">стоило бы передать регионам часть НДС, а не налога на прибыль.</segment>
		<segment id="32" parent="114" relname="span">##### Кроме того, в ближайшее время будут подготовлены поправки в Бюджетный кодекс,</segment>
		<segment id="33" parent="32" relname="elaboration">разрешающие регионам предоставлять гарантии по банковским кредитам в размере 50— 70%,</segment>
		<segment id="34" parent="114" relname="attribution">рассказал вице-премьер Алексей Кудрин.</segment>
		<segment id="35" parent="117" relname="span">##### Однако реальная глубина кризиса, охватившего российские промышленные районы, непонятна до конца и правительству.</segment>
		<segment id="36" parent="37" relname="attribution">Екатеринбургский сайт "Английское название" публикует сенсационные материалы о ситуации на уральских предприятиях, составленные профсоюзными организациями.</segment>
		<segment id="37" parent="116" relname="span">Из них следует, что кризис ударил Свердловскую область под дых.</segment>
		<segment id="38" parent="119" relname="sequence">##### Уже сейчас на предприятиях Среднего Урала тяжелейшая ситуация,</segment>
		<segment id="39" parent="120" relname="span">но в январе всё будет еще хуже</segment>
		<segment id="40" parent="39" relname="cause-effect">— большинство заводов-гигантов анонсируют новые сокращения заработной платы.</segment>
		<segment id="41" parent="135" relname="preparation">##### До сегодняшнего дня экономический кризис на Урале не имел своего лица.</segment>
		<segment id="42" parent="122" relname="contrast">Да, региональные власти раньше федеральных признали серьезные проблемы на заводах,</segment>
		<segment id="43" parent="121" relname="span">но иначе и быть не могло —</segment>
		<segment id="44" parent="43" relname="cause-effect">свердловское правительство физически ближе к директорам предприятий и рабочим металлургических предприятий, моментально почувствовавшим неладное.</segment>
		<segment id="45" parent="124" relname="span">Впрочем, даже в этой ситуации уральские политики старались сохранить лицо,</segment>
		<segment id="46" parent="123" relname="joint">советуя перетерпеть</segment>
		<segment id="47" parent="123" relname="joint">и переждать.</segment>
		<segment id="48" parent="131" relname="span">С таким подходом общей картины кризиса не было ни у кого:</segment>
		<segment id="49" parent="86" relname="joint">вот проблемы в банках,</segment>
		<segment id="50" parent="86" relname="joint">вот на УГМК продлили ноябрьские праздники,</segment>
		<segment id="51" parent="128" relname="span">но в целом всё отлично</segment>
		<segment id="52" parent="127" relname="joint">и якобы все сокращения касаются только управленцев,</segment>
		<segment id="53" parent="127" relname="joint">простые люди не страдают.</segment>
		<segment id="54" parent="140" relname="preparation">##### Но теперь ситуация иная.</segment>
		<segment id="55" parent="132" relname="span">В распоряжении "Английское название" оказалась сводная информация,</segment>
		<segment id="56" parent="55" relname="elaboration">подготовленная Федерацией профсоюзов Свердловской области по данным членских организаций.</segment>
		<segment id="57" parent="133" relname="joint">Это значит, что ячейки ФПСО отзвонились в Екатеринбург</segment>
		<segment id="58" parent="59" relname="attribution">и рассказали руководству региональной федерации,</segment>
		<segment id="59" parent="151" relname="span">что происходит на местах.</segment>
		<segment id="60" parent="139" relname="elaboration">В той информации, которой мы обладаем, описана ситуация на 46 заводах, но в нее попали и самые крупные предприятия (НТМК, Уралмашзавод и т.д.).</segment>
		<segment id="61" parent="146" relname="span">##### Главный вывод — ситуация критическая.</segment>
		<segment id="62" parent="89" relname="joint">На 12 предприятиях (25%) уже появилась задолженность по заработной плате,</segment>
		<segment id="63" parent="87" relname="sequence">на 13 либо уже проведены,</segment>
		<segment id="64" parent="87" relname="sequence">либо в январе-феврале 2009 года начнутся сокращения рабочих.</segment>
		<segment id="65" parent="88" relname="comparison">Лишь единицы заводов не изменили графика работы,</segment>
		<segment id="66" parent="88" relname="comparison">большинство же сократили и рабочую неделю, и рабочий день.</segment>
		<segment id="67" parent="91" relname="attribution">Профсоюзы отмечают и нарушения:</segment>
		<segment id="68" parent="90" relname="joint">«Фанком» сократил раздел коллективного договора «Социальные гарантии»,</segment>
		<segment id="69" parent="90" relname="joint">Уральская гидрогеологическая экспедиция не согласовала приказ об изменении режима рабочего времени с профкомом,</segment>
		<segment id="70" parent="90" relname="joint">на Буланашском машзаводе 51 человек уволен якобы по собственному желанию».</segment>
		<segment id="71" parent="154" relname="same-unit">##### Но самое неприятное впереди</segment>
		<segment id="72" parent="73" relname="attribution">— с января предприятия-гиганты обещают</segment>
		<segment id="73" parent="153" relname="span">сократить средний размер заработной платы.</segment>
		<segment id="74" parent="155" relname="elaboration">Где-то (СУМЗ) на 27%, где-то на 90% (СинТЗ).</segment>
		<segment id="75" parent="149" relname="joint">Не будем обобщать — данные по самым большим заводам и случаи наибольшего сокращения указаны в приведенной ниже таблице.</segment>
		<segment id="76" parent="149" relname="joint">Сделать выводы и прогнозы каждый сможет самостоятельно.</segment>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" parent="95" relname="preparation"/>
		<group id="79" type="multinuc" parent="95" relname="span"/>
		<group id="80" type="multinuc" />
		<group id="81" type="multinuc" parent="82" relname="span"/>
		<group id="82" type="span" parent="83" relname="purpose"/>
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" parent="147" relname="span"/>
		<group id="85" type="span" parent="112" relname="span"/>
		<group id="86" type="multinuc" parent="129" relname="contrast"/>
		<group id="87" type="multinuc" parent="89" relname="joint"/>
		<group id="88" type="multinuc" parent="143" relname="joint"/>
		<group id="89" type="multinuc" parent="143" relname="joint"/>
		<group id="90" type="multinuc" parent="91" relname="span"/>
		<group id="91" type="span" parent="92" relname="span"/>
		<group id="92" type="span" parent="143" relname="joint"/>
		<group id="93" type="span" parent="94" relname="same-unit"/>
		<group id="94" type="multinuc" parent="79" relname="contrast"/>
		<group id="95" type="span" parent="96" relname="span"/>
		<group id="96" type="span" />
		<group id="97" type="multinuc" parent="9" relname="cause-effect"/>
		<group id="98" type="span" parent="97" relname="same-unit"/>
		<group id="99" type="span" parent="80" relname="joint"/>
		<group id="100" type="span" parent="81" relname="joint"/>
		<group id="101" type="multinuc" parent="102" relname="span"/>
		<group id="102" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="84" relname="interpretation-evaluation"/>
		<group id="104" type="span" parent="110" relname="span"/>
		<group id="105" type="multinuc" parent="107" relname="span"/>
		<group id="106" type="span" parent="105" relname="joint"/>
		<group id="107" type="span" parent="108" relname="span"/>
		<group id="108" type="span" parent="22" relname="elaboration"/>
		<group id="109" type="span" parent="104" relname="cause-effect"/>
		<group id="110" type="span" parent="101" relname="contrast"/>
		<group id="111" type="span" parent="152" relname="same-unit"/>
		<group id="112" type="span" parent="113" relname="joint"/>
		<group id="113" type="multinuc" parent="118" relname="contrast"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="113" relname="joint"/>
		<group id="116" type="span" parent="137" relname="span"/>
		<group id="117" type="span" parent="118" relname="contrast"/>
		<group id="118" type="multinuc" />
		<group id="119" type="multinuc" parent="116" relname="evidence"/>
		<group id="120" type="span" parent="119" relname="sequence"/>
		<group id="121" type="span" parent="122" relname="contrast"/>
		<group id="122" type="multinuc" parent="125" relname="span"/>
		<group id="123" type="multinuc" parent="45" relname="condition"/>
		<group id="124" type="span" parent="130" relname="span"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="135" relname="span"/>
		<group id="127" type="multinuc" parent="51" relname="elaboration"/>
		<group id="128" type="span" parent="129" relname="contrast"/>
		<group id="129" type="multinuc" parent="48" relname="cause-effect"/>
		<group id="130" type="span" parent="125" relname="concession"/>
		<group id="131" type="span" parent="124" relname="interpretation-evaluation"/>
		<group id="132" type="span" parent="138" relname="cause-effect"/>
		<group id="133" type="multinuc" parent="138" relname="span"/>
		<group id="135" type="span" parent="136" relname="span"/>
		<group id="136" type="span" parent="142" relname="contrast"/>
		<group id="137" type="span" parent="35" relname="interpretation-evaluation"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="141" relname="span"/>
		<group id="141" type="span" parent="142" relname="contrast"/>
		<group id="142" type="multinuc" parent="61" relname="evidence"/>
		<group id="143" type="multinuc" parent="144" relname="span"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" />
		<group id="146" type="span" parent="144" relname="preparation"/>
		<group id="147" type="span" />
		<group id="149" type="multinuc" parent="156" relname="elaboration"/>
		<group id="151" type="span" parent="133" relname="joint"/>
		<group id="152" type="multinuc" parent="28" relname="interpretation-evaluation"/>
		<group id="153" type="span" parent="154" relname="same-unit"/>
		<group id="154" type="multinuc" parent="155" relname="span"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" />
	</body>
</rst>