<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="53" relname="span">##### Департамент собственной безопасности (ДСБ) МВД РФ проводит проверку в отношении подполковника милиции Артема Кузнецова,</segment>
		<segment id="2" parent="1" relname="elaboration">который является фигурантом обнародованного на минувшей неделе видеоролика об обстоятельствах смерти в СИЗО юриста Сергея Магнитского,</segment>
		<segment id="3" parent="53" relname="attribution">сообщает «Эхо Москвы».</segment>
		<segment id="4" parent="54" relname="span">Видеоролик является частью информационной кампании на двуязычном сайте «Остановить неприкасаемых!» (russian-untouch ables.com),</segment>
		<segment id="5" parent="4" relname="elaboration">где публикуются материалы о деле М агнитского,</segment>
		<segment id="6" parent="55" relname="joint">и в среду 23 июня появление ролика вызвало большой общественный резонанс в русскоязыч ных блогах, стало причиной публик аций в СМИ. В частности, интенсивное обсуждение ролика происходило в блоге известного общественного активиста Алексея Навального.</segment>
		<segment id="7" parent="58" relname="attribution">##### В ролике сообщается,</segment>
		<segment id="8" parent="58" relname="span">что американские юристы, связанные с инвестиционным фондом Hermitage Capital Management, с которым сотрудничал Магнитский, предоставили российским властям документы, подтверждающие факты крупных денежных расходов членов семьи Артема Кузнецова в России и других странах,</segment>
		<segment id="9" parent="8" relname="elaboration">несопоставимых с уровнем официально получаемых ими доходов.</segment>
		<segment id="10" parent="61" relname="span">Авторы ролика, ссылаясь на руководителей фонда, увязывают это с причастностью Кузнецова с крупным хищениям из российского госбюджета.</segment>
		<segment id="11" parent="59" relname="attribution">В частности, в ролике указывается,</segment>
		<segment id="12" parent="59" relname="span">что при официальной зарплате Кузнецова 850 долларов США в месяц в рублевом эквиваленте ему бы потребовалось работать 322 года,</segment>
		<segment id="13" parent="12" relname="purpose">чтобы заработать на имущество, записанное на его семью в течение последних нескольких лет.</segment>
		<segment id="14" >##### Работавший с Магнитским юрист Джемисон Файрстоун подготовил обращения с просьбой проверить источники обогащения семьи подполковника Кузнецова к президенту РФ, генпрокурору Юрию Чайке, а также в ДСБ и Управление организации профилактики коррупционных и иных правонарушений Департамента кадрового обеспечения МВД.</segment>
		<segment id="15" parent="65" relname="attribution">Как пишет «Лента.ру»,</segment>
		<segment id="16" parent="64" relname="joint">жалобы были направлены 21 мая,</segment>
		<segment id="17" parent="64" relname="joint">ответов на них пока не поступало.</segment>
		<segment id="18" parent="71" relname="span">##### В апреле 2010 года американский сенатор Бен Кардин выступил с предложением аннулировать вьездные визы в США для 60 российских чиновников,</segment>
		<segment id="19" parent="18" relname="elaboration">связанных со смертью Магнитского.</segment>
		<segment id="20" parent="69" relname="joint">Соответствующий запрос был подан госсекретарю США Хиллари Клинтон.</segment>
		<segment id="21" parent="67" relname="joint">Решение об этом пока не принято,</segment>
		<segment id="22" parent="67" relname="joint">но 24 июня Клинтон, выступая в Вашингтоне на российско-американском форуме «Гражданское общество — гражданскому обществу», что администрация Барака Обамы «глубоко озабочена» ситуацией вокруг дела Магнитского,</segment>
		<segment id="23" parent="68" relname="attribution">пишет газета Telegraph.</segment>
		<segment id="24" parent="73" relname="contrast">Форум был приурочен к визиту в США российского президента Дмитрия Медведева,</segment>
		<segment id="25" parent="73" relname="contrast">но сам Медведев на нём не присутствовал.</segment>
		<segment id="26" parent="78" relname="attribution">##### Сторонники Магнитского отмечают,</segment>
		<segment id="27" parent="78" relname="span">что Артём Кузнецов со времени совершения приписываемых ему преступлений пошёл на повышение:</segment>
		<segment id="28" parent="76" relname="sequence">ранее он служил в Управлении по налоговым преступлениям ГУВД Москвы,</segment>
		<segment id="29" parent="76" relname="sequence">а с начала 2010 года перешел в Департамент экономической безопасности (ДЭБ) МВД.</segment>
		<segment id="30" parent="31" relname="attribution">За последние месяцы было несколько громких случаев, когда частные лица или инициативные группы российских граждан публично сообщали о</segment>
		<segment id="31" parent="100" relname="span">крупномасштабных фактах коррупции в органах российской власти с упоминанием конкретных эпизодов и называнием фамилий предполагаемых коррупционеров.</segment>
		<segment id="32" parent="80" relname="span">В частности, особый резонанс имело дело о коррупции в банке ВТБ,</segment>
		<segment id="33" parent="32" relname="elaboration">инициированное Алексеем Навальным.</segment>
		<segment id="34" parent="101" relname="elaboration">Кроме того, фамилии предполагаемых правоохранителей-коррупционеров называл сбежавший из России бизнесмен Евгений Чичваркин.</segment>
		<segment id="35" parent="88" relname="attribution">##### Комментаторы-активисты в блоге Навального сообщают о том,</segment>
		<segment id="36" parent="84" relname="span">что они направляют многочисленные запросы,</segment>
		<segment id="37" parent="36" relname="elaboration">связанные с озвучиваемыми случаями,</segment>
		<segment id="38" parent="85" relname="same-unit">в блог президента РФ Медеведева,</segment>
		<segment id="39" parent="87" relname="contrast">но такие комментарии не пропускаются модераторами блога.</segment>
		<segment id="40" parent="90" relname="contrast">Они также пишут обращения по Интернету и в письменном виде в надзорные органы власти,</segment>
		<segment id="41" parent="89" relname="joint">но оттуда, как правило, либо не приходит ответов,</segment>
		<segment id="42" parent="89" relname="joint">либо приходят формальные ответы характера «ваше сообщение принято к сведению».</segment>
		<segment id="43" parent="93" relname="span">Сам Навальный регулярно публикует в своём блоге приходящие ему письменные ответы властей на его запросы о случаях коррупции среди высокопоставленных чиновников:</segment>
		<segment id="44" parent="43" relname="elaboration">ответы в общем случае можно охарактеризовать как попытки избежать проведения следственных действий.</segment>
		<segment id="45" parent="95" relname="span">В частности, подобное происходит с обращениями, связанными с делом фирмы Daimler,</segment>
		<segment id="46" parent="94" relname="span">которая сама призналась в подкупе российских чиновников,</segment>
		<segment id="47" parent="103" relname="span">хотя о «взятии дела на контроль»</segment>
		<segment id="48" parent="47" relname="attribution">заявлял президент Медевдев.</segment>
		<segment id="49" parent="104" relname="attribution">Представители власти несколько раз обещали через СМИ</segment>
		<segment id="50" parent="104" relname="span">«провести проверки»</segment>
		<segment id="51" parent="50" relname="cause-effect">в связи с громкими коррупционными делами,</segment>
		<segment id="52" parent="96" relname="contrast">но конкретные действия пока свелись к увольнению или понижению нескольких милицейских чиновников.</segment>
		<group id="53" type="span" parent="56" relname="span"/>
		<group id="54" type="span" parent="55" relname="joint"/>
		<group id="55" type="multinuc" parent="57" relname="span"/>
		<group id="56" type="span" parent="57" relname="preparation"/>
		<group id="57" type="span" />
		<group id="58" type="span" parent="62" relname="span"/>
		<group id="59" type="span" parent="60" relname="span"/>
		<group id="60" type="span" parent="10" relname="elaboration"/>
		<group id="61" type="span" parent="63" relname="joint"/>
		<group id="62" type="span" parent="63" relname="joint"/>
		<group id="63" type="multinuc" />
		<group id="64" type="multinuc" parent="65" relname="span"/>
		<group id="65" type="span" parent="66" relname="span"/>
		<group id="66" type="span" parent="14" relname="elaboration"/>
		<group id="67" type="multinuc" parent="68" relname="span"/>
		<group id="68" type="span" parent="75" relname="span"/>
		<group id="69" type="multinuc" parent="72" relname="sequence"/>
		<group id="70" type="span" parent="69" relname="joint"/>
		<group id="71" type="span" parent="72" relname="sequence"/>
		<group id="72" type="multinuc" />
		<group id="73" type="multinuc" parent="74" relname="joint"/>
		<group id="74" type="multinuc" parent="70" relname="span"/>
		<group id="75" type="span" parent="74" relname="joint"/>
		<group id="76" type="multinuc" parent="77" relname="span"/>
		<group id="77" type="span" parent="27" relname="elaboration"/>
		<group id="78" type="span" parent="79" relname="span"/>
		<group id="79" type="span" parent="83" relname="joint"/>
		<group id="80" type="span" parent="100" relname="elaboration"/>
		<group id="83" type="multinuc" />
		<group id="84" type="span" parent="85" relname="same-unit"/>
		<group id="85" type="multinuc" parent="86" relname="span"/>
		<group id="86" type="span" parent="87" relname="contrast"/>
		<group id="87" type="multinuc" parent="88" relname="span"/>
		<group id="88" type="span" parent="91" relname="span"/>
		<group id="89" type="multinuc" parent="90" relname="contrast"/>
		<group id="90" type="multinuc" parent="92" relname="joint"/>
		<group id="91" type="span" parent="92" relname="joint"/>
		<group id="92" type="multinuc" parent="99" relname="comparison"/>
		<group id="93" type="span" parent="97" relname="span"/>
		<group id="94" type="span" parent="45" relname="elaboration"/>
		<group id="95" type="span" parent="93" relname="elaboration"/>
		<group id="96" type="multinuc" parent="98" relname="joint"/>
		<group id="97" type="span" parent="98" relname="joint"/>
		<group id="98" type="multinuc" parent="99" relname="comparison"/>
		<group id="99" type="multinuc" />
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" parent="102" relname="span"/>
		<group id="102" type="span" parent="83" relname="joint"/>
		<group id="103" type="span" parent="46" relname="concession"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" parent="96" relname="contrast"/>
	</body>
</rst>