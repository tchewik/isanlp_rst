<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="40" relname="span">##### На улице Грушевского в Киеве,</segment>
		<segment id="2" parent="1" relname="elaboration">где в воскресенье начались беспорядки,</segment>
		<segment id="3" parent="39" relname="same-unit">группа активистов занялась строительством катапульты.</segment>
		<segment id="4" parent="41" relname="attribution">Об этом сообщает «Сегодня».</segment>
		<segment id="5" parent="45" relname="span">Пока что они заняты изучением чертежей.</segment>
		<segment id="6" parent="63" relname="span">##### «Четверо активистов, которые принесли длинные — почти двухметровые — бруски,</segment>
		<segment id="7" parent="6" relname="attribution">— описывает происходящее издание. —</segment>
		<segment id="8" parent="43" relname="same-unit">И,</segment>
		<segment id="9" parent="10" relname="condition">развернув план построения метательной машины,</segment>
		<segment id="10" parent="42" relname="span">они живо стали обсуждать распечатанные образцы».</segment>
		<segment id="11" parent="66" relname="elaboration">Один из них подтвердил, что «это будет катапульта».</segment>
		<segment id="12" parent="13" relname="attribution">##### Ранее УНН сообщало,</segment>
		<segment id="13" parent="49" relname="span">что противостояние на улице Грушевского активизировалось.</segment>
		<segment id="14" parent="47" relname="joint">«Митингующие активно бьют в барабаны</segment>
		<segment id="15" parent="47" relname="joint">и бросают камни,</segment>
		<segment id="16" parent="48" relname="attribution">— передавал с места происшествия корреспондент агентства. —</segment>
		<segment id="17" parent="51" relname="joint">Активисты под прикрытием тентов и крышек от биотуалетов пытаются подобраться ближе к внутренним войскам».</segment>
		<segment id="18" parent="68" relname="attribution">##### По данным "Английское название"</segment>
		<segment id="19" parent="52" relname="joint">сторонники оппозиции продолжают возводить на улице Грушевского баррикады,</segment>
		<segment id="20" parent="52" relname="joint">там же изготавливают «коктейли Молотова».</segment>
		<segment id="21" parent="72" relname="same-unit">Число протестующих там,</segment>
		<segment id="22" parent="23" relname="attribution">как сообщает «РБК-Украина»,</segment>
		<segment id="23" parent="71" relname="span">составляет около двух тысяч человек.</segment>
		<segment id="24" parent="73" relname="elaboration">##### Против тех, кто атакует милицейские кордоны, правоохранители используют слезоточивый газ.</segment>
		<segment id="25" parent="60" relname="span">##### Беспорядки в центре Киева начались после «народного вече» — массового митинга оппозиции,</segment>
		<segment id="26" parent="25" relname="elaboration">состоявшегося в воскресенье, 19 января.</segment>
		<segment id="27" parent="75" relname="attribution">На митинге лидеры оппозиции объявили о том,</segment>
		<segment id="28" parent="55" relname="joint">что в стране якобы пройдут досрочные выборы,</segment>
		<segment id="29" parent="55" relname="joint">а также предложили приступить к созданию «народных органов власти».</segment>
		<segment id="30" parent="56" relname="contrast">Часть протестующих пыталась пройти к правительственному кварталу,</segment>
		<segment id="31" parent="56" relname="contrast">но была остановлена милицейскими кордонами.</segment>
		<segment id="32" parent="57" relname="comparison">Начались столкновения, в котором радикально настроенные противники власти использовали палки, булыжники и бутылки с зажигательной смесью.</segment>
		<segment id="33" parent="57" relname="comparison">Правоохранители, в свою очередь, применяли водометы, слезоточивый газ, шумовые гранаты и резиновые пули.</segment>
		<segment id="34" parent="80" relname="preparation">##### По данным на утро понедельника, число пострадавших с обеих сторон составило около 200 человек.</segment>
		<segment id="35" parent="36" relname="cause-effect">В связи с событиями в Киеве</segment>
		<segment id="36" parent="76" relname="span">было начато уголовное производство.</segment>
		<segment id="37" parent="62" relname="span">В то же время власти согласились создать рабочую группу с участием оппозиции,</segment>
		<segment id="38" parent="37" relname="purpose">которая займется урегулированием политического кризиса.</segment>
		<group id="39" type="multinuc" parent="41" relname="span"/>
		<group id="40" type="span" parent="39" relname="same-unit"/>
		<group id="41" type="span" parent="46" relname="span"/>
		<group id="42" type="span" parent="43" relname="same-unit"/>
		<group id="43" type="multinuc" parent="44" relname="span"/>
		<group id="44" type="span" parent="64" relname="same-unit"/>
		<group id="45" type="span" parent="65" relname="span"/>
		<group id="46" type="span" parent="45" relname="background"/>
		<group id="47" type="multinuc" parent="48" relname="span"/>
		<group id="48" type="span" parent="50" relname="span"/>
		<group id="49" type="span" parent="53" relname="preparation"/>
		<group id="50" type="span" parent="51" relname="joint"/>
		<group id="51" type="multinuc" parent="70" relname="joint"/>
		<group id="52" type="multinuc" parent="68" relname="span"/>
		<group id="53" type="span" parent="54" relname="span"/>
		<group id="54" type="span" />
		<group id="55" type="multinuc" parent="75" relname="span"/>
		<group id="56" type="multinuc" parent="58" relname="cause-effect"/>
		<group id="57" type="multinuc" parent="58" relname="span"/>
		<group id="58" type="span" parent="59" relname="span"/>
		<group id="59" type="span" parent="61" relname="joint"/>
		<group id="60" type="span" parent="78" relname="preparation"/>
		<group id="61" type="multinuc" parent="78" relname="span"/>
		<group id="62" type="span" parent="77" relname="joint"/>
		<group id="63" type="span" parent="64" relname="same-unit"/>
		<group id="64" type="multinuc" parent="66" relname="span"/>
		<group id="65" type="span" />
		<group id="66" type="span" parent="67" relname="span"/>
		<group id="67" type="span" parent="5" relname="elaboration"/>
		<group id="68" type="span" parent="69" relname="span"/>
		<group id="69" type="span" parent="70" relname="joint"/>
		<group id="70" type="multinuc" parent="73" relname="span"/>
		<group id="71" type="span" parent="72" relname="same-unit"/>
		<group id="72" type="multinuc" parent="70" relname="joint"/>
		<group id="73" type="span" parent="53" relname="span"/>
		<group id="74" type="span" parent="61" relname="joint"/>
		<group id="75" type="span" parent="74" relname="span"/>
		<group id="76" type="span" parent="77" relname="joint"/>
		<group id="77" type="multinuc" parent="80" relname="span"/>
		<group id="78" type="span" parent="79" relname="span"/>
		<group id="79" type="span" />
		<group id="80" type="span" parent="81" relname="span"/>
		<group id="81" type="span" />
	</body>
</rst>