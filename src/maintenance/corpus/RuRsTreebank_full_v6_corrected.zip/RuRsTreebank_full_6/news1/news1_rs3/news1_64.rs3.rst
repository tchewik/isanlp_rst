<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="2" relname="attribution">##### Основатель файлообменника Megaupload Ким Дотком (Kim Dotcom) объявил</segment>
		<segment id="2" parent="39" relname="span">о запуске собственного музыкального сервиса под названием Baboom.</segment>
		<segment id="3" parent="39" relname="elaboration">Сообщение об этом 20 января появилось в твиттере Доткома.</segment>
		<segment id="4" parent="41" relname="joint">##### Идет последняя синхронизация серверов.</segment>
		<segment id="5" parent="41" relname="joint">Почти готов нажать на кнопку запуска»</segment>
		<segment id="6" parent="42" relname="attribution">написал в микроблоге Ким Дотком.</segment>
		<segment id="7" parent="45" relname="attribution">Ранее в опубликованном им на сайте "Английское название" пресс-релизе, уточнялось,</segment>
		<segment id="8" parent="43" relname="sequence">что сервис начнет работу в тестовом режиме</segment>
		<segment id="9" parent="44" relname="span">музыка появится на сайте только после запуска полной версии,</segment>
		<segment id="10" parent="9" relname="elaboration">появление которой ожидается через несколько месяцев.</segment>
		<segment id="11" parent="12" relname="attribution">##### По информации издания The National Business Review,</segment>
		<segment id="12" parent="59" relname="span">в ближайшее время на "Английское название" будет выложен альбом самого Доткома под названием «Good Times».</segment>
		<segment id="13" parent="46" relname="joint">Это позволит пользователям понять, как устроен сервис,</segment>
		<segment id="14" parent="46" relname="joint">как можно находить</segment>
		<segment id="15" parent="46" relname="joint">и скачивать с его помощью музыку»</segment>
		<segment id="16" parent="71" relname="attribution">заявил Дотком.</segment>
		<segment id="17" parent="18" relname="attribution">По его словам,</segment>
		<segment id="18" parent="75" relname="span">Baboom станет своего рода «сочетанием iTunes и сервиса Spotify»,</segment>
		<segment id="19" parent="48" relname="contrast">однако будет использовать более справедливую модель распределения прибыли между музыкантами и правообладателями.</segment>
		<segment id="20" parent="21" relname="attribution">##### Ранее проживающий в Новой Зеландии Ким Дотком намеревался объявить</segment>
		<segment id="21" parent="70" relname="span">о запуске Baboom во время презентации своего музыкального альбома на стадионе в Окленде.</segment>
		<segment id="22" parent="49" relname="joint">Презентация должна была пройти 20 января.</segment>
		<segment id="23" parent="49" relname="joint">В общей сложности ее планировало посетить около 25 тысяч человек.</segment>
		<segment id="24" parent="63" relname="same-unit">Однако</segment>
		<segment id="25" parent="26" relname="attribution">из-за планов Доткома также объявить на концерте</segment>
		<segment id="26" parent="74" relname="span">о создании собственной политической партии,</segment>
		<segment id="27" parent="62" relname="span">мероприятие было отменено по требованию властей страны.</segment>
		<segment id="28" parent="60" relname="attribution">Избирательная комиссия Новой Зеландии посчитала,</segment>
		<segment id="29" parent="60" relname="span">что раздача бесплатной еды и презентация альбома могут использоваться Доткомом</segment>
		<segment id="30" parent="29" relname="purpose">для незаконной политической агитации.</segment>
		<segment id="31" parent="53" relname="preparation">##### Ким Дотком известен как создатель сервиса обмена файлами Megaupload.</segment>
		<segment id="32" parent="33" relname="cause-effect">В 2012 году по запросу США Дотком был арестован новозеландской полицией.</segment>
		<segment id="33" parent="67" relname="span">Сайт Megaupload был закрыт.</segment>
		<segment id="34" parent="51" relname="joint">Позже Дотком был выпущен под залог</segment>
		<segment id="35" parent="51" relname="joint">и занялся разработкой нового файлообменника — Mega.</segment>
		<segment id="36" parent="52" relname="span">В настоящее время судом Новой Зеландии рассматривается вопрос об экстрадиции Кима Доткома в Америку,</segment>
		<segment id="37" parent="36" relname="cause-effect">где его обвиняют в нарушении авторских прав и мошенничестве.</segment>
		<segment id="38" parent="50" relname="sequence">Слушания по делу о его выдаче должны состояться в апреле 2014 года.</segment>
		<group id="39" type="span" parent="40" relname="span"/>
		<group id="40" type="span" parent="56" relname="preparation"/>
		<group id="41" type="multinuc" parent="42" relname="span"/>
		<group id="42" type="span" parent="55" relname="span"/>
		<group id="43" type="multinuc" parent="45" relname="span"/>
		<group id="44" type="span" parent="43" relname="sequence"/>
		<group id="45" type="span" parent="47" relname="span"/>
		<group id="46" type="multinuc" parent="59" relname="purpose"/>
		<group id="47" type="span" parent="57" relname="sequence"/>
		<group id="48" type="multinuc" parent="72" relname="interpretation-evaluation"/>
		<group id="49" type="multinuc" parent="64" relname="contrast"/>
		<group id="50" type="multinuc" parent="53" relname="span"/>
		<group id="51" type="multinuc" parent="50" relname="sequence"/>
		<group id="52" type="span" parent="50" relname="sequence"/>
		<group id="53" type="span" parent="54" relname="span"/>
		<group id="54" type="span" />
		<group id="55" type="span" parent="57" relname="sequence"/>
		<group id="56" type="span" parent="58" relname="span"/>
		<group id="57" type="multinuc" parent="56" relname="span"/>
		<group id="58" type="span" />
		<group id="59" type="span" parent="71" relname="span"/>
		<group id="60" type="span" parent="61" relname="span"/>
		<group id="61" type="span" parent="66" relname="elaboration"/>
		<group id="62" type="span" parent="63" relname="same-unit"/>
		<group id="63" type="multinuc" parent="66" relname="span"/>
		<group id="64" type="multinuc" parent="68" relname="span"/>
		<group id="65" type="span" parent="64" relname="contrast"/>
		<group id="66" type="span" parent="65" relname="span"/>
		<group id="67" type="span" parent="50" relname="sequence"/>
		<group id="68" type="span" parent="69" relname="span"/>
		<group id="69" type="span" />
		<group id="70" type="span" parent="68" relname="preparation"/>
		<group id="71" type="span" parent="72" relname="span"/>
		<group id="72" type="span" parent="73" relname="span"/>
		<group id="73" type="span" />
		<group id="74" type="span" parent="27" relname="cause-effect"/>
		<group id="75" type="span" parent="48" relname="contrast"/>
	</body>
</rst>