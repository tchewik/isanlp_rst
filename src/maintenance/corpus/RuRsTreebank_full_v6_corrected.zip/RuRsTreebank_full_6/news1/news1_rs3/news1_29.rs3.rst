<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution1" type="rst"/>
			<rel name="attribution2" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause-effect" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="interpretation-evaluation" type="rst"/>
			<rel name="interpretation" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="non_volitional_cause" type="rst"/>
			<rel name="non_volitional_effect" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
			<rel name="volitional_cause" type="rst"/>
			<rel name="volitional_effect" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" parent="120" relname="concession">##### Несмотря на то, что российский медиарынок на порядок отстаёт от американского,</segment>
		<segment id="2" parent="117" relname="span">издатели отечественной прессы единодушны: планшетный компьютер iPad,</segment>
		<segment id="3" parent="2" relname="elaboration">который ещё даже не продаётся в РФ легально,</segment>
		<segment id="4" parent="118" relname="span">даёт отрасли новую надежду на выживание,</segment>
		<segment id="5" parent="4" relname="interpretation-evaluation">которая больше похожа на ту самую спасительную соломинку.</segment>
		<segment id="6" parent="176" relname="preparation">##### 13 июля Ассоциация распространителей печатной продукции (АРПП) совместно с медиа-агентством Jet-Co провели семинар «Перспективы электронных носителей информации на медиарынке России. iPad — новые возможности в индустрии СМИ и книгоиздании».</segment>
		<segment id="7" parent="176" relname="span">Представители издательств, сопутствующих бизнесов и дистрибуторов прессы в интернете единодушно признали важность нового цифрового устройства и его перспективность для рынка.</segment>
		<segment id="8" parent="124" relname="span">Их даже не смутило то, что пока, по приблизительным оценкам, в Россию завезено около 90 тыс. этих устройств — причём все условно нелегально:</segment>
		<segment id="9" parent="89" relname="cause-effect">Apple ещё не начала официальные продажи в нашей стране.</segment>
		<segment id="10" parent="88" relname="joint">Поэтому отчаянные потребители везут планшеты из США сами</segment>
		<segment id="11" parent="88" relname="joint">или, на свой страх и риск, покупают у «серых» дистрибуторов втридорога.</segment>
		<segment id="12" parent="13" relname="cause-effect">Интерес к iPad столь высок,</segment>
		<segment id="13" parent="91" relname="span">что даже переплата не имеет шансов сбить спрос.</segment>
		<segment id="14" parent="93" relname="attribution">##### Между тем, по определению председателя правления АРПП Александра Оськина,</segment>
		<segment id="15" parent="93" relname="span">массовым рынок iPad в России сможет стать только после того,</segment>
		<segment id="16" parent="15" relname="condition">как число устройств перевалит за 2 млн.</segment>
		<segment id="17" parent="125" relname="concession">Пока же, по предварительным прогнозам, в год будут продавать «всего» по 500 тыс. штук.</segment>
		<segment id="18" parent="132" relname="comparison">Рынок в США больше нашего раз в двадцать.</segment>
		<segment id="19" parent="127" relname="span">А ведь именно массовость имеет ключевую роль</segment>
		<segment id="20" parent="19" relname="condition">при принятии издателями решения о выходе на новые платформы,</segment>
		<segment id="21" parent="129" relname="condition">и пока рынок невелик,</segment>
		<segment id="22" parent="128" relname="joint">«айпадные» версии газет и журналов, скорее, носят имиджевый характер</segment>
		<segment id="23" parent="128" relname="joint">и имеют мало отношения к бизнесу.</segment>
		<segment id="24" parent="136" relname="span">##### Между тем нужно понимать, что мега-популярная новинка от Apple ценна не только сама по себе, но и как катализатор рынка для нового поколения цифровых устройств,</segment>
		<segment id="25" parent="95" relname="joint">позволяющих читать книги и прессу,</segment>
		<segment id="26" parent="95" relname="joint">сёрфить в интернете, играть в цифровые игры</segment>
		<segment id="27" parent="95" relname="joint">и развлекаться всеми возможными способами</segment>
		<segment id="28" parent="134" relname="elaboration">— и делать это всё вместе или по отдельности.</segment>
		<segment id="29" parent="137" relname="span">В 2010— 11 годах на рынок выйдет ещё не один планшет,</segment>
		<segment id="30" parent="175" relname="joint">в том числе весьма ожидаемый — от Samsung</segment>
		<segment id="31" parent="175" relname="joint">и рассчитанный именно на потребление газетного контента — Skiff от News Corp. Руперта Мёрдока.</segment>
		<segment id="32" parent="139" relname="span">##### Часть новых планшетов будет дешевле Apple</segment>
		<segment id="33" parent="32" relname="interpretation-evaluation">(самые радужные прогнозы дают, как всегда, китайцы, которые не упустят возможности завоевать и рынок «айпадов»)</segment>
		<segment id="34" parent="174" relname="joint">, однако не настолько, чтобы быть сразу же раскупленными потребителями,</segment>
		<segment id="35" parent="36" relname="interpretation-evaluation">которые «пожадничали»</segment>
		<segment id="36" parent="142" relname="span">и не потратились на устройства первой волны.</segment>
		<segment id="37" parent="97" relname="condition">До тех пор, пока цена на новые устройства не опуститься ниже 300 долларов, а в идеале — до 99,</segment>
		<segment id="38" parent="96" relname="joint">они не станут товарами первой необходимости,</segment>
		<segment id="39" parent="96" relname="joint">а значит — будут восприниматься издателями только как приятный «бантик» на огромной коробке с печатными изданиями.</segment>
		<segment id="40" parent="179" relname="same-unit">Ситуация,</segment>
		<segment id="41" parent="42" relname="attribution">по словам Александра Оськина,</segment>
		<segment id="42" parent="178" relname="span">может измениться лишь к 2012 году.</segment>
		<segment id="43" parent="145" relname="span">##### Результаты опроса,</segment>
		<segment id="44" parent="43" relname="attribution">проведённого авторитетным в США интернет-ресурсом Mashable,</segment>
		<segment id="45" parent="146" relname="same-unit">показали,</segment>
		<segment id="46" parent="102" relname="cause-effect">что прежде всего пользователи считают iPad дорогой игрушкой</segment>
		<segment id="47" parent="102" relname="span">и покупают планшет,</segment>
		<segment id="48" parent="100" relname="joint">чтобы играть</segment>
		<segment id="49" parent="100" relname="joint">и развлекаться с его помощью.</segment>
		<segment id="50" parent="147" relname="cause-effect">В то же время он сочетает в себе такое количество функций,</segment>
		<segment id="51" parent="105" relname="contrast">что это позволяет утверждать: iPad — не уникальный технологический продукт,</segment>
		<segment id="52" parent="149" relname="span">а хорошо продуманный и конъюнктурный, следующий основным трендам,</segment>
		<segment id="53" parent="152" relname="span">которые будут определять медиа-потребление в течение ближайших 5—10 лет.</segment>
		<segment id="54" parent="151" relname="span">К этим трендам относятся тачскрин, перманентное потребление медиа вместе с его «мобилизацией».</segment>
		<segment id="55" parent="150" relname="span">По прогнозам экспертов, мобильные приложения к 2012 году будут пользоваться большей популярностью, чем сайты СМИ.</segment>
		<segment id="56" parent="55" relname="elaboration">Инфотейнмент — гибрид развлечения и новостной информации, в свою очередь, может заменить собой традиционную журналистику.</segment>
		<segment id="57" parent="161" relname="span">##### В итоге, это позволяет говорить о том, что iPad стал первым представителем lean back device, ленивых медиа.</segment>
		<segment id="58" parent="159" relname="span">Теперь читать электронную газету можно лёжа на диване</segment>
		<segment id="59" parent="58" relname="concession">— и, казалось бы, что тут особенного?</segment>
		<segment id="60" parent="107" relname="evidence">Но вот первые исследования показали,</segment>
		<segment id="61" parent="106" relname="contrast">что если обычно информационный сайт читают на протяжении нескольких минут,</segment>
		<segment id="62" parent="157" relname="span">то iPad — час!</segment>
		<segment id="63" parent="154" relname="evidence">И вот этот факт действительно позволяет говорить о том, что</segment>
		<segment id="64" parent="65" relname="cause-effect">благодаря планшетной революции</segment>
		<segment id="65" parent="154" relname="span">восстанавливается привычка к длинному, вдумчивому чтению.</segment>
		<segment id="66" parent="155" relname="background">До сих пор, с момента развития интернета, веб-сёрфинг в массовом порядке заменял потребление медиа-контента.</segment>
		<segment id="67" parent="68" relname="purpose">##### Однако для того, чтобы цифровой контент был доступен пользователям,</segment>
		<segment id="68" parent="109" relname="span">необходимо развивать каналы дистрибуции в интернете.</segment>
		<segment id="69" parent="162" relname="span">Один из вариантов — цифровые «киоски» компании Zinio,</segment>
		<segment id="70" parent="69" relname="attribution">о которой уже писал «Часкор»,</segment>
		<segment id="71" parent="163" relname="same-unit">а также AppStore, Android Market и Nokia OviStore, то есть магазины мобильных приложений.</segment>
		<segment id="72" parent="164" relname="span">Пока что такие киоски выступают лишь как дополнение к другим каналам распространения</segment>
		<segment id="73" parent="165" relname="span">— так как не позволяют издателям зарабатывать существенную прибыль.</segment>
		<segment id="74" parent="108" relname="joint">По приблизительным расчётам, с момента запуска AppStore заработал 428 млн долларов,</segment>
		<segment id="75" parent="108" relname="joint">данных по выручке СМИ на платформе планшетов пока нет.</segment>
		<segment id="76" parent="77" relname="purpose">##### Чтобы наладить бизнес в приложениях,</segment>
		<segment id="77" parent="113" relname="span">корпорация Apple вводит рекламную платформу iAd.</segment>
		<segment id="78" parent="167" relname="span">Однако «входной билет» в систему стоит 1 млн долларов.</segment>
		<segment id="79" parent="168" relname="span">Впрочем, столь высокая цена не отпугнула рекламодателей:</segment>
		<segment id="80" parent="79" relname="elaboration">например, Nissan уже заплатил 10 млн.</segment>
		<segment id="81" parent="82" relname="cause-effect">##### Именно интерес рекламодателей и позволяет надеяться,</segment>
		<segment id="82" parent="116" relname="span">что в некой перспективе СМИ в формате планшета ожидает финансовый успех.</segment>
		<segment id="83" parent="84" relname="attribution">По данным генерального директора агентства Mosaic Игоря Пискунова,</segment>
		<segment id="84" parent="171" relname="span">в России 26% рекламодателей рассматривают возможность размещения рекламы на iPad в 2010—11 годах.</segment>
		<segment id="85" parent="114" relname="contrast">Самыми активными группами рекламодателей будут телекомщики, FMCG, авто-производители, виноделы, фармацевты и модные товары.</segment>
		<segment id="86" parent="169" relname="span">Однако даже пионеры планшетной рекламы не готовы тратить на разработку больше 50—200 тыс. долларов,</segment>
		<segment id="87" parent="86" relname="cause-effect">поскольку и отдача пока невелика.</segment>
		<group id="88" type="multinuc" parent="89" relname="span"/>
		<group id="89" type="span" parent="90" relname="span"/>
		<group id="90" type="span" parent="92" relname="span"/>
		<group id="91" type="span" parent="90" relname="cause-effect"/>
		<group id="92" type="span" parent="8" relname="elaboration"/>
		<group id="93" type="span" parent="94" relname="span"/>
		<group id="94" type="span" parent="125" relname="span"/>
		<group id="95" type="multinuc" parent="134" relname="span"/>
		<group id="96" type="multinuc" parent="97" relname="span"/>
		<group id="97" type="span" parent="98" relname="span"/>
		<group id="98" type="span" parent="141" relname="span"/>
		<group id="100" type="multinuc" parent="101" relname="span"/>
		<group id="101" type="span" parent="47" relname="purpose"/>
		<group id="102" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" parent="153" relname="contrast"/>
		<group id="105" type="multinuc" parent="147" relname="span"/>
		<group id="106" type="multinuc" parent="107" relname="span"/>
		<group id="107" type="span" parent="158" relname="span"/>
		<group id="108" type="multinuc" parent="73" relname="elaboration"/>
		<group id="109" type="span" parent="111" relname="preparation"/>
		<group id="110" type="multinuc" parent="111" relname="span"/>
		<group id="111" type="span" parent="112" relname="span"/>
		<group id="112" type="span" />
		<group id="113" type="span" parent="166" relname="contrast"/>
		<group id="114" type="multinuc" parent="171" relname="elaboration"/>
		<group id="115" type="span" parent="172" relname="span"/>
		<group id="116" type="span" parent="115" relname="preparation"/>
		<group id="117" type="span" parent="119" relname="same-unit"/>
		<group id="118" type="span" parent="119" relname="same-unit"/>
		<group id="119" type="multinuc" parent="120" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" />
		<group id="124" type="span" parent="7" relname="concession"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="132" relname="comparison"/>
		<group id="127" type="span" parent="130" relname="cause-effect"/>
		<group id="128" type="multinuc" parent="129" relname="span"/>
		<group id="129" type="span" parent="130" relname="span"/>
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" parent="133" relname="contrast"/>
		<group id="132" type="multinuc" parent="133" relname="contrast"/>
		<group id="133" type="multinuc" />
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="24" relname="purpose"/>
		<group id="136" type="span" parent="138" relname="span"/>
		<group id="137" type="span" parent="136" relname="elaboration"/>
		<group id="138" type="span" />
		<group id="139" type="span" parent="140" relname="contrast"/>
		<group id="140" type="multinuc" parent="143" relname="span"/>
		<group id="141" type="span" parent="143" relname="elaboration"/>
		<group id="142" type="span" parent="174" relname="joint"/>
		<group id="143" type="span" parent="144" relname="span"/>
		<group id="144" type="span" />
		<group id="145" type="span" parent="146" relname="same-unit"/>
		<group id="146" type="multinuc" parent="103" relname="evidence"/>
		<group id="147" type="span" parent="148" relname="span"/>
		<group id="148" type="span" parent="153" relname="contrast"/>
		<group id="149" type="span" parent="105" relname="contrast"/>
		<group id="150" type="span" parent="54" relname="interpretation-evaluation"/>
		<group id="151" type="span" parent="53" relname="elaboration"/>
		<group id="152" type="span" parent="52" relname="elaboration"/>
		<group id="153" type="multinuc" parent="57" relname="evidence"/>
		<group id="154" type="span" parent="155" relname="span"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="62" relname="elaboration"/>
		<group id="157" type="span" parent="106" relname="contrast"/>
		<group id="158" type="span" parent="160" relname="span"/>
		<group id="159" type="span" parent="158" relname="solutionhood"/>
		<group id="160" type="span" parent="173" relname="span"/>
		<group id="161" type="span" parent="160" relname="preparation"/>
		<group id="162" type="span" parent="163" relname="same-unit"/>
		<group id="163" type="multinuc" parent="110" relname="contrast"/>
		<group id="164" type="span" parent="170" relname="span"/>
		<group id="165" type="span" parent="72" relname="cause-effect"/>
		<group id="166" type="multinuc" parent="164" relname="elaboration"/>
		<group id="167" type="span" parent="166" relname="contrast"/>
		<group id="168" type="span" parent="78" relname="concession"/>
		<group id="169" type="span" parent="114" relname="contrast"/>
		<group id="170" type="span" parent="110" relname="contrast"/>
		<group id="171" type="span" parent="115" relname="span"/>
		<group id="172" type="span" />
		<group id="173" type="span" />
		<group id="174" type="multinuc" parent="140" relname="contrast"/>
		<group id="175" type="multinuc" parent="29" relname="elaboration"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" />
		<group id="178" type="span" parent="179" relname="same-unit"/>
		<group id="179" type="multinuc" parent="98" relname="interpretation-evaluation"/>
	</body>
</rst>