<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://salatshop.ru/post/10-sochetanie</segment>
		<segment id="2" >Простота — залог здоровья. 10 принципов сочетания продуктов</segment>
		<segment id="3" parent="169" relname="span">Сочетание продуктов — один из самых простых и эффективных инструментов</segment>
		<segment id="4" parent="3" relname="purpose">для улучшение пищеварения, избавления от лишних сантиметров, повышения бодрости и легкости.</segment>
		<segment id="5" parent="168" relname="contrast">Главные правила достаточно просты,</segment>
		<segment id="6" parent="168" relname="contrast">но в начале можно запутаться.</segment>
		<segment id="7" parent="170" relname="joint">Эти простые принципы помогут быстро перейти от теории к практике</segment>
		<segment id="8" parent="170" relname="joint">и ответят на самые частые вопросы о сочетании продуктов.</segment>
		<segment id="9" parent="176" relname="span">Впервые о сочетании продуктов я прочитала лет 10 назад в книге американского натуропата Герберта Шелтона.</segment>
		<segment id="10" parent="174" relname="condition">Когда я стала использовать его рекомендации,</segment>
		<segment id="11" parent="173" relname="joint">сразу заметила улучшение пищеварения,</segment>
		<segment id="12" parent="173" relname="joint">появилось больше энергии</segment>
		<segment id="13" parent="173" relname="joint">и пропало чувство тяжести после еды.</segment>
		<segment id="14" parent="180" relname="comparison">Более простую систему по сочетанию продуктов я узнала во время обучения у Наталии Роуз, американского специалиста по детоксу.</segment>
		<segment id="15" parent="178" relname="span">Сегодня эти принципы сочетания рекомендуют многие специалисты по питанию.</segment>
		<segment id="16" parent="318" relname="joint">Именно этой системой я пользуюсь сама</segment>
		<segment id="17" parent="318" relname="joint">и рассказываю о ней на своих семинарах.</segment>
		<segment id="18" parent="184" relname="span">На принципах сочетания продуктов строится меню в нашей онлайн детокс-программе. IMG</segment>
		<segment id="19" parent="182" relname="span">На сайте уже был пост про сочетание продуктов.</segment>
		<segment id="20" parent="310" relname="joint">В нем расписано, в чем суть подхода,</segment>
		<segment id="21" parent="310" relname="joint">и на какие категории делятся продукты.</segment>
		<segment id="22" parent="314" relname="joint">В этом посте разберем частые вопросы, исключения и важные детали.</segment>
		<segment id="23" parent="192" relname="preparation">・ ・ ・ 1 ・ ・ ・ Животные белки не дружат с крахмалами</segment>
		<segment id="24" parent="185" relname="span">Мясо, курица, рыба, сыр, яйца лучше употреблять отдельно от картофеля, макарон, теста, риса, гречки и других круп.</segment>
		<segment id="25" parent="186" relname="span">Это самое главное правило,</segment>
		<segment id="26" parent="187" relname="joint">применение которого на практике кардинально меняет пищеварение в лучшую сторону,</segment>
		<segment id="27" parent="187" relname="joint">помогает забыть о сонливости и тяжести после еды.</segment>
		<segment id="28" parent="188" relname="span">- Животные белки и крахмалы лучше употреблять в разные приемы пищи,</segment>
		<segment id="29" parent="28" relname="condition">сочетая их со свежими или приготовленными овощами.</segment>
		<segment id="30" parent="190" relname="span">Например:</segment>
		<segment id="31" parent="189" relname="joint">— на обед: гречка + овощной салат с авокадо</segment>
		<segment id="32" parent="189" relname="joint">— на ужин: рыба + овощи-гриль</segment>
		<segment id="33" parent="211" relname="preparation">・ ・ ・ 2 ・ ・ ・ IMG Тяжелые «белки» + тяжелые «крахмалы» = очень тяжело</segment>
		<segment id="34" parent="194" relname="span">В каждой категории продуктов есть продукты более тяжелые</segment>
		<segment id="35" parent="34" relname="purpose">для усвоения,</segment>
		<segment id="36" parent="195" relname="contrast">а есть более легкие.</segment>
		<segment id="37" parent="196" relname="joint">Тяжелые продукты дольше усваиваются,</segment>
		<segment id="38" parent="196" relname="joint">медленнее проходят по пищеварительному тракту</segment>
		<segment id="39" parent="196" relname="joint">и затрачивают больше усилий организма на их переваривание.</segment>
		<segment id="40" parent="197" relname="span">Например, в категории «животных белков» красное мясо является более тяжелым</segment>
		<segment id="41" parent="40" relname="purpose">для усвоения,</segment>
		<segment id="42" parent="198" relname="same-unit">чем птица.</segment>
		<segment id="43" parent="200" relname="comparison">Рыба будет усваиваться еще легче, чем птица.</segment>
		<segment id="44" parent="199" relname="contrast">Молодой козий сыр также относится к животным белкам,</segment>
		<segment id="45" parent="199" relname="contrast">но усваивается гораздо легче, чем все остальные продукты из этой категории.</segment>
		<segment id="46" parent="200" relname="comparison">В категории «крахмалов» кусок белого хлеба, тесто или макароны из рафинированной муки усваиваются хуже, чем такие цельные безглютеновые крупы, как гречка, киноа, пшено или дикий рис.</segment>
		<segment id="47" parent="201" relname="joint">Батат также относится к «крахмалам»</segment>
		<segment id="48" parent="201" relname="joint">и будет самым легким представителем этой категории.</segment>
		<segment id="49" parent="207" relname="span">Наиболее трудной задачей для нашего пищеварения будет сочетание в одном приеме пищи самых тяжелых продуктов из несочетаемых категорий:</segment>
		<segment id="50" parent="202" relname="joint">— красное мясо + макароны = тяжело</segment>
		<segment id="51" parent="202" relname="joint">— булка + котлета = тяжелый-тяжелый бургер</segment>
		<segment id="52" parent="202" relname="joint">— курица + белый рафинированный рис = по-прежнему тяжело</segment>
		<segment id="53" parent="54" relname="purpose">На усвоение таких сочетаний</segment>
		<segment id="54" parent="203" relname="span">организм затрачивает больше всего усилий.</segment>
		<segment id="55" parent="204" relname="joint">После такой еды мы чувствуем вялость, тяжесть</segment>
		<segment id="56" parent="204" relname="joint">и после стола хотим скорее переместиться на диван.</segment>
		<segment id="57" parent="227" relname="preparation">・ ・ ・ 3 ・ ・ ・ IMG Легкие «белки» + легкие «крахмалы» = OK!</segment>
		<segment id="58" parent="213" relname="contrast">Если мы кладем в одну тарелку те же несочетаемые друг с другом «белки» и «крахмалы»,</segment>
		<segment id="59" parent="214" relname="span">но выбираем продукты наиболее легкие</segment>
		<segment id="60" parent="59" relname="purpose">для усвоения,</segment>
		<segment id="61" parent="215" relname="span">этот вариант становится куда более допустимым.</segment>
		<segment id="62" parent="216" relname="contrast">Не идеальным,</segment>
		<segment id="63" parent="217" relname="span">но вполне допустимым,</segment>
		<segment id="64" parent="63" relname="condition">если у вас нет серьезных проблем с пищеварением или задачи похудеть.</segment>
		<segment id="65" parent="224" relname="span">Например:</segment>
		<segment id="66" parent="219" relname="joint">— пшено + молодой козий сыр = ОК</segment>
		<segment id="67" parent="219" relname="joint">— чечевица + козий йогурт = ОК</segment>
		<segment id="68" parent="219" relname="joint">— батат + перепелиные яйца = ОК</segment>
		<segment id="69" parent="219" relname="joint">— киноа + рыба = ОК</segment>
		<segment id="70" parent="221" relname="span">Особенно таким сочетаниям есть место,</segment>
		<segment id="71" parent="220" relname="joint">если вы только начинаете использовать принципы сочетания</segment>
		<segment id="72" parent="220" relname="joint">и вам не хватает привычной сложносочинённости блюд.</segment>
		<segment id="73" parent="222" relname="span">И такие сочетания могут регулярно присутствовать в рационе,</segment>
		<segment id="74" parent="73" relname="condition">если у вас активный образ жизни и отличное пищеварение.</segment>
		<segment id="75" parent="222" relname="background">- Почему козий сыр предпочтительнее коровьего — в этом посте.</segment>
		<segment id="76" parent="240" relname="preparation">・ ・ ・ 4 ・ ・ ・ IMG Свежие фрукты — отдельно</segment>
		<segment id="77" parent="238" relname="span">Большинство свежих фруктов лучше употреблять отдельно от других продуктов.</segment>
		<segment id="78" parent="229" relname="cause">Свежие фрукты быстро проходят по пищеварительному тракту</segment>
		<segment id="79" parent="229" relname="span">и если мы смешиваем их с другими продуктами,</segment>
		<segment id="80" parent="79" relname="condition">требующими больше времени на усвоение,</segment>
		<segment id="81" parent="230" relname="span">мы способствуем процессам брожения</segment>
		<segment id="82" parent="231" relname="span">и ухудшаем наше пищеварение.</segment>
		<segment id="83" parent="237" relname="span">Фрукты рекомендуется есть только на пустой желудок — например, утром на завтрак или через 3—4 часа после обеда.</segment>
		<segment id="84" parent="233" relname="contrast">Долго ждать после фруктов не нужно</segment>
		<segment id="85" parent="233" relname="contrast">— начинать есть продукты из других категорий можно уже через 20—30 минут.</segment>
		<segment id="86" parent="236" relname="span">Исключения:</segment>
		<segment id="87" parent="88" relname="cause">— свежие фрукты хорошо сочетаются со свежей зеленью,</segment>
		<segment id="88" parent="234" relname="span">поэтому зеленые смузи являются примером правильного сочетания,</segment>
		<segment id="89" parent="235" relname="joint">— бананы могут сочетаться также с орехами и сухофруктами,</segment>
		<segment id="90" parent="235" relname="joint">— авокадо сочетается и с фруктами, и с крупами, крахмалами.</segment>
		<segment id="91" parent="252" relname="preparation">・ ・ ・ 5 ・ ・ ・ IMG Фрукты + фрукты</segment>
		<segment id="92" parent="253" relname="span">Есть таблицы сочетания продуктов, где рекомендуется кислые фрукты употреблять отдельно от сладких.</segment>
		<segment id="93" parent="94" relname="condition">Те, кто углубляется в сыроедение,</segment>
		<segment id="94" parent="242" relname="span">встречает рекомендации, что в один прием пищи лучше съедать только один вид фруктов.</segment>
		<segment id="95" parent="244" relname="joint">Мне ближе всего мнение, что для большинства людей сочетание в один прием пищи разных видов фруктов абсолютно допустимо</segment>
		<segment id="96" parent="244" relname="joint">и не вызывает каких-либо трудностей.</segment>
		<segment id="97" parent="311" relname="span">Единственное, не рекомендуется смешивать арбузы и дыни с другими фруктами</segment>
		<segment id="98" parent="97" relname="elaboration">— их всегда лучше есть отдельно.</segment>
		<segment id="99" parent="100" relname="condition">- Если у вас слабое пищеварение,</segment>
		<segment id="100" parent="247" relname="span">во всем приветствуется максимальная простота, в том числе и в случае с фруктами.</segment>
		<segment id="101" parent="102" relname="condition">Если вы экспериментируете с сыроедением и каждый день едите много фруктов,</segment>
		<segment id="102" parent="248" relname="span">также вашему пищеварению будет проще справляться с простыми сочетаниями.</segment>
		<segment id="103" parent="250" relname="contrast">Для всех остальных смешивание разных фруктов и их употребление в разумных количествах не будет проблемой для пищеварения.</segment>
		<segment id="104" parent="258" relname="preparation">・ ・ ・ 6 ・ ・ ・ IMG Овощи и фрукты в свежевыжатых соках и смузи</segment>
		<segment id="105" parent="261" relname="span">С соком любых овощей хорошо сочетаются сок лимона, лайма, яблок или груш.</segment>
		<segment id="106" parent="107" relname="cause">Эти фрукты содержат меньше сахара, чем другие фрукты,</segment>
		<segment id="107" parent="255" relname="span">и нейтрально сочетаются с соком овощей.</segment>
		<segment id="108" parent="260" relname="span">Поэтому морковный сок с яблоком или сельдерей с грушей будут примерами хороших сочетаний.</segment>
		<segment id="109" parent="261" relname="elaboration">Сок имбиря хорошо сочетается с соком любых овощей и фруктов.</segment>
		<segment id="110" parent="111" relname="purpose">Для сочетаний продуктов в смузи</segment>
		<segment id="111" parent="312" relname="span">работают те же правила, что и для сочетания этих продуктов до попадания в ваш блендер:</segment>
		<segment id="112" parent="256" relname="joint">— свежие фрукты + свежая зелень = дружба</segment>
		<segment id="113" parent="256" relname="joint">— арбузы + другие фрукты = плохое сочетание</segment>
		<segment id="114" parent="256" relname="joint">— дыня + бананы = плохое сочетание</segment>
		<segment id="115" parent="256" relname="joint">— авокадо + ягоды = дружба</segment>
		<segment id="116" parent="256" relname="joint">— банан + ягоды + миндальное молоко = дружба</segment>
		<segment id="117" parent="256" relname="joint">— фрукты + коровье молоко = плохое сочетание</segment>
		<segment id="118" parent="269" relname="preparation">・ ・ ・ 7 ・ ・ ・ IMG Коровье молоко</segment>
		<segment id="119" parent="321" relname="attribution">Согласно аюрведе</segment>
		<segment id="120" parent="321" relname="span">коровье молоко нужно употреблять отдельно ото всех других продуктов, в горячем виде,</segment>
		<segment id="121" parent="120" relname="condition">сочетая его со специями.</segment>
		<segment id="122" parent="264" relname="span">Нужно внимательно наблюдать, как ваш организм реагирует на молоко:</segment>
		<segment id="123" parent="122" relname="elaboration">не способствует ли оно накоплению слизи — насморку на следующий день и боли в горле.</segment>
		<segment id="124" parent="266" relname="span">Я совсем не употребляю коровье молоко</segment>
		<segment id="125" parent="319" relname="cause">и считаю, что коровье молоко не обязательный в рационе человека продукт,</segment>
		<segment id="126" parent="265" relname="joint">и его лучше полностью исключить из рациона</segment>
		<segment id="127" parent="265" relname="joint">или заменить ферментированными молочными продуктами.</segment>
		<segment id="128" parent="282" relname="preparation">・ ・ ・ 8 ・ ・ ・ IMG Миндальное молоко</segment>
		<segment id="129" parent="271" relname="contrast">В отличие от коровьего</segment>
		<segment id="130" parent="272" relname="joint">миндальное молоко сочетается более нейтрально</segment>
		<segment id="131" parent="272" relname="joint">и может сочетаться с большинством продуктов.</segment>
		<segment id="132" parent="273" relname="span">Миндальное молоко или другое ореховое молоко можно добавлять в смузи,</segment>
		<segment id="133" parent="132" relname="condition">сочетая его с бананами, свежей зеленью и ягодами.</segment>
		<segment id="134" parent="275" relname="contrast">Ореховое молоко с добавлением какао и фиников может стать отличной альтернативой десерту.</segment>
		<segment id="135" parent="274" relname="joint">Но запивать миндальным молоком свежий арбуз</segment>
		<segment id="136" parent="274" relname="joint">или делать смузи из дыни и миндального молока не стоит.</segment>
		<segment id="137" parent="276" relname="joint">- Как самим приготовить миндальное молоко — в этом посте.</segment>
		<segment id="138" parent="276" relname="joint">Купить готовое миндальное молоко можно у нас в 365 detox.</segment>
		<segment id="139" parent="294" relname="preparation">・ ・ ・ 9 ・ ・ ・ IMG Орехи, семечки и сухофрукты</segment>
		<segment id="140" parent="141" relname="cause">Орехи, семечки и сухофрукты хорошо дружат друг с другом,</segment>
		<segment id="141" parent="284" relname="span">поэтому различные Raw-десерты — примеры правильных сочетаний.</segment>
		<segment id="142" parent="285" relname="joint">Также орехи и сухофрукты отлично сочетаются со свежими овощами.</segment>
		<segment id="143" parent="286" relname="contrast">С «крахмалами» и «животными белками» сочетать орехи и сухофрукты нежелательно,</segment>
		<segment id="144" parent="286" relname="contrast">но здесь имеет значение количество.</segment>
		<segment id="145" parent="287" relname="joint">Если вы добавляете в тыквенный суп чайную ложку тыквенных семечек,</segment>
		<segment id="146" parent="287" relname="joint">а зачем едите киноа с овощами</segment>
		<segment id="147" parent="287" relname="joint">или посыпаете кашу пятью изюминками и ложкой кунжутных семечек,</segment>
		<segment id="148" parent="288" relname="span">большой проблемы для пищеварения не будет.</segment>
		<segment id="149" parent="150" relname="condition">Если же вы заедаете рис большим ореховым батончиком,</segment>
		<segment id="150" parent="289" relname="span">вашему пищеварению это может не понравиться.</segment>
		<segment id="151" parent="291" relname="span">- Как правильно есть орехи — в этом посте.</segment>
		<segment id="152" parent="308" relname="preparation">・ ・ ・ 10 ・ ・ ・ IMG Количество всегда имеет значение</segment>
		<segment id="153" parent="296" relname="contrast">Я никогда не ем фрукты после еды,</segment>
		<segment id="154" parent="155" relname="condition">но если в моем десерте оказывается пара ягод,</segment>
		<segment id="155" parent="297" relname="span">я не делаю из этого проблемы.</segment>
		<segment id="156" parent="298" relname="contrast">Таблицы сочетаний — это некий ориентир,</segment>
		<segment id="157" parent="307" relname="span">но большое значение также имеет количество и качество того, что вы сочетаете в вашей тарелке.</segment>
		<segment id="158" parent="299" relname="joint">Есть вы всегда едите небольшими порциями</segment>
		<segment id="159" parent="299" relname="joint">и пищеварение у вас работает отлично,</segment>
		<segment id="160" parent="300" relname="span">всегда следовать принципам сочетания вам может быть не обязательно.</segment>
		<segment id="161" parent="301" relname="joint">Но если вам не хватает бодрости и легкости,</segment>
		<segment id="162" parent="301" relname="joint">есть задача улучшить пищеварение</segment>
		<segment id="163" parent="301" relname="joint">и повысить иммунитет,</segment>
		<segment id="164" parent="302" relname="span">принципы сочетания продуктов быстро дают отличные результаты.</segment>
		<segment id="165" parent="304" relname="span">Разобраться, как составлять меню</segment>
		<segment id="166" parent="165" relname="condition">с учётом этой системы,</segment>
		<segment id="167" parent="305" relname="span">вам поможет наша онлайн детокс-программа.</segment>
		<group id="168" type="multinuc" parent="169" relname="evaluation"/>
		<group id="169" type="span" parent="171" relname="span"/>
		<group id="170" type="multinuc" parent="171" relname="elaboration"/>
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" />
		<group id="173" type="multinuc" parent="174" relname="span"/>
		<group id="174" type="span" parent="175" relname="span"/>
		<group id="175" type="span" parent="9" relname="evaluation"/>
		<group id="176" type="span" parent="180" relname="comparison"/>
		<group id="178" type="span" parent="179" relname="span"/>
		<group id="179" type="span" parent="315" relname="sequence"/>
		<group id="180" type="multinuc" parent="315" relname="sequence"/>
		<group id="182" type="span" parent="314" relname="joint"/>
		<group id="184" type="span" parent="178" relname="elaboration"/>
		<group id="185" type="span" parent="192" relname="span"/>
		<group id="186" type="span" parent="24" relname="evaluation"/>
		<group id="187" type="multinuc" parent="25" relname="elaboration"/>
		<group id="188" type="span" parent="191" relname="span"/>
		<group id="189" type="multinuc" parent="30" relname="elaboration"/>
		<group id="190" type="span" parent="188" relname="elaboration"/>
		<group id="191" type="span" parent="185" relname="elaboration"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" />
		<group id="194" type="span" parent="195" relname="contrast"/>
		<group id="195" type="multinuc" parent="209" relname="span"/>
		<group id="196" type="multinuc" parent="209" relname="elaboration"/>
		<group id="197" type="span" parent="198" relname="same-unit"/>
		<group id="198" type="multinuc" parent="200" relname="comparison"/>
		<group id="199" type="multinuc" parent="200" relname="comparison"/>
		<group id="200" type="multinuc" parent="210" relname="elaboration"/>
		<group id="201" type="multinuc" parent="200" relname="comparison"/>
		<group id="202" type="multinuc" parent="49" relname="elaboration"/>
		<group id="203" type="span" parent="205" relname="cause"/>
		<group id="204" type="multinuc" parent="205" relname="span"/>
		<group id="205" type="span" parent="206" relname="span"/>
		<group id="206" type="span" parent="207" relname="evaluation"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="200" relname="comparison"/>
		<group id="209" type="span" parent="210" relname="span"/>
		<group id="210" type="span" parent="211" relname="span"/>
		<group id="211" type="span" parent="212" relname="span"/>
		<group id="212" type="span" />
		<group id="213" type="multinuc" parent="215" relname="condition"/>
		<group id="214" type="span" parent="213" relname="contrast"/>
		<group id="215" type="span" parent="218" relname="span"/>
		<group id="216" type="multinuc" parent="61" relname="concession"/>
		<group id="217" type="span" parent="216" relname="contrast"/>
		<group id="218" type="span" parent="227" relname="span"/>
		<group id="219" type="multinuc" parent="65" relname="elaboration"/>
		<group id="220" type="multinuc" parent="70" relname="condition"/>
		<group id="221" type="span" parent="225" relname="joint"/>
		<group id="222" type="span" parent="223" relname="span"/>
		<group id="223" type="span" parent="225" relname="joint"/>
		<group id="224" type="span" parent="226" relname="span"/>
		<group id="225" type="multinuc" parent="224" relname="elaboration"/>
		<group id="226" type="span" parent="218" relname="elaboration"/>
		<group id="227" type="span" parent="228" relname="span"/>
		<group id="228" type="span" />
		<group id="229" type="span" parent="232" relname="span"/>
		<group id="230" type="span" parent="82" relname="cause"/>
		<group id="231" type="span" parent="77" relname="elaboration"/>
		<group id="232" type="span" parent="81" relname="cause"/>
		<group id="233" type="multinuc" parent="83" relname="elaboration"/>
		<group id="234" type="span" parent="235" relname="joint"/>
		<group id="235" type="multinuc" parent="86" relname="elaboration"/>
		<group id="236" type="span" parent="239" relname="concession"/>
		<group id="237" type="span" parent="238" relname="elaboration"/>
		<group id="238" type="span" parent="239" relname="span"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" />
		<group id="242" type="span" parent="92" relname="elaboration"/>
		<group id="243" type="multinuc" parent="251" relname="span"/>
		<group id="244" type="multinuc" parent="246" relname="span"/>
		<group id="245" type="span" parent="243" relname="contrast"/>
		<group id="246" type="span" parent="245" relname="span"/>
		<group id="247" type="span" parent="249" relname="joint"/>
		<group id="248" type="span" parent="249" relname="joint"/>
		<group id="249" type="multinuc" parent="250" relname="contrast"/>
		<group id="250" type="multinuc" parent="251" relname="elaboration"/>
		<group id="251" type="span" parent="252" relname="span"/>
		<group id="252" type="span" parent="254" relname="span"/>
		<group id="253" type="span" parent="243" relname="contrast"/>
		<group id="254" type="span" />
		<group id="255" type="span" parent="108" relname="cause"/>
		<group id="256" type="multinuc" parent="312" relname="elaboration"/>
		<group id="257" type="span" parent="258" relname="span"/>
		<group id="258" type="span" parent="259" relname="span"/>
		<group id="259" type="span" />
		<group id="260" type="span" parent="105" relname="elaboration"/>
		<group id="261" type="span" parent="257" relname="span"/>
		<group id="263" type="multinuc" parent="266" relname="solutionhood"/>
		<group id="264" type="span" parent="263" relname="joint"/>
		<group id="265" type="multinuc" parent="319" relname="span"/>
		<group id="266" type="span" parent="269" relname="span"/>
		<group id="269" type="span" parent="270" relname="span"/>
		<group id="270" type="span" />
		<group id="271" type="multinuc" parent="281" relname="span"/>
		<group id="272" type="multinuc" parent="280" relname="span"/>
		<group id="273" type="span" parent="280" relname="elaboration"/>
		<group id="274" type="multinuc" parent="277" relname="span"/>
		<group id="275" type="multinuc" parent="281" relname="elaboration"/>
		<group id="276" type="multinuc" parent="277" relname="background"/>
		<group id="277" type="span" parent="278" relname="span"/>
		<group id="278" type="span" parent="275" relname="contrast"/>
		<group id="279" type="span" parent="271" relname="contrast"/>
		<group id="280" type="span" parent="279" relname="span"/>
		<group id="281" type="span" parent="282" relname="span"/>
		<group id="282" type="span" parent="283" relname="span"/>
		<group id="283" type="span" />
		<group id="284" type="span" parent="285" relname="joint"/>
		<group id="285" type="multinuc" parent="294" relname="span"/>
		<group id="286" type="multinuc" parent="292" relname="span"/>
		<group id="287" type="multinuc" parent="148" relname="condition"/>
		<group id="288" type="span" parent="290" relname="contrast"/>
		<group id="289" type="span" parent="290" relname="contrast"/>
		<group id="290" type="multinuc" parent="151" relname="solutionhood"/>
		<group id="291" type="span" parent="292" relname="elaboration"/>
		<group id="292" type="span" parent="293" relname="span"/>
		<group id="293" type="span" parent="285" relname="joint"/>
		<group id="294" type="span" parent="295" relname="span"/>
		<group id="295" type="span" />
		<group id="296" type="multinuc" parent="305" relname="solutionhood"/>
		<group id="297" type="span" parent="306" relname="span"/>
		<group id="298" type="multinuc" parent="297" relname="cause"/>
		<group id="299" type="multinuc" parent="160" relname="condition"/>
		<group id="300" type="span" parent="303" relname="contrast"/>
		<group id="301" type="multinuc" parent="164" relname="condition"/>
		<group id="302" type="span" parent="303" relname="contrast"/>
		<group id="303" type="multinuc" parent="157" relname="elaboration"/>
		<group id="304" type="span" parent="167" relname="purpose"/>
		<group id="305" type="span" parent="308" relname="span"/>
		<group id="306" type="span" parent="296" relname="contrast"/>
		<group id="307" type="span" parent="298" relname="contrast"/>
		<group id="308" type="span" parent="309" relname="span"/>
		<group id="309" type="span" />
		<group id="310" type="multinuc" parent="19" relname="elaboration"/>
		<group id="311" type="span" parent="246" relname="concession"/>
		<group id="312" type="span" parent="313" relname="span"/>
		<group id="313" type="span" parent="257" relname="elaboration"/>
		<group id="314" type="multinuc" parent="18" relname="elaboration"/>
		<group id="315" type="multinuc" />
		<group id="318" type="multinuc" parent="15" relname="elaboration"/>
		<group id="319" type="span" parent="320" relname="span"/>
		<group id="320" type="span" parent="124" relname="elaboration"/>
		<group id="321" type="span" parent="322" relname="span"/>
		<group id="322" type="span" parent="263" relname="joint"/>
	</body>
</rst>