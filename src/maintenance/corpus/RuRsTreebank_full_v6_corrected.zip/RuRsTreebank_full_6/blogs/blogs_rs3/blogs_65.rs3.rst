<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://evo-lutio.livejournal.com/933179.html</segment>
		<segment id="2" >Душевные страдания</segment>
		<segment id="3" parent="4" relname="condition">Когда мы разбираем письма в рубрику,</segment>
		<segment id="4" parent="286" relname="span">мы видим разные степени душевных страданий авторов.</segment>
		<segment id="5" parent="290" relname="span">Многие привыкли относиться к душевным страданиям людей со страхом и сочувствием.</segment>
		<segment id="6" parent="7" relname="cause">Страх возникает от того,</segment>
		<segment id="7" parent="287" relname="span">что все почти боятся оказаться на том же месте.</segment>
		<segment id="8" parent="9" relname="cause">Сочувствие возникает от того,</segment>
		<segment id="9" parent="288" relname="span">что душевные страдания кажутся незаслуженными и пришедшими извне.</segment>
		<segment id="10" parent="302" relname="preparation">Душевные страдания ассоциируются с физическими.</segment>
		<segment id="11" parent="292" relname="span">Мало кто виноват в своей физической боли.</segment>
		<segment id="12" parent="291" relname="joint">Болезни достаются по наследству,</segment>
		<segment id="13" parent="291" relname="joint">приходят в результате старения</segment>
		<segment id="14" parent="291" relname="joint">или являются следствием инфекций, травм, других печальных обстоятельств.</segment>
		<segment id="15" parent="293" relname="joint">Физически люди уязвимы</segment>
		<segment id="16" parent="293" relname="joint">и должны поддерживать друг друга в болезнях по мере сил.</segment>
		<segment id="17" parent="563" relname="elaboration">Физически страдающие люди заслуживают мягкого отношения, бытовой и медицинской помощи.</segment>
		<segment id="18" parent="301" relname="span">Примерно так же многие рассматривают и душевные страдания.</segment>
		<segment id="19" parent="298" relname="span">Плачет человек,</segment>
		<segment id="20" parent="19" relname="cause">значит на то есть причина,</segment>
		<segment id="21" parent="22" relname="cause">он чувствует боль,</segment>
		<segment id="22" parent="297" relname="span">ему нужно сочувствовать.</segment>
		<segment id="23" parent="300" relname="contrast">Однако, душевная боль чаще всего имеет отношение не к физическим органам, а к функциональным органам.</segment>
		<segment id="24" parent="304" relname="span">Термин "функциональный орган"</segment>
		<segment id="25" parent="24" relname="attribution">ввел А.А. Ухтомский, великий русский физиолог.</segment>
		<segment id="26" parent="305" relname="span">Функциональный орган - это система сил, организованная вокруг доминанты</segment>
		<segment id="27" parent="26" relname="purpose">для выполнения какой-то задачи.</segment>
		<segment id="28" parent="306" relname="restatement">Душевная боль, которую испытывает человек, это несоответствие доминанты силам,</segment>
		<segment id="29" parent="306" relname="restatement">то есть несоответствие задачи возможностям.</segment>
		<segment id="30" parent="307" relname="restatement">Говоря простыми словами - это когда хочется недостижимого.</segment>
		<segment id="31" parent="320" relname="span">Возникает сбой в функциональном органе,</segment>
		<segment id="32" parent="31" relname="evaluation">и это воспринимается почти так же болезненно, как нарушение работы физического органа.</segment>
		<segment id="33" parent="324" relname="span">Боль</segment>
		<segment id="34" parent="33" relname="cause">от потери</segment>
		<segment id="35" parent="325" relname="same-unit">- невозможность вернуть утрату.</segment>
		<segment id="36" parent="326" relname="span">Боль</segment>
		<segment id="37" parent="36" relname="cause">от несчастной любви</segment>
		<segment id="38" parent="327" relname="same-unit">- это невозможность удовлетворить потребность в близости</segment>
		<segment id="39" parent="328" relname="cause">из-за нелюбви второго.</segment>
		<segment id="40" parent="330" relname="span">Боль</segment>
		<segment id="41" parent="40" relname="cause">от разлуки</segment>
		<segment id="42" parent="330" relname="condition">при взаимной любви</segment>
		<segment id="43" parent="332" relname="same-unit">переносится куда легче,</segment>
		<segment id="44" parent="308" relname="span">поскольку оба делают все возможное</segment>
		<segment id="45" parent="44" relname="purpose">для встречи.</segment>
		<segment id="46" parent="565" relname="span">Однако нетерпеливые люди, желающие получать все и сразу, могут и</segment>
		<segment id="47" parent="46" relname="cause">от короткой разлуки</segment>
		<segment id="48" parent="565" relname="condition">при взаимной любви</segment>
		<segment id="49" parent="310" relname="same-unit">испытывать острую боль.</segment>
		<segment id="50" parent="311" relname="cause">Их доминанта (потребность) требует немедленной реализации желаемого и</segment>
		<segment id="51" parent="52" relname="cause">от невозможности получить это быстро</segment>
		<segment id="52" parent="311" relname="span">возникает боль.</segment>
		<segment id="53" parent="315" relname="joint">Боль в этом случае реальна,</segment>
		<segment id="54" parent="315" relname="joint">она не надумана.</segment>
		<segment id="55" parent="345" relname="span">Неверно думать, что человек, страдающий по какой-то непонятной нам причине, притворщик.</segment>
		<segment id="56" parent="317" relname="joint">Он страдает реально,</segment>
		<segment id="57" parent="317" relname="joint">у него может даже случиться инфаркт от переживаний,</segment>
		<segment id="58" parent="317" relname="joint">он испытывает ломоту в теле и головную боль,</segment>
		<segment id="59" parent="318" relname="span">у него спазм всех сосудов и мышц</segment>
		<segment id="60" parent="59" relname="cause">от стресса.</segment>
		<segment id="61" parent="317" relname="joint">У него кислота в желудке,</segment>
		<segment id="62" parent="317" relname="joint">застой желчи в печени.</segment>
		<segment id="63" parent="342" relname="span">Боль его реальна,</segment>
		<segment id="64" parent="65" relname="cause">а вот причина, по которой он страдает может быть настолько эгоцентрична и абсурдна,</segment>
		<segment id="65" parent="337" relname="span">что для взрослого человека, привыкшего жить в мире ограничений, выглядит надуманной.</segment>
		<segment id="66" parent="338" relname="span">Мало ли чего тебе хочется, удивляется взрослый человек,</segment>
		<segment id="67" parent="66" relname="condition">глядя на страдающего инфантила.</segment>
		<segment id="68" parent="340" relname="span">Хотелки наши не правят миром,</segment>
		<segment id="69" parent="68" relname="evaluation">это очевидно.</segment>
		<segment id="70" parent="344" relname="contrast">Но инфантил отличается тем, что так не думает.</segment>
		<segment id="71" parent="343" relname="joint">Человек простирает свою активность в мир</segment>
		<segment id="72" parent="343" relname="joint">и конструирует способы реализации намерений.</segment>
		<segment id="73" parent="314" relname="attribution">Так описывал Ухтомский функциональный орган.</segment>
		<segment id="74" parent="351" relname="restatement">Сильная боль означает,</segment>
		<segment id="75" parent="350" relname="contrast">что функциональный орган нежизнеспособен,</segment>
		<segment id="76" parent="350" relname="contrast">даже нефункционален,</segment>
		<segment id="77" parent="352" relname="concession">несмотря на оксюморон.</segment>
		<segment id="78" parent="354" relname="restatement">Боль умеренная, терпимая</segment>
		<segment id="79" parent="354" relname="restatement">может означать рост и перестройку системы.</segment>
		<segment id="80" parent="355" relname="span">Когда у ребенка растут зубы,</segment>
		<segment id="81" parent="80" relname="evaluation">ему очень дискомфортно.</segment>
		<segment id="82" parent="356" relname="contrast">Но сильная боль означает болезнь десен или зубов.</segment>
		<segment id="83" parent="360" relname="evaluation">Как мы смотрели бы на взрослого человека,</segment>
		<segment id="84" parent="358" relname="joint">который громко стонет</segment>
		<segment id="85" parent="358" relname="joint">и воет от зубной боли,</segment>
		<segment id="86" parent="359" relname="contrast">но не идет к стоматологу?</segment>
		<segment id="87" parent="361" relname="evaluation">Мы были бы недовольны его поведением, верно?</segment>
		<segment id="88" parent="363" relname="joint">Он страдает сам,</segment>
		<segment id="89" parent="363" relname="joint">он заставляет окружающих переживать за него,</segment>
		<segment id="90" parent="364" relname="span">но не делает ничего,</segment>
		<segment id="91" parent="90" relname="purpose">чтобы помочь себе,</segment>
		<segment id="92" parent="364" relname="concession">хотя способы помощи известны.</segment>
		<segment id="93" parent="367" relname="span">Примерно так же выглядят большинство страдающих</segment>
		<segment id="94" parent="93" relname="cause">от сильной душевной боли.</segment>
		<segment id="95" parent="368" relname="joint">Чаще всего их боль - следствие эгоцентризма или инфантильных запросов,</segment>
		<segment id="96" parent="368" relname="joint">и лекарство от этих недугов придумано давно.</segment>
		<segment id="97" parent="369" relname="comparison">Это проще,</segment>
		<segment id="98" parent="369" relname="comparison">чем вылечить зуб,</segment>
		<segment id="99" parent="567" relname="same-unit">поскольку</segment>
		<segment id="100" parent="101" relname="purpose">для избавления от зубной боли</segment>
		<segment id="101" parent="566" relname="span">нужен стоматолог,</segment>
		<segment id="102" parent="371" relname="contrast">просто рвать зуб нежелательно.</segment>
		<segment id="103" parent="374" relname="same-unit">А вот</segment>
		<segment id="104" parent="105" relname="purpose">для излечения душевных страданий</segment>
		<segment id="105" parent="373" relname="span">иногда достаточно просто вырвать свое капризное "хочу"</segment>
		<segment id="106" parent="379" relname="span">и направить свою энергию в другое русло.</segment>
		<segment id="107" parent="581" relname="attribution">Еще в древности люди говорили в таких случаях:</segment>
		<segment id="108" parent="377" relname="joint">"делай что-нибудь для других</segment>
		<segment id="109" parent="377" relname="joint">и отпустит".</segment>
		<segment id="110" parent="389" relname="span">Но я опишу эту известную мысль подробней, в понятиях не этики, а психологии,</segment>
		<segment id="111" parent="110" relname="purpose">чтобы стало очевидно,</segment>
		<segment id="112" parent="390" relname="same-unit">как это работает.</segment>
		<segment id="113" parent="391" relname="restatement">Душевная боль чаще всего означает,</segment>
		<segment id="114" parent="393" relname="span">что фокус у вас на себе.</segment>
		<segment id="115" parent="114" relname="elaboration">Самосожаление и обида.</segment>
		<segment id="116" parent="392" relname="span">"Доминанта на свое лицо"</segment>
		<segment id="117" parent="116" relname="attribution">называл это Ухтомский в своих этических размышлениях</segment>
		<segment id="118" parent="119" relname="attribution">(он считал,</segment>
		<segment id="119" parent="568" relname="span">что счастливы только люди, имеющие "доминанту на другое лицо",</segment>
		<segment id="120" parent="394" relname="restatement">то есть фокус на других, те, чьи потребности включают пользу других).</segment>
		<segment id="121" parent="396" relname="contrast">Фокус на себе,</segment>
		<segment id="122" parent="396" relname="contrast">а локус контроля ваш - за пределами ваших границ, ваших возможностей.</segment>
		<segment id="123" parent="397" relname="contrast">Вы хотите получить намного больше,</segment>
		<segment id="124" parent="398" relname="joint">чем можете себе позволить,</segment>
		<segment id="125" parent="398" relname="joint">чем можете себе дать.</segment>
		<segment id="126" parent="399" relname="span">Должны подключиться другие люди и внешние обстоятельства,</segment>
		<segment id="127" parent="126" relname="purpose">чтобы дать вам желаемое.</segment>
		<segment id="128" parent="400" relname="joint">Без участия других сил,</segment>
		<segment id="129" parent="400" relname="joint">вне зоны вашего контроля,</segment>
		<segment id="130" parent="401" relname="span">вы не можете реализовать потребность.</segment>
		<segment id="131" parent="403" relname="span">Вы не распоряжаетесь другими людьми и природными стихиями,</segment>
		<segment id="132" parent="131" relname="purpose">чтобы поставить их себе на службу.</segment>
		<segment id="133" parent="417" relname="contrast">Но вы не угнетаете свою доминанту разумным пониманием недостижимости, невозможности.</segment>
		<segment id="134" parent="405" relname="span">Притормозить доминанту несложно,</segment>
		<segment id="135" parent="404" relname="joint">если видеть, что это бесполезный расход энергии,</segment>
		<segment id="136" parent="404" relname="joint">что это истощает вас</segment>
		<segment id="137" parent="404" relname="joint">и разрушает без результата.</segment>
		<segment id="138" parent="139" relname="condition">При нормальном локусе контроля</segment>
		<segment id="139" parent="411" relname="span">торможение подобной доминанты происходит в самом зачатке,</segment>
		<segment id="140" parent="406" relname="span">а в большинстве случаев такая доминанта</segment>
		<segment id="141" parent="140" relname="condition">(вне границ возможностей)</segment>
		<segment id="142" parent="407" relname="same-unit">не возникает вообще,</segment>
		<segment id="143" parent="428" relname="span">и этим как раз занимается адекватная самооценка.</segment>
		<segment id="144" parent="418" relname="span">Самооценка реалистичная и трезвая для того и нужна,</segment>
		<segment id="145" parent="144" relname="purpose">чтобы четко оценить свои реальные возможности,</segment>
		<segment id="146" parent="419" relname="joint">не преувеличивая</segment>
		<segment id="147" parent="419" relname="joint">и не преуменьшая.</segment>
		<segment id="148" parent="424" relname="span">Вот для чего нужно развить привычку жить без короны,</segment>
		<segment id="149" parent="422" relname="span">не пользоваться короной</segment>
		<segment id="150" parent="421" relname="joint">ни для утешения,</segment>
		<segment id="151" parent="421" relname="joint">ни для развлечения,</segment>
		<segment id="152" parent="423" relname="same-unit">ни в коем случае и никогда.</segment>
		<segment id="153" parent="424" relname="purpose">Это позволит иметь верного золотого помощника - адекватную и честную самооценку.</segment>
		<segment id="154" parent="425" relname="span">И пожирающие вас доминанты</segment>
		<segment id="155" parent="427" relname="joint">(потребности, которые вы не можете реализовать</segment>
		<segment id="156" parent="427" relname="joint">и бесполезно тратите на них энергию)</segment>
		<segment id="157" parent="426" relname="same-unit">возникать не будут.</segment>
		<segment id="158" parent="441" relname="span">Зрелая личность - это система настроек,</segment>
		<segment id="159" parent="438" relname="restatement">которая позволяет контролировать функциональные органы,</segment>
		<segment id="160" parent="437" relname="span">"мыслящее тело"</segment>
		<segment id="161" parent="160" relname="attribution">о котором писал Спиноза,</segment>
		<segment id="162" parent="439" relname="purpose">чтобы те работали слаженно и эффективно всегда.</segment>
		<segment id="163" parent="443" relname="evaluation">Трудно представить,</segment>
		<segment id="164" parent="442" relname="comparison">но человек со зрелой личностью действительно не испытывает тех душевный мук,</segment>
		<segment id="165" parent="442" relname="comparison">которые испытывает инфантил.</segment>
		<segment id="166" parent="446" relname="comparison">Страдания души зрелой личности направлены на ее рост,</segment>
		<segment id="167" parent="445" relname="span">это как боль мышц</segment>
		<segment id="168" parent="167" relname="cause">после тренировки.</segment>
		<segment id="169" parent="447" relname="span">Это что-то вроде мук творчества или напряжения воли</segment>
		<segment id="170" parent="169" relname="purpose">для преодоления преград.</segment>
		<segment id="171" parent="452" relname="span">Это та самая боль,</segment>
		<segment id="172" parent="449" relname="joint">которая говорит о том, что человек жив,</segment>
		<segment id="173" parent="449" relname="joint">трудится,</segment>
		<segment id="174" parent="449" relname="joint">развивается,</segment>
		<segment id="175" parent="451" relname="joint">а не бултыхается в анабиозе</segment>
		<segment id="176" parent="451" relname="joint">и не погружается в сон.</segment>
		<segment id="177" parent="456" relname="span">Муки инфантилов совсем иные.</segment>
		<segment id="178" parent="455" relname="joint">Они бесполезно рвут их на куски</segment>
		<segment id="179" parent="455" relname="joint">и раскачивают во все стороны.</segment>
		<segment id="180" parent="462" relname="contrast">Такие муки можно считать продуктивными с той точки зрения, что они сигнализируют о неправильных настройках.</segment>
		<segment id="181" parent="457" relname="contrast">Но инфантилы редко воспринимают боль как сигнал, что внутри них что-то неправильно,</segment>
		<segment id="182" parent="183" relname="cause">они ищут пороки снаружи, в устройстве мира, в поведении других людей.</segment>
		<segment id="183" parent="458" relname="span">Внешний локус вызывает и рост короны.</segment>
		<segment id="184" parent="459" relname="span">И вот уже человеку кажется, что его муки связаны с тем,</segment>
		<segment id="185" parent="184" relname="cause">что он слишком хорош для этого мира.</segment>
		<segment id="186" parent="464" relname="joint">Обязательно обратите внимание на свойство внешнего локуса расширять сферу притязаний</segment>
		<segment id="187" parent="464" relname="joint">и сужать сферу ответственности.</segment>
		<segment id="188" parent="589" relname="span">Это хорошо проявляется в нытиках.</segment>
		<segment id="189" parent="469" relname="span">Они занимаются самобичеванием и самоуничижением</segment>
		<segment id="190" parent="189" relname="evaluation">и некоторым кажется, что они таким образом берут ответственность на себя.</segment>
		<segment id="191" parent="470" relname="contrast">Но ответственность измеряется только действиями,</segment>
		<segment id="192" parent="569" relname="span">а нытье - это обращение к внешним силам</segment>
		<segment id="193" parent="192" relname="purpose">за помощью.</segment>
		<segment id="194" parent="593" relname="condition">Когда нытик жалуется, что он плохой и никчемным,</segment>
		<segment id="195" parent="196" relname="attribution">он считает</segment>
		<segment id="196" parent="593" relname="span">"себя" чем-то таким, что должны улучшить другие.</segment>
		<segment id="197" parent="473" relname="contrast">Другие должны помочь стать ему годным,</segment>
		<segment id="198" parent="475" relname="contrast">а не он сам себе,</segment>
		<segment id="199" parent="474" relname="joint">иначе бы молчал</segment>
		<segment id="200" parent="474" relname="joint">и делал.</segment>
		<segment id="201" parent="202" relname="cause">Он отчуждает себя</segment>
		<segment id="202" parent="476" relname="span">и только потому жалуется на себя,</segment>
		<segment id="203" parent="477" relname="span">но он хочет чтобы ему дали больше возможностей,</segment>
		<segment id="204" parent="203" relname="purpose">его притязания на то, чтобы быть не просто обычным, а лучшим.</segment>
		<segment id="205" parent="206" relname="condition">Если вы владеете своей рукой,</segment>
		<segment id="206" parent="481" relname="span">вы просто действуете ею.</segment>
		<segment id="207" parent="482" relname="condition">Но если вы жалуетесь врачу на ватные непослушные пальцы,</segment>
		<segment id="208" parent="570" relname="joint">вы отчуждаете руку,</segment>
		<segment id="209" parent="571" relname="span">вы признаете, что не можете владеть ей</segment>
		<segment id="210" parent="209" relname="cause">в силу какой-то болезни.</segment>
		<segment id="211" parent="484" relname="joint">Вы потеряли управление рукой,</segment>
		<segment id="212" parent="484" relname="joint">она не в полной мере ваша,</segment>
		<segment id="213" parent="485" relname="contrast">но вы хотите ее себе вернуть.</segment>
		<segment id="214" parent="487" relname="joint">А вот если вы учитесь играть на гитаре</segment>
		<segment id="215" parent="487" relname="joint">и жалуетесь учителю, что ваши пальцы плохо слушаются вас,</segment>
		<segment id="216" parent="488" relname="joint">вы считаете, что кто-то иной, кроме вас, должен научить вашу собственную руку новым навыкам,</segment>
		<segment id="217" parent="488" relname="joint">натренировать ее,</segment>
		<segment id="218" parent="488" relname="joint">сделать за вас работу.</segment>
		<segment id="219" parent="506" relname="span">Именно так относятся к себе нытики.</segment>
		<segment id="220" parent="500" relname="joint">Им кажется, что они - это нечто инородное,</segment>
		<segment id="221" parent="500" relname="joint">возможно нездоровое,</segment>
		<segment id="222" parent="501" relname="span">и другие люди должны им помочь овладеть собой.</segment>
		<segment id="223" parent="502" relname="span">Но в отличие от физических болезней,</segment>
		<segment id="224" parent="223" relname="background">которые можно устранить лекарственной компенсацией и физиотерапией,</segment>
		<segment id="225" parent="504" relname="joint">недоразвитые функциональные органы и правильные настройки личности нужно формировать изнутри,</segment>
		<segment id="226" parent="504" relname="joint">и кроме вас этим некому заняться.</segment>
		<segment id="227" parent="507" relname="joint">В тот момент когда вы решаете не ныть</segment>
		<segment id="228" parent="507" relname="joint">и не беситься</segment>
		<segment id="229" parent="508" relname="cause">из-за своих нереализуемых хочу,</segment>
		<segment id="230" parent="510" relname="contrast">а делать что-то для других,</segment>
		<segment id="231" parent="511" relname="contrast">фокус ваш смещается на других,</segment>
		<segment id="232" parent="511" relname="contrast">а локус контроля встает внутрь.</segment>
		<segment id="233" parent="516" relname="span">Локус контроля встает внутрь каждый раз,</segment>
		<segment id="234" parent="515" relname="span">когда вы занимаетесь деятельностью,</segment>
		<segment id="235" parent="234" relname="purpose">направленной на реальный результат, особенно полезный другим.</segment>
		<segment id="236" parent="237" relname="condition">Если вы можете что-то делать сами, тем более сознательно и произвольно,</segment>
		<segment id="237" parent="517" relname="span">значит локус контроля в это время у вас.</segment>
		<segment id="238" parent="572" relname="span">А фокус на чужих нуждах</segment>
		<segment id="239" parent="238" relname="purpose">позволяет направлять энергию от себя в мир</segment>
		<segment id="240" parent="520" relname="comparison">и эти вложения дадут прирост и ваших сил, и ответ со стороны мира.</segment>
		<segment id="241" parent="520" relname="comparison">Это принцип экономики, обмена с другими, оборота и роста средств.</segment>
		<segment id="242" parent="573" relname="span">Фокус на чужой пользе</segment>
		<segment id="243" parent="242" relname="purpose">позволяет выстроить самую адекватную функциональную энергетическую цепочку.</segment>
		<segment id="244" parent="523" relname="span">Вам нужны силы,</segment>
		<segment id="245" parent="244" relname="purpose">чтобы приносить пользу,</segment>
		<segment id="246" parent="524" relname="span">поэтому вы заботитесь о себе,</segment>
		<segment id="247" parent="527" relname="span">но не больше и не меньше, чем нужно для активной деятельности.</segment>
		<segment id="248" parent="528" relname="joint">Вы поддерживаете себя в форме.</segment>
		<segment id="249" parent="526" relname="span">Вы не чувствуете страданий,</segment>
		<segment id="250" parent="249" relname="cause">поскольку ваш фокус всегда почти вне,</segment>
		<segment id="251" parent="528" relname="joint">вы не занимаетесь самокопанием, расчесыванием старых ран и ковырянием новых,</segment>
		<segment id="252" parent="528" relname="joint">не циклитесь,</segment>
		<segment id="253" parent="528" relname="joint">не куклитесь,</segment>
		<segment id="254" parent="528" relname="joint">ваш поток течет свободно.</segment>
		<segment id="255" parent="532" relname="purpose">Это и позволяет чувствовать счастье как непрерывное состояние.</segment>
		<segment id="256" parent="535" relname="span">Однако счастье не стоит путать с блаженством.</segment>
		<segment id="257" parent="531" relname="span">Счастье - это активное состояние души,</segment>
		<segment id="258" parent="529" relname="contrast">оно включает в себя и напряжение, и усилия, и временами даже боль,</segment>
		<segment id="259" parent="530" relname="span">но все это направлено на движение,</segment>
		<segment id="260" parent="259" relname="elaboration">и вот состояние движения - это и есть счастье личности.</segment>
		<segment id="261" parent="540" relname="span">Правильные настройки, то есть внутренний локус контроля, хорошие границы и адекватная самооценка, это то, что должно укорениться на постоянной основе как правильная осанка,</segment>
		<segment id="262" parent="539" relname="span">которая не только привычка, но и такое положение тела,</segment>
		<segment id="263" parent="262" relname="background">которое поддерживается сформированным мышечным корсетом.</segment>
		<segment id="264" parent="541" relname="joint">Вот и настройки личности должны стать не просто привычным навыком,</segment>
		<segment id="265" parent="541" relname="joint">но и обрасти опытом, продуктивным опытом деятельности в разных сферах жизни.</segment>
		<segment id="266" parent="543" relname="span">Тогда они превратятся в костяк личности</segment>
		<segment id="267" parent="266" relname="evaluation">и можно будет сказать, что личность стала зрелой и сильной.</segment>
		<segment id="268" parent="545" relname="joint">Счастье, которого люди ищут,</segment>
		<segment id="269" parent="545" relname="joint">о котором молят</segment>
		<segment id="270" parent="545" relname="joint">и которое часто придумывают себе,</segment>
		<segment id="271" parent="546" relname="same-unit">это эволюционное подкрепление зрелости личности.</segment>
		<segment id="272" parent="547" relname="comparison">Как кайф - удовлетворение конкретной потребности,</segment>
		<segment id="273" parent="547" relname="comparison">так счастье - постоянное удовлетворение гармонично организованных потребностей.</segment>
		<segment id="274" parent="548" relname="joint">Слабая личность всегда почти несчастна,</segment>
		<segment id="275" parent="548" relname="joint">всегда страдает</segment>
		<segment id="276" parent="548" relname="joint">или живет во сне иллюзий или наркотиков, по аналогии с больным, нежизнеспособным телом.</segment>
		<segment id="277" parent="549" relname="contrast">Но если в случае тела мы далеко не все можем выбирать,</segment>
		<segment id="278" parent="555" relname="span">сильной свою личность может сделать любой психически здоровый человек.</segment>
		<segment id="279" parent="550" relname="span">"Созидающее тело создало себе дух как длань своей воле",</segment>
		<segment id="280" parent="279" relname="attribution">- сказал Ницше за Заратустру.</segment>
		<segment id="281" parent="551" relname="contrast">Телом вы владеем лишь частично,</segment>
		<segment id="282" parent="554" relname="span">а вот в создании духа напрямую участвует наша воля.</segment>
		<segment id="283" parent="552" relname="span">Мы будто берем тело в аренду,</segment>
		<segment id="284" parent="283" relname="purpose">чтобы создать себе дух</segment>
		<segment id="285" parent="552" relname="purpose">ради счастья бытия.</segment>
		<group id="286" type="span" parent="290" relname="preparation"/>
		<group id="287" type="span" parent="289" relname="joint"/>
		<group id="288" type="span" parent="289" relname="joint"/>
		<group id="289" type="multinuc" parent="5" relname="elaboration"/>
		<group id="290" type="span" parent="296" relname="span"/>
		<group id="291" type="multinuc" parent="11" relname="cause"/>
		<group id="292" type="span" parent="294" relname="span"/>
		<group id="293" type="multinuc" parent="563" relname="span"/>
		<group id="294" type="span" parent="295" relname="comparison"/>
		<group id="295" type="multinuc" parent="302" relname="span"/>
		<group id="296" type="span" />
		<group id="297" type="span" parent="299" relname="joint"/>
		<group id="298" type="span" parent="299" relname="joint"/>
		<group id="299" type="multinuc" parent="300" relname="contrast"/>
		<group id="300" type="multinuc" parent="18" relname="elaboration"/>
		<group id="301" type="span" parent="295" relname="comparison"/>
		<group id="302" type="span" parent="303" relname="span"/>
		<group id="303" type="span" />
		<group id="304" type="span" parent="574" relname="preparation"/>
		<group id="305" type="span" parent="574" relname="span"/>
		<group id="306" type="multinuc" parent="307" relname="restatement"/>
		<group id="307" type="multinuc" parent="320" relname="cause"/>
		<group id="308" type="span" parent="333" relname="cause"/>
		<group id="309" type="span" parent="310" relname="same-unit"/>
		<group id="310" type="multinuc" parent="313" relname="span"/>
		<group id="311" type="span" parent="312" relname="span"/>
		<group id="312" type="span" parent="316" relname="span"/>
		<group id="313" type="span" parent="314" relname="span"/>
		<group id="314" type="span" parent="349" relname="span"/>
		<group id="315" type="multinuc" parent="347" relname="span"/>
		<group id="316" type="span" parent="313" relname="elaboration"/>
		<group id="317" type="multinuc" parent="63" relname="cause"/>
		<group id="318" type="span" parent="317" relname="joint"/>
		<group id="319" type="multinuc" parent="55" relname="elaboration"/>
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" parent="305" relname="elaboration"/>
		<group id="324" type="span" parent="325" relname="same-unit"/>
		<group id="325" type="multinuc" parent="335" relname="comparison"/>
		<group id="326" type="span" parent="327" relname="same-unit"/>
		<group id="327" type="multinuc" parent="328" relname="span"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="335" relname="comparison"/>
		<group id="330" type="span" parent="331" relname="span"/>
		<group id="331" type="span" parent="332" relname="same-unit"/>
		<group id="332" type="multinuc" parent="333" relname="span"/>
		<group id="333" type="span" parent="334" relname="span"/>
		<group id="334" type="span" parent="336" relname="contrast"/>
		<group id="335" type="multinuc" />
		<group id="336" type="multinuc" parent="335" relname="comparison"/>
		<group id="337" type="span" parent="339" relname="span"/>
		<group id="338" type="span" parent="348" relname="contrast"/>
		<group id="339" type="span" parent="319" relname="contrast"/>
		<group id="340" type="span" parent="341" relname="contrast"/>
		<group id="341" type="multinuc" parent="348" relname="contrast"/>
		<group id="342" type="span" parent="319" relname="contrast"/>
		<group id="343" type="multinuc" parent="344" relname="contrast"/>
		<group id="344" type="multinuc" parent="341" relname="contrast"/>
		<group id="345" type="span" parent="347" relname="evaluation"/>
		<group id="346" type="span" parent="312" relname="evaluation"/>
		<group id="347" type="span" parent="346" relname="span"/>
		<group id="348" type="multinuc" parent="337" relname="evaluation"/>
		<group id="349" type="span" parent="336" relname="contrast"/>
		<group id="350" type="multinuc" parent="351" relname="restatement"/>
		<group id="351" type="multinuc" parent="352" relname="span"/>
		<group id="352" type="span" parent="353" relname="span"/>
		<group id="353" type="span" parent="357" relname="comparison"/>
		<group id="354" type="multinuc" parent="385" relname="span"/>
		<group id="355" type="span" parent="356" relname="contrast"/>
		<group id="356" type="multinuc" parent="385" relname="elaboration"/>
		<group id="357" type="multinuc" parent="380" relname="preparation"/>
		<group id="358" type="multinuc" parent="359" relname="contrast"/>
		<group id="359" type="multinuc" parent="360" relname="span"/>
		<group id="360" type="span" parent="361" relname="span"/>
		<group id="361" type="span" parent="362" relname="span"/>
		<group id="362" type="span" parent="380" relname="span"/>
		<group id="363" type="multinuc" parent="366" relname="contrast"/>
		<group id="364" type="span" parent="365" relname="span"/>
		<group id="365" type="span" parent="366" relname="contrast"/>
		<group id="366" type="multinuc" parent="382" relname="span"/>
		<group id="367" type="span" parent="381" relname="span"/>
		<group id="368" type="multinuc" parent="367" relname="elaboration"/>
		<group id="369" type="multinuc" parent="370" relname="span"/>
		<group id="370" type="span" parent="372" relname="span"/>
		<group id="371" type="multinuc" parent="370" relname="cause"/>
		<group id="372" type="span" parent="376" relname="contrast"/>
		<group id="373" type="span" parent="374" relname="same-unit"/>
		<group id="374" type="multinuc" parent="375" relname="joint"/>
		<group id="375" type="multinuc" parent="376" relname="contrast"/>
		<group id="376" type="multinuc" parent="386" relname="span"/>
		<group id="377" type="multinuc" parent="581" relname="span"/>
		<group id="379" type="span" parent="375" relname="joint"/>
		<group id="380" type="span" parent="388" relname="span"/>
		<group id="381" type="span" parent="382" relname="evaluation"/>
		<group id="382" type="span" parent="383" relname="span"/>
		<group id="383" type="span" parent="362" relname="elaboration"/>
		<group id="384" type="span" parent="357" relname="comparison"/>
		<group id="385" type="span" parent="384" relname="span"/>
		<group id="386" type="span" parent="387" relname="span"/>
		<group id="387" type="span" />
		<group id="388" type="span" parent="386" relname="solutionhood"/>
		<group id="389" type="span" parent="390" relname="same-unit"/>
		<group id="390" type="multinuc" parent="580" relname="preparation"/>
		<group id="391" type="multinuc" parent="580" relname="span"/>
		<group id="392" type="span" parent="395" relname="span"/>
		<group id="393" type="span" parent="391" relname="restatement"/>
		<group id="394" type="multinuc" parent="392" relname="elaboration"/>
		<group id="395" type="span" parent="391" relname="restatement"/>
		<group id="396" type="multinuc" parent="578" relname="span"/>
		<group id="397" type="multinuc" parent="414" relname="cause"/>
		<group id="398" type="multinuc" parent="397" relname="contrast"/>
		<group id="399" type="span" parent="402" relname="contrast"/>
		<group id="400" type="multinuc" parent="130" relname="condition"/>
		<group id="401" type="span" parent="416" relname="span"/>
		<group id="402" type="multinuc" parent="417" relname="contrast"/>
		<group id="403" type="span" parent="401" relname="cause"/>
		<group id="404" type="multinuc" parent="134" relname="condition"/>
		<group id="405" type="span" parent="433" relname="span"/>
		<group id="406" type="span" parent="407" relname="same-unit"/>
		<group id="407" type="multinuc" parent="410" relname="span"/>
		<group id="408" type="multinuc" parent="405" relname="elaboration"/>
		<group id="409" type="span" parent="408" relname="joint"/>
		<group id="410" type="span" parent="409" relname="span"/>
		<group id="411" type="span" parent="408" relname="joint"/>
		<group id="414" type="span" parent="415" relname="span"/>
		<group id="415" type="span" parent="578" relname="elaboration"/>
		<group id="416" type="span" parent="402" relname="contrast"/>
		<group id="417" type="multinuc" parent="414" relname="span"/>
		<group id="418" type="span" parent="420" relname="span"/>
		<group id="419" type="multinuc" parent="418" relname="condition"/>
		<group id="420" type="span" parent="143" relname="elaboration"/>
		<group id="421" type="multinuc" parent="149" relname="purpose"/>
		<group id="422" type="span" parent="423" relname="same-unit"/>
		<group id="423" type="multinuc" parent="148" relname="elaboration"/>
		<group id="424" type="span" parent="429" relname="span"/>
		<group id="425" type="span" parent="426" relname="same-unit"/>
		<group id="426" type="multinuc" parent="430" relname="span"/>
		<group id="427" type="multinuc" parent="154" relname="elaboration"/>
		<group id="428" type="span" parent="432" relname="span"/>
		<group id="429" type="span" parent="430" relname="cause"/>
		<group id="430" type="span" parent="431" relname="span"/>
		<group id="431" type="span" parent="428" relname="elaboration"/>
		<group id="432" type="span" parent="410" relname="elaboration"/>
		<group id="433" type="span" parent="434" relname="span"/>
		<group id="434" type="span" />
		<group id="437" type="span" parent="438" relname="restatement"/>
		<group id="438" type="multinuc" parent="439" relname="span"/>
		<group id="439" type="span" parent="440" relname="span"/>
		<group id="440" type="span" parent="158" relname="purpose"/>
		<group id="441" type="span" parent="444" relname="preparation"/>
		<group id="442" type="multinuc" parent="443" relname="span"/>
		<group id="443" type="span" parent="444" relname="span"/>
		<group id="444" type="span" parent="468" relname="span"/>
		<group id="445" type="span" parent="448" relname="joint"/>
		<group id="446" type="multinuc" parent="453" relname="span"/>
		<group id="447" type="span" parent="448" relname="joint"/>
		<group id="448" type="multinuc" parent="446" relname="comparison"/>
		<group id="449" type="multinuc" parent="450" relname="contrast"/>
		<group id="450" type="multinuc" parent="171" relname="purpose"/>
		<group id="451" type="multinuc" parent="450" relname="contrast"/>
		<group id="452" type="span" parent="453" relname="elaboration"/>
		<group id="453" type="span" parent="454" relname="span"/>
		<group id="454" type="span" parent="465" relname="contrast"/>
		<group id="455" type="multinuc" parent="177" relname="elaboration"/>
		<group id="456" type="span" parent="463" relname="span"/>
		<group id="457" type="multinuc" parent="462" relname="contrast"/>
		<group id="458" type="span" parent="459" relname="cause"/>
		<group id="459" type="span" parent="460" relname="span"/>
		<group id="460" type="span" parent="457" relname="contrast"/>
		<group id="462" type="multinuc" parent="456" relname="evaluation"/>
		<group id="463" type="span" parent="465" relname="contrast"/>
		<group id="464" type="multinuc" parent="479" relname="span"/>
		<group id="465" type="multinuc" parent="466" relname="span"/>
		<group id="466" type="span" parent="467" relname="span"/>
		<group id="467" type="span" />
		<group id="468" type="span" parent="466" relname="preparation"/>
		<group id="469" type="span" parent="471" relname="contrast"/>
		<group id="470" type="multinuc" parent="471" relname="contrast"/>
		<group id="471" type="multinuc" parent="188" relname="elaboration"/>
		<group id="473" type="multinuc" parent="493" relname="span"/>
		<group id="474" type="multinuc" parent="475" relname="contrast"/>
		<group id="475" type="multinuc" parent="473" relname="contrast"/>
		<group id="476" type="span" parent="478" relname="contrast"/>
		<group id="477" type="span" parent="478" relname="contrast"/>
		<group id="478" type="multinuc" parent="497" relname="span"/>
		<group id="479" type="span" parent="480" relname="span"/>
		<group id="480" type="span" parent="595" relname="preparation"/>
		<group id="481" type="span" parent="494" relname="contrast"/>
		<group id="482" type="span" parent="483" relname="span"/>
		<group id="483" type="span" parent="486" relname="span"/>
		<group id="484" type="multinuc" parent="485" relname="contrast"/>
		<group id="485" type="multinuc" parent="483" relname="elaboration"/>
		<group id="486" type="span" parent="494" relname="contrast"/>
		<group id="487" type="multinuc" parent="591" relname="condition"/>
		<group id="488" type="multinuc" parent="591" relname="span"/>
		<group id="492" type="span" parent="594" relname="elaboration"/>
		<group id="493" type="span" parent="492" relname="span"/>
		<group id="494" type="multinuc" parent="495" relname="joint"/>
		<group id="495" type="multinuc" parent="497" relname="elaboration"/>
		<group id="496" type="span" parent="493" relname="elaboration"/>
		<group id="497" type="span" parent="496" relname="span"/>
		<group id="500" type="multinuc" parent="222" relname="cause"/>
		<group id="501" type="span" parent="219" relname="elaboration"/>
		<group id="502" type="span" parent="503" relname="contrast"/>
		<group id="503" type="multinuc" parent="505" relname="contrast"/>
		<group id="504" type="multinuc" parent="503" relname="contrast"/>
		<group id="505" type="multinuc" parent="513" relname="solutionhood"/>
		<group id="506" type="span" parent="505" relname="contrast"/>
		<group id="507" type="multinuc" parent="508" relname="span"/>
		<group id="508" type="span" parent="509" relname="span"/>
		<group id="509" type="span" parent="510" relname="contrast"/>
		<group id="510" type="multinuc" parent="512" relname="cause"/>
		<group id="511" type="multinuc" parent="538" relname="span"/>
		<group id="512" type="span" parent="513" relname="span"/>
		<group id="513" type="span" parent="514" relname="span"/>
		<group id="514" type="span" />
		<group id="515" type="span" parent="233" relname="condition"/>
		<group id="516" type="span" parent="519" relname="span"/>
		<group id="517" type="span" parent="516" relname="elaboration"/>
		<group id="518" type="multinuc" parent="521" relname="span"/>
		<group id="519" type="span" parent="537" relname="joint"/>
		<group id="520" type="multinuc" parent="518" relname="joint"/>
		<group id="521" type="span" parent="522" relname="span"/>
		<group id="522" type="span" parent="536" relname="span"/>
		<group id="523" type="span" parent="246" relname="cause"/>
		<group id="524" type="span" parent="525" relname="contrast"/>
		<group id="525" type="multinuc" parent="522" relname="elaboration"/>
		<group id="526" type="span" parent="528" relname="joint"/>
		<group id="527" type="span" parent="525" relname="contrast"/>
		<group id="528" type="multinuc" parent="532" relname="span"/>
		<group id="529" type="multinuc" parent="257" relname="elaboration"/>
		<group id="530" type="span" parent="529" relname="contrast"/>
		<group id="531" type="span" parent="256" relname="elaboration"/>
		<group id="532" type="span" parent="533" relname="span"/>
		<group id="533" type="span" parent="534" relname="contrast"/>
		<group id="534" type="multinuc" parent="247" relname="elaboration"/>
		<group id="535" type="span" parent="534" relname="contrast"/>
		<group id="536" type="span" parent="537" relname="joint"/>
		<group id="537" type="multinuc" parent="538" relname="elaboration"/>
		<group id="538" type="span" parent="512" relname="span"/>
		<group id="539" type="span" parent="261" relname="elaboration"/>
		<group id="540" type="span" parent="542" relname="comparison"/>
		<group id="541" type="multinuc" parent="542" relname="comparison"/>
		<group id="542" type="multinuc" parent="543" relname="condition"/>
		<group id="543" type="span" parent="544" relname="span"/>
		<group id="544" type="span" />
		<group id="545" type="multinuc" parent="546" relname="same-unit"/>
		<group id="546" type="multinuc" parent="559" relname="span"/>
		<group id="547" type="multinuc" parent="559" relname="elaboration"/>
		<group id="548" type="multinuc" parent="558" relname="contrast"/>
		<group id="549" type="multinuc" parent="556" relname="span"/>
		<group id="550" type="span" parent="278" relname="elaboration"/>
		<group id="551" type="multinuc" parent="556" relname="elaboration"/>
		<group id="552" type="span" parent="553" relname="span"/>
		<group id="553" type="span" parent="282" relname="elaboration"/>
		<group id="554" type="span" parent="551" relname="contrast"/>
		<group id="555" type="span" parent="549" relname="contrast"/>
		<group id="556" type="span" parent="557" relname="span"/>
		<group id="557" type="span" parent="558" relname="contrast"/>
		<group id="558" type="multinuc" parent="561" relname="span"/>
		<group id="559" type="span" parent="560" relname="span"/>
		<group id="560" type="span" parent="561" relname="preparation"/>
		<group id="561" type="span" parent="564" relname="span"/>
		<group id="562" type="span" parent="292" relname="elaboration"/>
		<group id="563" type="span" parent="562" relname="span"/>
		<group id="564" type="span" />
		<group id="565" type="span" parent="309" relname="span"/>
		<group id="566" type="span" parent="567" relname="same-unit"/>
		<group id="567" type="multinuc" parent="371" relname="contrast"/>
		<group id="568" type="span" parent="394" relname="restatement"/>
		<group id="569" type="span" parent="470" relname="contrast"/>
		<group id="570" type="multinuc" parent="482" relname="span"/>
		<group id="571" type="span" parent="570" relname="joint"/>
		<group id="572" type="span" parent="518" relname="joint"/>
		<group id="573" type="span" parent="521" relname="evaluation"/>
		<group id="574" type="span" parent="575" relname="span"/>
		<group id="575" type="span" />
		<group id="576" type="multinuc" parent="433" relname="solutionhood"/>
		<group id="577" type="span" parent="576" relname="joint"/>
		<group id="578" type="span" parent="577" relname="span"/>
		<group id="579" type="span" parent="576" relname="joint"/>
		<group id="580" type="span" parent="579" relname="span"/>
		<group id="581" type="span" parent="582" relname="span"/>
		<group id="582" type="span" parent="106" relname="background"/>
		<group id="589" type="span" parent="479" relname="elaboration"/>
		<group id="591" type="span" parent="592" relname="span"/>
		<group id="592" type="span" parent="495" relname="joint"/>
		<group id="593" type="span" parent="594" relname="span"/>
		<group id="594" type="span" parent="595" relname="span"/>
		<group id="595" type="span" parent="596" relname="span"/>
		<group id="596" type="span" />
	</body>
</rst>