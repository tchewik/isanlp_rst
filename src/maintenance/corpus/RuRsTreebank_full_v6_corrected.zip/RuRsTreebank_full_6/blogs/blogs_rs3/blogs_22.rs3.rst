<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://odin-moy-den.livejournal.com/2214902.html</segment>
		<segment id="2" >Субботний день эмигрантки в Праге.</segment>
		<segment id="3" parent="4" relname="preparation">Всем привет :)</segment>
		<segment id="4" parent="803" relname="span">Это мой... первый пост в этом сообществе.</segment>
		<segment id="5" parent="416" relname="contrast">Идея вообще-то крутилась давно,</segment>
		<segment id="6" parent="417" relname="span">но я все время забывала:</segment>
		<segment id="7" parent="419" relname="joint">то полдня пройдет, как я вспомню, что хотела фиксировать события дня,</segment>
		<segment id="8" parent="418" relname="contrast">то начинала,</segment>
		<segment id="9" parent="418" relname="contrast">но потом как все заверте!</segment>
		<segment id="10" parent="420" relname="span">Наконец, ура, я сделала это!</segment>
		<segment id="11" parent="796" relname="preparation">Представлюсь:</segment>
		<segment id="12" parent="423" relname="joint">меня зовут Света,</segment>
		<segment id="13" parent="423" relname="joint">мне 39</segment>
		<segment id="14" parent="425" relname="span">и я живу в Праге.</segment>
		<segment id="15" parent="424" relname="span">Переехала сюда недавно - 29 декабря прошлого года из Англии,</segment>
		<segment id="16" parent="15" relname="background">где прожила более 7 лет.</segment>
		<segment id="17" parent="425" relname="background">А родом я из Риги (привет землякам) :)</segment>
		<segment id="18" parent="427" relname="span">Работаю в отделе комплаенс</segment>
		<segment id="19" parent="18" relname="elaboration">(слежу за соответствием деятельности организации нормам и законам) фармакомпании.</segment>
		<segment id="20" parent="430" relname="cause">Согласно политике компании,</segment>
		<segment id="21" parent="428" relname="span">освещать внутреннюю среду и работу</segment>
		<segment id="22" parent="21" relname="condition">без согласования</segment>
		<segment id="23" parent="429" relname="same-unit">нельзя,</segment>
		<segment id="24" parent="432" relname="span">поэтому для сообщества я выбрала выходной день,</segment>
		<segment id="25" parent="435" relname="span">тем более, у нас сейчас каникулы</segment>
		<segment id="26" parent="25" relname="elaboration">и на них запланировано все то, что частенько не влезает в рабочий день.</segment>
		<segment id="27" parent="467" relname="span">Итак, под катом 63 фотографии выходного дня, 22 декабря 2018 года.</segment>
		<segment id="28" parent="437" relname="cause">С 20 декабря у нас корпоративные каникулы</segment>
		<segment id="29" parent="436" relname="joint">и это дает не только спокойно подготовиться к зимним праздникам,</segment>
		<segment id="30" parent="436" relname="joint">но и отдохнуть (а на работу 2 января, да).</segment>
		<segment id="31" parent="440" relname="cause">В Праге я первый год,</segment>
		<segment id="32" parent="439" relname="joint">поэтому многие бытовые моменты еще не устаканились,</segment>
		<segment id="33" parent="439" relname="joint">да и город я еще не досконально изучила. IMG</segment>
		<segment id="34" parent="445" relname="span">Утро начинается около 9.</segment>
		<segment id="35" parent="442" relname="joint">Все будильники отключены,</segment>
		<segment id="36" parent="442" relname="joint">графики сбиты,</segment>
		<segment id="37" parent="443" relname="evaluation">ощущение свободы безгранично :) IMG</segment>
		<segment id="38" parent="446" relname="span">Как же без соц.сетей? :)</segment>
		<segment id="39" parent="38" relname="elaboration">У меня невообразимый микс из новостей в ленте: новости от близких друзей, которых разбросало по всему миру, новости латвийские, чешские, мировые. IMG</segment>
		<segment id="40" parent="451" relname="span">Лохматое утро.</segment>
		<segment id="41" parent="450" relname="span">В плане селфи я какой-то перфекционист.</segment>
		<segment id="42" parent="448" relname="joint">То мне не нравится как близкая камера искажает лицо,</segment>
		<segment id="43" parent="448" relname="joint">то не нравится одинаковая поза с вытянутой рукой :)</segment>
		<segment id="44" parent="449" relname="span">Поэтому себяшек у меня мало (не только в этом посте, вообще). IMG</segment>
		<segment id="45" parent="454" relname="span">Минимальный завтрак: чай, творог с малиной</segment>
		<segment id="46" parent="45" relname="concession">(нет, печенек не было, это обман зрения).</segment>
		<segment id="47" parent="453" relname="joint">Минимальный потому, что иду в бассейн,</segment>
		<segment id="48" parent="456" relname="span">а завтрак - потому что не могу не завтракать.</segment>
		<segment id="49" parent="48" relname="concession">Хотя бы чай должен быть обязательно.</segment>
		<segment id="50" parent="458" relname="span">По телевизору - ретро-музыка,</segment>
		<segment id="51" parent="459" relname="span">это единственный канал, который я знаю</segment>
		<segment id="52" parent="457" relname="joint">(тв не смотрю вообще,</segment>
		<segment id="53" parent="457" relname="joint">в Англии у меня и телевизора-то не было). IMG</segment>
		<segment id="54" parent="460" relname="sequence">Надеваю теплый махровый халат</segment>
		<segment id="55" parent="460" relname="sequence">и выхожу с чаем на балкон.</segment>
		<segment id="56" parent="461" relname="background">Это почти ежеутренний ритуал (исключение - проливной дождь и ураганный ветер).</segment>
		<segment id="57" parent="58" relname="cause">Сутки лил дождь,</segment>
		<segment id="58" parent="463" relname="span">ковер еще не высох</segment>
		<segment id="59" parent="464" relname="joint">- хочу его снять</segment>
		<segment id="60" parent="464" relname="joint">и скрутить в рулон.</segment>
		<segment id="61" parent="469" relname="cause">Осень была теплой</segment>
		<segment id="62" parent="468" relname="joint">и я лишь в ноябре сняла подушки,</segment>
		<segment id="63" parent="468" relname="joint">убрала шезлонг</segment>
		<segment id="64" parent="468" relname="joint">и переставила цветы в комнаты.</segment>
		<segment id="65" parent="471" relname="joint">Оставшиеся горшки надо убрать</segment>
		<segment id="66" parent="471" relname="joint">и почистить</segment>
		<segment id="67" parent="472" relname="evaluation">- это оставим на воскресенье.</segment>
		<segment id="68" parent="478" relname="span">Погода так себе - ветерок и намечающийся дождь.</segment>
		<segment id="69" parent="68" relname="background">Пражане давно уже не видели белого Рождества. IMG</segment>
		<segment id="70" parent="488" relname="span">Еще немного утренней прокрастинации.</segment>
		<segment id="71" parent="480" relname="span">В октябре выбрались с подругой в Дрезден,</segment>
		<segment id="72" parent="71" relname="background">от Праги тут два часа на автобусе,</segment>
		<segment id="73" parent="480" relname="elaboration">погуляли по дрезденской галерее.</segment>
		<segment id="74" parent="75" relname="cause">Репродукции Шоколадницы я видела давно, а вот в реале - впервые.</segment>
		<segment id="75" parent="485" relname="span">Так что, недолго думая, приобрела паззл</segment>
		<segment id="76" parent="483" relname="span">и оставила его до каникул</segment>
		<segment id="77" parent="484" relname="span">(иначе бессонные ночи на рабочей неделе мне гарантированы</segment>
		<segment id="78" parent="77" relname="cause">- в плане паззлов я азартна).</segment>
		<segment id="79" parent="489" relname="sequence">Самое время приступить к собиранию. Недолго. И за сборы! IMG</segment>
		<segment id="80" parent="490" relname="span">Полгода я ходила в бассейн,</segment>
		<segment id="81" parent="786" relname="span">что где-то в получасе езды от дома и от офиса.</segment>
		<segment id="82" parent="81" relname="evaluation">Полчаса - для Праги это значительно :)</segment>
		<segment id="83" parent="491" relname="span">Искала бассейны в округе.</segment>
		<segment id="84" parent="83" relname="elaboration">Съездила в один - те же полчаса.</segment>
		<segment id="85" parent="814" relname="attribution">А тут, коллеги рассказали</segment>
		<segment id="86" parent="814" relname="span">- рядом с офисом отель,</segment>
		<segment id="87" parent="86" relname="elaboration">в отеле спортзал с бассейном.</segment>
		<segment id="88" parent="815" relname="elaboration">Вот сегодня я туда и иду на разведку.</segment>
		<segment id="89" parent="497" relname="span">Да, уже 10:40.</segment>
		<segment id="90" parent="495" relname="contrast">На работу я собираюсь за 40 минут,</segment>
		<segment id="91" parent="92" relname="condition">но если у меня свободный режим</segment>
		<segment id="92" parent="496" relname="span">- я черепашу. :) IMG</segment>
		<segment id="93" parent="501" relname="span">Живу я на стыке центра и спальных районов.</segment>
		<segment id="94" parent="498" relname="span">Здесь смешение частного сектора и многоквартирных домов.</segment>
		<segment id="95" parent="94" relname="background">Истинно спальные районы (со знакомыми всем многоэтажками и многоподъездниками) дальше на 4 станции метро.</segment>
		<segment id="96" parent="97" relname="cause">Район выбирала только в ближнем радиусе от работы.</segment>
		<segment id="97" parent="499" relname="span">И сейчас до работы мне 20 минут пешком или 10 минут на автобусе.</segment>
		<segment id="98" parent="499" relname="evaluation">Идеально. IMG</segment>
		<segment id="99" parent="788" relname="preparation">Отели, дома, офисы вперемешку.</segment>
		<segment id="100" parent="504" relname="span">Тепло. +8. Декабрь :)</segment>
		<segment id="101" parent="787" relname="contrast">Хотя уже выпадал первый снег (в конце ноября), и даже второй (в начале декабря).</segment>
		<segment id="102" parent="787" relname="contrast">А сейчас такая теплая и дождливая осень.</segment>
		<segment id="103" parent="829" relname="contrast">Прогнозируют снижение температуры аж до +4 к концу месяца.</segment>
		<segment id="104" parent="506" relname="span">В Праге я прожила все 4 сезона</segment>
		<segment id="105" parent="505" relname="contrast">и кроме лета, которое вызвало у меня климатический шок (+35+38),</segment>
		<segment id="106" parent="505" relname="contrast">особых потрясений не было.</segment>
		<segment id="107" parent="507" relname="comparison">Влажность выше, чем в Англии,</segment>
		<segment id="108" parent="507" relname="comparison">но ниже, чем в родной Риге.</segment>
		<segment id="109" parent="508" relname="span">Ах да и снега в Праге больше, чем в Бирмингеме</segment>
		<segment id="110" parent="109" relname="elaboration">(даже если в Праге он 5 раз за зиму). :)) IMG</segment>
		<segment id="111" parent="514" relname="span">Неспешно к 11 утра я подошла к своей цели.</segment>
		<segment id="112" parent="513" relname="span">Мне нужен 24-й этаж вот этого бежевого здания.</segment>
		<segment id="113" parent="112" relname="background">А за V-образным зданием - моя работа. IMG</segment>
		<segment id="114" parent="115" relname="condition">Пока поднимаюсь в лифте,</segment>
		<segment id="115" parent="515" relname="span">делаю на заметку фото со временем работы спортзала в празднчные дни.</segment>
		<segment id="116" parent="521" relname="background">В Праге Рождество - это выходные 24, 25 и 26 декабря.</segment>
		<segment id="117" parent="517" relname="attribution">В этом году был принят закон,</segment>
		<segment id="118" parent="518" relname="joint">что в официальные праздничные выходные торговые центры и магазины площадью свыше 200 кв.м. должны быть закрыты.</segment>
		<segment id="119" parent="516" relname="span">Маленькие частные магазинчики оставлены на усмотрение хозяев</segment>
		<segment id="120" parent="119" relname="elaboration">- в основном, закрыты, как я успела заметить.</segment>
		<segment id="121" parent="519" relname="restatement">Из продуктовых будут работать "вечерки"</segment>
		<segment id="122" parent="520" relname="span">(или, как их тут называют "вьетнамки",</segment>
		<segment id="123" parent="122" relname="cause">из-за хозяев-вьетнамцев).</segment>
		<segment id="124" parent="125" relname="condition">Так что если вижу где расписание на Рождество</segment>
		<segment id="125" parent="794" relname="span">- обязательно фиксирую. IMG</segment>
		<segment id="126" parent="525" relname="sequence">Получаю ключ от шкафчика</segment>
		<segment id="127" parent="525" relname="sequence">и иду переодеваться.</segment>
		<segment id="128" parent="526" relname="span">Шкафчики, душевые кабинки.</segment>
		<segment id="129" parent="529" relname="span">Аккуратно, чисто.</segment>
		<segment id="130" parent="527" relname="span">Почему я так щепетильна?</segment>
		<segment id="131" parent="130" relname="elaboration">Ну, в отношении чистоты общественных мест - очень.</segment>
		<segment id="132" parent="528" relname="span">К тому же был неприятный опыт в Бирмингеме, где приходилось мириться со своеобразным отношением к чистоте и гигиене. IMG</segment>
		<segment id="133" parent="530" relname="contrast">Спорткомплекс небольшой,</segment>
		<segment id="134" parent="530" relname="contrast">но вмещает в себя всё: бассейн, джакузи, тренажерный зал, массажный кабинет.</segment>
		<segment id="135" parent="539" relname="contrast">Весьма удобно.</segment>
		<segment id="136" parent="533" relname="same-unit">Единственное но -</segment>
		<segment id="137" parent="138" relname="condition">если отель переполнен,</segment>
		<segment id="138" parent="532" relname="span">тут яблоку негде упасть.</segment>
		<segment id="139" parent="535" relname="condition">Коллега была в начале декабря,</segment>
		<segment id="140" parent="804" relname="attribution">говорит,</segment>
		<segment id="141" parent="534" relname="contrast">в бассейне не плавала</segment>
		<segment id="142" parent="534" relname="contrast">- ходила.</segment>
		<segment id="143" parent="547" relname="contrast">Отель не сильно туристический,</segment>
		<segment id="144" parent="546" relname="span">больше деловой -</segment>
		<segment id="145" parent="543" relname="joint">приезжают делегации,</segment>
		<segment id="146" parent="543" relname="joint">устраиваются конференции,</segment>
		<segment id="147" parent="545" relname="same-unit">да и наши коллеги из других стран,</segment>
		<segment id="148" parent="149" relname="condition">приезжая в командировку в Прагу,</segment>
		<segment id="149" parent="544" relname="span">останавливаются здесь же.</segment>
		<segment id="150" parent="551" relname="span">Ну что ж, в январе народу много не будет, а там посмотрим.</segment>
		<segment id="151" parent="548" relname="joint">Расположение идеальное,</segment>
		<segment id="152" parent="548" relname="joint">выбор активностей широкий.</segment>
		<segment id="153" parent="548" relname="joint">А, да. И вид прекрасный (окно во весь размер зала). IMG</segment>
		<segment id="154" parent="552" relname="joint">С удовольствием поплавала,</segment>
		<segment id="155" parent="552" relname="joint">повтыкала на вид.</segment>
		<segment id="156" parent="553" relname="sequence">Пора собираться.</segment>
		<segment id="157" parent="831" relname="span">Да, поясню, чем фотографирую</segment>
		<segment id="158" parent="819" relname="span">- у меня два телефона. Чешский и британский.</segment>
		<segment id="159" parent="821" relname="span">В начале года было 3 (еще и латвийский).</segment>
		<segment id="160" parent="554" relname="span">Латвийский закрыла,</segment>
		<segment id="161" parent="160" relname="condition">как только поняла, что в Ригу уже не вернусь.</segment>
		<segment id="162" parent="556" relname="contrast">От британского избавлюсь в марте.</segment>
		<segment id="163" parent="164" relname="evaluation">А пока удобно</segment>
		<segment id="164" parent="557" relname="span">- роуминга в Европе нет. IMG</segment>
		<segment id="165" parent="580" relname="sequence">Домой возвращаюсь той же дорогой.</segment>
		<segment id="166" parent="582" relname="span">Проверяю почтовый ящик.</segment>
		<segment id="167" parent="563" relname="span">К этому пришлось привыкнуть.</segment>
		<segment id="168" parent="562" relname="same-unit">После 7,5 лет в Англии,</segment>
		<segment id="169" parent="170" relname="condition">когда вся почта сваливается через почтовую щель прямо в квартиру,</segment>
		<segment id="170" parent="561" relname="span">пришлось заново привыкать к почтовому ящику.</segment>
		<segment id="171" parent="564" relname="span">В самом начале своей пражской жизни, я сделала еще одно открытие</segment>
		<segment id="172" parent="565" relname="contrast">- пражане не пишут на почтовых ящиках номера квартир.</segment>
		<segment id="173" parent="583" relname="span">Вместо них они пишут фамилии.</segment>
		<segment id="174" parent="566" relname="joint">Квартиры сдаются,</segment>
		<segment id="175" parent="566" relname="joint">снимаются</segment>
		<segment id="176" parent="567" relname="span">- каждый раз лепится новая наклейка.</segment>
		<segment id="177" parent="568" relname="span">Из-за этого многие ящики имеют непрезентабельный вид.</segment>
		<segment id="178" parent="569" relname="joint">Я как-то задалась вопросом: что если почтальон новый,</segment>
		<segment id="179" parent="569" relname="joint">а в его ведении многоподъездный, многоквартирный дом?</segment>
		<segment id="180" parent="581" relname="span">Это ж каждый раз читать постоянно меняющиеся фамилии!</segment>
		<segment id="181" parent="570" relname="contrast">Вот так ящики выглядят снаружи. IMG</segment>
		<segment id="182" parent="570" relname="contrast">А вот так внутри.</segment>
		<segment id="183" parent="573" relname="attribution">Как мне объяснили,</segment>
		<segment id="184" parent="185" relname="condition">если пакет объемный,</segment>
		<segment id="185" parent="823" relname="span">то почтальон заходит внутрь</segment>
		<segment id="186" parent="571" relname="sequence">и кладет его сверху, на ящики.</segment>
		<segment id="187" parent="578" relname="same-unit">Или,</segment>
		<segment id="188" parent="577" relname="condition">если почтальон ленив,</segment>
		<segment id="189" parent="578" relname="same-unit">оставляет извещение</segment>
		<segment id="190" parent="575" relname="sequence">и за пакетом приходится идти в почтовое отделение. IMG</segment>
		<segment id="191" parent="192" relname="evaluation">Чехи знатно спамят</segment>
		<segment id="192" parent="587" relname="span">- я проверяла ящик два дня назад.</segment>
		<segment id="193" parent="591" relname="span">Множество буклетов, рекламок, скидочных талонов.</segment>
		<segment id="194" parent="193" relname="evaluation">Я за год еще не выучила названия всех магазинов!</segment>
		<segment id="195" parent="590" relname="contrast">Можно, конечно, швырнуть все в мусорку,</segment>
		<segment id="196" parent="589" relname="same-unit">но</segment>
		<segment id="197" parent="198" relname="condition">пока еще на этот адрес приходят письма хозяйке квартиры,</segment>
		<segment id="198" parent="588" relname="span">приходится пролистывать всё. IMG</segment>
		<segment id="199" parent="599" relname="span">Как-то уже проголодалась.</segment>
		<segment id="200" parent="597" relname="span">Не настолько,</segment>
		<segment id="201" parent="200" relname="condition">чтобы полноценно готовить,</segment>
		<segment id="202" parent="598" relname="span">поэтому доедаю пачку творога с малиной и бананом.</segment>
		<segment id="203" parent="600" relname="joint">Ну и немного паззла :) IMG</segment>
		<segment id="204" parent="602" relname="span">Переодеваюсь и на выход.</segment>
		<segment id="205" parent="204" relname="cause">У меня еще есть дела. IMG</segment>
		<segment id="206" parent="601" relname="span">Попытка селфи.</segment>
		<segment id="207" parent="206" relname="evaluation">Непохожа на себя. Вообще :)) IMG</segment>
		<segment id="208" parent="603" relname="span">Проверка времени и транспорта. IMG</segment>
		<segment id="209" parent="208" relname="background">Тот самый частный сектор. IMG</segment>
		<segment id="210" parent="607" relname="span">Мне нужен 118 автобус,</segment>
		<segment id="211" parent="608" relname="span">поэтому иду с другой стороны, чем обычно,</segment>
		<segment id="212" parent="606" relname="same-unit">но всегда,</segment>
		<segment id="213" parent="214" relname="condition">проходя мимо этого дома,</segment>
		<segment id="214" parent="605" relname="span">улыбаюсь. IMG</segment>
		<segment id="215" parent="607" relname="background">Карта Праги. Я живу вот тут. IMG</segment>
		<segment id="216" parent="617" relname="span">Сажусь в автобус.</segment>
		<segment id="217" parent="616" relname="span">Транспорт в Праге - один из лучших, что я видела в Европе.</segment>
		<segment id="218" parent="217" relname="elaboration">Короли, конечно, трамваи и метро.</segment>
		<segment id="219" parent="625" relname="span">Очень удобная система проездных - не только месячный, но и годовой.</segment>
		<segment id="220" parent="615" relname="span">Небольшая сравнительная характеристика.</segment>
		<segment id="221" parent="611" relname="comparison">В Праге годовой проездной обойдется в 143 евро,</segment>
		<segment id="222" parent="611" relname="comparison">в Бирмингеме - 805,</segment>
		<segment id="223" parent="611" relname="comparison">в Риге - 600 евро.</segment>
		<segment id="224" parent="612" relname="comparison">Одноразовые билеты: на полчаса стоит 24 кроны (0,95 евро),</segment>
		<segment id="225" parent="612" relname="comparison">на 90 минут - 32,</segment>
		<segment id="226" parent="612" relname="comparison">на весь день - 110 крон (4,30 евро),</segment>
		<segment id="227" parent="612" relname="comparison">на 3 дня - 310.</segment>
		<segment id="228" parent="614" relname="contrast">Правда, говорят, что с нового года подорожают.</segment>
		<segment id="229" parent="618" relname="joint">Приобрести билеты у водителя невозможно,</segment>
		<segment id="230" parent="619" relname="contrast">кондукторов тут тоже нет</segment>
		<segment id="231" parent="619" relname="contrast">(контролеры, кстати, встречаются).</segment>
		<segment id="232" parent="620" relname="span">Поэтому своим гостям я заранее покупаю несколько штук.</segment>
		<segment id="233" parent="621" relname="joint">Компостируют билет вот в этих желтых ящиках со светящейся стрелочкой. IMG</segment>
		<segment id="234" parent="628" relname="sequence">Ехать минут 10, на другой берег Влтавы.</segment>
		<segment id="235" parent="627" relname="span">Потом пересаживаюсь на желтую ветку метро.</segment>
		<segment id="236" parent="626" relname="span">Люблю метро.</segment>
		<segment id="237" parent="236" relname="elaboration">Точнее, люблю города, в которых есть метро :)</segment>
		<segment id="238" parent="629" relname="span">В Праге оно неглубокое</segment>
		<segment id="239" parent="238" relname="elaboration">и то и дело выныривает на поверхность. IMG</segment>
		<segment id="240" parent="631" relname="evaluation">Желтая ветка метро брутальна.</segment>
		<segment id="241" parent="630" relname="joint">Немного напоминает питерскую - двери с грохотом закрываются,</segment>
		<segment id="242" parent="630" relname="joint">вагоны с лязгом проносятся по тунелям.</segment>
		<segment id="243" parent="633" relname="span">Моя обычная ветка - красная,</segment>
		<segment id="244" parent="243" relname="evaluation">вся такая тишайшая, прилизанная :))) IMG</segment>
		<segment id="245" parent="636" relname="sequence">Приехала.</segment>
		<segment id="246" parent="636" relname="sequence">Таймчек и наверх. IMG</segment>
		<segment id="247" parent="636" relname="sequence">Наверху внезапно взгляд цепляется за искусство :)) IMG</segment>
		<segment id="248" parent="639" relname="span">Приехала я в район Смихов-Андел,</segment>
		<segment id="249" parent="248" relname="background">где обычно бываю редко.</segment>
		<segment id="250" parent="641" relname="joint">Смихов - промышленный район, Андел - экспатско-тусовочный.</segment>
		<segment id="251" parent="641" relname="joint">Тут у меня две остановки.</segment>
		<segment id="252" parent="253" relname="condition">Пока иду до нужного магазина,</segment>
		<segment id="253" parent="640" relname="span">осматриваю окрестности.</segment>
		<segment id="254" parent="647" relname="span">На любой, мало-мальски людной площади развернуты рождественские рыночки.</segment>
		<segment id="255" parent="254" relname="elaboration">Тут есть все, в топе, конечно, горячее вино, трдельник (лакомство из теста с сахаром и корицей), хот-доги, да блюда из свинины на вертеле.</segment>
		<segment id="256" parent="644" relname="contrast">Основная часть рождественских рыночков работает до конца года,</segment>
		<segment id="257" parent="644" relname="contrast">но самые крупные в центре - до 6 января.</segment>
		<segment id="258" parent="645" relname="elaboration">Наметила себе до конца года обойти их все :)) IMG</segment>
		<segment id="259" parent="651" relname="span">А это - чисто чешское.</segment>
		<segment id="260" parent="650" relname="span">За дня два до Рождества практически на всех углах стоят вот такие вот палатки.</segment>
		<segment id="261" parent="649" relname="span">Здесь продают живых карпов.</segment>
		<segment id="262" parent="648" relname="joint">Запеченный карп - главное блюдо чешского рождественского стола.</segment>
		<segment id="263" parent="648" relname="joint">И продают их только до 24 числа. IMG</segment>
		<segment id="264" parent="659" relname="joint">Говорят, что в последнее время, 25-26 декабря все больше людей выходят на набережные Влтавы</segment>
		<segment id="265" parent="656" relname="span">и выпускают в реку живых карпов,</segment>
		<segment id="266" parent="658" relname="same-unit">которые</segment>
		<segment id="267" parent="268" relname="cause">из милосердия</segment>
		<segment id="268" parent="657" relname="span">не стали украшением праздничного стола.</segment>
		<segment id="269" parent="270" relname="cause">Честно скажу - я рыбу не ем вообще (как и любые морепродукты),</segment>
		<segment id="270" parent="830" relname="span">поэтому полюбопытствовала, но и только. IMG</segment>
		<segment id="271" parent="664" relname="span">Ёлочные базары тоже работают только до 24 числа.</segment>
		<segment id="272" parent="826" relname="span">Цены на ёлки разные</segment>
		<segment id="273" parent="272" relname="elaboration">- 1,5м стоит где-то 500-600 крон (20-25 евро). IMG</segment>
		<segment id="274" parent="665" relname="contrast">А вот и моя цель. Книжный супермаркет.</segment>
		<segment id="275" parent="665" relname="contrast">Но я сюда за открытками пришла.</segment>
		<segment id="276" parent="277" relname="solutionhood">Нужно докупить несколько,</segment>
		<segment id="277" parent="667" relname="span">а в одном из сообществ прочитала, что тут просто открыточный рай.</segment>
		<segment id="278" parent="666" relname="contrast">Что ж, всегда надо понимать, что то, что для одного вау,</segment>
		<segment id="279" parent="666" relname="contrast">для другого - мда?.</segment>
		<segment id="280" parent="669" relname="span">Рая не оказалось,</segment>
		<segment id="281" parent="280" relname="condition">если не считать пару штативов с не очень большим выбором.</segment>
		<segment id="282" parent="671" relname="contrast">Но может все распродали?</segment>
		<segment id="283" parent="672" relname="sequence">Купила три штуки</segment>
		<segment id="284" parent="672" relname="sequence">и покинула заведение. IMG</segment>
		<segment id="285" parent="677" relname="span">До второй цели я решила пройти пешком,</segment>
		<segment id="286" parent="285" relname="condition">попутно глазея на дома.</segment>
		<segment id="287" parent="678" relname="joint">Рельсы, рельсы. IMG</segment>
		<segment id="288" parent="681" relname="span">Церквей и костелов в Праге множество.</segment>
		<segment id="289" parent="679" relname="joint">Их можно не заметить</segment>
		<segment id="290" parent="679" relname="joint">и пройти мимо,</segment>
		<segment id="291" parent="680" relname="contrast">или только их и замечать IMG</segment>
		<segment id="292" parent="293" relname="cause">Прага архитектурно напоминает мне Ригу,</segment>
		<segment id="293" parent="682" relname="span">может поэтому я за неполный год почувствовала себя здесь как дома? :) IMG</segment>
		<segment id="294" parent="688" relname="span">Ищу нужный дом.</segment>
		<segment id="295" parent="685" relname="span">Кстати. На пражских домах всегда два номера - на красной табличке и на синей.</segment>
		<segment id="296" parent="686" relname="span">На красной - кадастровый номер дома, на синей - порядковый.</segment>
		<segment id="297" parent="296" relname="elaboration">И номер на почтовых отправлениях всегда будет двойной- 506/48. IMG</segment>
		<segment id="298" parent="689" relname="joint">А мне сюда IMG</segment>
		<segment id="299" parent="697" relname="preparation">В Праге 4 котокафе.</segment>
		<segment id="300" parent="690" relname="sequence">После переезда и встречи нового года, первое, куда я пошла после обзорной прогулки по городу - котокафе.</segment>
		<segment id="301" parent="694" relname="span">Потом узнала о существовании еще трех :)</segment>
		<segment id="302" parent="693" relname="comparison">Это второе.</segment>
		<segment id="303" parent="691" relname="joint">Оно теснее, чем первое,</segment>
		<segment id="304" parent="691" relname="joint">котов тут меньше,</segment>
		<segment id="305" parent="691" relname="joint">посетителей больше.</segment>
		<segment id="306" parent="692" relname="joint">Котолежбище IMG</segment>
		<segment id="307" parent="692" relname="joint">Котики быват разные IMG</segment>
		<segment id="308" parent="692" relname="joint">Запостить в инстаграм, собрать лайки :))) IMG</segment>
		<segment id="309" parent="692" relname="joint">На стене - список обитателей. IMG</segment>
		<segment id="310" parent="311" relname="condition">Пока жду заказ (домашний малиновый лимонад),</segment>
		<segment id="311" parent="699" relname="span">записываю мысль.</segment>
		<segment id="312" parent="699" relname="background">Одно из моих увлечений - написание рассказов.</segment>
		<segment id="313" parent="700" relname="contrast">Иногда в голову приходит какая-то мысль,</segment>
		<segment id="314" parent="700" relname="contrast">а полноценно писать нет времени.</segment>
		<segment id="315" parent="792" relname="span">Для этого на телефоне есть заметки. IMG</segment>
		<segment id="316" parent="703" relname="contrast">Котиков можно постить бесконечно, хоть на весь пост,</segment>
		<segment id="317" parent="703" relname="contrast">но лучше их гладить :))</segment>
		<segment id="318" parent="706" relname="span">Ухожу из кафе с восстановившейся кармой :)))</segment>
		<segment id="319" parent="318" relname="evaluation">Прошу прощения за качество, с часами вообще проблема оказалась. IMG</segment>
		<segment id="320" parent="321" relname="cause">Раз открыточки куплены,</segment>
		<segment id="321" parent="707" relname="span">их надо отправить.</segment>
		<segment id="322" parent="798" relname="sequence">Сажусь в трамвай</segment>
		<segment id="323" parent="798" relname="sequence">и через три остановки оказываюсь у Чешской почты. IMG</segment>
		<segment id="324" parent="325" relname="condition">Если я бываю в центре,</segment>
		<segment id="325" parent="708" relname="span">то всегда захожу в это отделение</segment>
		<segment id="326" parent="708" relname="background">(работает, кстати, до полуночи).</segment>
		<segment id="327" parent="709" relname="evaluation">Оно шикарное</segment>
		<segment id="328" parent="711" relname="span">- жаль, в деталях фоткать не дают</segment>
		<segment id="329" parent="330" relname="attribution">- строгий дядечка не разрешает</segment>
		<segment id="330" parent="827" relname="span">даже говорить по телефону,</segment>
		<segment id="331" parent="710" relname="joint">а уж фотографирование - это вовсе за гранью его понимания!</segment>
		<segment id="332" parent="712" relname="contrast">Приходится тайком. IMG</segment>
		<segment id="333" parent="718" relname="span">Очередь оказывается длинной.</segment>
		<segment id="334" parent="716" relname="contrast">У меня 350 номер,</segment>
		<segment id="335" parent="716" relname="contrast">а сейчас на обслуживании 283,</segment>
		<segment id="336" parent="793" relname="joint">при этом за 20 минут прошло только 10 номерков.</segment>
		<segment id="337" parent="717" relname="sequence">Тогда я решаю зайти еще в одно местечко,</segment>
		<segment id="338" parent="717" relname="sequence">а потом вернуться на почту.</segment>
		<segment id="339" parent="721" relname="span">Местечко совсем рядом с почтой, на соседней улице</segment>
		<segment id="340" parent="339" relname="elaboration">и называется оно музей Мухи.</segment>
		<segment id="341" parent="722" relname="joint">Я люблю его постеры</segment>
		<segment id="342" parent="722" relname="joint">и могу разглядывать их бесконечно. IMG</segment>
		<segment id="343" parent="723" relname="span">Сейчас в национальной галерее открыта выставка его грандиозной Славянской эпопеи,</segment>
		<segment id="344" parent="343" relname="elaboration">отметила себе, что обязательно надо сходить.</segment>
		<segment id="345" parent="724" relname="contrast">Но постеры - это моя любовь навечно. IMG</segment>
		<segment id="346" parent="728" relname="sequence">Быстро заскакиваю на почту,</segment>
		<segment id="347" parent="728" relname="sequence">за 5 минут отправляю открыточки</segment>
		<segment id="348" parent="729" relname="span">и с чувством выполненного долга смотрю на часы.</segment>
		<segment id="349" parent="348" relname="evaluation">О! Восьмой час!</segment>
		<segment id="350" parent="351" relname="evaluation">Неудивительно, что</segment>
		<segment id="351" parent="805" relname="span">я вдруг проголодалась. IMG</segment>
		<segment id="352" parent="801" relname="span">Идти в ресторан не хочется</segment>
		<segment id="353" parent="352" relname="elaboration">(особо времени нет),</segment>
		<segment id="354" parent="730" relname="joint">кафешки к этому времени закрыты.</segment>
		<segment id="355" parent="732" relname="span">Остается уличная еда,</segment>
		<segment id="356" parent="357" relname="cause">но моросит противненький дождик</segment>
		<segment id="357" parent="733" relname="span">и хочется внутрь.</segment>
		<segment id="358" parent="736" relname="span">Тогда - общепит.</segment>
		<segment id="359" parent="737" relname="span">Есть в Праге сетевое заведение Bageterie Boulevard,</segment>
		<segment id="360" parent="359" relname="evaluation">весьма неплохое.</segment>
		<segment id="361" parent="738" relname="joint">Иногда мы с коллегами выбираемся на обед (в фудкорт торгового центра рядом с офисом)</segment>
		<segment id="362" parent="738" relname="joint">и частенько заходим в багетерию. IMG</segment>
		<segment id="363" parent="743" relname="span">Заказываю салат Цезарь и печеную картошку (169 крон, около 6,5 евро).</segment>
		<segment id="364" parent="740" relname="span">Тут и выясняется отличие заведения в туристическом центре от такого же заведения, но в офисном квартале.</segment>
		<segment id="365" parent="364" relname="elaboration">Соуса, больше похожего на майонез, чуть ли не столько же, сколько самой еды.</segment>
		<segment id="366" parent="741" relname="span">Аккуратно скидываю этот типа соус,</segment>
		<segment id="367" parent="366" relname="evaluation">за исключением него, вполне нормально.</segment>
		<segment id="368" parent="802" relname="joint">Ем</segment>
		<segment id="369" parent="802" relname="joint">и заодно читаю соц.сети. IMG</segment>
		<segment id="370" parent="752" relname="span">Последний пункт сегодняшней программы - кино.</segment>
		<segment id="371" parent="747" relname="span">Искала что-нибудь старое рождественское,</segment>
		<segment id="372" parent="371" relname="elaboration">нашлась только Love Actually (Реальная любовь - весьма странный перевод).</segment>
		<segment id="373" parent="748" relname="span">Старое кино в Праге показывает один-два кинотеатра.</segment>
		<segment id="374" parent="750" relname="span">Основной - кинотеатр Люцерн.</segment>
		<segment id="375" parent="374" relname="elaboration">Тут же часто показывают и российское кино (обычно нечто конкурсное и т.д.).</segment>
		<segment id="376" parent="749" relname="comparison">Вообще, кино в Праге бывает с субтитрами и дублированное.</segment>
		<segment id="377" parent="749" relname="comparison">В Риге любое кино идет с субтитрами (российское с латышскими), английское (с русскими и латышскими).</segment>
		<segment id="378" parent="754" relname="same-unit">Помню,</segment>
		<segment id="379" parent="380" relname="condition">будучи в Питере,</segment>
		<segment id="380" parent="753" relname="span">зашла в кино,</segment>
		<segment id="381" parent="755" relname="joint">с удивлением увидела отметку (дублированное).</segment>
		<segment id="382" parent="756" relname="contrast">В Праге - на любой вкус.</segment>
		<segment id="383" parent="760" relname="span">Люцерн симпатичен - я тут впервые.</segment>
		<segment id="384" parent="758" relname="joint">Начало в 20:30.</segment>
		<segment id="385" parent="758" relname="joint">Зал был полный. IMG</segment>
		<segment id="386" parent="762" relname="preparation">Из кинотеатра я вышла в половине одиннадцатого.</segment>
		<segment id="387" parent="388" relname="cause">Раз уж я в самом центре,</segment>
		<segment id="388" parent="762" relname="span">то немного кадров из дождливой предрождественской Праги.</segment>
		<segment id="389" parent="765" relname="sequence">Не так много народу на Пшикопе, улице с брендовыми магазинами и прочим пафосом. IMG</segment>
		<segment id="390" parent="764" relname="span">Вацлавская площадь.</segment>
		<segment id="391" parent="763" relname="span">В последнее время ходит много слухов насчет того, чтобы снова пустить по площади трамваи,</segment>
		<segment id="392" parent="391" relname="background">как это было раньше. IMG</segment>
		<segment id="393" parent="765" relname="sequence">Кому цветочек? IMG</segment>
		<segment id="394" parent="765" relname="sequence">Ёлки повсюду IMG</segment>
		<segment id="395" parent="767" relname="span">Пора домой.</segment>
		<segment id="396" parent="766" relname="sequence">Тишайшая красная ветка метро. IMG</segment>
		<segment id="397" parent="766" relname="sequence">Таймчек. IMG</segment>
		<segment id="398" parent="766" relname="sequence">Ура. Я дома.</segment>
		<segment id="399" parent="766" relname="sequence">Натопала сегодня прилично :) IMG</segment>
		<segment id="400" parent="782" relname="sequence">В душ, смыть косметику. IMG</segment>
		<segment id="401" parent="771" relname="contrast">Пока спать не хочется.</segment>
		<segment id="402" parent="773" relname="span">Хочется посмотреть чего-то милого, душевного.</segment>
		<segment id="403" parent="772" relname="span">Как раз под мандаринки и пипаркукас</segment>
		<segment id="404" parent="403" relname="elaboration">(латвийское пряное печенье - пеку его только на зимние праздники).</segment>
		<segment id="405" parent="774" relname="span">Душевное и милое быстро находится.</segment>
		<segment id="406" parent="405" relname="elaboration">Как украсть миллион. :) IMG</segment>
		<segment id="407" parent="778" relname="cause">Спать, как всегда, хочется за 15 минут до конца фильма.</segment>
		<segment id="408" parent="778" relname="span">Значит, на сегодня все.</segment>
		<segment id="409" parent="408" relname="evaluation">О! А сегодня уже завтра :))</segment>
		<segment id="410" parent="776" relname="sequence">День получился насыщенным,</segment>
		<segment id="411" parent="776" relname="sequence">воскресенье, скорее всего, будет ленивым,</segment>
		<segment id="412" parent="777" relname="span">а затем снова насыщенные дни.</segment>
		<segment id="413" parent="412" relname="evaluation">В этом прелесть отпуска :))</segment>
		<segment id="414" >Спасибо, что провели этот день со мной! :)</segment>
		<segment id="415" >С наступающими праздниками! :)</segment>
		<group id="416" type="multinuc" parent="422" relname="span"/>
		<group id="417" type="span" parent="416" relname="contrast"/>
		<group id="418" type="multinuc" parent="419" relname="joint"/>
		<group id="419" type="multinuc" parent="6" relname="cause"/>
		<group id="420" type="span" />
		<group id="421" type="span" parent="10" relname="solutionhood"/>
		<group id="422" type="span" parent="421" relname="span"/>
		<group id="423" type="multinuc" parent="796" relname="span"/>
		<group id="424" type="span" parent="14" relname="elaboration"/>
		<group id="425" type="span" parent="426" relname="span"/>
		<group id="426" type="span" parent="423" relname="joint"/>
		<group id="427" type="span" parent="433" relname="preparation"/>
		<group id="428" type="span" parent="429" relname="same-unit"/>
		<group id="429" type="multinuc" parent="430" relname="span"/>
		<group id="430" type="span" parent="431" relname="span"/>
		<group id="431" type="span" parent="24" relname="cause"/>
		<group id="432" type="span" parent="433" relname="span"/>
		<group id="433" type="span" parent="434" relname="span"/>
		<group id="434" type="span" parent="781" relname="span"/>
		<group id="435" type="span" parent="432" relname="cause"/>
		<group id="436" type="multinuc" parent="437" relname="span"/>
		<group id="437" type="span" parent="438" relname="span"/>
		<group id="438" type="span" parent="452" relname="span"/>
		<group id="439" type="multinuc" parent="440" relname="span"/>
		<group id="440" type="span" parent="441" relname="span"/>
		<group id="441" type="span" parent="438" relname="background"/>
		<group id="442" type="multinuc" parent="443" relname="span"/>
		<group id="443" type="span" parent="444" relname="span"/>
		<group id="444" type="span" parent="34" relname="elaboration"/>
		<group id="445" type="span" parent="447" relname="sequence"/>
		<group id="446" type="span" parent="447" relname="sequence"/>
		<group id="447" type="multinuc" />
		<group id="448" type="multinuc" parent="44" relname="cause"/>
		<group id="449" type="span" parent="41" relname="elaboration"/>
		<group id="450" type="span" parent="40" relname="elaboration"/>
		<group id="451" type="span" parent="447" relname="sequence"/>
		<group id="452" type="span" parent="27" relname="elaboration"/>
		<group id="453" type="multinuc" parent="454" relname="cause"/>
		<group id="454" type="span" parent="455" relname="span"/>
		<group id="455" type="span" parent="447" relname="sequence"/>
		<group id="456" type="span" parent="453" relname="joint"/>
		<group id="457" type="multinuc" parent="51" relname="cause"/>
		<group id="458" type="span" parent="447" relname="sequence"/>
		<group id="459" type="span" parent="50" relname="elaboration"/>
		<group id="460" type="multinuc" parent="461" relname="span"/>
		<group id="461" type="span" parent="462" relname="span"/>
		<group id="462" type="span" parent="476" relname="preparation"/>
		<group id="463" type="span" parent="465" relname="cause"/>
		<group id="464" type="multinuc" parent="465" relname="span"/>
		<group id="465" type="span" parent="466" relname="span"/>
		<group id="466" type="span" parent="474" relname="span"/>
		<group id="467" type="span" parent="434" relname="elaboration"/>
		<group id="468" type="multinuc" parent="469" relname="span"/>
		<group id="469" type="span" parent="470" relname="span"/>
		<group id="470" type="span" parent="466" relname="background"/>
		<group id="471" type="multinuc" parent="472" relname="span"/>
		<group id="472" type="span" parent="473" relname="span"/>
		<group id="473" type="span" parent="475" relname="sequence"/>
		<group id="474" type="span" parent="475" relname="sequence"/>
		<group id="475" type="multinuc" parent="479" relname="span"/>
		<group id="476" type="span" parent="477" relname="span"/>
		<group id="477" type="span" />
		<group id="478" type="span" parent="479" relname="background"/>
		<group id="479" type="span" parent="476" relname="span"/>
		<group id="480" type="span" parent="481" relname="span"/>
		<group id="481" type="span" parent="486" relname="background"/>
		<group id="482" type="multinuc" parent="486" relname="span"/>
		<group id="483" type="span" parent="482" relname="joint"/>
		<group id="484" type="span" parent="76" relname="cause"/>
		<group id="485" type="span" parent="482" relname="joint"/>
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" parent="70" relname="elaboration"/>
		<group id="488" type="span" parent="489" relname="sequence"/>
		<group id="489" type="multinuc" />
		<group id="490" type="span" parent="494" relname="comparison"/>
		<group id="491" type="span" parent="494" relname="comparison"/>
		<group id="494" type="multinuc" />
		<group id="495" type="multinuc" parent="89" relname="elaboration"/>
		<group id="496" type="span" parent="495" relname="contrast"/>
		<group id="497" type="span" parent="502" relname="preparation"/>
		<group id="498" type="span" parent="93" relname="elaboration"/>
		<group id="499" type="span" parent="500" relname="span"/>
		<group id="500" type="span" parent="501" relname="elaboration"/>
		<group id="501" type="span" parent="502" relname="span"/>
		<group id="502" type="span" parent="503" relname="span"/>
		<group id="503" type="span" />
		<group id="504" type="span" parent="788" relname="span"/>
		<group id="505" type="multinuc" parent="104" relname="elaboration"/>
		<group id="506" type="span" parent="510" relname="span"/>
		<group id="507" type="multinuc" parent="509" relname="joint"/>
		<group id="508" type="span" parent="509" relname="joint"/>
		<group id="509" type="multinuc" parent="506" relname="elaboration"/>
		<group id="510" type="span" />
		<group id="513" type="span" parent="111" relname="elaboration"/>
		<group id="514" type="span" parent="524" relname="sequence"/>
		<group id="515" type="span" parent="524" relname="sequence"/>
		<group id="516" type="span" parent="518" relname="joint"/>
		<group id="517" type="span" parent="521" relname="span"/>
		<group id="518" type="multinuc" parent="517" relname="span"/>
		<group id="519" type="multinuc" parent="518" relname="joint"/>
		<group id="520" type="span" parent="519" relname="restatement"/>
		<group id="521" type="span" parent="522" relname="span"/>
		<group id="522" type="span" parent="523" relname="span"/>
		<group id="523" type="span" parent="794" relname="solutionhood"/>
		<group id="524" type="multinuc" parent="522" relname="preparation"/>
		<group id="525" type="multinuc" parent="541" relname="preparation"/>
		<group id="526" type="span" parent="541" relname="span"/>
		<group id="527" type="span" parent="132" relname="solutionhood"/>
		<group id="528" type="span" parent="129" relname="elaboration"/>
		<group id="529" type="span" parent="128" relname="evaluation"/>
		<group id="530" type="multinuc" parent="531" relname="span"/>
		<group id="531" type="span" parent="540" relname="span"/>
		<group id="532" type="span" parent="533" relname="same-unit"/>
		<group id="533" type="multinuc" parent="537" relname="span"/>
		<group id="534" type="multinuc" parent="804" relname="span"/>
		<group id="535" type="span" parent="536" relname="span"/>
		<group id="536" type="span" parent="537" relname="evidence"/>
		<group id="537" type="span" parent="538" relname="span"/>
		<group id="538" type="span" parent="539" relname="contrast"/>
		<group id="539" type="multinuc" parent="531" relname="evaluation"/>
		<group id="540" type="span" />
		<group id="541" type="span" parent="542" relname="span"/>
		<group id="542" type="span" />
		<group id="543" type="multinuc" parent="144" relname="cause"/>
		<group id="544" type="span" parent="545" relname="same-unit"/>
		<group id="545" type="multinuc" parent="543" relname="joint"/>
		<group id="546" type="span" parent="547" relname="contrast"/>
		<group id="547" type="multinuc" parent="549" relname="span"/>
		<group id="548" type="multinuc" parent="150" relname="elaboration"/>
		<group id="549" type="span" parent="550" relname="span"/>
		<group id="550" type="span" />
		<group id="551" type="span" parent="549" relname="evaluation"/>
		<group id="552" type="multinuc" parent="553" relname="sequence"/>
		<group id="553" type="multinuc" parent="822" relname="joint"/>
		<group id="554" type="span" parent="558" relname="sequence"/>
		<group id="556" type="multinuc" parent="558" relname="sequence"/>
		<group id="557" type="span" parent="556" relname="contrast"/>
		<group id="558" type="multinuc" parent="159" relname="elaboration"/>
		<group id="561" type="span" parent="562" relname="same-unit"/>
		<group id="562" type="multinuc" parent="167" relname="elaboration"/>
		<group id="563" type="span" parent="166" relname="elaboration"/>
		<group id="564" type="span" parent="586" relname="span"/>
		<group id="565" type="multinuc" parent="171" relname="elaboration"/>
		<group id="566" type="multinuc" parent="176" relname="cause"/>
		<group id="567" type="span" parent="177" relname="cause"/>
		<group id="568" type="span" parent="584" relname="span"/>
		<group id="569" type="multinuc" parent="180" relname="solutionhood"/>
		<group id="570" type="multinuc" parent="581" relname="elaboration"/>
		<group id="571" type="multinuc" parent="573" relname="span"/>
		<group id="573" type="span" parent="574" relname="span"/>
		<group id="574" type="span" parent="579" relname="contrast"/>
		<group id="575" type="multinuc" parent="577" relname="span"/>
		<group id="576" type="span" parent="579" relname="contrast"/>
		<group id="577" type="span" parent="576" relname="span"/>
		<group id="578" type="multinuc" parent="575" relname="sequence"/>
		<group id="579" type="multinuc" parent="593" relname="span"/>
		<group id="580" type="multinuc" parent="564" relname="preparation"/>
		<group id="581" type="span" parent="585" relname="span"/>
		<group id="582" type="span" parent="580" relname="sequence"/>
		<group id="583" type="span" parent="565" relname="contrast"/>
		<group id="584" type="span" parent="173" relname="evaluation"/>
		<group id="585" type="span" parent="593" relname="preparation"/>
		<group id="586" type="span" />
		<group id="587" type="span" parent="592" relname="span"/>
		<group id="588" type="span" parent="589" relname="same-unit"/>
		<group id="589" type="multinuc" parent="590" relname="contrast"/>
		<group id="590" type="multinuc" parent="595" relname="span"/>
		<group id="591" type="span" parent="587" relname="elaboration"/>
		<group id="592" type="span" parent="595" relname="solutionhood"/>
		<group id="593" type="span" parent="594" relname="span"/>
		<group id="594" type="span" />
		<group id="595" type="span" parent="596" relname="span"/>
		<group id="596" type="span" />
		<group id="597" type="span" parent="202" relname="cause"/>
		<group id="598" type="span" parent="199" relname="elaboration"/>
		<group id="599" type="span" parent="600" relname="joint"/>
		<group id="600" type="multinuc" parent="604" relname="sequence"/>
		<group id="601" type="span" parent="604" relname="sequence"/>
		<group id="602" type="span" parent="604" relname="sequence"/>
		<group id="603" type="span" parent="609" relname="preparation"/>
		<group id="604" type="multinuc" />
		<group id="605" type="span" parent="606" relname="same-unit"/>
		<group id="606" type="multinuc" parent="211" relname="evaluation"/>
		<group id="607" type="span" parent="609" relname="span"/>
		<group id="608" type="span" parent="210" relname="cause"/>
		<group id="609" type="span" parent="610" relname="span"/>
		<group id="610" type="span" />
		<group id="611" type="multinuc" parent="613" relname="joint"/>
		<group id="612" type="multinuc" parent="613" relname="joint"/>
		<group id="613" type="multinuc" parent="614" relname="contrast"/>
		<group id="614" type="multinuc" parent="220" relname="elaboration"/>
		<group id="615" type="span" parent="624" relname="span"/>
		<group id="616" type="span" parent="216" relname="evaluation"/>
		<group id="617" type="span" parent="219" relname="preparation"/>
		<group id="618" type="multinuc" parent="232" relname="cause"/>
		<group id="619" type="multinuc" parent="618" relname="joint"/>
		<group id="620" type="span" parent="621" relname="joint"/>
		<group id="621" type="multinuc" parent="622" relname="span"/>
		<group id="622" type="span" parent="623" relname="span"/>
		<group id="623" type="span" />
		<group id="624" type="span" parent="622" relname="background"/>
		<group id="625" type="span" parent="615" relname="evaluation"/>
		<group id="626" type="span" parent="235" relname="evaluation"/>
		<group id="627" type="span" parent="635" relname="span"/>
		<group id="628" type="multinuc" parent="637" relname="preparation"/>
		<group id="629" type="span" parent="627" relname="background"/>
		<group id="630" type="multinuc" parent="631" relname="span"/>
		<group id="631" type="span" parent="632" relname="span"/>
		<group id="632" type="span" parent="634" relname="comparison"/>
		<group id="633" type="span" parent="634" relname="comparison"/>
		<group id="634" type="multinuc" parent="637" relname="span"/>
		<group id="635" type="span" parent="628" relname="sequence"/>
		<group id="636" type="multinuc" parent="642" relname="preparation"/>
		<group id="637" type="span" parent="638" relname="span"/>
		<group id="638" type="span" />
		<group id="639" type="span" parent="642" relname="span"/>
		<group id="640" type="span" parent="654" relname="preparation"/>
		<group id="641" type="multinuc" parent="639" relname="elaboration"/>
		<group id="642" type="span" parent="643" relname="span"/>
		<group id="643" type="span" />
		<group id="644" type="multinuc" parent="645" relname="span"/>
		<group id="645" type="span" parent="646" relname="span"/>
		<group id="646" type="span" parent="647" relname="elaboration"/>
		<group id="647" type="span" parent="652" relname="span"/>
		<group id="648" type="multinuc" parent="660" relname="contrast"/>
		<group id="649" type="span" parent="260" relname="elaboration"/>
		<group id="650" type="span" parent="259" relname="elaboration"/>
		<group id="651" type="span" parent="653" relname="joint"/>
		<group id="652" type="span" parent="653" relname="joint"/>
		<group id="653" type="multinuc" parent="654" relname="span"/>
		<group id="654" type="span" parent="655" relname="span"/>
		<group id="655" type="span" />
		<group id="656" type="span" parent="659" relname="joint"/>
		<group id="657" type="span" parent="658" relname="same-unit"/>
		<group id="658" type="multinuc" parent="265" relname="elaboration"/>
		<group id="659" type="multinuc" parent="660" relname="contrast"/>
		<group id="660" type="multinuc" parent="663" relname="span"/>
		<group id="662" type="span" parent="261" relname="background"/>
		<group id="663" type="span" parent="662" relname="span"/>
		<group id="664" type="span" parent="653" relname="joint"/>
		<group id="665" type="multinuc" parent="676" relname="preparation"/>
		<group id="666" type="multinuc" parent="667" relname="evaluation"/>
		<group id="667" type="span" parent="668" relname="span"/>
		<group id="668" type="span" parent="670" relname="contrast"/>
		<group id="669" type="span" parent="671" relname="contrast"/>
		<group id="670" type="multinuc" parent="676" relname="span"/>
		<group id="671" type="multinuc" parent="670" relname="contrast"/>
		<group id="672" type="multinuc" parent="673" relname="span"/>
		<group id="673" type="span" parent="674" relname="span"/>
		<group id="674" type="span" />
		<group id="675" type="span" parent="673" relname="solutionhood"/>
		<group id="676" type="span" parent="675" relname="span"/>
		<group id="677" type="span" parent="678" relname="joint"/>
		<group id="678" type="multinuc" parent="684" relname="preparation"/>
		<group id="679" type="multinuc" parent="680" relname="contrast"/>
		<group id="680" type="multinuc" parent="288" relname="evaluation"/>
		<group id="681" type="span" parent="683" relname="span"/>
		<group id="682" type="span" parent="683" relname="evaluation"/>
		<group id="683" type="span" parent="684" relname="span"/>
		<group id="684" type="span" parent="687" relname="span"/>
		<group id="685" type="span" parent="294" relname="background"/>
		<group id="686" type="span" parent="295" relname="elaboration"/>
		<group id="687" type="span" />
		<group id="688" type="span" parent="689" relname="joint"/>
		<group id="689" type="multinuc" />
		<group id="690" type="multinuc" parent="697" relname="span"/>
		<group id="691" type="multinuc" parent="693" relname="comparison"/>
		<group id="692" type="multinuc" parent="695" relname="elaboration"/>
		<group id="693" type="multinuc" parent="695" relname="span"/>
		<group id="694" type="span" parent="690" relname="sequence"/>
		<group id="695" type="span" parent="696" relname="span"/>
		<group id="696" type="span" parent="301" relname="elaboration"/>
		<group id="697" type="span" parent="698" relname="span"/>
		<group id="698" type="span" />
		<group id="699" type="span" parent="701" relname="span"/>
		<group id="700" type="multinuc" parent="315" relname="solutionhood"/>
		<group id="701" type="span" parent="702" relname="span"/>
		<group id="702" type="span" />
		<group id="703" type="multinuc" parent="705" relname="span"/>
		<group id="704" type="span" />
		<group id="705" type="span" parent="704" relname="span"/>
		<group id="706" type="span" parent="705" relname="evaluation"/>
		<group id="707" type="span" parent="799" relname="preparation"/>
		<group id="708" type="span" parent="709" relname="span"/>
		<group id="709" type="span" parent="713" relname="span"/>
		<group id="710" type="multinuc" parent="328" relname="cause"/>
		<group id="711" type="span" parent="712" relname="contrast"/>
		<group id="712" type="multinuc" parent="713" relname="evaluation"/>
		<group id="713" type="span" parent="714" relname="span"/>
		<group id="714" type="span" parent="715" relname="span"/>
		<group id="715" type="span" />
		<group id="716" type="multinuc" parent="793" relname="joint"/>
		<group id="717" type="multinuc" parent="727" relname="span"/>
		<group id="718" type="span" parent="719" relname="cause"/>
		<group id="719" type="span" parent="720" relname="span"/>
		<group id="720" type="span" />
		<group id="721" type="span" parent="725" relname="span"/>
		<group id="722" type="multinuc" parent="721" relname="evaluation"/>
		<group id="723" type="span" parent="724" relname="contrast"/>
		<group id="724" type="multinuc" parent="725" relname="background"/>
		<group id="725" type="span" parent="726" relname="span"/>
		<group id="726" type="span" parent="727" relname="elaboration"/>
		<group id="727" type="span" parent="719" relname="span"/>
		<group id="728" type="multinuc" parent="806" relname="preparation"/>
		<group id="729" type="span" parent="728" relname="sequence"/>
		<group id="730" type="multinuc" parent="355" relname="cause"/>
		<group id="731" type="multinuc" parent="805" relname="elaboration"/>
		<group id="732" type="span" parent="731" relname="contrast"/>
		<group id="733" type="span" parent="731" relname="contrast"/>
		<group id="736" type="span" parent="808" relname="span"/>
		<group id="737" type="span" parent="739" relname="span"/>
		<group id="738" type="multinuc" parent="737" relname="background"/>
		<group id="739" type="span" parent="745" relname="preparation"/>
		<group id="740" type="span" parent="741" relname="solutionhood"/>
		<group id="741" type="span" parent="742" relname="span"/>
		<group id="742" type="span" parent="363" relname="elaboration"/>
		<group id="743" type="span" parent="744" relname="sequence"/>
		<group id="744" type="multinuc" parent="745" relname="span"/>
		<group id="745" type="span" parent="746" relname="span"/>
		<group id="746" type="span" />
		<group id="747" type="span" parent="370" relname="elaboration"/>
		<group id="748" type="span" parent="751" relname="span"/>
		<group id="749" type="multinuc" parent="757" relname="span"/>
		<group id="750" type="span" parent="373" relname="elaboration"/>
		<group id="751" type="span" parent="759" relname="span"/>
		<group id="752" type="span" parent="759" relname="preparation"/>
		<group id="753" type="span" parent="754" relname="same-unit"/>
		<group id="754" type="multinuc" parent="755" relname="joint"/>
		<group id="755" type="multinuc" parent="756" relname="contrast"/>
		<group id="756" type="multinuc" parent="749" relname="comparison"/>
		<group id="757" type="span" parent="748" relname="background"/>
		<group id="758" type="multinuc" parent="383" relname="elaboration"/>
		<group id="759" type="span" parent="761" relname="span"/>
		<group id="760" type="span" parent="751" relname="evaluation"/>
		<group id="761" type="span" />
		<group id="762" type="span" parent="768" relname="span"/>
		<group id="763" type="span" parent="390" relname="elaboration"/>
		<group id="764" type="span" parent="765" relname="sequence"/>
		<group id="765" type="multinuc" parent="769" relname="span"/>
		<group id="766" type="multinuc" parent="395" relname="elaboration"/>
		<group id="767" type="span" parent="765" relname="sequence"/>
		<group id="768" type="span" parent="769" relname="preparation"/>
		<group id="769" type="span" parent="770" relname="span"/>
		<group id="770" type="span" />
		<group id="771" type="multinuc" parent="774" relname="solutionhood"/>
		<group id="772" type="span" parent="402" relname="elaboration"/>
		<group id="773" type="span" parent="771" relname="contrast"/>
		<group id="774" type="span" parent="775" relname="span"/>
		<group id="775" type="span" parent="780" relname="span"/>
		<group id="776" type="multinuc" parent="779" relname="evaluation"/>
		<group id="777" type="span" parent="776" relname="sequence"/>
		<group id="778" type="span" parent="779" relname="span"/>
		<group id="779" type="span" parent="783" relname="span"/>
		<group id="780" type="span" parent="782" relname="sequence"/>
		<group id="781" type="span" />
		<group id="782" type="multinuc" parent="784" relname="span"/>
		<group id="783" type="span" parent="782" relname="sequence"/>
		<group id="784" type="span" parent="785" relname="span"/>
		<group id="785" type="span" />
		<group id="786" type="span" parent="80" relname="background"/>
		<group id="787" type="multinuc" parent="829" relname="contrast"/>
		<group id="788" type="span" parent="789" relname="span"/>
		<group id="789" type="span" />
		<group id="792" type="span" parent="701" relname="purpose"/>
		<group id="793" type="multinuc" parent="333" relname="elaboration"/>
		<group id="794" type="span" parent="795" relname="span"/>
		<group id="795" type="span" />
		<group id="796" type="span" parent="797" relname="span"/>
		<group id="797" type="span" />
		<group id="798" type="multinuc" parent="799" relname="span"/>
		<group id="799" type="span" parent="800" relname="span"/>
		<group id="800" type="span" parent="714" relname="preparation"/>
		<group id="801" type="span" parent="730" relname="joint"/>
		<group id="802" type="multinuc" parent="744" relname="sequence"/>
		<group id="803" type="span" parent="422" relname="preparation"/>
		<group id="804" type="span" parent="535" relname="span"/>
		<group id="805" type="span" parent="806" relname="span"/>
		<group id="806" type="span" parent="807" relname="span"/>
		<group id="807" type="span" parent="736" relname="solutionhood"/>
		<group id="808" type="span" />
		<group id="814" type="span" parent="815" relname="span"/>
		<group id="815" type="span" parent="816" relname="span"/>
		<group id="816" type="span" parent="494" relname="comparison"/>
		<group id="819" type="span" parent="157" relname="elaboration"/>
		<group id="821" type="span" parent="158" relname="background"/>
		<group id="822" type="multinuc" />
		<group id="823" type="span" parent="571" relname="sequence"/>
		<group id="826" type="span" parent="271" relname="elaboration"/>
		<group id="827" type="span" parent="710" relname="joint"/>
		<group id="829" type="multinuc" parent="100" relname="elaboration"/>
		<group id="830" type="span" parent="663" relname="evaluation"/>
		<group id="831" type="span" parent="822" relname="joint"/>
	</body>
</rst>