<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://t.me/chtobitchto/165</segment>
		<segment id="2" >Что bitch что?, [28.02.19 22:34]</segment>
		<segment id="3" parent="63" relname="span">Читаю срач между авторами приложения насилию.нет и разработчиками,</segment>
		<segment id="4" parent="62" relname="same-unit">которые сначала сделали эту приложуху,</segment>
		<segment id="5" parent="62" relname="same-unit">а потом для тех же целей вторую – певице Маниже.</segment>
		<segment id="6" parent="65" relname="attribution">Разработчики говорят,</segment>
		<segment id="7" parent="64" relname="contrast">что начинка другая,</segment>
		<segment id="8" parent="64" relname="contrast">но кто ж им поверит.</segment>
		<segment id="9" parent="67" relname="joint">Мол, инициатор не виноват,</segment>
		<segment id="10" parent="67" relname="joint">«она просто не знала»,</segment>
		<segment id="11" parent="68" relname="contrast">а негодяйские разработчики не сказали.</segment>
		<segment id="12" parent="125" relname="same-unit">Стоп,</segment>
		<segment id="13" parent="14" relname="background">но веткой комментов выше было сказано,</segment>
		<segment id="14" parent="124" relname="span">что насилию.нет использовался в качестве референса,</segment>
		<segment id="15" parent="70" relname="span">то есть знала.</segment>
		<segment id="16" parent="17" relname="condition">А даже если бы и нет,</segment>
		<segment id="17" parent="71" relname="span">это не задача исполнителя – устраивать ликбез по рынку.</segment>
		<segment id="18" parent="76" relname="joint">И я не могу врубиться – в стране, где декриминализовано домашнее насилие</segment>
		<segment id="19" parent="77" relname="span">и есть в принципе два приложения</segment>
		<segment id="20" parent="19" relname="purpose">для экстренной помощи,</segment>
		<segment id="21" parent="78" relname="same-unit">реально нужен этот срач?</segment>
		<segment id="22" parent="79" relname="purpose">Ну вот чтобы что?</segment>
		<segment id="23" parent="81" relname="span">Я понимаю,</segment>
		<segment id="24" parent="23" relname="condition">если бы там была встроенная монетизация,</segment>
		<segment id="25" parent="82" relname="contrast">но ее вроде как нет.</segment>
		<segment id="26" parent="27" relname="solutionhood">Кто выживет?</segment>
		<segment id="27" parent="120" relname="span">Самый удобный и популярный.</segment>
		<segment id="28" parent="123" relname="attribution">На семинарах для НКО сто раз уже повторили</segment>
		<segment id="29" parent="85" relname="contrast">«считайте не только деньги на разработку, но и на раскрутку, обслуживание, апдейты</segment>
		<segment id="30" parent="85" relname="contrast">– иначе загнётся все к чертовой матери».</segment>
		<segment id="31" parent="86" relname="span">Можно сходить на кладбище благотворительных мобильных приложений,</segment>
		<segment id="32" parent="31" relname="purpose">чтобы убедиться.</segment>
		<segment id="33" parent="89" relname="span">Да, многие люди с именем и деньгами прыгают в социальные вопросы,</segment>
		<segment id="34" parent="33" relname="evaluation">уже считая себя профессионалами.</segment>
		<segment id="35" parent="91" relname="span">И срать хотели на тех, кто годами работает в теме</segment>
		<segment id="36" parent="90" relname="span">– даже массовые сборы  «новогодних подарочков в детские дома» продолжают всплывать,</segment>
		<segment id="37" parent="36" relname="concession">хотя казалось бы.</segment>
		<segment id="38" parent="93" relname="span">Тут, наверное, однажды бы помог железобетонный авторитет НКО/профессионалов в конкретной теме,</segment>
		<segment id="39" parent="38" relname="condition">если бы он был.</segment>
		<segment id="40" parent="94" relname="span">Чтобы никто не сунулся,</segment>
		<segment id="41" parent="40" relname="condition">не спросив совета/не заручившись поддержкой.</segment>
		<segment id="42" parent="114" relname="span">Но откуда ему взяться,</segment>
		<segment id="43" parent="97" relname="joint">если «эти люди постоянно просят у нас денег»</segment>
		<segment id="44" parent="99" relname="restatement">или бомбардируют безнадёгой</segment>
		<segment id="45" parent="98" relname="contrast">(то есть как будто и давят,</segment>
		<segment id="46" parent="98" relname="contrast">и не справляются).</segment>
		<segment id="47" parent="104" relname="span">Экспертами воспринимаются те, кто «справляется».</segment>
		<segment id="48" parent="102" relname="span">Как правило, они работают в самых сложных темах,</segment>
		<segment id="49" parent="103" relname="contrast">на которые не найдёшь помощи,</segment>
		<segment id="50" parent="103" relname="contrast">иначе как находя доказательства успехов – хосписа, поиск пропавших.</segment>
		<segment id="51" parent="107" relname="span">Мне почему-то кажется, что и в работе с волонтерами, со сторонниками, у них много позитива.</segment>
		<segment id="52" parent="51" relname="elaboration">То есть не только коммуникация, но и личное мнение подкрепляет веру «эти –могут».</segment>
		<segment id="53" parent="106" relname="contrast">Ну и с приветом волонтерскому фандрайзингу – вместо комментов на тему копирования приложения,</segment>
		<segment id="54" parent="105" relname="span">не было бы эффективнее потратить это время,</segment>
		<segment id="55" parent="54" relname="purpose">чтобы помочь подруге научить подругу им пользоваться?</segment>
		<segment id="56" parent="109" relname="span">И так по цепочке.</segment>
		<segment id="57" parent="110" relname="joint">Хотя бы с благотворительного сектора начать.</segment>
		<segment id="58" parent="110" relname="joint">Или с флешмоба на очередной конференции по женскому лидерству.</segment>
		<segment id="59" parent="112" relname="contrast">Алиса хорошо написала вчера в фб – статистически, у каждого из нас есть знакомый (и угроза), столкнувшийся с ВИЧ или насилием, или онкологией, или психическими расстройствами, или алкогольной зависимостью.</segment>
		<segment id="60" parent="111" relname="span">Но обсуждаем ли мы «что делать»,</segment>
		<segment id="61" parent="60" relname="condition">если знаем, кто вообще-то может помочь?</segment>
		<group id="62" type="multinuc" parent="3" relname="elaboration"/>
		<group id="63" type="span" parent="74" relname="preparation"/>
		<group id="64" type="multinuc" parent="65" relname="span"/>
		<group id="65" type="span" parent="66" relname="span"/>
		<group id="66" type="span" parent="69" relname="span"/>
		<group id="67" type="multinuc" parent="68" relname="contrast"/>
		<group id="68" type="multinuc" parent="66" relname="elaboration"/>
		<group id="69" type="span" parent="73" relname="contrast"/>
		<group id="70" type="span" parent="72" relname="contrast"/>
		<group id="71" type="span" parent="72" relname="contrast"/>
		<group id="72" type="multinuc" parent="73" relname="contrast"/>
		<group id="73" type="multinuc" parent="74" relname="span"/>
		<group id="74" type="span" parent="75" relname="span"/>
		<group id="75" type="span" />
		<group id="76" type="multinuc" parent="78" relname="same-unit"/>
		<group id="77" type="span" parent="76" relname="joint"/>
		<group id="78" type="multinuc" parent="79" relname="span"/>
		<group id="79" type="span" parent="80" relname="span"/>
		<group id="80" type="span" parent="83" relname="solutionhood"/>
		<group id="81" type="span" parent="82" relname="contrast"/>
		<group id="82" type="multinuc" parent="83" relname="span"/>
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" parent="101" relname="joint"/>
		<group id="85" type="multinuc" parent="123" relname="span"/>
		<group id="86" type="span" parent="87" relname="evidence"/>
		<group id="87" type="span" parent="88" relname="span"/>
		<group id="88" type="span" parent="120" relname="evidence"/>
		<group id="89" type="span" parent="92" relname="joint"/>
		<group id="90" type="span" parent="35" relname="evidence"/>
		<group id="91" type="span" parent="92" relname="joint"/>
		<group id="92" type="multinuc" parent="95" relname="solutionhood"/>
		<group id="93" type="span" parent="95" relname="span"/>
		<group id="94" type="span" parent="93" relname="purpose"/>
		<group id="95" type="span" parent="115" relname="span"/>
		<group id="96" type="multinuc" parent="116" relname="solutionhood"/>
		<group id="97" type="multinuc" parent="42" relname="condition"/>
		<group id="98" type="multinuc" parent="99" relname="restatement"/>
		<group id="99" type="multinuc" parent="97" relname="joint"/>
		<group id="100" type="span" parent="96" relname="contrast"/>
		<group id="101" type="multinuc" />
		<group id="102" type="span" parent="47" relname="cause"/>
		<group id="103" type="multinuc" parent="48" relname="condition"/>
		<group id="104" type="span" parent="108" relname="span"/>
		<group id="105" type="span" parent="106" relname="contrast"/>
		<group id="106" type="multinuc" parent="119" relname="span"/>
		<group id="107" type="span" parent="104" relname="evaluation"/>
		<group id="108" type="span" parent="114" relname="elaboration"/>
		<group id="109" type="span" parent="113" relname="span"/>
		<group id="110" type="multinuc" parent="56" relname="elaboration"/>
		<group id="111" type="span" parent="112" relname="contrast"/>
		<group id="112" type="multinuc" parent="109" relname="elaboration"/>
		<group id="113" type="span" parent="119" relname="elaboration"/>
		<group id="114" type="span" parent="100" relname="span"/>
		<group id="115" type="span" parent="96" relname="contrast"/>
		<group id="116" type="span" parent="117" relname="span"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" />
		<group id="119" type="span" parent="116" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="101" relname="joint"/>
		<group id="123" type="span" parent="87" relname="span"/>
		<group id="124" type="span" parent="125" relname="same-unit"/>
		<group id="125" type="multinuc" parent="15" relname="cause"/>
	</body>
</rst>