<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://t.me/corpequities/281</segment>
		<segment id="2" >СЕЛЕБРИТИ В ЭТИЧЕСКИХ ТЕМАХ БРЕНДОВ: НАСКОЛЬКО УМЕСТНО ВОВЛЕЧЕНИЕ?</segment>
		<segment id="3" parent="105" relname="span">Казалось бы, пора уже маркетологам больших потребительских брендов понять, что их общественно-политическая повестка ничего по сути не приобретает</segment>
		<segment id="4" parent="104" relname="span">от платного привлечения селебрити,</segment>
		<segment id="5" parent="106" relname="span">в особенности если селебрити до этой повестки не «дозрели».</segment>
		<segment id="6" parent="107" relname="joint">(Сразу оговорюсь: никакого осуждения в адрес селебрити здесь нет</segment>
		<segment id="7" parent="107" relname="joint">и быть не может,</segment>
		<segment id="8" parent="113" relname="span">зрелость в данном случае предлагаю понимать исключительно как степень соответствия этической программы бренда привычному образу жизни и мышления привлеченной «звезды».</segment>
		<segment id="9" parent="112" relname="span">И вот тут у маркетологов беда:</segment>
		<segment id="10" parent="110" relname="cause">настолько имидж «лиц» рекламных кампаний расходится с их реальными жизненными принципами,</segment>
		<segment id="11" parent="109" relname="joint">что и поклонники «лиц» недоумевают,</segment>
		<segment id="12" parent="109" relname="joint">и последователи брендов конфузятся).</segment>
		<segment id="13" parent="116" relname="span">Припоминаю масштабнейший экологический марафон на берегах Байкала,</segment>
		<segment id="14" parent="115" relname="sequence">к участию в котором организаторы зачем-то привлекли многоуважаемую Елену #Летучую</segment>
		<segment id="15" parent="114" relname="span">(ещё до того, как её ангажировал #Ростех</segment>
		<segment id="16" parent="15" relname="purpose">для телевизионной кампании против мусорных свалок)</segment>
		<segment id="17" parent="118" relname="span">— и сначала нам показалось, что это прекрасная идея,</segment>
		<segment id="18" parent="117" relname="span">учитывая образ пламенного народного борца с показухой и косностью,</segment>
		<segment id="19" parent="18" relname="background">прочно за Еленой закрепившийся.</segment>
		<segment id="20" parent="133" relname="span">Казалось нам это ровно до того момента,</segment>
		<segment id="21" parent="120" relname="span">как мы услышали среди волонтеров,</segment>
		<segment id="22" parent="21" relname="elaboration">представлявших на марафоне десятки предприятий со всей страны,</segment>
		<segment id="23" parent="121" relname="same-unit">искреннее возмущение размером вознаграждения «звезды» и степенью детализации её технического райдера:</segment>
		<segment id="24" parent="122" relname="span">как оказалось, в нём заботливо перечислялись даже географические наименования вин,</segment>
		<segment id="25" parent="24" relname="elaboration">которые, понятное дело, на побережья Байкала пришлось специально доставлять из столицы.</segment>
		<segment id="26" parent="127" relname="span">Господь бы с ними, с требованиями к отелям и рационам</segment>
		<segment id="27" parent="125" relname="joint">(к ним прагматичные гении маркетинга давно привыкли,</segment>
		<segment id="28" parent="126" relname="contrast">как привыкли они и к тому, что коммерческая привязка имени селебрити к благому делу большого бренда снижает,</segment>
		<segment id="29" parent="126" relname="contrast">а отнюдь не повышает доверие к словам и действиям этих селебрити на период «ангажемента»).</segment>
		<segment id="30" parent="128" relname="contrast">Но сам факт, что за всё время проведения марафона Елена показалась участникам акции лишь раз (да и то с уютной сцены Иркутского областного драмтеатра,</segment>
		<segment id="31" parent="128" relname="contrast">а на берегах заповедного озера ребятам пришлось довольствоваться лишь её ощутимо скупым на смыслы видеообращением),</segment>
		<segment id="32" parent="129" relname="span">окончательно поставил под сомнение идею вовлекать в подобные акции тех, для кого самым ярким экологическим опытом остаются аккуратные напоминания о повторном использовании полотенец в 5-звёздных отелях.</segment>
		<segment id="33" parent="34" relname="cause">(Волонтёры у нас — на вес золота,</segment>
		<segment id="34" parent="130" relname="span">их веру в благое дело беречь надо.)</segment>
		<segment id="35" parent="36" relname="purpose">Диагностировать подобный диссонанс между большой заявкой на «спасение планеты» и реальным потребительским поведением предполагаемого «спасителя» — желательно на как можно более ранней стадии</segment>
		<segment id="36" parent="199" relname="span">— и есть задача маркетолога.</segment>
		<segment id="37" parent="136" relname="contrast">И она отнюдь не так невыполнима,</segment>
		<segment id="38" parent="136" relname="contrast">как может показаться,</segment>
		<segment id="39" parent="137" relname="cause">учитывая, что привилегированные «спасатели» с 5-звёздным мышлением, как правило, верны себе и в собственных проектах, в которые привлекают бренды в почётной роли «кошелька».</segment>
		<segment id="40" parent="139" relname="span">Так, например, бюджет на закрытое корпоративное мероприятие,</segment>
		<segment id="41" parent="40" relname="elaboration">посвященное запуску очередной партнёрской программы благотворительного фонда многоуважаемой Натальи #Водяновой,</segment>
		<segment id="42" parent="140" relname="same-unit">в отеле Hyatt на Неглинной оказался сопоставим со сметой этой самой программы, предусматривавшей строительство специализированных игровых площадок для детей с синдромом Дауна в ряде российских городов.</segment>
		<segment id="43" parent="44" relname="attribution">Райдер, предъявленный партнёру,</segment>
		<segment id="44" parent="202" relname="span">включал даже такие тонкости, как длина и толщина стеблей роз, предполагавшихся «звезде» в дар.</segment>
		<segment id="45" parent="142" relname="joint">Слава всевышнему, тонкости миновали внимание широкой общественности,</segment>
		<segment id="46" parent="143" relname="span">как миновала его и шокирующая деталь с церемонии открытия одной из таких площадок в Сибири,</segment>
		<segment id="47" parent="144" relname="span">которую сама модель сочла за лучшее не посещать:</segment>
		<segment id="48" parent="149" relname="span">на фоне новёхонькой площадки, оборудованной по последнему слову науки и техники, виднелось здание детского реабилитационного центра... с зияющей пустотой на месте крыши.</segment>
		<segment id="49" parent="145" relname="joint">Средств областного бюджета хватило, видимо, лишь на её демонтаж,</segment>
		<segment id="50" parent="145" relname="joint">на дворе стоял сентябрь,</segment>
		<segment id="51" parent="145" relname="joint">в Сибири стремительно холодало.</segment>
		<segment id="52" parent="147" relname="elaboration">Картинка навсегда осталась в памяти представителей организации-партнёра — местного трудового коллектива, который не то что к фонду, к своему руководству в этот момент утратил какое бы то ни было доверие.</segment>
		<segment id="53" parent="151" relname="contrast">Упрекая бренды в алчном стремлении «купить их аудиторию»,</segment>
		<segment id="54" parent="152" relname="contrast">блогеры как бы претендуют на то, что они этой самой аудиторией успешно торгуют.</segment>
		<segment id="55" parent="152" relname="contrast">Но торговать вниманием — отнюдь не то, что торговать доверием.</segment>
		<segment id="56" parent="153" relname="span">Бренд средств</segment>
		<segment id="57" parent="56" relname="purpose">для ухода за волосами</segment>
		<segment id="58" parent="155" relname="same-unit">#HeadandShoulders вложил свою экологическую позицию в уста #Басты</segment>
		<segment id="59" parent="156" relname="span">— и вот мы уже наблюдаем, как половина комментаторов у крутого российского рэпера в Инстаграме задаются вопросом,</segment>
		<segment id="60" parent="154" relname="span">насколько такая позиция ему свойственна по жизни</segment>
		<segment id="61" parent="60" relname="evaluation">(с лейтмотивом «почём нонче экологическая сознательность»),</segment>
		<segment id="62" parent="157" relname="comparison">в то время как другая половина просто сомневается в том, что артист в принципе имеет что-то общее с этим замечательным продуктом.</segment>
		<segment id="63" parent="198" relname="span">Сомнения аудитории в принципиальности «звёзд» здесь — отражение их чрезмерной универсальности, всеядности, граничащей с беспринципностью</segment>
		<segment id="64" parent="197" relname="contrast">(«Какая разница, что продвигать и зачем?</segment>
		<segment id="65" parent="197" relname="contrast">Главное — почём»).</segment>
		<segment id="66" parent="161" relname="span">Универсальность Ольги #Бузовой,</segment>
		<segment id="67" parent="66" relname="evaluation">уже ставшей в мире потребительских товаров синонимом пусть и не обременённой глубоким смыслом, но молниеносной реанимации любого, даже самого «мёртвого» бренда,</segment>
		<segment id="68" parent="162" relname="same-unit">стала своего рода мотто российской выборки «золотоносцев» #EffieAwards этого года.</segment>
		<segment id="69" parent="167" relname="condition">Однако если в торговых промо такое «хирургическое» вмешательство оправдано,</segment>
		<segment id="70" parent="163" relname="span">то в кампаниях,</segment>
		<segment id="71" parent="70" relname="purpose">рассчитанных на популяризацию большой философии бренда,</segment>
		<segment id="72" parent="164" relname="same-unit">— как минимум бессмысленно,</segment>
		<segment id="73" parent="166" relname="span">а как максимум — вредно,</segment>
		<segment id="74" parent="73" relname="cause">ибо философию эту напрочь обесценивает.</segment>
		<segment id="75" parent="172" relname="joint">В очередной (давно уже не первый) раз договорились сегодня о том, что прежде, чем спасать мир</segment>
		<segment id="76" parent="172" relname="joint">и «причинять добро»,</segment>
		<segment id="77" parent="173" relname="contrast">брендам не мешало бы озаботиться решением самых неудобных вопросов, связанных с их собственным существованием.</segment>
		<segment id="78" parent="174" relname="joint">У одних — это непрозрачная тарифная политика,</segment>
		<segment id="79" parent="174" relname="joint">у других — нездоровая рецептура,</segment>
		<segment id="80" parent="174" relname="joint">у третьих — заведомо неперерабатываемая упаковка,</segment>
		<segment id="81" parent="174" relname="joint">у четвёртых — да мало ли что ещё.</segment>
		<segment id="82" parent="83" relname="condition">Когда слышу, как коллеги по репутационному менеджменту делятся наболевшим на редких закрытых встречах,</segment>
		<segment id="83" parent="175" relname="span">думаю, что трудно найти бренд (окей, продукт или услугу) без своего скелета в шкафу.</segment>
		<segment id="84" parent="176" relname="restatement">Главная задача репутационщика</segment>
		<segment id="85" parent="176" relname="restatement">(на конференции #Коммерсанта #КСО2019 нас сегодня зачем-то назвали «пиарщиками»)</segment>
		<segment id="86" parent="177" relname="same-unit">— не спасовать</segment>
		<segment id="87" parent="178" relname="joint">и убедить бизнес в необходимости с дорогими сердцу скелетами прощаться,</segment>
		<segment id="88" parent="178" relname="joint">рецептуру и упаковку менять,</segment>
		<segment id="89" parent="178" relname="joint">тарифную политику делать прозрачной,</segment>
		<segment id="90" parent="178" relname="joint">а «да мало ли что ещё» откровенно обсуждать с уважаемыми общественными экспертами.</segment>
		<segment id="91" parent="182" relname="span">Именно таким путём часто идут новички типа #Тинькова в российском банковском секторе или #Улюкайи в американском секторе йогуртов,</segment>
		<segment id="92" parent="181" relname="joint">делая все так, как «никем не делается»,</segment>
		<segment id="93" parent="181" relname="joint">подрывая устоявшиеся отраслевые модели и</segment>
		<segment id="94" parent="95" relname="evaluation">без какого-либо стеснения</segment>
		<segment id="95" parent="180" relname="span">поражая лидеров рынка в их самые больные места.</segment>
		<segment id="96" parent="183" relname="span">Вот тогда-то и лидерам рынка, взыскующих общественного признания и одобрения, и некоммерческому сектору,</segment>
		<segment id="97" parent="96" relname="elaboration">требующему спасать мир «здесь и сейчас»</segment>
		<segment id="98" parent="183" relname="elaboration">(и вообще редко интересующемуся реальными скелетами в шкафах своих привычных доноров),</segment>
		<segment id="99" parent="185" relname="same-unit">становится ясно, что попытки спешить «причинять добро»</segment>
		<segment id="100" parent="186" relname="joint">и спасать страждущих за периметром бизнеса,</segment>
		<segment id="101" parent="187" relname="condition">если бизнес сам по себе давно требует «хирургического» вмешательства,</segment>
		<segment id="102" parent="204" relname="contrast">— свидетельствуют скорее об отсутствии долгосрочной стратегии развития бизнеса и мужества это признать у его руководства,</segment>
		<segment id="103" parent="204" relname="contrast">нежели о высокой социальной ответственности такого бизнеса.</segment>
		<group id="104" type="span" parent="3" relname="condition"/>
		<group id="105" type="span" />
		<group id="106" type="span" parent="4" relname="condition"/>
		<group id="107" type="multinuc" parent="108" relname="contrast"/>
		<group id="108" type="multinuc" parent="5" relname="elaboration"/>
		<group id="109" type="multinuc" parent="110" relname="span"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="9" relname="elaboration"/>
		<group id="112" type="span" parent="8" relname="elaboration"/>
		<group id="113" type="span" parent="108" relname="contrast"/>
		<group id="114" type="span" parent="115" relname="sequence"/>
		<group id="115" type="multinuc" parent="13" relname="elaboration"/>
		<group id="116" type="span" parent="119" relname="span"/>
		<group id="117" type="span" parent="17" relname="condition"/>
		<group id="118" type="span" parent="116" relname="evaluation"/>
		<group id="119" type="span" parent="134" relname="sequence"/>
		<group id="120" type="span" parent="121" relname="same-unit"/>
		<group id="121" type="multinuc" parent="123" relname="span"/>
		<group id="122" type="span" parent="123" relname="cause"/>
		<group id="123" type="span" parent="124" relname="span"/>
		<group id="124" type="span" parent="20" relname="elaboration"/>
		<group id="125" type="multinuc" parent="26" relname="elaboration"/>
		<group id="126" type="multinuc" parent="125" relname="joint"/>
		<group id="127" type="span" parent="132" relname="contrast"/>
		<group id="128" type="multinuc" parent="32" relname="cause"/>
		<group id="129" type="span" parent="131" relname="span"/>
		<group id="130" type="span" parent="129" relname="elaboration"/>
		<group id="131" type="span" parent="132" relname="contrast"/>
		<group id="132" type="multinuc" parent="133" relname="evaluation"/>
		<group id="133" type="span" parent="135" relname="span"/>
		<group id="134" type="multinuc" />
		<group id="135" type="span" parent="134" relname="sequence"/>
		<group id="136" type="multinuc" parent="137" relname="span"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="199" relname="evaluation"/>
		<group id="139" type="span" parent="140" relname="same-unit"/>
		<group id="140" type="multinuc" parent="141" relname="span"/>
		<group id="141" type="span" parent="146" relname="span"/>
		<group id="142" type="multinuc" parent="150" relname="contrast"/>
		<group id="143" type="span" parent="142" relname="joint"/>
		<group id="144" type="span" parent="46" relname="elaboration"/>
		<group id="145" type="multinuc" parent="147" relname="span"/>
		<group id="146" type="span" parent="150" relname="contrast"/>
		<group id="147" type="span" parent="148" relname="span"/>
		<group id="148" type="span" parent="48" relname="elaboration"/>
		<group id="149" type="span" parent="47" relname="elaboration"/>
		<group id="150" type="multinuc" parent="200" relname="evidence"/>
		<group id="151" type="multinuc" parent="159" relname="preparation"/>
		<group id="152" type="multinuc" parent="151" relname="contrast"/>
		<group id="153" type="span" parent="155" relname="same-unit"/>
		<group id="154" type="span" parent="59" relname="elaboration"/>
		<group id="155" type="multinuc" parent="158" relname="cause"/>
		<group id="156" type="span" parent="157" relname="comparison"/>
		<group id="157" type="multinuc" parent="158" relname="span"/>
		<group id="158" type="span" parent="159" relname="span"/>
		<group id="159" type="span" parent="160" relname="span"/>
		<group id="160" type="span" />
		<group id="161" type="span" parent="162" relname="same-unit"/>
		<group id="162" type="multinuc" parent="169" relname="contrast"/>
		<group id="163" type="span" parent="164" relname="same-unit"/>
		<group id="164" type="multinuc" parent="165" relname="joint"/>
		<group id="165" type="multinuc" parent="167" relname="span"/>
		<group id="166" type="span" parent="165" relname="joint"/>
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="169" relname="contrast"/>
		<group id="169" type="multinuc" parent="170" relname="span"/>
		<group id="170" type="span" parent="171" relname="span"/>
		<group id="171" type="span" />
		<group id="172" type="multinuc" parent="173" relname="contrast"/>
		<group id="173" type="multinuc" parent="195" relname="preparation"/>
		<group id="174" type="multinuc" parent="192" relname="span"/>
		<group id="175" type="span" parent="179" relname="span"/>
		<group id="176" type="multinuc" parent="177" relname="same-unit"/>
		<group id="177" type="multinuc" parent="178" relname="joint"/>
		<group id="178" type="multinuc" parent="191" relname="span"/>
		<group id="179" type="span" parent="192" relname="elaboration"/>
		<group id="180" type="span" parent="181" relname="joint"/>
		<group id="181" type="multinuc" parent="91" relname="evaluation"/>
		<group id="182" type="span" parent="191" relname="elaboration"/>
		<group id="183" type="span" parent="184" relname="span"/>
		<group id="184" type="span" parent="185" relname="same-unit"/>
		<group id="185" type="multinuc" parent="186" relname="joint"/>
		<group id="186" type="multinuc" parent="187" relname="span"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" parent="205" relname="evidence"/>
		<group id="190" type="span" parent="194" relname="span"/>
		<group id="191" type="span" parent="190" relname="span"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" parent="194" relname="solutionhood"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" parent="196" relname="span"/>
		<group id="196" type="span" />
		<group id="197" type="multinuc" parent="63" relname="elaboration"/>
		<group id="198" type="span" parent="170" relname="preparation"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" />
		<group id="202" type="span" parent="141" relname="elaboration"/>
		<group id="203" type="span" parent="190" relname="evaluation"/>
		<group id="204" type="multinuc" parent="205" relname="span"/>
		<group id="205" type="span" parent="203" relname="span"/>
	</body>
</rst>