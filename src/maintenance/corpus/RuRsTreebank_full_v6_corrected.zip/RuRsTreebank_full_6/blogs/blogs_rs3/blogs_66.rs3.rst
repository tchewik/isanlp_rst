<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://miumau.livejournal.com/3029993.html</segment>
		<segment id="2" >А вот еще - про страхи</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="515" relname="span">Еще историю вспомнили, про профессионального спортсмена</segment>
		<segment id="5" parent="4" relname="elaboration">(он был с М. в одной команде по пляжному воллейболу в свое время),</segment>
		<segment id="6" parent="257" relname="same-unit">который получил травму позвоночника.</segment>
		<segment id="7" parent="8" relname="evaluation">Ему несказанно повезло:</segment>
		<segment id="8" parent="258" relname="span">он сначала совсем не чувствовал своих ног.</segment>
		<segment id="9" parent="259" relname="span">Но потом выяснилось, что у него всего лишь был тяжелый отек,</segment>
		<segment id="10" parent="9" relname="elaboration">который давил на нерв,</segment>
		<segment id="11" parent="12" relname="cause">и когда он рассосался,</segment>
		<segment id="12" parent="260" relname="span">все потихоньку вернулось на свои места.</segment>
		<segment id="13" parent="262" relname="joint">Т.е. все нервы оказались целы,</segment>
		<segment id="14" parent="262" relname="joint">паралич был только временным.</segment>
		<segment id="15" parent="275" relname="span">Тем не менее - между делом произошла еще одна страшная история.</segment>
		<segment id="16" parent="266" relname="span">Сначала он очень испугался,</segment>
		<segment id="17" parent="16" relname="cause">что никогда больше не сможет ходить.</segment>
		<segment id="18" parent="267" relname="joint">Потом ощущения начали возвращаться,</segment>
		<segment id="19" parent="20" relname="attribution">и врачи объяснили,</segment>
		<segment id="20" parent="491" relname="span">что кажется ему повезло.</segment>
		<segment id="21" parent="268" relname="joint">И теперь нужно ждать заживления,</segment>
		<segment id="22" parent="268" relname="joint">и готовиться к серьезной реабилитации.</segment>
		<segment id="23" parent="492" relname="cause">Хотели подбодрить парня,</segment>
		<segment id="24" parent="25" relname="attribution">и сказали,</segment>
		<segment id="25" parent="492" relname="span">что в таких случаях успех реабилитации зависит от энтузиазма пациента.</segment>
		<segment id="26" parent="274" relname="contrast">Это так и есть.</segment>
		<segment id="27" parent="273" relname="span">Но некоторые в 22 года такие боевые,</segment>
		<segment id="28" parent="272" relname="contrast">что их скорее нужно тормозить,</segment>
		<segment id="29" parent="272" relname="contrast">нежели подгонять.</segment>
		<segment id="30" parent="31" relname="cause">Он рвался из своего кресла с такой страшной силой,</segment>
		<segment id="31" parent="277" relname="span">что удержать было невозможно.</segment>
		<segment id="32" parent="278" relname="joint">Хотел пробовать вставать,</segment>
		<segment id="33" parent="278" relname="joint">делать шаги, еще и еще.</segment>
		<segment id="34" parent="497" relname="attribution">Ему говорили</segment>
		<segment id="35" parent="497" relname="span">- осторожно,</segment>
		<segment id="36" parent="279" relname="joint">у тебя пока мало сил в ногах,</segment>
		<segment id="37" parent="279" relname="joint">не горячись,</segment>
		<segment id="38" parent="279" relname="joint">отдохни.</segment>
		<segment id="39" parent="40" relname="attribution">Но он был уверен,</segment>
		<segment id="40" parent="505" relname="span">что "больше-лучше"</segment>
		<segment id="41" parent="281" relname="contrast">и рвался в бой.</segment>
		<segment id="42" parent="480" relname="same-unit">Поэтому</segment>
		<segment id="43" parent="44" relname="condition">при второй или третьей попытке походить</segment>
		<segment id="44" parent="479" relname="span">вырвался из рук терапевтов,</segment>
		<segment id="45" parent="282" relname="joint">и бросился шагать вперед.</segment>
		<segment id="46" parent="283" relname="joint">Естественно через пару шагов упал</segment>
		<segment id="47" parent="283" relname="joint">и сломал ногу.</segment>
		<segment id="48" parent="297" relname="span">На этом все стало снова хуже.</segment>
		<segment id="49" parent="50" relname="cause">Во-первых - теперь пришлось загипсовать ногу,</segment>
		<segment id="50" parent="287" relname="span">что сильно помешало любым попыткам мобилизовать пациента.</segment>
		<segment id="51" parent="287" relname="elaboration">Он и так не особо хорошо стоял на ногах, а теперь, с гипсом.</segment>
		<segment id="52" parent="295" relname="span">Во-вторых - его очень испугало само падение.</segment>
		<segment id="53" parent="54" relname="cause">Т.к. чувствительность еще не совсем вернулась к нему,</segment>
		<segment id="54" parent="289" relname="span">его поразила вот эта неспособность контролировать свое тело.</segment>
		<segment id="55" parent="291" relname="joint">Он летел в пол,</segment>
		<segment id="56" parent="290" relname="span">и не смог даже как-то сгруппироваться,</segment>
		<segment id="57" parent="56" relname="purpose">чтобы упасть получше.</segment>
		<segment id="58" parent="292" relname="span">А ведь он был научен падать в любых направлениях, много раз в день,</segment>
		<segment id="59" parent="58" relname="evaluation">и все ему было ни по чем.</segment>
		<segment id="60" parent="305" relname="preparation">В итоге после этого переживания у парня надолго включился вообще страх встать на ноги.</segment>
		<segment id="61" parent="298" relname="joint">Он не хотел вставать,</segment>
		<segment id="62" parent="298" relname="joint">очень боялся.</segment>
		<segment id="63" parent="64" relname="cause">Потом его ставили на ноги,</segment>
		<segment id="64" parent="299" relname="span">и он боялся сделать шаг.</segment>
		<segment id="65" parent="66" relname="cause">Ему казалось, что сейчас опять все выйдет из под контроля,</segment>
		<segment id="66" parent="300" relname="span">и он полетит.</segment>
		<segment id="67" parent="68" relname="cause">И еще думалось, что полетит он не известно куда,</segment>
		<segment id="68" parent="301" relname="span">и ничего не сможет с этим делать.</segment>
		<segment id="69" parent="305" relname="span">Так врезалось в память страшное ощущение неконтролируемого полета.</segment>
		<segment id="70" parent="313" relname="span">С этим страхом они птом боролись еще очень долго.</segment>
		<segment id="71" parent="307" relname="joint">С трудом уговорили стоять</segment>
		<segment id="72" parent="307" relname="joint">и шагать,</segment>
		<segment id="73" parent="74" relname="condition">а потом, когда он практически уже все мог,</segment>
		<segment id="74" parent="308" relname="span">он не мог вернуться ни к каким спортивным занятиям,</segment>
		<segment id="75" parent="310" relname="span">потому что все ему было страшно</segment>
		<segment id="76" parent="309" relname="joint">- и подпрыгнуть,</segment>
		<segment id="77" parent="309" relname="joint">и на одной ноге попробовать стоять.</segment>
		<segment id="78" parent="316" relname="span">Вот как бывает</segment>
		<segment id="79" parent="315" relname="contrast">- такой спортивный человек, с таким огромным опытом работы со своим телом -</segment>
		<segment id="80" parent="315" relname="contrast">и так его переклинило.</segment>
		<segment id="81" parent="484" relname="attribution">М. говорит,</segment>
		<segment id="82" parent="484" relname="span">что это все от потери контроля.</segment>
		<segment id="83" parent="318" relname="contrast">Он привык так хорошо владеть своим телом.</segment>
		<segment id="84" parent="317" relname="joint">А тут оно как быдто обрело собственное сознание</segment>
		<segment id="85" parent="317" relname="joint">и не слушается.</segment>
		<segment id="86" parent="319" relname="evaluation">Страшно.</segment>
		<segment id="87" parent="323" relname="span">В связи с этим вспомнился фильм про советских олимпийских гимнасток, получивших тяжелые травмы.</segment>
		<segment id="88" parent="87" relname="evaluation">(Страшный был фильм, кстати.)</segment>
		<segment id="89" parent="90" relname="attribution">Они рассказывали,</segment>
		<segment id="90" parent="499" relname="span">что на самом деле они все чего-то боялись.</segment>
		<segment id="91" parent="325" relname="joint">У каждой был какой-то свой страх,</segment>
		<segment id="92" parent="471" relname="span">и страхи эти естественно появились не без причины.</segment>
		<segment id="93" parent="327" relname="joint">Где больше всего больно падал</segment>
		<segment id="94" parent="327" relname="joint">и расшибался,</segment>
		<segment id="95" parent="328" relname="span">того и боишься.</segment>
		<segment id="96" parent="97" relname="cause">Кто-то брусьев боялся как огня,</segment>
		<segment id="97" parent="329" relname="span">прямо каждый раз подойти не могли,</segment>
		<segment id="98" parent="330" relname="joint">кто турника,</segment>
		<segment id="99" parent="330" relname="joint">кто прыгать.</segment>
		<segment id="100" parent="504" relname="attribution">И они рассказывали,</segment>
		<segment id="101" parent="334" relname="same-unit">что тренеры каждый раз,</segment>
		<segment id="102" parent="502" relname="condition">заметив, что кто-то в очередной раз сильно ушибся,</segment>
		<segment id="103" parent="333" relname="joint">немедленно ставили их туда же,</segment>
		<segment id="104" parent="333" relname="joint">заставляли повторить то же самое.</segment>
		<segment id="105" parent="335" relname="joint">Вот увидели, что она в приницпе ничего не сломала</segment>
		<segment id="106" parent="335" relname="joint">и ходить может</segment>
		<segment id="107" parent="336" relname="span">- и сразу снова туда.</segment>
		<segment id="108" parent="337" relname="span">Якобы это был их метод борьбы со страхом</segment>
		<segment id="109" parent="108" relname="elaboration">- не дать подумать.</segment>
		<segment id="110" parent="111" relname="condition">Они знали, что как только окончательно включится разум,</segment>
		<segment id="111" parent="339" relname="span">их туда больше не загонишь.</segment>
		<segment id="112" parent="340" relname="span">Поэтому гнали немедленно повторить трюк,</segment>
		<segment id="113" parent="112" relname="purpose">чтобы продемонстрировать мозгу, что можно сделать то же движение удачно.</segment>
		<segment id="114" parent="341" relname="span">Во второй раз обычно никто уже не падал,</segment>
		<segment id="115" parent="114" relname="cause">потому что после такого тяжелого переживания следующее повторение все делали особо осторожно.</segment>
		<segment id="116" parent="343" relname="span">И таким образом мозг обучали, что вот, смотри, это возможно сделать и без трагедии.</segment>
		<segment id="117" parent="342" relname="span">В принципе очень хитрый прием.</segment>
		<segment id="118" parent="117" relname="evaluation">Хоть и жестокий.</segment>
		<segment id="119" parent="506" relname="attribution">И вот одна из них рассказала,</segment>
		<segment id="120" parent="350" relname="joint">как она получила тяжелую травму</segment>
		<segment id="121" parent="350" relname="joint">и пыталаьс вернуться на тренировки.</segment>
		<segment id="122" parent="351" relname="span">И вернулась</segment>
		<segment id="123" parent="122" relname="elaboration">- феноменальный случай, когда после такой катастрофы получилось полностью реабилитироваться.</segment>
		<segment id="124" parent="353" relname="span">Через полтора года после того, как она сломала шею</segment>
		<segment id="125" parent="124" relname="elaboration">(и ее завиксировали титановыми креплениями)</segment>
		<segment id="126" parent="354" relname="joint">она получила от врачей разрешение готовиться к олимпиаде,</segment>
		<segment id="127" parent="354" relname="joint">тренироваться в полную силу.</segment>
		<segment id="128" parent="357" relname="contrast">Но она отказалась</segment>
		<segment id="129" parent="357" relname="contrast">и бросила спорт.</segment>
		<segment id="130" parent="358" relname="cause">Потому что победил страх.</segment>
		<segment id="131" parent="508" relname="attribution">Она сказала,</segment>
		<segment id="132" parent="508" relname="span">что все сломалось,</segment>
		<segment id="133" parent="132" relname="condition">когда тренер начала ее щадить.</segment>
		<segment id="134" parent="362" relname="contrast">Она вернулась к тренировкам,</segment>
		<segment id="135" parent="362" relname="contrast">но была нездорова.</segment>
		<segment id="136" parent="364" relname="cause">Тренер не могла понять, насколько у нее что болит,</segment>
		<segment id="137" parent="363" relname="joint">и когда она отползала в сторонку,</segment>
		<segment id="138" parent="363" relname="joint">посидеть,</segment>
		<segment id="139" parent="363" relname="joint">передохнуть,</segment>
		<segment id="140" parent="364" relname="span">она ее не трогала.</segment>
		<segment id="141" parent="369" relname="span">И вот тогда она прямо чувствовала, как подкрадывается страх</segment>
		<segment id="142" parent="143" relname="condition">- чем дольше сидишь,</segment>
		<segment id="143" parent="473" relname="span">тем страшнее.</segment>
		<segment id="144" parent="486" relname="attribution">Она сама говорила:</segment>
		<segment id="145" parent="370" relname="joint">"Если бы тренер меня сразу снова ставила на ноги,</segment>
		<segment id="146" parent="370" relname="joint">и не дала бы мне столько времени прислушиваться к своим чувствам,</segment>
		<segment id="147" parent="371" relname="span">может быть страх не успел бы меня съесть.</segment>
		<segment id="148" parent="149" relname="cause">А так его становилось все больше и больше,</segment>
		<segment id="149" parent="372" relname="span">пока я не поняла, что не могу больше вообще."</segment>
		<segment id="150" parent="380" relname="span">На самом деле в этом случае страх ведь был прав!</segment>
		<segment id="151" parent="378" relname="cause">Она уже шею сломала,</segment>
		<segment id="152" parent="378" relname="span">и весь ее разум пытался защитить ее от повторения такой трагедии</segment>
		<segment id="153" parent="154" relname="condition">(очевидно, что упади она еще раз вот так,</segment>
		<segment id="154" parent="377" relname="span">никто бы ее на ноги уде не поставил).</segment>
		<segment id="155" parent="156" relname="cause">И инстинкты тела победили,</segment>
		<segment id="156" parent="381" relname="span">она бросила спорт.</segment>
		<segment id="157" parent="383" relname="evaluation">И видимо сберегла этим остатки здоровья.</segment>
		<segment id="158" parent="386" relname="span">Но вот интересно раздумывать об этом</segment>
		<segment id="159" parent="385" relname="span">- как нас может сжирать страх,</segment>
		<segment id="160" parent="159" relname="cause">стоит миру как-то пошатнуться.</segment>
		<segment id="161" parent="474" relname="contrast">Я - совсем не спортсменка,</segment>
		<segment id="162" parent="391" relname="span">просто немного двигаюсь</segment>
		<segment id="163" parent="162" relname="purpose">для собственного развлечения.</segment>
		<segment id="164" parent="388" relname="cause">И когда только начала жить со своим искривленным зрением,</segment>
		<segment id="165" parent="166" relname="cause">насколько раз из-за какого-то движения, или потому что что-то резко появилось в поле зрения,</segment>
		<segment id="166" parent="388" relname="span">просто падала.</segment>
		<segment id="167" parent="392" relname="sequence">Меня заносило,</segment>
		<segment id="168" parent="392" relname="sequence">и в следующий момент я понимала, что не могу уже удержаться в вертикальном положении,</segment>
		<segment id="169" parent="392" relname="sequence">перевалила за критическую точку,</segment>
		<segment id="170" parent="392" relname="sequence">и лечу к полу.</segment>
		<segment id="171" parent="396" relname="span">Падения среди супермаркета меня как-то совсем не испугали</segment>
		<segment id="172" parent="395" relname="joint">- ну, лечу,</segment>
		<segment id="173" parent="395" relname="joint">даже еще ухватилась за что-то.</segment>
		<segment id="174" parent="397" relname="sequence">Не успела долететь до пола,</segment>
		<segment id="175" parent="475" relname="span">как акие-то люди подбежали,</segment>
		<segment id="176" parent="175" relname="purpose">помогли встать.</segment>
		<segment id="177" parent="400" relname="joint">В принципе люди и в обмороки иногда падают, например летом в жару.</segment>
		<segment id="178" parent="400" relname="joint">И ничего. Через минуту проходит.</segment>
		<segment id="179" parent="512" relname="evaluation">Радостно заметила,</segment>
		<segment id="180" parent="402" relname="joint">что ничего не сломала</segment>
		<segment id="181" parent="402" relname="joint">и не свернула - ура.</segment>
		<segment id="182" parent="183" relname="cause">А вот когда я единственный раз навернулась так в зале, полном танцующих людей,</segment>
		<segment id="183" parent="405" relname="span">я очень испугалась.</segment>
		<segment id="184" parent="406" relname="joint">И Не только потому, что все в движении,</segment>
		<segment id="185" parent="406" relname="joint">и я не хотела никого сбить с ног.</segment>
		<segment id="186" parent="409" relname="span">(На самом деле я невероятно удачно упала,</segment>
		<segment id="187" parent="407" relname="joint">никто даже не остановился сначала,</segment>
		<segment id="188" parent="407" relname="joint">я никому не попала под ноги,</segment>
		<segment id="189" parent="407" relname="joint">и очень удачно выкатилась к ближайшему столбу, рядом с которым никого не было.)</segment>
		<segment id="190" parent="412" relname="contrast">Но все равно я очень испугалась.</segment>
		<segment id="191" parent="416" relname="span">Там много всяких факторов было.</segment>
		<segment id="192" parent="413" relname="span">Например я начала думать, что меня могут и перестать туда пускать вообще,</segment>
		<segment id="193" parent="192" relname="condition">если подумают, что такое может повторится</segment>
		<segment id="194" parent="413" relname="cause">- это же опасность для других людей.</segment>
		<segment id="195" parent="414" relname="joint">И вообще - там все в движении,</segment>
		<segment id="196" parent="414" relname="joint">и не знаешь, случится ли это еще раз, и когда, и как.</segment>
		<segment id="197" parent="425" relname="span">К счастью это никогда больше не повторилось в зале.</segment>
		<segment id="198" parent="418" relname="joint">Я все лучше выучивала, что сбивает меня с толку,</segment>
		<segment id="199" parent="417" relname="span">и предпочитаю просто пропустить какой-то поворот,</segment>
		<segment id="200" parent="199" relname="condition">если не уверена.</segment>
		<segment id="201" parent="419" relname="span">Научилась находить себе места в зале,</segment>
		<segment id="202" parent="201" relname="elaboration">где никто просто так не вбегает в мое поле зрения.</segment>
		<segment id="203" parent="422" relname="joint">Ну и сказала честно всем, в чем проблема.</segment>
		<segment id="204" parent="423" relname="span">И они знают, почему я себе выбираю некое место,</segment>
		<segment id="205" parent="420" relname="span">где я в крайнем случае и не помешаю никому,</segment>
		<segment id="206" parent="205" relname="condition">если упаду,</segment>
		<segment id="207" parent="421" relname="joint">и где никто не "маячит" у меня перед глазами.</segment>
		<segment id="208" parent="428" relname="span">Но я тоже помню этот срах.</segment>
		<segment id="209" parent="210" relname="condition">Когда заходишь в зал,</segment>
		<segment id="210" parent="426" relname="span">начинает рубить супер громкая музыка,</segment>
		<segment id="211" parent="427" relname="joint">часто еще включают светомузыку,</segment>
		<segment id="212" parent="427" relname="joint">и 20-70 человек вокруг начинают очень быстро плясать.</segment>
		<segment id="213" parent="430" relname="span">В первое время я чувствовала этот страх каждый раз.</segment>
		<segment id="214" parent="429" relname="contrast">Несколько раз даже думала уйти,</segment>
		<segment id="215" parent="429" relname="contrast">но просто постеснялась среди первой же песни выходить из зала.</segment>
		<segment id="216" parent="217" relname="condition">Потом поняла, что надо пережить первые 10 минут,</segment>
		<segment id="217" parent="431" relname="span">и что-то внутри успокаивается.</segment>
		<segment id="218" parent="435" relname="span">Потом только начались проблески,</segment>
		<segment id="219" parent="220" relname="condition">когда приходишь,</segment>
		<segment id="220" parent="432" relname="span">и страха нет</segment>
		<segment id="221" parent="222" relname="cause">(замечаешь это</segment>
		<segment id="222" parent="516" relname="span">и радуешься).</segment>
		<segment id="223" parent="440" relname="span">Это такое же ощущение,</segment>
		<segment id="224" parent="438" relname="cause">как когда тебя все время кто-то преследует в школе,</segment>
		<segment id="225" parent="438" relname="span">и ты каждый раз думаешь, как бы пересечь школьный двор,</segment>
		<segment id="226" parent="225" relname="condition">не встретив врага.</segment>
		<segment id="227" parent="441" relname="sequence">И тут в какой-то момент приходишь</segment>
		<segment id="228" parent="441" relname="sequence">и обнаруживаешь, что его нет</segment>
		<segment id="229" parent="442" relname="span">- облегчение!</segment>
		<segment id="230" parent="446" relname="span">Кстати тут мне помогли танцы</segment>
		<segment id="231" parent="445" relname="joint">- на танцах, в отличие от зумбы, не 20 человек, а 6-8,</segment>
		<segment id="232" parent="445" relname="joint">зал пустой</segment>
		<segment id="233" parent="445" relname="joint">и светомузыки нет.</segment>
		<segment id="234" parent="445" relname="joint">Обстановка не такая боевая.</segment>
		<segment id="235" parent="447" relname="span">Я помню, что я с одной стороны дико скучала по всем этим занятиям,</segment>
		<segment id="236" parent="235" relname="condition">если приходилось их пропускать.</segment>
		<segment id="237" parent="448" relname="sequence">Но все равно иногда входила в зал,</segment>
		<segment id="238" parent="448" relname="sequence">и чувствовала, как этот ком подступает к горлу</segment>
		<segment id="239" parent="448" relname="sequence">и в животе что-то сжимается.</segment>
		<segment id="240" parent="451" relname="contrast">Иногда уже давно все хорошо</segment>
		<segment id="241" parent="450" relname="sequence">- и тут тело вдруг что-то вспомнит,</segment>
		<segment id="242" parent="450" relname="sequence">и включается какая-то тревожность.</segment>
		<segment id="243" parent="453" relname="span">Но я это рассматриваю как еще одну возможность</segment>
		<segment id="244" parent="452" relname="span">для тренировки</segment>
		<segment id="245" parent="244" relname="evaluation">(не знаю, чего).</segment>
		<segment id="246" parent="461" relname="span">С одной стороны - нельзя уже рваться в бой как тот мальчишка, не думая вообще ни о чем.</segment>
		<segment id="247" parent="458" relname="joint">Потому что так можно и упасть лишний раз,</segment>
		<segment id="248" parent="458" relname="joint">и ногу сломать,</segment>
		<segment id="249" parent="458" relname="joint">и не знаю что еще</segment>
		<segment id="250" parent="459" relname="evaluation">- все же слушать свое тело надо.</segment>
		<segment id="251" parent="462" relname="joint">А с другой стороны - нельзя слишком много думать</segment>
		<segment id="252" parent="462" relname="joint">и слушать.</segment>
		<segment id="253" parent="464" relname="span">И различать,</segment>
		<segment id="254" parent="463" relname="comparison">где страх включился по какой-то привычке,</segment>
		<segment id="255" parent="463" relname="comparison">а где серьезный повод есть.</segment>
		<group id="257" type="multinuc" parent="258" relname="preparation"/>
		<group id="258" type="span" parent="264" relname="span"/>
		<group id="259" type="span" parent="261" relname="joint"/>
		<group id="260" type="span" parent="261" relname="joint"/>
		<group id="261" type="multinuc" parent="263" relname="restatement"/>
		<group id="262" type="multinuc" parent="263" relname="restatement"/>
		<group id="263" type="multinuc" parent="265" relname="contrast"/>
		<group id="264" type="span" parent="265" relname="contrast"/>
		<group id="265" type="multinuc" />
		<group id="266" type="span" parent="269" relname="sequence"/>
		<group id="267" type="multinuc" parent="269" relname="sequence"/>
		<group id="268" type="multinuc" parent="269" relname="sequence"/>
		<group id="269" type="multinuc" parent="495" relname="span"/>
		<group id="272" type="multinuc" parent="27" relname="elaboration"/>
		<group id="273" type="span" parent="274" relname="contrast"/>
		<group id="274" type="multinuc" parent="493" relname="evaluation"/>
		<group id="275" type="span" />
		<group id="277" type="span" parent="280" relname="span"/>
		<group id="278" type="multinuc" parent="277" relname="elaboration"/>
		<group id="279" type="multinuc" parent="35" relname="cause"/>
		<group id="280" type="span" parent="285" relname="preparation"/>
		<group id="281" type="multinuc" parent="468" relname="cause"/>
		<group id="282" type="multinuc" parent="468" relname="span"/>
		<group id="283" type="multinuc" parent="469" relname="evaluation"/>
		<group id="284" type="multinuc" parent="285" relname="span"/>
		<group id="285" type="span" parent="286" relname="span"/>
		<group id="286" type="span" />
		<group id="287" type="span" parent="288" relname="span"/>
		<group id="288" type="span" parent="296" relname="joint"/>
		<group id="289" type="span" parent="293" relname="span"/>
		<group id="290" type="span" parent="291" relname="joint"/>
		<group id="291" type="multinuc" parent="289" relname="elaboration"/>
		<group id="292" type="span" parent="294" relname="contrast"/>
		<group id="293" type="span" parent="294" relname="contrast"/>
		<group id="294" type="multinuc" parent="52" relname="cause"/>
		<group id="295" type="span" parent="296" relname="joint"/>
		<group id="296" type="multinuc" parent="48" relname="elaboration"/>
		<group id="297" type="span" />
		<group id="298" type="multinuc" parent="304" relname="sequence"/>
		<group id="299" type="span" parent="303" relname="span"/>
		<group id="300" type="span" parent="302" relname="joint"/>
		<group id="301" type="span" parent="302" relname="joint"/>
		<group id="302" type="multinuc" parent="299" relname="cause"/>
		<group id="303" type="span" parent="304" relname="sequence"/>
		<group id="304" type="multinuc" parent="69" relname="cause"/>
		<group id="305" type="span" parent="306" relname="span"/>
		<group id="306" type="span" parent="314" relname="span"/>
		<group id="307" type="multinuc" parent="312" relname="sequence"/>
		<group id="308" type="span" parent="311" relname="span"/>
		<group id="309" type="multinuc" parent="75" relname="cause"/>
		<group id="310" type="span" parent="308" relname="cause"/>
		<group id="311" type="span" parent="312" relname="sequence"/>
		<group id="312" type="multinuc" parent="70" relname="elaboration"/>
		<group id="313" type="span" parent="306" relname="elaboration"/>
		<group id="314" type="span" parent="322" relname="span"/>
		<group id="315" type="multinuc" parent="78" relname="elaboration"/>
		<group id="316" type="span" parent="321" relname="span"/>
		<group id="317" type="multinuc" parent="318" relname="contrast"/>
		<group id="318" type="multinuc" parent="319" relname="span"/>
		<group id="319" type="span" parent="320" relname="span"/>
		<group id="320" type="span" parent="82" relname="elaboration"/>
		<group id="321" type="span" parent="314" relname="evaluation"/>
		<group id="322" type="span" />
		<group id="323" type="span" parent="500" relname="preparation"/>
		<group id="325" type="multinuc" parent="499" relname="elaboration"/>
		<group id="327" type="multinuc" parent="95" relname="cause"/>
		<group id="328" type="span" parent="331" relname="span"/>
		<group id="329" type="span" parent="330" relname="joint"/>
		<group id="330" type="multinuc" parent="328" relname="evidence"/>
		<group id="331" type="span" parent="92" relname="elaboration"/>
		<group id="333" type="multinuc" parent="502" relname="span"/>
		<group id="334" type="multinuc" parent="504" relname="span"/>
		<group id="335" type="multinuc" parent="107" relname="cause"/>
		<group id="336" type="span" parent="338" relname="span"/>
		<group id="337" type="span" parent="336" relname="evaluation"/>
		<group id="338" type="span" parent="346" relname="span"/>
		<group id="339" type="span" parent="340" relname="cause"/>
		<group id="340" type="span" parent="472" relname="span"/>
		<group id="341" type="span" parent="116" relname="cause"/>
		<group id="342" type="span" parent="343" relname="evaluation"/>
		<group id="343" type="span" parent="344" relname="span"/>
		<group id="344" type="span" parent="345" relname="span"/>
		<group id="345" type="span" parent="338" relname="elaboration"/>
		<group id="346" type="span" parent="347" relname="evidence"/>
		<group id="347" type="span" parent="348" relname="span"/>
		<group id="348" type="span" parent="349" relname="joint"/>
		<group id="349" type="multinuc" />
		<group id="350" type="multinuc" parent="506" relname="span"/>
		<group id="351" type="span" parent="482" relname="sequence"/>
		<group id="353" type="span" parent="355" relname="sequence"/>
		<group id="354" type="multinuc" parent="355" relname="sequence"/>
		<group id="355" type="multinuc" parent="483" relname="contrast"/>
		<group id="357" type="multinuc" parent="358" relname="span"/>
		<group id="358" type="span" parent="359" relname="span"/>
		<group id="359" type="span" parent="376" relname="span"/>
		<group id="362" type="multinuc" parent="366" relname="span"/>
		<group id="363" type="multinuc" parent="140" relname="condition"/>
		<group id="364" type="span" parent="365" relname="span"/>
		<group id="365" type="span" parent="367" relname="elaboration"/>
		<group id="366" type="span" parent="367" relname="span"/>
		<group id="367" type="span" parent="368" relname="span"/>
		<group id="368" type="span" parent="375" relname="joint"/>
		<group id="369" type="span" parent="374" relname="span"/>
		<group id="370" type="multinuc" parent="147" relname="condition"/>
		<group id="371" type="span" parent="373" relname="contrast"/>
		<group id="372" type="span" parent="373" relname="contrast"/>
		<group id="373" type="multinuc" parent="486" relname="span"/>
		<group id="374" type="span" parent="375" relname="joint"/>
		<group id="375" type="multinuc" parent="359" relname="elaboration"/>
		<group id="376" type="span" />
		<group id="377" type="span" parent="152" relname="evidence"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="150" relname="elaboration"/>
		<group id="380" type="span" parent="382" relname="joint"/>
		<group id="381" type="span" parent="382" relname="joint"/>
		<group id="382" type="multinuc" parent="383" relname="span"/>
		<group id="383" type="span" parent="384" relname="span"/>
		<group id="384" type="span" parent="387" relname="contrast"/>
		<group id="385" type="span" parent="158" relname="elaboration"/>
		<group id="386" type="span" parent="387" relname="contrast"/>
		<group id="387" type="multinuc" />
		<group id="388" type="span" parent="389" relname="span"/>
		<group id="389" type="span" parent="390" relname="joint"/>
		<group id="390" type="multinuc" parent="393" relname="preparation"/>
		<group id="391" type="span" parent="474" relname="contrast"/>
		<group id="392" type="multinuc" parent="393" relname="span"/>
		<group id="393" type="span" parent="394" relname="span"/>
		<group id="394" type="span" parent="399" relname="span"/>
		<group id="395" type="multinuc" parent="171" relname="elaboration"/>
		<group id="396" type="span" parent="398" relname="span"/>
		<group id="397" type="multinuc" parent="396" relname="elaboration"/>
		<group id="398" type="span" parent="476" relname="span"/>
		<group id="399" type="span" parent="401" relname="span"/>
		<group id="400" type="multinuc" parent="398" relname="evidence"/>
		<group id="401" type="span" parent="403" relname="cause"/>
		<group id="402" type="multinuc" parent="512" relname="span"/>
		<group id="403" type="span" parent="404" relname="span"/>
		<group id="404" type="span" parent="424" relname="contrast"/>
		<group id="405" type="span" parent="477" relname="span"/>
		<group id="406" type="multinuc" parent="410" relname="span"/>
		<group id="407" type="multinuc" parent="186" relname="elaboration"/>
		<group id="408" type="span" parent="405" relname="cause"/>
		<group id="409" type="span" parent="411" relname="span"/>
		<group id="410" type="span" parent="408" relname="span"/>
		<group id="411" type="span" parent="412" relname="contrast"/>
		<group id="412" type="multinuc" parent="410" relname="evaluation"/>
		<group id="413" type="span" parent="478" relname="span"/>
		<group id="414" type="multinuc" parent="415" relname="joint"/>
		<group id="415" type="multinuc" parent="191" relname="evidence"/>
		<group id="416" type="span" />
		<group id="417" type="span" parent="418" relname="joint"/>
		<group id="418" type="multinuc" parent="422" relname="joint"/>
		<group id="419" type="span" parent="422" relname="joint"/>
		<group id="420" type="span" parent="421" relname="joint"/>
		<group id="421" type="multinuc" parent="204" relname="elaboration"/>
		<group id="422" type="multinuc" parent="197" relname="elaboration"/>
		<group id="423" type="span" parent="422" relname="joint"/>
		<group id="424" type="multinuc" />
		<group id="425" type="span" />
		<group id="426" type="span" parent="427" relname="joint"/>
		<group id="427" type="multinuc" parent="208" relname="elaboration"/>
		<group id="428" type="span" parent="213" relname="preparation"/>
		<group id="429" type="multinuc" parent="430" relname="elaboration"/>
		<group id="430" type="span" parent="437" relname="span"/>
		<group id="431" type="span" parent="436" relname="sequence"/>
		<group id="432" type="span" parent="434" relname="span"/>
		<group id="434" type="span" parent="218" relname="elaboration"/>
		<group id="435" type="span" parent="436" relname="sequence"/>
		<group id="436" type="multinuc" parent="444" relname="comparison"/>
		<group id="437" type="span" parent="436" relname="sequence"/>
		<group id="438" type="span" parent="439" relname="span"/>
		<group id="439" type="span" parent="223" relname="elaboration"/>
		<group id="440" type="span" parent="443" relname="joint"/>
		<group id="441" type="multinuc" parent="229" relname="cause"/>
		<group id="442" type="span" parent="443" relname="joint"/>
		<group id="443" type="multinuc" parent="444" relname="comparison"/>
		<group id="444" type="multinuc" />
		<group id="445" type="multinuc" parent="230" relname="background"/>
		<group id="446" type="span" parent="447" relname="preparation"/>
		<group id="447" type="span" parent="456" relname="span"/>
		<group id="448" type="multinuc" parent="449" relname="contrast"/>
		<group id="449" type="multinuc" parent="454" relname="span"/>
		<group id="450" type="multinuc" parent="451" relname="contrast"/>
		<group id="451" type="multinuc" parent="454" relname="evidence"/>
		<group id="452" type="span" parent="243" relname="purpose"/>
		<group id="453" type="span" parent="455" relname="evaluation"/>
		<group id="454" type="span" parent="455" relname="span"/>
		<group id="455" type="span" parent="457" relname="span"/>
		<group id="456" type="span" parent="449" relname="contrast"/>
		<group id="457" type="span" />
		<group id="458" type="multinuc" parent="459" relname="span"/>
		<group id="459" type="span" parent="460" relname="span"/>
		<group id="460" type="span" parent="246" relname="cause"/>
		<group id="461" type="span" parent="466" relname="contrast"/>
		<group id="462" type="multinuc" parent="465" relname="contrast"/>
		<group id="463" type="multinuc" parent="253" relname="elaboration"/>
		<group id="464" type="span" parent="465" relname="contrast"/>
		<group id="465" type="multinuc" parent="466" relname="contrast"/>
		<group id="466" type="multinuc" />
		<group id="468" type="span" parent="469" relname="span"/>
		<group id="469" type="span" parent="470" relname="span"/>
		<group id="470" type="span" parent="284" relname="contrast"/>
		<group id="471" type="span" parent="325" relname="joint"/>
		<group id="472" type="span" parent="344" relname="cause"/>
		<group id="473" type="span" parent="141" relname="elaboration"/>
		<group id="474" type="multinuc" parent="390" relname="joint"/>
		<group id="475" type="span" parent="397" relname="sequence"/>
		<group id="476" type="span" parent="394" relname="evaluation"/>
		<group id="477" type="span" parent="424" relname="contrast"/>
		<group id="478" type="span" parent="415" relname="joint"/>
		<group id="479" type="span" parent="480" relname="same-unit"/>
		<group id="480" type="multinuc" parent="282" relname="joint"/>
		<group id="482" type="multinuc" parent="483" relname="contrast"/>
		<group id="483" type="multinuc" />
		<group id="484" type="span" parent="485" relname="span"/>
		<group id="485" type="span" parent="316" relname="evidence"/>
		<group id="486" type="span" parent="487" relname="span"/>
		<group id="487" type="span" parent="369" relname="evidence"/>
		<group id="491" type="span" parent="267" relname="joint"/>
		<group id="492" type="span" parent="493" relname="span"/>
		<group id="493" type="span" parent="494" relname="span"/>
		<group id="494" type="span" parent="495" relname="elaboration"/>
		<group id="495" type="span" parent="496" relname="span"/>
		<group id="496" type="span" parent="15" relname="elaboration"/>
		<group id="497" type="span" parent="498" relname="span"/>
		<group id="498" type="span" parent="284" relname="contrast"/>
		<group id="499" type="span" parent="500" relname="span"/>
		<group id="500" type="span" parent="501" relname="span"/>
		<group id="501" type="span" parent="349" relname="joint"/>
		<group id="502" type="span" parent="503" relname="span"/>
		<group id="503" type="span" parent="334" relname="same-unit"/>
		<group id="504" type="span" parent="347" relname="span"/>
		<group id="505" type="span" parent="281" relname="contrast"/>
		<group id="506" type="span" parent="507" relname="span"/>
		<group id="507" type="span" parent="482" relname="sequence"/>
		<group id="508" type="span" parent="509" relname="span"/>
		<group id="509" type="span" parent="366" relname="preparation"/>
		<group id="512" type="span" parent="403" relname="span"/>
		<group id="515" type="span" parent="257" relname="same-unit"/>
		<group id="516" type="span" parent="432" relname="evaluation"/>
	</body>
</rst>