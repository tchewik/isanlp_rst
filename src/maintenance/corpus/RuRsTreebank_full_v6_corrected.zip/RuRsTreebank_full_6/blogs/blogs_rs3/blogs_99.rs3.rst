<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://ru-travel.livejournal.com/33784217.html</segment>
		<segment id="2" >Монголия! Юрты, юрты, небоскрёб, юрты!</segment>
		<segment id="3" parent="264" relname="preparation">Итак, Монголия. Сначала и не думала заворачивать в эту страну.</segment>
		<segment id="4" parent="263" relname="sequence">Решили ехать на Байкал, с иркутской стороны, соответственно.</segment>
		<segment id="5" parent="261" relname="span">Потом к Байкалу плавно приплюсовали Бурятию</segment>
		<segment id="6" parent="5" relname="elaboration">(и не пожалели ни разу!),</segment>
		<segment id="7" parent="506" relname="span">а потом я рассмотрела, что с Улан-Удэ не так далеко и до Улан-Батора!</segment>
		<segment id="8" parent="7" relname="elaboration">Не далеко — это 500 километров.</segment>
		<segment id="9" parent="265" relname="elaboration">IMG</segment>
		<segment id="10" parent="268" relname="span">Выбор подтвердился окончательно,</segment>
		<segment id="11" parent="267" relname="joint">когда стала искать виды транспортировки из Улан-Удэ в Монголию,</segment>
		<segment id="12" parent="267" relname="joint">и нашла рейс монгольских авиалиний.</segment>
		<segment id="13" parent="268" relname="elaboration">Летает он несколько раз в неделю.</segment>
		<segment id="14" parent="270" relname="joint">Еще есть поезд, также пару раз в неделю.</segment>
		<segment id="15" parent="272" relname="span">Причем, цена на самолет и поезд практически одна и та же — 5000 руб., плюс/минус.</segment>
		<segment id="16" parent="271" relname="comparison">Только вот самолетом доберетесь за 1,5 часа,</segment>
		<segment id="17" parent="271" relname="comparison">а поезд плетётся 14,5 часов.</segment>
		<segment id="18" parent="277" relname="span">Мы сделали так: в Улан-Батор полетели самолетом, а обратно — поездом.</segment>
		<segment id="19" parent="275" relname="joint">Во-первых, так было удобнее по датам и времени,</segment>
		<segment id="20" parent="276" relname="span">а во-вторых, ни капли не пожалели, выбрав поезд,</segment>
		<segment id="21" parent="20" relname="cause">потому что виды за окном были потрясающие.</segment>
		<segment id="22" parent="286" relname="span">Монголии я побаивалась, честно сказать.</segment>
		<segment id="23" parent="280" relname="joint">Знала о ней несколько отдалённых фактов: степи, степи, большая территория, мало жителей, большинство из которых — кочевники, лошади,</segment>
		<segment id="24" parent="279" relname="joint">Улан-Батор — самая холодная столица мира,</segment>
		<segment id="25" parent="279" relname="joint">и то, что один мой знакомый ездил туда охотиться с монголами.</segment>
		<segment id="26" parent="281" relname="evaluation">С таким набором я бы, наверно, ещё долго не выбрала Монголию как объект посещения.</segment>
		<segment id="27" parent="283" relname="joint">Ещё казалось, что вот сейчас выйду из аэропорта,</segment>
		<segment id="28" parent="283" relname="joint">а там — коровы какие-нибудь ходят, гужевые повозки с лошадьми, монголы в национальных одеждах, ни одного магазина, и вот она, я...</segment>
		<segment id="29" parent="287" relname="span">Но, каково было удивление, что сначала встретила в аэропорту огромную толпу туристов из Южной Кореи</segment>
		<segment id="30" parent="29" relname="elaboration">(уже, думаю, не одни тут будем :),</segment>
		<segment id="31" parent="471" relname="span">а потом нас вёз очень даже симпатичный, модный, молодой монгол, и не на гужевой повозке, а на вполне хорошем авто.</segment>
		<segment id="32" parent="31" relname="elaboration">Да и музыка в машине играла приятная.</segment>
		<segment id="33" parent="473" relname="elaboration">IMG Аэропорт имени, конечно же, Чингисхана!</segment>
		<segment id="34" parent="509" relname="preparation">В общем — выдохнула.</segment>
		<segment id="35" parent="290" relname="span">Ещё больше расслабилась,</segment>
		<segment id="36" parent="35" relname="condition">когда заселились в отель</segment>
		<segment id="37" parent="290" relname="evaluation">— вот уж действительно, это вам не сибирский сервис — номер оказался просто огромный!</segment>
		<segment id="38" parent="291" relname="joint">И воду питьевую не забыли, и все принадлежности на месте, и даже печеньки в качестве комплимента.</segment>
		<segment id="39" parent="508" relname="evaluation">Вот, думаю, тебе и монголы!</segment>
		<segment id="40" parent="292" relname="span">В Монголии у нас была местная гид — Болор,</segment>
		<segment id="41" parent="40" relname="elaboration">вместе с которой мы и начали изучение страны.</segment>
		<segment id="42" parent="293" relname="span">Болор хорошо знает русский язык,</segment>
		<segment id="43" parent="42" relname="cause">так как училась в школе при российском посольстве.</segment>
		<segment id="44" parent="293" relname="elaboration">Хотя это, скорее, исключение.</segment>
		<segment id="45" parent="303" relname="span">Русский язык в Монголии не знают, общение с туристами — на английском либо «на пальцах».</segment>
		<segment id="46" parent="296" relname="span">Туристов, кстати, не мало. Особенно много корейцев.</segment>
		<segment id="47" parent="46" relname="evaluation">Так и не поняла с чем это связано.</segment>
		<segment id="48" parent="301" relname="comparison">Очень много корейских ресторанов, кафе, и чуть ли не несколько рейсов в день прилетает из Сеула.</segment>
		<segment id="49" parent="512" relname="restatement">Есть туристы из Китая, но больше, так называемых, внутренних монголов.</segment>
		<segment id="50" parent="512" relname="restatement">Это те же самые монголы, которые живут обособленно на китайской территории, граничащей с Монголией.</segment>
		<segment id="51" parent="297" relname="joint">Естественно, китайцам такое соседство сто лет не нужно,</segment>
		<segment id="52" parent="297" relname="joint">и притесняют несчастных всеми способами.</segment>
		<segment id="53" parent="300" relname="span">Русских туристов совсем не много.</segment>
		<segment id="54" parent="299" relname="span">Видимо, это связано с очень дорогими рейсами из Москвы в Улан-Батор:</segment>
		<segment id="55" parent="298" relname="joint">летает Аэрофлот,</segment>
		<segment id="56" parent="298" relname="joint">билет в оба конца стоит примерно 50 000 руб., а также, возможно, с отсутствием туристических программ в данную страну.</segment>
		<segment id="57" parent="515" relname="span">Так вот, начали мы непосредственное знакомство с Улан-Батором с ресторана с буддийского монастыря Гандан</segment>
		<segment id="58" parent="57" relname="background">(основной религией в Монголии является тибетский буддизм)</segment>
		<segment id="59" parent="516" relname="same-unit">— это крупнейший монастырь в Монголии.</segment>
		<segment id="60" parent="517" relname="elaboration">IMG</segment>
		<segment id="61" parent="475" relname="span">Монастырь Гандан IMG А вот и монголы. IMG</segment>
		<segment id="62" parent="63" relname="cause">Идет молебен.</segment>
		<segment id="63" parent="456" relname="span">Внутри снимать нельзя. IMG</segment>
		<segment id="64" parent="65" relname="cause">Большая чаша с благовониями. Купила для себя маленькую в Бурятии,</segment>
		<segment id="65" parent="457" relname="span">теперь жгу дома. IMG</segment>
		<segment id="66" parent="304" relname="span">Далее отправились на вершину Зайсан-Толгой.</segment>
		<segment id="67" parent="66" relname="elaboration">Сей мемориал символизирует память о поддержке Красной Армией монгольской революции и победе при Халкин-Голе. IMG</segment>
		<segment id="68" parent="477" relname="span">Вместе с тем сюда стоит подняться, главным образом,</segment>
		<segment id="69" parent="68" relname="purpose">ради панорамного вида на Улан-Батор. IMG</segment>
		<segment id="70" parent="476" relname="span">Внизу хорошо видны юрты.</segment>
		<segment id="71" parent="70" relname="elaboration">Они жилые. IMG IMG IMG IMG</segment>
		<segment id="72" parent="305" relname="joint">Улан-Батор - самая холодная столица мира.</segment>
		<segment id="73" parent="305" relname="joint">Среднегодовая температура –0,4 °C.</segment>
		<segment id="74" parent="521" relname="span">Сад Будды был, к сожалению, закрыт</segment>
		<segment id="75" parent="74" relname="purpose">на реконструкцию</segment>
		<segment id="76" parent="521" relname="purpose">(большая золотая статуя Будды находится именно там),</segment>
		<segment id="77" parent="307" relname="joint">и мы отправились во Дворец Богдо-Хана.</segment>
		<segment id="78" parent="460" relname="span">Атмосферное место, где можно немного прикоснуться к истории и культуре Монголии.</segment>
		<segment id="79" parent="78" relname="elaboration">IMG Золотой Будда. IMG Дворец Богдо-Хана. IMG</segment>
		<segment id="80" parent="310" relname="span">Главная площадь Улан-Батора носит имя крупнейшего монгольского революционера и руководителя — Сухэ-Батора.</segment>
		<segment id="81" parent="308" relname="span">Её вы не упустите из вида,</segment>
		<segment id="82" parent="81" relname="cause">ведь площадь просто огромная.</segment>
		<segment id="83" parent="308" relname="evaluation">Не удивительно, что она входит в десятку самых больших площадей мира.</segment>
		<segment id="84" parent="522" relname="span">Есть очень милая традиция — каждые выходные на этой площади собираются одноклассники, окончившие школу,</segment>
		<segment id="85" parent="84" relname="elaboration">для встречи.</segment>
		<segment id="86" parent="311" relname="contrast">О дате встречи, конечно, договариваются заранее,</segment>
		<segment id="87" parent="311" relname="contrast">а место всегда одно и то же — площадь Сухэ-Батора.</segment>
		<segment id="88" parent="313" relname="span">Есть и еще одна традиция — это фото с Чингисханом.</segment>
		<segment id="89" parent="88" relname="elaboration">Статуя сидящего Чингисхана тоже находится на этой площади.</segment>
		<segment id="90" parent="315" relname="elaboration">IMG Площадь Сухэ-Батора. IMG IMG Одноклассники)</segment>
		<segment id="91" parent="319" relname="span">Побывали мы и в Национальном историческом музее.</segment>
		<segment id="92" parent="317" relname="span">Я не большой любитель подобных музеев,</segment>
		<segment id="93" parent="92" relname="cause">всё больше люблю изучать страну, так сказать, живьем,</segment>
		<segment id="94" parent="318" relname="contrast">но музей оказался интересный.</segment>
		<segment id="95" parent="320" relname="span">Закончили первый день в Улан-Баторе концертом народного фольклора.</segment>
		<segment id="96" parent="95" relname="evaluation">Вот это действо, считаю, пропускать нельзя.</segment>
		<segment id="97" parent="321" relname="span">Одно выступление с горловым пением чего стоит!</segment>
		<segment id="98" parent="97" relname="evaluation">Пожалуй, такого я не слышала, уж вживую — точно.</segment>
		<segment id="99" parent="322" relname="span">Да, на концерт советую прийти заранее,</segment>
		<segment id="100" parent="99" relname="purpose">чтобы занять хорошие места</segment>
		<segment id="101" parent="484" relname="contrast">(билеты продаются без мест),</segment>
		<segment id="102" parent="323" relname="joint">иначе потом вас атакуют со всех сторон корейцы</segment>
		<segment id="103" parent="323" relname="joint">и придется ютиться где попало.</segment>
		<segment id="104" parent="328" relname="elaboration">IMG</segment>
		<segment id="105" parent="106" relname="preparation">В общем, первый день прошел на одном дыхании, класс!</segment>
		<segment id="106" parent="485" relname="span">Идем в корейский ресторан!</segment>
		<segment id="107" parent="331" relname="span">Ну, а где ещё в ближайшее время попадешь в хороший корейский ресторан?</segment>
		<segment id="108" parent="331" relname="elaboration">Сходите обязательно.</segment>
		<segment id="109" parent="332" relname="span">Многое есть было невозможно,</segment>
		<segment id="110" parent="109" relname="cause">потом всё внутри, да и снаружи, горело,</segment>
		<segment id="111" parent="333" relname="contrast">но мы сходили))</segment>
		<segment id="112" parent="487" relname="joint">IMG Вечерняя площадь. IMG Тугрики.</segment>
		<segment id="113" parent="336" relname="preparation">День второй.</segment>
		<segment id="114" parent="336" relname="span">Улан-Батор, кстати, переводится с монгольского как Красный богатырь.</segment>
		<segment id="115" parent="114" relname="evaluation">Красиво.</segment>
		<segment id="116" parent="345" relname="span">Второй день мы провели за пределами Улан-Батора.</segment>
		<segment id="117" parent="337" relname="span">Сначала отправились к самой большой статуе Чингисхана,</segment>
		<segment id="118" parent="117" relname="evaluation">она же — крупнейшая конная статуя в мире.</segment>
		<segment id="119" parent="338" relname="joint">Путь к ней — примерно 60 км.</segment>
		<segment id="120" parent="338" relname="joint">Статую сделали на деньги местного бизнесмена.</segment>
		<segment id="121" parent="338" relname="joint">Там же есть музей, магазинчики сувениров, кафешка.</segment>
		<segment id="122" parent="342" relname="span">На голове лошади располагается смотровая площадка.</segment>
		<segment id="123" parent="341" relname="contrast">Добраться туда можно на лифте,</segment>
		<segment id="124" parent="340" relname="span">но советую пройтись по лестнице,</segment>
		<segment id="125" parent="339" relname="joint">так как очень много людей</segment>
		<segment id="126" parent="339" relname="joint">и лифт ждать долго.</segment>
		<segment id="127" parent="343" relname="joint">Сама статуя 40 метров в высоту,</segment>
		<segment id="128" parent="343" relname="joint">была открыта в 2008 году.</segment>
		<segment id="129" parent="344" relname="span">Территория ещё достраивается.</segment>
		<segment id="130" parent="129" relname="elaboration">Говорят, в ближайшем будущем там появится много всего интересного — юрты для туристов, гольф-клуб, тематический парк, открытий театр и другое.</segment>
		<segment id="131" parent="346" relname="elaboration">IMG IMG Внутренние монголы. Путешествуют всегда организованными группами. IMG Вид сверху.</segment>
		<segment id="132" parent="354" relname="preparation">Далее наш путь пролегал в Национальный парк Тэрэлж.</segment>
		<segment id="133" parent="134" relname="cause">О данном парке я ранее не слышала,</segment>
		<segment id="134" parent="348" relname="span">поэтому ехала без особого воодушевления.</segment>
		<segment id="135" parent="348" relname="elaboration">И вновь Монголия меня удивила!</segment>
		<segment id="136" parent="350" relname="joint">Какая красота открылась взору!</segment>
		<segment id="137" parent="350" relname="joint">Природа Монголии — как она есть.</segment>
		<segment id="138" parent="491" relname="contrast">Оказалось, что Монголия — это далеко не одни степи, степи.</segment>
		<segment id="139" parent="352" relname="span">Это и горы различных причудливых форм, и красивый ландшафт местности, и речушки, и леса и ещё много чего,</segment>
		<segment id="140" parent="139" relname="elaboration">что менее чем за 4 дня увидеть не удалось(</segment>
		<segment id="141" parent="470" relname="joint">IMG Национальный парк Тэрэлж. IMG IMG Гора "Черепаха".</segment>
		<segment id="142" parent="492" relname="span">На территории парка расположено очень много туристических баз.</segment>
		<segment id="143" parent="142" relname="elaboration">Мне особо приглянулась вот эта. IMG</segment>
		<segment id="144" parent="357" relname="elaboration">Юрты для туристов. IMG IMG IMG</segment>
		<segment id="145" parent="357" relname="span">В этих юртах захотелось переночевать хоть бы одну ночку!</segment>
		<segment id="146" parent="147" relname="condition">Так что, у кого будет возможность —</segment>
		<segment id="147" parent="356" relname="span">не упустите шанс.</segment>
		<segment id="148" parent="362" relname="span">В том же парке Тэрэлж есть Буддийский медитационный центр Арьяабал.</segment>
		<segment id="149" parent="358" relname="contrast">Подъём туда занимает минут 20-30,</segment>
		<segment id="150" parent="358" relname="contrast">но оно того стоит.</segment>
		<segment id="151" parent="493" relname="span">Вид сверху просто улётный.</segment>
		<segment id="152" parent="151" relname="evaluation">Медитировать да и только!</segment>
		<segment id="153" parent="363" relname="span">И вообще, за эту поездку на буддийские территории нашей Бурятии и Монголии я как-то, неожиданно для себя, прониклась буддизмом.</segment>
		<segment id="154" parent="153" relname="evaluation">Приятно это всё у них, по мне.</segment>
		<segment id="155" parent="464" relname="elaboration">IMG IMG Путь к медитации. IMG IMG Жить надо высоко, душою звезд касаясь!</segment>
		<segment id="156" parent="533" relname="span">Самым колоритным местом за всю поездку считаю заход в гости к настоящей семье кочевников, в настоящую юрту. Да, не в эту красивую и ухоженную, как в парке, для туристов.</segment>
		<segment id="157" parent="366" relname="span">Причем, заход в гости был такой:</segment>
		<segment id="158" parent="159" relname="attribution">Болор сказала,</segment>
		<segment id="159" parent="532" relname="span">что любая семья кочевников обязана принять путника, который постучался к ним.</segment>
		<segment id="160" parent="367" relname="span">Собственно, мы и зарулили в ближайшую юрту вдоль дороги.</segment>
		<segment id="161" parent="160" relname="elaboration">Семья оказалась казахская.</segment>
		<segment id="162" parent="368" relname="restatement">Кочевники обычно обитают в одной и той же местности,</segment>
		<segment id="163" parent="368" relname="restatement">то есть не уходят далеко от дома.</segment>
		<segment id="164" parent="369" relname="contrast">Но поговаривают, что бывают случаи непреднамеренного перехода границы кочевниками из Казахстана и Китая в Монголию и наоборот.</segment>
		<segment id="165" parent="370" relname="span">Современные кочевники пользуются многими благами цивилизации —</segment>
		<segment id="166" parent="165" relname="elaboration">есть у них автомобили, сотовые телефоны и т.д.</segment>
		<segment id="167" parent="168" relname="cause">Когда нужно переехать на другое место —</segment>
		<segment id="168" parent="371" relname="span">юрту быстренько складывают в багажник,</segment>
		<segment id="169" parent="372" relname="joint">а на новом месте быстренько раскладывают.</segment>
		<segment id="170" parent="494" relname="span">Юрты в Монголии повсюду,</segment>
		<segment id="171" parent="523" relname="span">это очень удобное жилье для кочевников</segment>
		<segment id="172" parent="171" relname="condition">в условиях здешнего климата.</segment>
		<segment id="173" parent="380" relname="span">В Улан-Баторе до сих пор есть целый район с юртами.</segment>
		<segment id="174" parent="375" relname="contrast">И как правительство не пытается заманить жителей в квартиры —</segment>
		<segment id="175" parent="375" relname="contrast">монголы держатся за свои юрты до последнего!</segment>
		<segment id="176" parent="376" relname="span">В отличие от той же Бурятии,</segment>
		<segment id="177" parent="176" relname="elaboration">где в юртах уже практически не живут, даже в деревнях,</segment>
		<segment id="178" parent="377" relname="comparison">в Монголии и в деревнях живут, и в городах.</segment>
		<segment id="179" parent="382" relname="span">Монголия — это островок доподлинной аутентичности.</segment>
		<segment id="180" parent="381" relname="joint">Это приятно,</segment>
		<segment id="181" parent="381" relname="joint">интересно.</segment>
		<segment id="182" parent="413" relname="preparation">Вернемся к казахам-кочевникам.</segment>
		<segment id="183" parent="392" relname="sequence">Зашли мы в юрту,</segment>
		<segment id="184" parent="392" relname="sequence">сели на кровать,</segment>
		<segment id="185" parent="392" relname="sequence">ждем угощения.</segment>
		<segment id="186" parent="396" relname="span">В юрте живет, вроде как, трое взрослых и двое детей.</segment>
		<segment id="187" parent="534" relname="span">Скажу сразу — по достижении школьного возраста кочевники отдают детей в школы.</segment>
		<segment id="188" parent="394" relname="span">Детей монголы очень любят.</segment>
		<segment id="189" parent="393" relname="joint">Стараются дать получше образование, возможность изучать языки,</segment>
		<segment id="190" parent="393" relname="joint">балуют подарками.</segment>
		<segment id="191" parent="399" relname="span">Обстановка в юрте такая:</segment>
		<segment id="192" parent="524" relname="span">посередине стоит печка</segment>
		<segment id="193" parent="192" relname="purpose">для варки еды,</segment>
		<segment id="194" parent="397" relname="joint">труба выходит на улицу, 2 кровати, полочки, табуреточки, посуда,</segment>
		<segment id="195" parent="398" relname="span">также стоит чан с кумысом</segment>
		<segment id="196" parent="195" relname="elaboration">(кисломолочный напиток из кобыльего молока, настаивается несколько дней).</segment>
		<segment id="197" parent="401" relname="span">За кумысом мы и зашли.</segment>
		<segment id="198" parent="409" relname="background">Кочевники живут, кроме прочего, на доходы от продажи кумыса.</segment>
		<segment id="199" parent="403" relname="span">Ну что, попробовали —</segment>
		<segment id="200" parent="402" relname="joint">кумыс прикольный,</segment>
		<segment id="201" parent="402" relname="joint">кисленький,</segment>
		<segment id="202" parent="402" relname="joint">жидкий,</segment>
		<segment id="203" parent="496" relname="comparison">похож отдаленно на кефир обезжиренный.</segment>
		<segment id="204" parent="404" relname="contrast">Оставили за гостеприимство и кумыс денежку,</segment>
		<segment id="205" parent="497" relname="span">но это не обязательно.</segment>
		<segment id="206" parent="405" relname="joint">Каждый кочевник примет путника,</segment>
		<segment id="207" parent="405" relname="joint">накормит</segment>
		<segment id="208" parent="405" relname="joint">и обогреет совершенно бесплатно.</segment>
		<segment id="209" parent="415" relname="cause">Монголия — край суровый, особенного зимой.</segment>
		<segment id="210" parent="414" relname="elaboration">IMG Чан с кумысом. IMG Жилая юрта. IMG Кумыс. IMG Традиционное занятие монголов - скотоводство. IMG IMG Двугорбый верблюд мало где обитает на Земле. Монголия - одно из таких мест.</segment>
		<segment id="211" parent="419" relname="span">К большому сожалению, не удалось увидеть пустыню Гоби.</segment>
		<segment id="212" parent="417" relname="joint">Уж слишком далеко она от Улан-Батора,</segment>
		<segment id="213" parent="417" relname="joint">и слишком мало времени было.</segment>
		<segment id="214" parent="418" relname="contrast">Но ради неё, в том числе, я вернусь в Монголию ещё раз.</segment>
		<segment id="215" parent="498" relname="contrast">Передвигались мы везде на заранее заказанном авто.</segment>
		<segment id="216" parent="421" relname="contrast">Однако могу сказать, что такси относительно не дорогое,</segment>
		<segment id="217" parent="421" relname="contrast">но опять же, многие таксисты говорят только на монгольском.</segment>
		<segment id="218" parent="422" relname="elaboration">Есть междугородний транспорт, автовокзал.</segment>
		<segment id="219" parent="500" relname="joint">Ехать в Монголию, всё же, лучше в теплое время года.</segment>
		<segment id="220" parent="501" relname="joint">IMG Монгол Шуудан переводится как Монгольская почта.</segment>
		<segment id="221" parent="423" relname="contrast">Монголы живут не богато,</segment>
		<segment id="222" parent="423" relname="contrast">но как-то на жизнь не жалуются.</segment>
		<segment id="223" parent="525" relname="evaluation">Может, потому что буддисты).</segment>
		<segment id="224" parent="432" relname="preparation">Отдельно нужно сказать о кухне Монголии.</segment>
		<segment id="225" parent="432" relname="span">Кухня — это сплошные блюда из мяса — буузы, хушуры, цуйван.</segment>
		<segment id="226" parent="424" relname="span">В общем, для меня, как человека,</segment>
		<segment id="227" parent="425" relname="joint">который уже 2 года не ест мясо</segment>
		<segment id="228" parent="425" relname="joint">и не собирается —</segment>
		<segment id="229" parent="426" relname="same-unit">нужно было потрудиться,</segment>
		<segment id="230" parent="427" relname="purpose">чтобы выбрать что-то национальное и не мясное.</segment>
		<segment id="231" parent="429" relname="span">Но меня не проведешь —</segment>
		<segment id="232" parent="231" relname="cause">я и буузы нашла с овощами, и цуйван с морепродуктами.</segment>
		<segment id="233" parent="429" relname="evaluation">Да — все ржали)) но всё же!</segment>
		<segment id="234" parent="434" relname="span">Национальные блюда схожи с бурятскими.</segment>
		<segment id="235" parent="234" relname="evaluation">Буряты и монголы вообще как единый народ.</segment>
		<segment id="236" parent="434" relname="background">В 20 — 30-е годы 20 века было даже национальное движение за объединение Монголии и Бурятии.</segment>
		<segment id="237" parent="441" relname="span">Из напитков меня покорил монгольских чай.</segment>
		<segment id="238" parent="440" relname="span">Чаем это, конечно, уже сложно назвать.</segment>
		<segment id="239" parent="439" relname="span">Мешанина жуткая.</segment>
		<segment id="240" parent="438" relname="contrast">Это одновременно и суп, и второе блюдо, и десерт,</segment>
		<segment id="241" parent="437" relname="joint">но вкусно,</segment>
		<segment id="242" parent="437" relname="joint">согревает</segment>
		<segment id="243" parent="437" relname="joint">и как-то успокаивает.</segment>
		<segment id="244" parent="245" relname="cause">Мне настолько понравился,</segment>
		<segment id="245" parent="502" relname="span">что хапнула потом в магазине огромный пакет этого чая.</segment>
		<segment id="246" parent="444" relname="same-unit">Теперь,</segment>
		<segment id="247" parent="442" relname="joint">когда навожу</segment>
		<segment id="248" parent="442" relname="joint">и пью его —</segment>
		<segment id="249" parent="443" relname="span">вспоминаю радушную Монголию.</segment>
		<segment id="250" parent="448" relname="span">Состав примерно такой — настой трав (или китайский зеленый чай), крупа, соль, молоко, масло сливочное.</segment>
		<segment id="251" parent="447" relname="span">Можно и буузы туда кинуть, не шутка)</segment>
		<segment id="252" parent="446" relname="joint">Ну а что — быстро</segment>
		<segment id="253" parent="446" relname="joint">и питательно.</segment>
		<segment id="254" parent="468" relname="elaboration">IMG Овощные буузы. IMG Знаменитый чай!</segment>
		<segment id="255" parent="504" relname="preparation">Путешествие заканчивается, пора домой, через Улан-Удэ.</segment>
		<segment id="256" parent="452" relname="contrast">Болор отлично говорит по-русски,</segment>
		<segment id="257" parent="452" relname="contrast">но ни разу не была в России.</segment>
		<segment id="258" parent="453" relname="joint">Мечтает поехать в Москву, причем в Москву и только в Москву)</segment>
		<segment id="259" parent="454" relname="joint">Болор, желаю тебе скорее осуществить эту мечту!)</segment>
		<segment id="260" parent="455" relname="joint">А частичку моей души Монголия забрала навсегда, определённо..</segment>
		<group id="261" type="span" parent="262" relname="joint"/>
		<group id="262" type="multinuc" parent="263" relname="sequence"/>
		<group id="263" type="multinuc" parent="264" relname="span"/>
		<group id="264" type="span" parent="265" relname="span"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" />
		<group id="267" type="multinuc" parent="10" relname="condition"/>
		<group id="268" type="span" parent="269" relname="span"/>
		<group id="269" type="span" parent="270" relname="joint"/>
		<group id="270" type="multinuc" parent="273" relname="span"/>
		<group id="271" type="multinuc" parent="15" relname="elaboration"/>
		<group id="272" type="span" parent="273" relname="cause"/>
		<group id="273" type="span" parent="274" relname="span"/>
		<group id="274" type="span" parent="278" relname="span"/>
		<group id="275" type="multinuc" parent="18" relname="cause"/>
		<group id="276" type="span" parent="275" relname="joint"/>
		<group id="277" type="span" parent="274" relname="elaboration"/>
		<group id="278" type="span" parent="289" relname="joint"/>
		<group id="279" type="multinuc" parent="280" relname="joint"/>
		<group id="280" type="multinuc" parent="281" relname="span"/>
		<group id="281" type="span" parent="282" relname="span"/>
		<group id="282" type="span" parent="284" relname="joint"/>
		<group id="283" type="multinuc" parent="284" relname="joint"/>
		<group id="284" type="multinuc" parent="285" relname="span"/>
		<group id="285" type="span" parent="22" relname="elaboration"/>
		<group id="286" type="span" parent="472" relname="contrast"/>
		<group id="287" type="span" parent="288" relname="joint"/>
		<group id="288" type="multinuc" parent="473" relname="span"/>
		<group id="289" type="multinuc" />
		<group id="290" type="span" parent="507" relname="span"/>
		<group id="291" type="multinuc" parent="508" relname="span"/>
		<group id="292" type="span" parent="295" relname="span"/>
		<group id="293" type="span" parent="511" relname="span"/>
		<group id="294" type="span" parent="292" relname="elaboration"/>
		<group id="295" type="span" />
		<group id="296" type="span" parent="302" relname="span"/>
		<group id="297" type="multinuc" parent="513" relname="elaboration"/>
		<group id="298" type="multinuc" parent="54" relname="cause"/>
		<group id="299" type="span" parent="53" relname="evaluation"/>
		<group id="300" type="span" parent="301" relname="comparison"/>
		<group id="301" type="multinuc" parent="296" relname="evidence"/>
		<group id="302" type="span" parent="45" relname="elaboration"/>
		<group id="303" type="span" parent="511" relname="elaboration"/>
		<group id="304" type="span" parent="459" relname="joint"/>
		<group id="305" type="multinuc" parent="520" relname="elaboration"/>
		<group id="306" type="span" parent="307" relname="joint"/>
		<group id="307" type="multinuc" parent="479" relname="span"/>
		<group id="308" type="span" parent="309" relname="span"/>
		<group id="309" type="span" parent="481" relname="span"/>
		<group id="310" type="span" parent="314" relname="joint"/>
		<group id="311" type="multinuc" parent="522" relname="elaboration"/>
		<group id="312" type="span" parent="482" relname="joint"/>
		<group id="313" type="span" parent="482" relname="joint"/>
		<group id="314" type="multinuc" parent="483" relname="span"/>
		<group id="315" type="span" parent="316" relname="span"/>
		<group id="316" type="span" parent="461" relname="span"/>
		<group id="317" type="span" parent="318" relname="contrast"/>
		<group id="318" type="multinuc" parent="91" relname="elaboration"/>
		<group id="319" type="span" parent="330" relname="sequence"/>
		<group id="320" type="span" parent="326" relname="span"/>
		<group id="321" type="span" parent="320" relname="evaluation"/>
		<group id="322" type="span" parent="324" relname="span"/>
		<group id="323" type="multinuc" parent="484" relname="contrast"/>
		<group id="324" type="span" parent="325" relname="span"/>
		<group id="325" type="span" parent="327" relname="joint"/>
		<group id="326" type="span" parent="327" relname="joint"/>
		<group id="327" type="multinuc" parent="328" relname="span"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="330" relname="sequence"/>
		<group id="330" type="multinuc" />
		<group id="331" type="span" parent="334" relname="span"/>
		<group id="332" type="span" parent="333" relname="contrast"/>
		<group id="333" type="multinuc" parent="334" relname="elaboration"/>
		<group id="334" type="span" parent="335" relname="span"/>
		<group id="335" type="span" parent="486" relname="span"/>
		<group id="336" type="span" parent="488" relname="span"/>
		<group id="337" type="span" parent="346" relname="span"/>
		<group id="338" type="multinuc" parent="337" relname="elaboration"/>
		<group id="339" type="multinuc" parent="124" relname="cause"/>
		<group id="340" type="span" parent="341" relname="contrast"/>
		<group id="341" type="multinuc" parent="122" relname="elaboration"/>
		<group id="342" type="span" parent="338" relname="joint"/>
		<group id="343" type="multinuc" parent="338" relname="joint"/>
		<group id="344" type="span" parent="338" relname="joint"/>
		<group id="345" type="span" parent="489" relname="span"/>
		<group id="346" type="span" parent="347" relname="span"/>
		<group id="347" type="span" parent="116" relname="elaboration"/>
		<group id="348" type="span" parent="349" relname="span"/>
		<group id="349" type="span" parent="351" relname="span"/>
		<group id="350" type="multinuc" parent="349" relname="evaluation"/>
		<group id="351" type="span" parent="354" relname="span"/>
		<group id="352" type="span" parent="491" relname="contrast"/>
		<group id="353" type="span" parent="351" relname="elaboration"/>
		<group id="354" type="span" parent="355" relname="span"/>
		<group id="355" type="span" parent="462" relname="span"/>
		<group id="356" type="span" parent="145" relname="elaboration"/>
		<group id="357" type="span" parent="463" relname="span"/>
		<group id="358" type="multinuc" parent="359" relname="span"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="361" relname="joint"/>
		<group id="361" type="multinuc" parent="148" relname="elaboration"/>
		<group id="362" type="span" parent="364" relname="joint"/>
		<group id="363" type="span" parent="364" relname="joint"/>
		<group id="364" type="multinuc" parent="464" relname="span"/>
		<group id="365" type="multinuc" />
		<group id="366" type="span" parent="389" relname="span"/>
		<group id="367" type="span" parent="366" relname="evidence"/>
		<group id="368" type="multinuc" parent="369" relname="contrast"/>
		<group id="369" type="multinuc" parent="388" relname="joint"/>
		<group id="370" type="span" parent="373" relname="span"/>
		<group id="371" type="span" parent="372" relname="joint"/>
		<group id="372" type="multinuc" parent="387" relname="span"/>
		<group id="373" type="span" parent="388" relname="joint"/>
		<group id="374" type="multinuc" parent="384" relname="span"/>
		<group id="375" type="multinuc" parent="378" relname="span"/>
		<group id="376" type="span" parent="377" relname="comparison"/>
		<group id="377" type="multinuc" parent="378" relname="elaboration"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="173" relname="elaboration"/>
		<group id="380" type="span" parent="383" relname="span"/>
		<group id="381" type="multinuc" parent="179" relname="evaluation"/>
		<group id="382" type="span" parent="380" relname="evaluation"/>
		<group id="383" type="span" parent="384" relname="elaboration"/>
		<group id="384" type="span" parent="385" relname="span"/>
		<group id="385" type="span" parent="387" relname="elaboration"/>
		<group id="386" type="span" parent="370" relname="elaboration"/>
		<group id="387" type="span" parent="386" relname="span"/>
		<group id="388" type="multinuc" parent="391" relname="joint"/>
		<group id="389" type="span" parent="156" relname="elaboration"/>
		<group id="391" type="multinuc" />
		<group id="392" type="multinuc" parent="412" relname="span"/>
		<group id="393" type="multinuc" parent="188" relname="evidence"/>
		<group id="394" type="span" parent="187" relname="evaluation"/>
		<group id="396" type="span" parent="411" relname="joint"/>
		<group id="397" type="multinuc" parent="191" relname="elaboration"/>
		<group id="398" type="span" parent="495" relname="span"/>
		<group id="399" type="span" parent="400" relname="span"/>
		<group id="400" type="span" parent="411" relname="joint"/>
		<group id="401" type="span" parent="398" relname="purpose"/>
		<group id="402" type="multinuc" parent="496" relname="comparison"/>
		<group id="403" type="span" parent="408" relname="joint"/>
		<group id="404" type="multinuc" parent="406" relname="span"/>
		<group id="405" type="multinuc" parent="415" relname="span"/>
		<group id="406" type="span" parent="407" relname="span"/>
		<group id="407" type="span" parent="408" relname="joint"/>
		<group id="408" type="multinuc" parent="409" relname="span"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" parent="197" relname="elaboration"/>
		<group id="411" type="multinuc" parent="412" relname="elaboration"/>
		<group id="412" type="span" parent="413" relname="span"/>
		<group id="413" type="span" parent="414" relname="span"/>
		<group id="414" type="span" parent="469" relname="span"/>
		<group id="415" type="span" parent="416" relname="span"/>
		<group id="416" type="span" parent="205" relname="evidence"/>
		<group id="417" type="multinuc" parent="418" relname="contrast"/>
		<group id="418" type="multinuc" parent="211" relname="cause"/>
		<group id="419" type="span" />
		<group id="421" type="multinuc" parent="498" relname="contrast"/>
		<group id="422" type="span" parent="499" relname="span"/>
		<group id="423" type="multinuc" parent="525" relname="span"/>
		<group id="424" type="span" parent="426" relname="same-unit"/>
		<group id="425" type="multinuc" parent="226" relname="cause"/>
		<group id="426" type="multinuc" parent="427" relname="span"/>
		<group id="427" type="span" parent="428" relname="span"/>
		<group id="428" type="span" parent="431" relname="contrast"/>
		<group id="429" type="span" parent="430" relname="span"/>
		<group id="430" type="span" parent="431" relname="contrast"/>
		<group id="431" type="multinuc" parent="225" relname="elaboration"/>
		<group id="432" type="span" parent="433" relname="span"/>
		<group id="433" type="span" parent="436" relname="comparison"/>
		<group id="434" type="span" parent="435" relname="span"/>
		<group id="435" type="span" parent="436" relname="comparison"/>
		<group id="436" type="multinuc" parent="450" relname="joint"/>
		<group id="437" type="multinuc" parent="438" relname="contrast"/>
		<group id="438" type="multinuc" parent="239" relname="evidence"/>
		<group id="439" type="span" parent="238" relname="cause"/>
		<group id="440" type="span" parent="237" relname="evaluation"/>
		<group id="441" type="span" parent="445" relname="span"/>
		<group id="442" type="multinuc" parent="249" relname="cause"/>
		<group id="443" type="span" parent="444" relname="same-unit"/>
		<group id="444" type="multinuc" parent="502" relname="elaboration"/>
		<group id="445" type="span" parent="449" relname="span"/>
		<group id="446" type="multinuc" parent="251" relname="evaluation"/>
		<group id="447" type="span" parent="250" relname="elaboration"/>
		<group id="448" type="span" parent="445" relname="elaboration"/>
		<group id="449" type="span" parent="466" relname="span"/>
		<group id="450" type="multinuc" parent="468" relname="span"/>
		<group id="451" type="multinuc" />
		<group id="452" type="multinuc" parent="453" relname="joint"/>
		<group id="453" type="multinuc" parent="454" relname="joint"/>
		<group id="454" type="multinuc" parent="455" relname="joint"/>
		<group id="455" type="multinuc" parent="504" relname="span"/>
		<group id="456" type="span" parent="61" relname="elaboration"/>
		<group id="457" type="span" parent="458" relname="joint"/>
		<group id="458" type="multinuc" parent="518" relname="elaboration"/>
		<group id="459" type="multinuc" />
		<group id="460" type="span" parent="479" relname="evaluation"/>
		<group id="461" type="span" />
		<group id="462" type="span" />
		<group id="463" type="span" parent="365" relname="joint"/>
		<group id="464" type="span" parent="465" relname="span"/>
		<group id="465" type="span" parent="365" relname="joint"/>
		<group id="466" type="span" parent="450" relname="joint"/>
		<group id="467" type="span" parent="451" relname="joint"/>
		<group id="468" type="span" parent="467" relname="span"/>
		<group id="469" type="span" />
		<group id="470" type="multinuc" parent="355" relname="elaboration"/>
		<group id="471" type="span" parent="288" relname="joint"/>
		<group id="472" type="multinuc" parent="289" relname="joint"/>
		<group id="473" type="span" parent="474" relname="span"/>
		<group id="474" type="span" parent="472" relname="contrast"/>
		<group id="475" type="span" parent="458" relname="joint"/>
		<group id="476" type="span" parent="477" relname="elaboration"/>
		<group id="477" type="span" parent="520" relname="span"/>
		<group id="478" type="span" parent="459" relname="joint"/>
		<group id="479" type="span" parent="480" relname="span"/>
		<group id="480" type="span" />
		<group id="481" type="span" parent="80" relname="elaboration"/>
		<group id="482" type="multinuc" parent="483" relname="background"/>
		<group id="483" type="span" parent="315" relname="span"/>
		<group id="484" type="multinuc" parent="322" relname="cause"/>
		<group id="485" type="span" parent="335" relname="preparation"/>
		<group id="486" type="span" parent="487" relname="joint"/>
		<group id="487" type="multinuc" />
		<group id="488" type="span" parent="345" relname="background"/>
		<group id="489" type="span" />
		<group id="490" type="span" parent="353" relname="span"/>
		<group id="491" type="multinuc" parent="490" relname="span"/>
		<group id="492" type="span" parent="470" relname="joint"/>
		<group id="493" type="span" parent="359" relname="cause"/>
		<group id="494" type="span" parent="374" relname="joint"/>
		<group id="495" type="span" parent="397" relname="joint"/>
		<group id="496" type="multinuc" parent="199" relname="evaluation"/>
		<group id="497" type="span" parent="404" relname="contrast"/>
		<group id="498" type="multinuc" parent="422" relname="span"/>
		<group id="499" type="span" parent="500" relname="joint"/>
		<group id="500" type="multinuc" parent="501" relname="joint"/>
		<group id="501" type="multinuc" />
		<group id="502" type="span" parent="503" relname="span"/>
		<group id="503" type="span" parent="441" relname="evaluation"/>
		<group id="504" type="span" parent="505" relname="span"/>
		<group id="505" type="span" />
		<group id="506" type="span" parent="262" relname="joint"/>
		<group id="507" type="span" parent="291" relname="joint"/>
		<group id="508" type="span" parent="509" relname="span"/>
		<group id="509" type="span" parent="510" relname="span"/>
		<group id="510" type="span" />
		<group id="511" type="span" parent="294" relname="span"/>
		<group id="512" type="multinuc" parent="513" relname="span"/>
		<group id="513" type="span" parent="514" relname="span"/>
		<group id="514" type="span" parent="301" relname="comparison"/>
		<group id="515" type="span" parent="516" relname="same-unit"/>
		<group id="516" type="multinuc" parent="517" relname="span"/>
		<group id="517" type="span" parent="518" relname="span"/>
		<group id="518" type="span" parent="519" relname="span"/>
		<group id="519" type="span" />
		<group id="520" type="span" parent="478" relname="span"/>
		<group id="521" type="span" parent="306" relname="span"/>
		<group id="522" type="span" parent="312" relname="span"/>
		<group id="523" type="span" parent="170" relname="evaluation"/>
		<group id="524" type="span" parent="397" relname="joint"/>
		<group id="525" type="span" parent="526" relname="span"/>
		<group id="526" type="span" parent="451" relname="joint"/>
		<group id="532" type="span" parent="157" relname="elaboration"/>
		<group id="533" type="span" parent="391" relname="joint"/>
		<group id="534" type="span" parent="186" relname="elaboration"/>
	</body>
</rst>