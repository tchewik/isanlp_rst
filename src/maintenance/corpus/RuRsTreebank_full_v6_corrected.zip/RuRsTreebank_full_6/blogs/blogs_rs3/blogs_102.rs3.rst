<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://ru-travel.livejournal.com/33776347.html</segment>
		<segment id="2" >Неаполь</segment>
		<segment id="3" parent="99" relname="joint">Вечное Солнце горит над Неаполем,</segment>
		<segment id="4" parent="99" relname="joint">Вечное Небо смеется волнам...</segment>
		<segment id="5" parent="100" relname="attribution">(с) Сергей Калугин</segment>
		<segment id="6" parent="102" relname="span">Вот я наконец и побывала в Неаполе,</segment>
		<segment id="7" parent="6" relname="elaboration">о котором поётся в любимой песне.</segment>
		<segment id="8" parent="105" relname="span">Мы заехали туда после посещения Помпей.</segment>
		<segment id="9" parent="10" relname="cause">Правда, экскурсия по Неаполю была очень короткой,</segment>
		<segment id="10" parent="103" relname="span">мы увидели только самый центр города.</segment>
		<segment id="11" parent="103" relname="elaboration">IMG</segment>
		<segment id="12" parent="108" relname="sequence">Неаполь был основан греческими поселенцами в VIII веке до н. э. под названием Партенопа (по имени мифологической сирены).</segment>
		<segment id="13" parent="108" relname="sequence">Впоследствии стал частью Римской республики, а затем — Римской империи.</segment>
		<segment id="14" parent="107" relname="span">В крепости Кастель делль Ово в 476 был заключён после своего свержения Ромул Августул, последний император Западной Римской империи.</segment>
		<segment id="15" parent="14" relname="elaboration">IMG</segment>
		<segment id="16" parent="111" relname="span">В VI веке Неаполь завоевали византийцы</segment>
		<segment id="17" parent="16" relname="cause">в ходе попытки императора Юстиниана I воссоздать Римскую империю.</segment>
		<segment id="18" parent="112" relname="sequence">В 638 — 1137 годах был столицей фактически независимого герцогства Неаполь.</segment>
		<segment id="19" parent="112" relname="sequence">В 1139 году вошёл в состав Сицилийского королевства.</segment>
		<segment id="20" parent="113" relname="span">В 1266 году Неаполь вместе со всем Сицилийским королевством был передан папой Карлу I Анжуйскому,</segment>
		<segment id="21" parent="20" relname="background">который перенёс столицу из Палермо в Неаполь.</segment>
		<segment id="22" parent="182" relname="span">В 1284 году королевство разделилось на две части, из которых каждая выдвигала претензии</segment>
		<segment id="23" parent="22" relname="purpose">на право называться «Королевство Сицилия».</segment>
		<segment id="24" parent="174" relname="span">В XVII веке Неаполь насчитывал 300 тысяч жителей</segment>
		<segment id="25" parent="24" relname="evaluation">и был вторым по величине городом Европы после Парижа.</segment>
		<segment id="26" parent="174" relname="elaboration">Он был славен театром Сан-Карло — в то время самым большим в мире.</segment>
		<segment id="27" parent="186" relname="attribution">В октябре 1860 года в результате референдума был объявлен</segment>
		<segment id="28" parent="114" relname="joint">конец королевства</segment>
		<segment id="29" parent="114" relname="joint">и основание государства Италия.</segment>
		<segment id="30" parent="31" relname="elaboration">IMG</segment>
		<segment id="31" parent="115" relname="span">Первое, что видит любой турист в Неаполе, — это легендарный вулкан Везувий.</segment>
		<segment id="32" parent="115" relname="evaluation">Эта ландшафтная доминанта придает панораме Неаполя удивительный вид.</segment>
		<segment id="33" parent="117" relname="span">Сам Везувий находится в 15 км от города,</segment>
		<segment id="34" parent="116" relname="joint">и это нее только самая известная,</segment>
		<segment id="35" parent="116" relname="joint">но и опасная достопримечательность пригорода — единственный в материковой Европе действующий вулкан.</segment>
		<segment id="36" parent="37" relname="elaboration">IMG</segment>
		<segment id="37" parent="120" relname="span">Мы вышли на Пьяцца-дель-Плебишито (итал. Piazza del Plebiscito).</segment>
		<segment id="38" parent="120" relname="evaluation">Это самая большая площадь в Неаполе, сердце города.</segment>
		<segment id="39" parent="121" relname="background">Здесь в античности стояли греческие городские стены и замок Луцилия.</segment>
		<segment id="40" parent="122" relname="elaboration">Площадь обрамлена Королевским дворцом (длина фасада — 169 м) и, с противоположной стороны, неоклассическим зданием церкви Св. Франциска Паоланского.</segment>
		<segment id="41" parent="126" relname="elaboration">IMG</segment>
		<segment id="42" parent="125" relname="sequence">Работы по сооружению королевского дворца начал Доменико Фонтана,</segment>
		<segment id="43" parent="124" relname="span">а закончил Ванвителли,</segment>
		<segment id="44" parent="43" relname="elaboration">устроивший ниши со статуями неаполитанских правителей.</segment>
		<segment id="45" parent="128" relname="joint">Церковь воздвигнута в 1817-46 годах по проекту Пьетро Бьянки</segment>
		<segment id="46" parent="128" relname="joint">и выделяется огромными крыльями с дорической колоннадой.</segment>
		<segment id="47" parent="130" relname="elaboration">IMG</segment>
		<segment id="48" parent="136" relname="span">С двух других сторон площадь замкнута стилистически близкими постройками: палаццо Салерно и палаццо делла Префеттура.</segment>
		<segment id="49" parent="132" relname="span">Дворец Салерно появился в 1775 году,</segment>
		<segment id="50" parent="49" relname="elaboration">несколько раз эту резиденцию министров бурбонского правительства (до 1825 г.) капитально перестраивали.</segment>
		<segment id="51" parent="134" relname="span">Позднее его фасад был переделан в стиле Дворца префектуры,</segment>
		<segment id="52" parent="133" relname="span">сооружённого в 1815 году зодчим Леопольдо Лаперута,</segment>
		<segment id="53" parent="52" relname="elaboration">вмонтировавшим в южный этаж кафе «Гамбринус».</segment>
		<segment id="54" parent="176" relname="span">Площадь украшают также два конных памятника — Карлу III (скульптор — Антонио Канова) и Фердинанду I (Антонио Кали[it]).</segment>
		<segment id="55" parent="141" relname="elaboration">IMG</segment>
		<segment id="56" parent="185" relname="span">Фердинанд I — король Неаполя в 1458—1494 годах из династии Трастамара</segment>
		<segment id="57" parent="56" relname="elaboration">(в Неаполе называемой обычно Арагонской):</segment>
		<segment id="58" parent="185" relname="elaboration">IMG</segment>
		<segment id="59" parent="144" relname="span">Карл III — король Испании с 1759 года, герцог Пармский (под именем Карл I) в 1731—1734 годах, король Неаполя и Сицилии (под именем Карл VII) в 1734—1759 годах:</segment>
		<segment id="60" parent="59" relname="elaboration">IMG</segment>
		<segment id="61" parent="146" relname="span">Королевский дворец в Неаполе (Палаццо Реале; итал. Palazzo Reale di Napoli) — главная резиденция монархов Королевства Обеих Сицилий из династии Бурбонов.</segment>
		<segment id="62" parent="138" relname="span">Построен вокруг Пьяцца-дель-Плебисчито в Неаполе на месте дворца, выстроенного по проекту Доменико Фонтаны для Филиппа III</segment>
		<segment id="63" parent="62" relname="elaboration">(который никогда не бывал в Неаполе).</segment>
		<segment id="64" parent="139" relname="joint">К строительству приступили в 1600 году</segment>
		<segment id="65" parent="139" relname="joint">и продолжалось оно более 50 лет.</segment>
		<segment id="66" parent="140" relname="sequence">В 1717 г. в том здании укрывался царевич Алексей перед арестом и выдачей в Россию.</segment>
		<segment id="67" parent="147" relname="elaboration">IMG</segment>
		<segment id="68" parent="150" relname="span">Ныне существующее сооружение — плод перестройки, предпринятой в середине XVIII в. под надзором Луиджи Ванвителли.</segment>
		<segment id="69" parent="149" relname="span">Перед западным фасадом дворца установлены статуи величайших правителей в истории королевства, а по сторонам садовых ворот — конные статуи с Аничкова моста в Санкт-Петербурге.</segment>
		<segment id="70" parent="69" relname="elaboration">IMG IMG</segment>
		<segment id="71" parent="152" relname="span">Кастель-Нуово (Castel Nuovo; собств. «новый замок») — замок, возведённый королём Карлом Анжуйским на взморье в Неаполе в связи с переносом столицы его владений из Палермо.</segment>
		<segment id="72" parent="151" relname="sequence">Строительство началось под присмотром французских военных инженеров в 1279 году</segment>
		<segment id="73" parent="151" relname="sequence">и продолжалось три года.</segment>
		<segment id="74" parent="152" relname="elaboration">IMG</segment>
		<segment id="75" parent="154" relname="span">Галерея Умберто I (итал. Galleria Umberto I) — публичная торговая галерея (пассаж) в Неаполе,</segment>
		<segment id="76" parent="75" relname="elaboration">названная в честь короля Италии Умберто I.</segment>
		<segment id="77" parent="157" relname="joint">Здание было построено в 1887—1891 годы,</segment>
		<segment id="78" parent="156" relname="span">и является отправной точкой в многолетней реконструкции Неаполя,</segment>
		<segment id="79" parent="155" relname="joint">которая называлась risanamento (букв. «делать здоровым снова»)</segment>
		<segment id="80" parent="155" relname="joint">и продолжалась до Первой мировой войны.</segment>
		<segment id="81" parent="158" relname="joint">Галерея была спроектирована Эмануэле Рокко,</segment>
		<segment id="82" parent="158" relname="joint">и напоминает галерею Витторио Эмануэле II в Милане.</segment>
		<segment id="83" parent="179" relname="purpose">Галерея была призвана создать общественное пространство в центре Неаполя, объединяющее бизнес, магазины и предприятия питания.</segment>
		<segment id="84" parent="160" relname="elaboration">IMG</segment>
		<segment id="85" parent="161" relname="span">Галерея была официально открыта 10 ноября 1894 года мэром Неаполя Никола Аморе.</segment>
		<segment id="86" parent="85" relname="elaboration">IMG</segment>
		<segment id="87" parent="180" relname="span">Представляет из себя высокое и просторное крестообразное сооружение, увенчанное стеклянным куполом.</segment>
		<segment id="88" parent="87" relname="elaboration">Площадь этих окон 1076 квадратных метра.</segment>
		<segment id="89" parent="162" relname="joint">Имеет четыре сводчатых крыла, одно из которых выходит на улицу Толедо — одну из центральных магистралей города.</segment>
		<segment id="90" parent="162" relname="joint">Здание является частью объекта «Исторический центр города Неаполь» в списке всемирного наследия ЮНЕСКО.</segment>
		<segment id="91" parent="163" relname="elaboration">IMG IMG</segment>
		<segment id="92" parent="164" relname="span">Пол Галереи покрывает мозаика.</segment>
		<segment id="93" parent="181" relname="span">В центре она изображает все двенадцать знаков зодиака.</segment>
		<segment id="94" parent="93" relname="elaboration">Я сфотографировала своего Стрельца: IMG</segment>
		<segment id="95" parent="169" relname="span">В Галерее множество кафешек, баров и магазинчиков,</segment>
		<segment id="96" parent="95" relname="elaboration">вот например мне очень понравился магазин сувенирного фарфора: IMG IMG IMG IMG</segment>
		<segment id="97" parent="171" relname="joint">Наш путь обратно в Рим сопровождал небывало яркий закат: IMG</segment>
		<segment id="98" parent="188" relname="elaboration">В следующем посте расскажу про наше посещение Ватикана.</segment>
		<group id="99" type="multinuc" parent="100" relname="span"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" />
		<group id="102" type="span" parent="105" relname="preparation"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" parent="8" relname="elaboration"/>
		<group id="105" type="span" parent="106" relname="span"/>
		<group id="106" type="span" parent="173" relname="span"/>
		<group id="107" type="span" parent="109" relname="elaboration"/>
		<group id="108" type="multinuc" parent="109" relname="span"/>
		<group id="109" type="span" parent="110" relname="span"/>
		<group id="110" type="span" parent="106" relname="background"/>
		<group id="111" type="span" parent="112" relname="sequence"/>
		<group id="112" type="multinuc" />
		<group id="113" type="span" parent="112" relname="sequence"/>
		<group id="114" type="multinuc" parent="186" relname="span"/>
		<group id="115" type="span" parent="118" relname="span"/>
		<group id="116" type="multinuc" parent="33" relname="evaluation"/>
		<group id="117" type="span" parent="118" relname="elaboration"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" />
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="span"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" />
		<group id="124" type="span" parent="125" relname="sequence"/>
		<group id="125" type="multinuc" parent="126" relname="span"/>
		<group id="126" type="span" parent="127" relname="span"/>
		<group id="127" type="span" parent="129" relname="span"/>
		<group id="128" type="multinuc" parent="130" relname="span"/>
		<group id="129" type="span" />
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" parent="127" relname="elaboration"/>
		<group id="132" type="span" parent="135" relname="sequence"/>
		<group id="133" type="span" parent="51" relname="elaboration"/>
		<group id="134" type="span" parent="135" relname="sequence"/>
		<group id="135" type="multinuc" parent="48" relname="background"/>
		<group id="136" type="span" parent="137" relname="joint"/>
		<group id="137" type="multinuc" parent="141" relname="span"/>
		<group id="138" type="span" parent="61" relname="elaboration"/>
		<group id="139" type="multinuc" parent="140" relname="sequence"/>
		<group id="140" type="multinuc" parent="146" relname="elaboration"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" />
		<group id="143" type="span" parent="145" relname="joint"/>
		<group id="144" type="span" parent="145" relname="joint"/>
		<group id="145" type="multinuc" parent="54" relname="elaboration"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" parent="148" relname="span"/>
		<group id="148" type="span" />
		<group id="149" type="span" parent="68" relname="elaboration"/>
		<group id="150" type="span" parent="177" relname="joint"/>
		<group id="151" type="multinuc" parent="71" relname="elaboration"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" parent="177" relname="joint"/>
		<group id="154" type="span" parent="160" relname="span"/>
		<group id="155" type="multinuc" parent="78" relname="background"/>
		<group id="156" type="span" parent="157" relname="joint"/>
		<group id="157" type="multinuc" parent="159" relname="joint"/>
		<group id="158" type="multinuc" parent="179" relname="span"/>
		<group id="159" type="multinuc" parent="154" relname="elaboration"/>
		<group id="160" type="span" parent="167" relname="span"/>
		<group id="161" type="span" parent="172" relname="joint"/>
		<group id="162" type="multinuc" parent="163" relname="span"/>
		<group id="163" type="span" parent="168" relname="span"/>
		<group id="164" type="span" parent="165" relname="joint"/>
		<group id="165" type="multinuc" parent="188" relname="span"/>
		<group id="167" type="span" parent="172" relname="joint"/>
		<group id="168" type="span" />
		<group id="169" type="span" parent="171" relname="joint"/>
		<group id="171" type="multinuc" parent="165" relname="joint"/>
		<group id="172" type="multinuc" />
		<group id="173" type="span" />
		<group id="174" type="span" parent="175" relname="span"/>
		<group id="175" type="span" parent="112" relname="sequence"/>
		<group id="176" type="span" parent="137" relname="joint"/>
		<group id="177" type="multinuc" />
		<group id="178" type="span" parent="159" relname="joint"/>
		<group id="179" type="span" parent="178" relname="span"/>
		<group id="180" type="span" parent="162" relname="joint"/>
		<group id="181" type="span" parent="92" relname="elaboration"/>
		<group id="182" type="span" parent="112" relname="sequence"/>
		<group id="185" type="span" parent="143" relname="span"/>
		<group id="186" type="span" parent="187" relname="span"/>
		<group id="187" type="span" parent="112" relname="sequence"/>
		<group id="188" type="span" parent="189" relname="span"/>
		<group id="189" type="span" />
	</body>
</rst>