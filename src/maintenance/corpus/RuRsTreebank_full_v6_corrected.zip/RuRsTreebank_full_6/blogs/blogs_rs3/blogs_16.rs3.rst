<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://my-first-time.livejournal.com/569291.html</segment>
		<segment id="2" >Первое маленькое "не слабО"</segment>
		<segment id="3" parent="94" relname="span">Когда мне было лет эдак 12 в наш сибирский городок с первыми лучами мнимой свободы и вседозволенности неожиданно нагрянул заграничный Лунапарк.</segment>
		<segment id="4" parent="3" relname="evaluation">Прям иностранными-иностранным его можно было назвать исключительно условно.</segment>
		<segment id="5" parent="95" relname="span">Не помню уж сейчас откуда это чудо-чудное, диво-дивное на гастроли приехало,</segment>
		<segment id="6" parent="97" relname="span">точно знаю, что из стран околосоветского пространства.</segment>
		<segment id="7" parent="166" relname="joint">Польша?</segment>
		<segment id="8" parent="166" relname="joint">Югославия...Хз. Не суть.</segment>
		<segment id="9" parent="98" relname="span">Средь диковинных сосучих леденцов, круглых, но плоских, предтечи мирового бренда с логотипом от Дали, и таких же, но других конфет в виде маленьких посохов, средь сладкой ваты и непременных жвачек, мечт простого, фактически еще советского ребенка, средь аттракционов</segment>
		<segment id="10" parent="100" relname="contrast">на самом то деле не отличающихся особым разнообразием и выдумкой (как уже понимаешь сейчас),</segment>
		<segment id="11" parent="99" relname="joint">но таких желанных</segment>
		<segment id="12" parent="99" relname="joint">и манких своею новизной,</segment>
		<segment id="13" parent="101" relname="same-unit">средь всего этого фестивально-капустнического великолепия капли цивилизации в далекой провинции,</segment>
		<segment id="14" parent="101" relname="same-unit">была привезена так называемая "Комната страха".</segment>
		<segment id="15" parent="102" relname="span">Помещение с чучелАми невинно убиенных зомби, внезапно возникающими из тьмы.</segment>
		<segment id="16" parent="103" relname="contrast">Любовно зачатый и выношенный плод фантазии нездоровых электриков с художественным видением и оформителей из ясельной группы отряда Тарантино.</segment>
		<segment id="17" parent="105" relname="span">Но, как гриться, много ли надо изголодавшемуся по шоу любителю адреналиновых приливов.</segment>
		<segment id="18" parent="172" relname="span">Все, что было в нашем детстве действительно страшного, это манная каша с комочками и рассказы про гробик и ручечку.</segment>
		<segment id="19" parent="104" relname="span">Непуганое тепличное поколение,</segment>
		<segment id="20" parent="19" relname="condition">живущее в священном безхорроравом вакууме.</segment>
		<segment id="21" parent="104" relname="evaluation">Поле непаханное.</segment>
		<segment id="22" parent="106" relname="span">К ангару с самоходными повозками, двигающимися во мраке на встречу страшному и приключениям, всегда была хвостатая очередь.</segment>
		<segment id="23" parent="22" relname="background">Впрочем, в то время к любому аттракциону Лунапарка махом организовывалось многолюдное поломничество, даже в палатку где кидали дротики.</segment>
		<segment id="24" parent="107" relname="span">В 12 лет, я , катастрофическая трусиха,</segment>
		<segment id="25" parent="24" relname="elaboration">боящаяся темноты и тараканов,</segment>
		<segment id="26" parent="108" relname="same-unit">не просто не решилась посмотреть чего там вкусного дают,</segment>
		<segment id="27" parent="110" relname="span">а на четыре метра кругом обошла жаждущих экстрима храбрецов,</segment>
		<segment id="28" parent="27" relname="condition">оставив сладкое на потом.</segment>
		<segment id="29" parent="113" relname="sequence">Года два-три на летних каникулах увеселительные механизмы вместе с обслуживающим персоналом приезжали к нам еще и еще,</segment>
		<segment id="30" parent="113" relname="sequence">а потом почему-то прекратили.</segment>
		<segment id="31" parent="114" relname="span">Но оставили после себя неизгладимый след в виде осевшей "Комнаты смеха" с дефективно-утилизированными зеркалами и "Комнаты страха"-видимо</segment>
		<segment id="32" parent="31" relname="purpose">для эмоционального контраста.</segment>
		<segment id="33" parent="115" relname="span">Были еще какие-то убогие паровозики,</segment>
		<segment id="34" parent="33" relname="purpose">но это так...для массовости.</segment>
		<segment id="35" parent="119" relname="span">И вот однажды летним днем, я,</segment>
		<segment id="36" parent="118" relname="joint">уже взрослая шестнадцатилетняя кобыла девочка, практически перешагнувшая пубертат с его комплексами</segment>
		<segment id="37" parent="118" relname="joint">и почти вступившая в юношескую жизнь,</segment>
		<segment id="38" parent="120" relname="same-unit">решила погулять на все деньги.</segment>
		<segment id="39" parent="174" relname="joint">Испытать себя я решила.</segment>
		<segment id="40" parent="41" relname="solutionhood">"А слабо Вольдемару в фонтан прыгнуть?",- ассоциативно пронеслось у меня в голове.</segment>
		<segment id="41" parent="121" relname="span">И в руках появился заветный билетик.</segment>
		<segment id="42" parent="128" relname="joint">Дорога в ад была на редкость свободна.</segment>
		<segment id="43" parent="127" relname="joint">День стоял жаркий,</segment>
		<segment id="44" parent="125" relname="span">да и земляки,</segment>
		<segment id="45" parent="44" relname="elaboration">лениво передвигавшиеся по раскаленному асфальту парка с многообещающим названием "Зеленый остров",</segment>
		<segment id="46" parent="126" relname="same-unit">явно присытились острыми ощущениями от плохо сделанных кукол с лампочками в жопе вместо глаз.</segment>
		<segment id="47" parent="137" relname="contrast">Это был мой звездный час.</segment>
		<segment id="48" parent="130" relname="same-unit">Но,</segment>
		<segment id="49" parent="50" relname="cause">как человек предусмотрительный,</segment>
		<segment id="50" parent="129" relname="span">одна я в машинку не села.</segment>
		<segment id="51" parent="131" relname="span">Рядом со мною решила потрястись в мелкой дрожи моя любимая подруженька Таня</segment>
		<segment id="52" parent="51" relname="evaluation">(дай ей бог здоровьица).</segment>
		<segment id="53" parent="136" relname="span">Собственно у неё и выбора-то не было.</segment>
		<segment id="54" parent="55" relname="attribution">Партия сказала</segment>
		<segment id="55" parent="177" relname="span">:"Надо!".</segment>
		<segment id="56" parent="57" relname="attribution">"Комсомол ответил</segment>
		<segment id="57" parent="178" relname="span">:"Есть!".</segment>
		<segment id="58" parent="134" relname="span">Я всегда была тираном,</segment>
		<segment id="59" parent="58" relname="background">просто в юности тренировалась только на подругах.</segment>
		<segment id="60" parent="61" relname="condition">До того, как нас засосало разверзшееся чрево черной пустоты, наполненное неизвестностью,</segment>
		<segment id="61" parent="141" relname="span">я старалась вести себя прилично.</segment>
		<segment id="62" parent="141" relname="elaboration">Даже истерично шутила на нервяке.</segment>
		<segment id="63" parent="64" relname="condition">Попавши внутрь аттракциона, где-то примерно метра три, это конечно строго по ощущениям, без компаса,</segment>
		<segment id="64" parent="143" relname="span">вцепилась в руку подруги</segment>
		<segment id="65" parent="145" relname="span">и пришибленно замолчала,</segment>
		<segment id="66" parent="65" relname="evaluation">адаптируясь к действительности.</segment>
		<segment id="67" parent="146" relname="joint">Потом что-то бумкнуло,</segment>
		<segment id="68" parent="146" relname="joint">крякнуло,</segment>
		<segment id="69" parent="146" relname="joint">засвистело,</segment>
		<segment id="70" parent="146" relname="joint">загоношилось</segment>
		<segment id="71" parent="147" relname="span">и эффектно засверкало красными очами-лампочками.</segment>
		<segment id="72" parent="71" relname="evaluation">Вспышка справа!(с)</segment>
		<segment id="73" parent="148" relname="joint">Паровозик со смертниками качнуло</segment>
		<segment id="74" parent="148" relname="joint">и подбросило.</segment>
		<segment id="75" parent="76" relname="cause">На голову упала чья-то костлявая рука,</segment>
		<segment id="76" parent="150" relname="span">а вместе с нею опало куда-то вниз все мое самообладание.</segment>
		<segment id="77" parent="179" relname="comparison">Воздух вокруг наполнился бухающими и вибрирующими звуками,</segment>
		<segment id="78" parent="179" relname="comparison">напоминавшими то ли предродовые стоны в кабинете стоматолога, то ли позывной общий.</segment>
		<segment id="79" parent="155" relname="joint">Я заорала дурным голосом нечленораздельное</segment>
		<segment id="80" parent="153" relname="span">и с размаху,</segment>
		<segment id="81" parent="80" relname="condition">разрезая клювом атмосферу,</segment>
		<segment id="82" parent="156" relname="span">уткнулась фасадной стороной туловища прямо в колени Татьяны.</segment>
		<segment id="83" parent="160" relname="span">Весь последующий путь там и провела.</segment>
		<segment id="84" parent="159" relname="joint">За пределами безопасности Таниных конечностей что-то грохотало,</segment>
		<segment id="85" parent="159" relname="joint">выло</segment>
		<segment id="86" parent="159" relname="joint">и яростно трещало,</segment>
		<segment id="87" parent="159" relname="joint">звало открыть глаза</segment>
		<segment id="88" parent="159" relname="joint">и принять бой.</segment>
		<segment id="89" parent="161" relname="contrast">Но так и не заставило меня поднять голову.</segment>
		<segment id="90" parent="91" relname="evaluation">Сложно сказать,</segment>
		<segment id="91" parent="180" relname="span">что испытывала при этом моя подруга,</segment>
		<segment id="92" parent="162" relname="contrast">но на божьем свету он смеялась сильно.</segment>
		<segment id="93" parent="163" relname="contrast">Однако галочку в тетрадочке о победе над собой я таки поставила.</segment>
		<group id="94" type="span" parent="96" relname="span"/>
		<group id="95" type="span" parent="94" relname="elaboration"/>
		<group id="96" type="span" />
		<group id="97" type="span" parent="5" relname="elaboration"/>
		<group id="98" type="span" parent="101" relname="same-unit"/>
		<group id="99" type="multinuc" parent="100" relname="contrast"/>
		<group id="100" type="multinuc" parent="9" relname="elaboration"/>
		<group id="101" type="multinuc" parent="171" relname="joint"/>
		<group id="102" type="span" parent="171" relname="joint"/>
		<group id="103" type="multinuc" parent="15" relname="evaluation"/>
		<group id="104" type="span" parent="173" relname="span"/>
		<group id="105" type="span" parent="103" relname="contrast"/>
		<group id="106" type="span" parent="111" relname="preparation"/>
		<group id="107" type="span" parent="108" relname="same-unit"/>
		<group id="108" type="multinuc" parent="109" relname="contrast"/>
		<group id="109" type="multinuc" parent="111" relname="span"/>
		<group id="110" type="span" parent="109" relname="contrast"/>
		<group id="111" type="span" parent="112" relname="span"/>
		<group id="112" type="span" />
		<group id="113" type="multinuc" parent="116" relname="contrast"/>
		<group id="114" type="span" parent="117" relname="joint"/>
		<group id="115" type="span" parent="117" relname="joint"/>
		<group id="116" type="multinuc" parent="123" relname="preparation"/>
		<group id="117" type="multinuc" parent="116" relname="contrast"/>
		<group id="118" type="multinuc" parent="35" relname="elaboration"/>
		<group id="119" type="span" parent="120" relname="same-unit"/>
		<group id="120" type="multinuc" parent="174" relname="joint"/>
		<group id="121" type="span" parent="122" relname="elaboration"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" parent="124" relname="span"/>
		<group id="124" type="span" />
		<group id="125" type="span" parent="126" relname="same-unit"/>
		<group id="126" type="multinuc" parent="127" relname="joint"/>
		<group id="127" type="multinuc" parent="128" relname="joint"/>
		<group id="128" type="multinuc" parent="175" relname="span"/>
		<group id="129" type="span" parent="130" relname="same-unit"/>
		<group id="130" type="multinuc" parent="140" relname="span"/>
		<group id="131" type="span" parent="139" relname="span"/>
		<group id="132" type="multinuc" parent="133" relname="span"/>
		<group id="133" type="span" parent="135" relname="span"/>
		<group id="134" type="span" parent="133" relname="evaluation"/>
		<group id="135" type="span" parent="53" relname="elaboration"/>
		<group id="136" type="span" parent="131" relname="elaboration"/>
		<group id="137" type="multinuc" parent="175" relname="elaboration"/>
		<group id="138" type="span" parent="137" relname="contrast"/>
		<group id="139" type="span" parent="140" relname="elaboration"/>
		<group id="140" type="span" parent="138" relname="span"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="151" relname="sequence"/>
		<group id="143" type="span" parent="144" relname="joint"/>
		<group id="144" type="multinuc" parent="151" relname="sequence"/>
		<group id="145" type="span" parent="144" relname="joint"/>
		<group id="146" type="multinuc" parent="151" relname="sequence"/>
		<group id="147" type="span" parent="146" relname="joint"/>
		<group id="148" type="multinuc" parent="149" relname="sequence"/>
		<group id="149" type="multinuc" parent="158" relname="span"/>
		<group id="150" type="span" parent="149" relname="sequence"/>
		<group id="151" type="multinuc" />
		<group id="153" type="span" parent="154" relname="same-unit"/>
		<group id="154" type="multinuc" parent="155" relname="joint"/>
		<group id="155" type="multinuc" parent="170" relname="sequence"/>
		<group id="156" type="span" parent="154" relname="same-unit"/>
		<group id="157" type="span" parent="170" relname="sequence"/>
		<group id="158" type="span" parent="157" relname="span"/>
		<group id="159" type="multinuc" parent="83" relname="elaboration"/>
		<group id="160" type="span" parent="161" relname="contrast"/>
		<group id="161" type="multinuc" parent="82" relname="elaboration"/>
		<group id="162" type="multinuc" parent="163" relname="contrast"/>
		<group id="163" type="multinuc" parent="167" relname="evaluation"/>
		<group id="164" type="span" parent="165" relname="span"/>
		<group id="165" type="span" />
		<group id="166" type="multinuc" parent="6" relname="elaboration"/>
		<group id="167" type="span" parent="164" relname="span"/>
		<group id="170" type="multinuc" parent="167" relname="span"/>
		<group id="171" type="multinuc" />
		<group id="172" type="span" parent="17" relname="background"/>
		<group id="173" type="span" parent="18" relname="evaluation"/>
		<group id="174" type="multinuc" parent="122" relname="span"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" />
		<group id="177" type="span" parent="132" relname="joint"/>
		<group id="178" type="span" parent="132" relname="joint"/>
		<group id="179" type="multinuc" parent="158" relname="elaboration"/>
		<group id="180" type="span" parent="162" relname="contrast"/>
	</body>
</rst>