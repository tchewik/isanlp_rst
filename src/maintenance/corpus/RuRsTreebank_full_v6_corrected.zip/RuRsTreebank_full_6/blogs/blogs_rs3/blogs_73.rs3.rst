<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://veronikahlebova.ru/mozhno-li-delitsya-chuvstvami-s-detmi-i-esli-da-to-kakimi/</segment>
		<segment id="2" >Можно ли делиться чувствами с детьми? И если — да, то какими?</segment>
		<segment id="3" parent="167" relname="span">Когда-то я не рассказывала близким людям о том, что я чувствую.</segment>
		<segment id="4" parent="3" relname="cause">Не было такой привычки.</segment>
		<segment id="5" parent="154" relname="joint">Я никогда не видела, чтобы члены моей родительской семьи говорили о своих чувствах.</segment>
		<segment id="6" parent="7" relname="attribution">И еще признавали,</segment>
		<segment id="7" parent="153" relname="span">что это их собственные чувства, по какому-то поводу.</segment>
		<segment id="8" parent="80" relname="span">Зато в нашей родительской семье все друг от друга чего-то ждали.</segment>
		<segment id="9" parent="10" relname="attribution">И, кстати, даже говорили о том,</segment>
		<segment id="10" parent="148" relname="span">какой они хотят меня видеть.</segment>
		<segment id="11" parent="78" relname="contrast">А иногда не говорили,</segment>
		<segment id="12" parent="81" relname="span">но я сама знала, что нужно делать,</segment>
		<segment id="13" parent="12" relname="purpose">чтобы понравиться.</segment>
		<segment id="14" parent="84" relname="same-unit">…Как-то раз,</segment>
		<segment id="15" parent="16" relname="condition">когда мои дети были младшими школьниками,</segment>
		<segment id="16" parent="83" relname="span">я обратила на это внимание.</segment>
		<segment id="17" parent="85" relname="contrast">Я ничего не говорила о себе.</segment>
		<segment id="18" parent="85" relname="contrast">Нет, мы, конечно, что-то обсуждали.</segment>
		<segment id="19" parent="86" relname="contrast">Но меня как будто в пространстве отношений не было.</segment>
		<segment id="20" parent="93" relname="preparation">Я задумалась о том, насколько я могу делиться своими чувствами с детьми.</segment>
		<segment id="21" parent="87" relname="span">Интуитивно я догадывалась, что какие-то чувства нельзя им доверять.</segment>
		<segment id="22" parent="21" relname="cause">Что это была бы слишком тяжелая ноша.</segment>
		<segment id="23" parent="88" relname="joint">Но какие-то можно,</segment>
		<segment id="24" parent="88" relname="joint">и даже нужно.</segment>
		<segment id="25" parent="90" relname="joint">Чтобы внести себя в пространство отношений,</segment>
		<segment id="26" parent="90" relname="joint">чтобы в них быть.</segment>
		<segment id="27" parent="95" relname="span">Я начала делиться, про то, что я зла,</segment>
		<segment id="28" parent="27" relname="cause">потому что у меня был тяжелый день,</segment>
		<segment id="29" parent="96" relname="span">и мне нужно отдохнуть.</segment>
		<segment id="30" parent="168" relname="joint">Еще я могла рассказать что у меня нет сил,</segment>
		<segment id="31" parent="168" relname="joint">и мне нужно побыть немного «для себя».</segment>
		<segment id="32" parent="33" relname="condition">А когда я побуду «для себя»,</segment>
		<segment id="33" parent="99" relname="span">я снова вернусь к детям.</segment>
		<segment id="34" parent="169" relname="span">Постепенно я заметила, что и дети стали выражать простые чувства.</segment>
		<segment id="35" parent="102" relname="joint">«Мне грустно,</segment>
		<segment id="36" parent="102" relname="joint">хочется поплакать».</segment>
		<segment id="37" parent="103" relname="joint">«Мне скучно,</segment>
		<segment id="38" parent="103" relname="joint">я не могу слушать твою серьезную книгу».</segment>
		<segment id="39" parent="105" relname="contrast">Одновременно я училась не предугадывать, что хочет тот или иной член семьи.</segment>
		<segment id="40" parent="106" relname="span">Но я училась слышать, что они чувствуют,</segment>
		<segment id="41" parent="40" relname="cause">в ответ на мои слова, или действия.</segment>
		<segment id="42" parent="164" relname="span">Легче было с детьми, и сложнее со взрослыми членами семьи.</segment>
		<segment id="43" parent="42" relname="elaboration">Теперь я могу объяснить этот феномен.</segment>
		<segment id="44" parent="113" relname="cause">Взрослые уже находятся в защитах,</segment>
		<segment id="45" parent="112" relname="same-unit">и</segment>
		<segment id="46" parent="110" relname="condition">при малейшей угрозе атаки на свою уязвимость</segment>
		<segment id="47" parent="109" relname="joint">они начинают нападать</segment>
		<segment id="48" parent="109" relname="joint">или защищаться.</segment>
		<segment id="49" parent="114" relname="elaboration">Много сил уходит на эти ритуальные танцы. Иногда – с нулевым результатом.</segment>
		<segment id="50" parent="117" relname="span">С детьми легче,</segment>
		<segment id="51" parent="116" relname="joint">потому что они еще не перегружены защитами,</segment>
		<segment id="52" parent="116" relname="joint">и все еще доверяют.</segment>
		<segment id="53" parent="118" relname="joint">И, если они замечают, что их слышат,</segment>
		<segment id="54" parent="118" relname="joint">и принимают в расчет,</segment>
		<segment id="55" parent="119" relname="span">защиты и не появляются.</segment>
		<segment id="56" parent="119" relname="elaboration">Пространство отношений так и остается открытым.</segment>
		<segment id="57" parent="126" relname="condition">Одновременно я замечала, когда я перегибаю палку с чувствами.</segment>
		<segment id="58" parent="126" relname="span">Дети явно давали понять, что им пока тяжело вынести.</segment>
		<segment id="59" parent="125" relname="joint">Они уходили из разговора</segment>
		<segment id="60" parent="125" relname="joint">или начинали злиться.</segment>
		<segment id="61" parent="147" relname="span">Я поняла, что ни в коем случае нельзя нагружать детей, как минимум, до определенного возраста, своими чувствами из отношений с другими взрослыми людьми. С бабушкой, с папой, или с подругой.</segment>
		<segment id="62" parent="61" relname="cause">Взрослые дела – это взрослые дела.</segment>
		<segment id="63" parent="128" relname="contrast">Нельзя загружать их своими детскими травмами.</segment>
		<segment id="64" parent="129" relname="same-unit">Нет, можно рассказать, что в детстве у вас не было своего айфона.</segment>
		<segment id="65" parent="132" relname="span">Но без эмоциональной нагрузки.</segment>
		<segment id="66" parent="131" relname="same-unit">А она,</segment>
		<segment id="67" parent="68" relname="condition">если вы понаблюдаете за собой,</segment>
		<segment id="68" parent="130" relname="span">вполне возможна.</segment>
		<segment id="69" parent="133" relname="span">Возможна зависть, злость, и другие чувства, которые идут из вашей детской части.</segment>
		<segment id="70" parent="69" relname="elaboration">Ну, как будто вы не родитель, а такой же ребенок, только менее удачливый.</segment>
		<segment id="71" parent="139" relname="span">Есть много чего еще, чем нельзя нагружать детей.</segment>
		<segment id="72" parent="71" relname="elaboration">Все случаи не опишешь.</segment>
		<segment id="73" parent="74" relname="condition">Однако если вы будете внимательны к своим детям,</segment>
		<segment id="74" parent="171" relname="span">вы сами заметите, что они не хотят слышать,</segment>
		<segment id="75" parent="171" relname="cause">в виду того, что некоторые ваши чувства – это не их зона ответственности.</segment>
		<group id="78" type="multinuc" parent="79" relname="contrast"/>
		<group id="79" type="multinuc" parent="8" relname="elaboration"/>
		<group id="80" type="span" parent="82" relname="contrast"/>
		<group id="81" type="span" parent="78" relname="contrast"/>
		<group id="82" type="multinuc" parent="143" relname="span"/>
		<group id="83" type="span" parent="84" relname="same-unit"/>
		<group id="84" type="multinuc" parent="145" relname="span"/>
		<group id="85" type="multinuc" parent="86" relname="contrast"/>
		<group id="86" type="multinuc" parent="145" relname="elaboration"/>
		<group id="87" type="span" parent="89" relname="contrast"/>
		<group id="88" type="multinuc" parent="92" relname="span"/>
		<group id="89" type="multinuc" parent="93" relname="span"/>
		<group id="90" type="multinuc" parent="92" relname="purpose"/>
		<group id="91" type="span" parent="101" relname="span"/>
		<group id="92" type="span" parent="91" relname="span"/>
		<group id="93" type="span" parent="94" relname="span"/>
		<group id="94" type="span" />
		<group id="95" type="span" parent="29" relname="cause"/>
		<group id="96" type="span" parent="100" relname="joint"/>
		<group id="98" type="multinuc" parent="100" relname="joint"/>
		<group id="99" type="span" parent="98" relname="sequence"/>
		<group id="100" type="multinuc" parent="91" relname="elaboration"/>
		<group id="101" type="span" parent="89" relname="contrast"/>
		<group id="102" type="multinuc" parent="104" relname="joint"/>
		<group id="103" type="multinuc" parent="104" relname="joint"/>
		<group id="104" type="multinuc" parent="34" relname="elaboration"/>
		<group id="105" type="multinuc" parent="108" relname="joint"/>
		<group id="106" type="span" parent="105" relname="contrast"/>
		<group id="108" type="multinuc" />
		<group id="109" type="multinuc" parent="110" relname="span"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="112" relname="same-unit"/>
		<group id="112" type="multinuc" parent="113" relname="span"/>
		<group id="113" type="span" parent="114" relname="span"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="122" relname="comparison"/>
		<group id="116" type="multinuc" parent="50" relname="cause"/>
		<group id="117" type="span" parent="121" relname="span"/>
		<group id="118" type="multinuc" parent="55" relname="condition"/>
		<group id="119" type="span" parent="120" relname="span"/>
		<group id="120" type="span" parent="117" relname="elaboration"/>
		<group id="121" type="span" parent="122" relname="comparison"/>
		<group id="122" type="multinuc" parent="165" relname="span"/>
		<group id="125" type="multinuc" parent="58" relname="elaboration"/>
		<group id="126" type="span" parent="170" relname="span"/>
		<group id="128" type="multinuc" parent="136" relname="joint"/>
		<group id="129" type="multinuc" parent="128" relname="contrast"/>
		<group id="130" type="span" parent="131" relname="same-unit"/>
		<group id="131" type="multinuc" parent="134" relname="span"/>
		<group id="132" type="span" parent="129" relname="same-unit"/>
		<group id="133" type="span" parent="134" relname="elaboration"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="65" relname="elaboration"/>
		<group id="136" type="multinuc" parent="137" relname="span"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" />
		<group id="139" type="span" parent="142" relname="contrast"/>
		<group id="142" type="multinuc" />
		<group id="143" type="span" parent="144" relname="span"/>
		<group id="144" type="span" />
		<group id="145" type="span" parent="146" relname="span"/>
		<group id="146" type="span" />
		<group id="147" type="span" parent="136" relname="joint"/>
		<group id="148" type="span" parent="79" relname="contrast"/>
		<group id="153" type="span" parent="154" relname="joint"/>
		<group id="154" type="multinuc" parent="82" relname="contrast"/>
		<group id="164" type="span" parent="165" relname="preparation"/>
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" />
		<group id="167" type="span" parent="143" relname="preparation"/>
		<group id="168" type="multinuc" parent="98" relname="sequence"/>
		<group id="169" type="span" parent="108" relname="joint"/>
		<group id="170" type="span" parent="137" relname="preparation"/>
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" parent="142" relname="contrast"/>
	</body>
</rst>