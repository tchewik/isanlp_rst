<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://wolonter.blogspot.com/2016/06/blog-post_21.html</segment>
		<segment id="2" >О менеджерах, тестировщиках и их отношениях</segment>
		<segment id="3" parent="229" relname="preparation">Текст моего выступления на внутренней конференции в Контуре.</segment>
		<segment id="4" parent="228" relname="joint">О менеджерах и тестировщиках.</segment>
		<segment id="5" parent="228" relname="joint">Ссылка на презентацию</segment>
		<segment id="6" parent="234" relname="contrast">Я недавно работаю в контуре, всего год.</segment>
		<segment id="7" parent="231" relname="comparison">Но до сих пор у меня не проходит ощущение новизны,</segment>
		<segment id="8" parent="231" relname="comparison">как будто я только что пришел месяц.</segment>
		<segment id="9" parent="232" relname="evaluation">Гуда не взгляни - везде необычное. Непонятное.</segment>
		<segment id="10" parent="240" relname="span">У нас - все очень любят контур, коллег и проект.</segment>
		<segment id="11" parent="239" relname="span">Я еще ни в одной компании этого не видел.</segment>
		<segment id="12" parent="236" relname="condition">Когда спрашиваешь о работе</segment>
		<segment id="13" parent="235" relname="contrast">люди начинают рассказывать не о том, что они кладут кирпичи,</segment>
		<segment id="14" parent="235" relname="contrast">а о том, что строят красивое здание.</segment>
		<segment id="15" parent="237" relname="evaluation">Я так не умею.</segment>
		<segment id="16" parent="244" relname="span">Кроме очевидных проблем это дает некоторые преимущества.</segment>
		<segment id="17" parent="242" relname="condition">Пока я еще не влюбился в это великолепие окончательно,</segment>
		<segment id="18" parent="241" relname="joint">я могу заметить что-нибудь интересное</segment>
		<segment id="19" parent="241" relname="joint">и сравнить.</segment>
		<segment id="20" parent="249" relname="span">Собственно, этим и хотелось бы поделиться.</segment>
		<segment id="21" parent="246" relname="sequence">Я считаю, что нашел конфликт между менеджером и тестировщиком</segment>
		<segment id="22" parent="246" relname="sequence">и сейчас рассмотрю его. С каждой стороны.</segment>
		<segment id="23" parent="247" relname="evaluation">Возможно, у меня даже есть решение.</segment>
		<segment id="24" parent="251" relname="span">Итак, конфликт.</segment>
		<segment id="25" parent="250" relname="contrast">1. Матерым тестерам мало платят.</segment>
		<segment id="26" parent="250" relname="contrast">2. Опытным тестерам вообще-то не за что платить много</segment>
		<segment id="27" parent="28" relname="solutionhood">Я думаю, что эту проблему можно решить.</segment>
		<segment id="28" parent="436" relname="span">коллизия ожиданий, требований, диалога и немного квалификации.</segment>
		<segment id="29" parent="436" relname="evaluation">Вообще, я считаю, что менеджер разработки - твой начальник - это очень важное в работе.</segment>
		<segment id="30" parent="255" relname="contrast">В айти увольняются от начальников.</segment>
		<segment id="31" parent="253" relname="joint">Я еще и нанимаюсь к начальникам.</segment>
		<segment id="32" parent="254" relname="span">И предлагаю страшную штуку.</segment>
		<segment id="33" parent="32" relname="elaboration">Работать с ними.</segment>
		<segment id="34" parent="388" relname="preparation">Я готовился к докладу.</segment>
		<segment id="35" parent="257" relname="joint">Я ходил по менеджерам проектов</segment>
		<segment id="36" parent="257" relname="joint">и задавал им разные вопросы, типа "А зачем вы наняли тестеров?" "А чего вы от них требуете?"</segment>
		<segment id="37" parent="258" relname="joint">Еще я спрашивал многих тестировщиков "а что от вас требуют менеджеры?"</segment>
		<segment id="38" parent="259" relname="joint">И знаете - каждый проект уникален.</segment>
		<segment id="39" parent="259" relname="joint">И каждый специалист уникален.</segment>
		<segment id="40" parent="259" relname="joint">И каждый менеджер уникален.</segment>
		<segment id="41" parent="260" relname="comparison">Как снежинки. Уникальные люди-снежинки.</segment>
		<segment id="42" parent="262" relname="condition">Я думаю, что если не решить,</segment>
		<segment id="43" parent="261" relname="joint">то снизить накал можно,</segment>
		<segment id="44" parent="261" relname="joint">посмотреть на мир с другой стороны.</segment>
		<segment id="45" parent="390" relname="span">Я надеюсь, тут вам может помочь моя модель производства.</segment>
		<segment id="46" parent="265" relname="joint">Я работаю в рамках модели, которую я для себя сформулировал</segment>
		<segment id="47" parent="265" relname="joint">и сейчас попытаюсь поделиться ею с вами.</segment>
		<segment id="48" parent="267" relname="span">Группа разработки это черный ящик,</segment>
		<segment id="49" parent="266" relname="sequence">в который попадает куча всего,</segment>
		<segment id="50" parent="266" relname="sequence">а на выходе вылетают фичи,</segment>
		<segment id="51" parent="267" relname="background">внутри черного ящика - тестеры и разработчики.</segment>
		<segment id="52" parent="438" relname="elaboration">Продукт черного ящика - фичи</segment>
		<segment id="53" parent="269" relname="span">Зачем нужен тестировщик:</segment>
		<segment id="54" parent="268" relname="joint">тестировщик это такая очень дорогая линейка которую менеджер незадолго до релиза может приложить к фиче.</segment>
		<segment id="55" parent="268" relname="joint">И заранее совершить управляющее воздействие.</segment>
		<segment id="56" parent="271" relname="span">Чего хочет менеджер:</segment>
		<segment id="57" parent="270" relname="joint">Отсутствия сюрпризов как минимум</segment>
		<segment id="58" parent="270" relname="joint">и попасть в окно качества как норма.</segment>
		<segment id="59" parent="273" relname="span">Что может</segment>
		<segment id="60" parent="272" relname="joint">- отложить</segment>
		<segment id="61" parent="272" relname="joint">и подвигать окно качества.</segment>
		<segment id="62" parent="275" relname="span">В рамках этой модели первое что должен сделать тестировщик на новом проекте</segment>
		<segment id="63" parent="62" relname="elaboration">- отрастить себе линейку -</segment>
		<segment id="64" parent="276" relname="same-unit">научиться искать баги в проекте.</segment>
		<segment id="65" parent="277" relname="joint">Как правило на это тратится от двух дней до полугода</segment>
		<segment id="66" parent="277" relname="joint">и это первое что требуют от тестеров</segment>
		<segment id="67" parent="397" relname="span">и это то, за что платят.</segment>
		<segment id="68" parent="280" relname="span">Тестировщики нормальные люди.</segment>
		<segment id="69" parent="278" relname="span">Они помнят, что в начале им давали деньги за то,</segment>
		<segment id="70" parent="69" relname="cause">что они хорошо искали.</segment>
		<segment id="71" parent="395" relname="span">И стараются - ищут еще лучше.</segment>
		<segment id="72" parent="396" relname="comparison">Кто работал в проекте с более чем 100 открытых багов?</segment>
		<segment id="73" parent="396" relname="comparison">У кого их сейчас болше 100? 200? 300?</segment>
		<segment id="74" parent="292" relname="solutionhood">Теперь помните я вас спрашивал про количество открытых багов и сходимость?</segment>
		<segment id="75" parent="292" relname="span">Открываю тайну.</segment>
		<segment id="76" parent="284" relname="span">У нас с вами не космос, а крайне терпимые к дефектам продукты.</segment>
		<segment id="77" parent="283" relname="joint">В них полно багов</segment>
		<segment id="78" parent="283" relname="joint">и мы принципиально не хотим их исправлять.</segment>
		<segment id="79" parent="401" relname="span">Менеджеры это отлично понимают.</segment>
		<segment id="80" parent="285" relname="joint">У каждого есть коридор</segment>
		<segment id="81" parent="285" relname="joint">и именно в него надо попасть.</segment>
		<segment id="82" parent="286" relname="contrast">Лучше - не надо.</segment>
		<segment id="83" parent="286" relname="contrast">Лучше - плохо.</segment>
		<segment id="84" parent="290" relname="span">У каждого тестера в истории есть отрицательная сходимость дефектов и сотни незакрытых багов.</segment>
		<segment id="85" parent="84" relname="elaboration">Это признак overskill тестера.</segment>
		<segment id="86" parent="289" relname="contrast">Ему бы в космическую отрасль,</segment>
		<segment id="87" parent="289" relname="contrast">а он у нас и не понимает, что лучше чем коридор качества менеджера - не нужно.</segment>
		<segment id="88" parent="294" relname="preparation">История.</segment>
		<segment id="89" parent="293" relname="restatement">Четыре года назад мы вместе с Юлей проводили чистку багов</segment>
		<segment id="90" parent="293" relname="restatement">- снижали когнитивную нагрузку на людей.</segment>
		<segment id="91" parent="297" relname="span">Что мы делали</segment>
		<segment id="92" parent="296" relname="sequence">- мы взяли 300 открытых багов</segment>
		<segment id="93" parent="296" relname="sequence">и не глядя закрыли сто.</segment>
		<segment id="94" parent="298" relname="joint">Никто не умер.</segment>
		<segment id="95" parent="298" relname="joint">Нагрузка стала ниже.</segment>
		<segment id="96" parent="299" relname="joint">Но милые и замечательные девочки тестировщицы чуть ли не со слезами на глазах подбегали,</segment>
		<segment id="97" parent="299" relname="joint">требовали переоткрытия.</segment>
		<segment id="98" parent="300" relname="evaluation">Мы перечеркнули ценность их работы, смысл их деятельности.</segment>
		<segment id="99" parent="100" relname="preparation">Выводы:</segment>
		<segment id="100" parent="310" relname="span">менеджеры. Передавайте знания о приоритетах.</segment>
		<segment id="101" parent="307" relname="span">Не посылайте тестеров на курсы</segment>
		<segment id="102" parent="306" relname="comparison">где учат искать лучше</segment>
		<segment id="103" parent="306" relname="comparison">чем вам надо.</segment>
		<segment id="104" parent="308" relname="span">Не поощряйте тщательную проверку там</segment>
		<segment id="105" parent="104" relname="elaboration">где она не нужна.</segment>
		<segment id="106" parent="311" relname="elaboration">Тестировщик должен находить ровно столько багов, сколько починят. Не меньше. Но и не больше.</segment>
		<segment id="107" parent="314" relname="span">Тестировщики. Мы делаем говно с тараканами.</segment>
		<segment id="108" parent="107" relname="elaboration">Продукты толерантные к большому количеству дефектов.</segment>
		<segment id="109" parent="315" relname="span">Смиритесь.</segment>
		<segment id="110" parent="405" relname="solutionhood">Что дальше?</segment>
		<segment id="111" parent="405" relname="span">Дальше менеджер желает знать о качестве не только за день до, но и раньше.</segment>
		<segment id="112" parent="439" relname="span">Это тест-аналитика, тест-ферст, пороги входа в тестирования, инструменты для разработчиков и стандарты качества.</segment>
		<segment id="113" parent="112" relname="elaboration">Они позволяют измерять раньше.</segment>
		<segment id="114" parent="440" relname="span">И частота измерений. Это автоматизация и банальная скорость работы.</segment>
		<segment id="115" parent="114" relname="elaboration">Чаще раза в день не надо никому.</segment>
		<segment id="116" parent="318" relname="joint">Менеджеры. Тестировать реально можно до поставки фичи на стенд.</segment>
		<segment id="117" parent="406" relname="span">Узнать, что фича работает хорошо можно до написания кода.</segment>
		<segment id="118" parent="117" relname="evidence">Есть способы.</segment>
		<segment id="119" parent="320" relname="span">А еще тестить можно в два раза быстрей, чем через полгода после найма.</segment>
		<segment id="120" parent="119" relname="elaboration">Смело требуйте.</segment>
		<segment id="121" parent="320" relname="elaboration">Способы и техники не ваша головная боль.</segment>
		<segment id="122" parent="323" relname="span">Тестеры. Будьте готовы.</segment>
		<segment id="123" parent="408" relname="contrast">Быстро работать руками - не поможет.</segment>
		<segment id="124" parent="407" relname="span">Придется работать головой.</segment>
		<segment id="125" parent="322" relname="span">Это сложнее,</segment>
		<segment id="126" parent="125" relname="evaluation">на это тратится примерно один-два тестерских года.</segment>
		<segment id="127" parent="325" relname="span">Как это ни странно, но и здесь у менеджеров есть потолок желаний.</segment>
		<segment id="128" parent="127" relname="elaboration">Чаще, чем раз в день информация уже не нужна, как правило.</segment>
		<segment id="129" parent="327" relname="condition">Если не захотеть чего-то еще</segment>
		<segment id="130" parent="441" relname="restatement">то вы получите автоматизацию ради автоматизации -</segment>
		<segment id="131" parent="441" relname="restatement">такую, которая не ищет дефекты.</segment>
		<segment id="132" parent="326" relname="joint">Или людей, которые считают, что они умеют все что нужно на проекте и не видят роста.</segment>
		<segment id="133" parent="409" relname="solutionhood">Что дальше?</segment>
		<segment id="134" parent="409" relname="span">И вот тут я серьезно ошибся.</segment>
		<segment id="135" parent="330" relname="joint">Я планировал выйти весь в белом</segment>
		<segment id="136" parent="472" relname="span">и рассказать менеджерам ПРАВДУ о том, что нужно делать с двухгодовалыми тестерами с кризисом среднего опыта.</segment>
		<segment id="137" parent="331" relname="joint">Это когда руководитель уже не знает, куда расти этим людям</segment>
		<segment id="138" parent="331" relname="joint">и придумывает всякую фигню.</segment>
		<segment id="139" parent="332" relname="span">То есть начинает платить за то,</segment>
		<segment id="140" parent="139" relname="purpose">что человек не уходит на другую работу.</segment>
		<segment id="141" parent="471" relname="span">Я предположил, что в рамках этой модели следующим этапом развития является время и рост тестировщика заключается во времени.</segment>
		<segment id="142" parent="444" relname="span">Это же самое ценное.</segment>
		<segment id="143" parent="443" relname="span">релиз, фича,</segment>
		<segment id="144" parent="442" relname="joint">выпустить,</segment>
		<segment id="145" parent="442" relname="joint">поставить,</segment>
		<segment id="146" parent="442" relname="joint">выпнуть из процесса разработки.</segment>
		<segment id="147" parent="335" relname="joint">Уменьшить запасы. Быстрей.</segment>
		<segment id="148" parent="335" relname="joint">Уменьшить вот эти вот области.</segment>
		<segment id="149" parent="336" relname="contrast">Время можно обменять на все</segment>
		<segment id="150" parent="336" relname="contrast">и мало что можно обменять на время.</segment>
		<segment id="151" parent="338" relname="span">Мы у себя в проекте и даже биллинг запустили на несколько месяцев подсчет.</segment>
		<segment id="152" parent="151" relname="elaboration">Сколько времени мы тратим.</segment>
		<segment id="153" parent="154" relname="preparation">Выводы.</segment>
		<segment id="154" parent="339" relname="span">Эти потери можно уменьшить?</segment>
		<segment id="155" parent="416" relname="span">Да.</segment>
		<segment id="156" parent="157" relname="solutionhood">Можно из 20 дней сделать 8?</segment>
		<segment id="157" parent="417" relname="span">Да.</segment>
		<segment id="158" parent="159" relname="solutionhood">Смогут тестеры уменьшить 20 до 8?</segment>
		<segment id="159" parent="418" relname="span">Нет.</segment>
		<segment id="160" parent="161" relname="solutionhood">А до 16?</segment>
		<segment id="161" parent="419" relname="span">Вполне.</segment>
		<segment id="162" parent="344" relname="span">И с горящими глазами я иду продавать менеджерам эту идею.</segment>
		<segment id="163" parent="340" relname="joint">Вот, умный тестировщик умеест строить отношения со временем</segment>
		<segment id="164" parent="340" relname="joint">и с помощью команды ускорять процесс.</segment>
		<segment id="165" parent="166" relname="attribution">Мне казалось что я скажу менеджерам</segment>
		<segment id="166" parent="466" relname="span">"вы хотите выпускать фичи в два раза быстрее?"</segment>
		<segment id="167" parent="341" relname="span">И вот она, победа.</segment>
		<segment id="168" parent="345" relname="joint">Оказалось, не надо быстро.</segment>
		<segment id="169" parent="345" relname="joint">Не надо даже быстро с тем же уровнем качества.</segment>
		<segment id="170" parent="348" relname="span">У менеджера есть коридор не только качества, но и скорости.</segment>
		<segment id="171" parent="172" relname="attribution">Несколько опытнейших менеджеров вслух сказали</segment>
		<segment id="172" parent="467" relname="span">что быстрее не надо.</segment>
		<segment id="173" parent="346" relname="comparison">Надо настолько быстро,</segment>
		<segment id="174" parent="346" relname="comparison">насколько хочет менеджер.</segment>
		<segment id="175" parent="421" relname="evaluation">Желание есть, но другое.</segment>
		<segment id="176" parent="473" relname="joint">Я считаю, что это фатальная ошибка</segment>
		<segment id="177" parent="473" relname="joint">и в корне неверно,</segment>
		<segment id="178" parent="356" relname="joint">тем не менее это вполне себе зона роста</segment>
		<segment id="179" parent="354" relname="condition">и если научиться выполнять эту работу</segment>
		<segment id="180" parent="353" relname="joint">- менеджер это заметит</segment>
		<segment id="181" parent="353" relname="joint">и оценит.</segment>
		<segment id="182" parent="358" relname="span">Итак, формулировки:</segment>
		<segment id="183" parent="182" relname="elaboration">"Самоорганизующаяся команда", "интерфейс", "самостоятельное принятие решений", "менеджмент команды", "сами знают куда расти". "Решить проблемы с тестерами".</segment>
		<segment id="184" parent="446" relname="span">Самоподдерживающаяся система,</segment>
		<segment id="185" parent="445" relname="contrast">не требующая ресурса управления,</segment>
		<segment id="186" parent="445" relname="contrast">требующая только материальных ресурсов.</segment>
		<segment id="187" parent="446" relname="elaboration">Это и управление потоком задач, приоритезация фич относительно багов, это управляющие воздействия, самоактуализация коридора качества.</segment>
		<segment id="188" parent="359" relname="evaluation">В лучшем случае это самостоятельная готовность к изменениям внешних условий.</segment>
		<segment id="189" parent="447" relname="attribution">По Адизесу,</segment>
		<segment id="190" parent="361" relname="contrast">большие ответственность и полномочия,</segment>
		<segment id="191" parent="361" relname="contrast">но без власти - в полный рост.</segment>
		<segment id="192" parent="426" relname="span">Признаки этапа - ведение задач полностью у тестеров, входящий поток задач - частично у  них с возможностью менеджера вмешаться.</segment>
		<segment id="193" parent="362" relname="contrast">Менеджер ждет, что он будет заниматься всякими другими штуками,</segment>
		<segment id="194" parent="362" relname="contrast">а система будет работать так же.</segment>
		<segment id="195" parent="424" relname="span">На этом этапе мы учимся нашей линейкой еще и бить.</segment>
		<segment id="196" parent="365" relname="span">Но это тупик</segment>
		<segment id="197" parent="196" relname="cause">- так как задача - самоподдерживающаяся система, а не изменения.</segment>
		<segment id="198" parent="199" relname="preparation">Выводы:</segment>
		<segment id="199" parent="367" relname="span">менеджеры. Вы все делаете правильно.</segment>
		<segment id="200" parent="366" relname="joint">Тестировщики. Работа менеджмента группы разработки - сложная штука,</segment>
		<segment id="201" parent="366" relname="joint">вы должны знать за что и зачем беретесь.</segment>
		<segment id="202" parent="474" relname="solutionhood">А что было потом?</segment>
		<segment id="203" parent="474" relname="span">Я считаю, что рост без ограничений невозможен.</segment>
		<segment id="204" parent="476" relname="span">Само - ничего не случится.</segment>
		<segment id="205" parent="369" relname="joint">У нас есть несколько продуктов и менеджеров с высокими требованиями к бездефектности</segment>
		<segment id="206" parent="369" relname="joint">и там можно применить весь тестерский матан.</segment>
		<segment id="207" parent="370" relname="joint">И он там еще не применен.</segment>
		<segment id="208" parent="450" relname="span">У нас есть пара продуктов, где нельзя тестировать,</segment>
		<segment id="209" parent="449" relname="joint">не становясь экспертом в домене</segment>
		<segment id="210" parent="449" relname="joint">и не занимаясь аналитикой.</segment>
		<segment id="211" parent="371" relname="joint">И там нужны тестеры - эксперты.</segment>
		<segment id="212" parent="373" relname="span">У нас есть экстерн, где очень  высокие и жесткие требования к скорости работы.</segment>
		<segment id="213" parent="372" relname="span">По слухам, они даже повышаются.</segment>
		<segment id="214" parent="213" relname="elaboration">Это тоже зона роста.</segment>
		<segment id="215" parent="374" relname="joint">У нас есть менеджеры любого продукта, которые с удовольствием отдадут тестировщикам часть работы по управлению разработкой.</segment>
		<segment id="216" parent="374" relname="joint">И у нас есть куча народу которые считают, что уже достигли потолка в проекте.</segment>
		<segment id="217" parent="374" relname="joint">И куча руководителей, желающих странного.</segment>
		<segment id="218" parent="378" relname="span">Менеджеры. Не требуйте странного.</segment>
		<segment id="219" parent="377" relname="span">Тестировщик - линейка.</segment>
		<segment id="220" parent="375" relname="joint">Он может: быстрее, чаще, точнее, раньше.</segment>
		<segment id="221" parent="375" relname="joint">Остальное - детали реализации.</segment>
		<segment id="222" parent="376" relname="joint">Инструменты тестер найдет сам.</segment>
		<segment id="223" parent="379" relname="joint">Тестеры. Используйте мою модель.</segment>
		<segment id="224" parent="379" relname="joint">Придумайте свою.</segment>
		<segment id="225" parent="434" relname="contrast">Но научитесь определять, чего от вас нужно.</segment>
		<segment id="226" parent="227" relname="condition">И если ничего не нужно</segment>
		<segment id="227" parent="380" relname="span">- меняйте проект.</segment>
		<group id="228" type="multinuc" parent="229" relname="span"/>
		<group id="229" type="span" parent="230" relname="span"/>
		<group id="230" type="span" parent="383" relname="preparation"/>
		<group id="231" type="multinuc" parent="232" relname="span"/>
		<group id="232" type="span" parent="233" relname="span"/>
		<group id="233" type="span" parent="234" relname="contrast"/>
		<group id="234" type="multinuc" parent="382" relname="background"/>
		<group id="235" type="multinuc" parent="236" relname="span"/>
		<group id="236" type="span" parent="237" relname="span"/>
		<group id="237" type="span" parent="238" relname="span"/>
		<group id="238" type="span" parent="11" relname="elaboration"/>
		<group id="239" type="span" parent="10" relname="evaluation"/>
		<group id="240" type="span" parent="245" relname="joint"/>
		<group id="241" type="multinuc" parent="242" relname="span"/>
		<group id="242" type="span" parent="243" relname="span"/>
		<group id="243" type="span" parent="16" relname="elaboration"/>
		<group id="244" type="span" parent="245" relname="joint"/>
		<group id="245" type="multinuc" parent="382" relname="span"/>
		<group id="246" type="multinuc" parent="247" relname="span"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" parent="20" relname="elaboration"/>
		<group id="249" type="span" parent="252" relname="preparation"/>
		<group id="250" type="multinuc" parent="24" relname="elaboration"/>
		<group id="251" type="span" parent="252" relname="span"/>
		<group id="252" type="span" parent="385" relname="span"/>
		<group id="253" type="multinuc" parent="255" relname="contrast"/>
		<group id="254" type="span" parent="253" relname="joint"/>
		<group id="255" type="multinuc" />
		<group id="257" type="multinuc" parent="258" relname="joint"/>
		<group id="258" type="multinuc" parent="388" relname="span"/>
		<group id="259" type="multinuc" parent="260" relname="comparison"/>
		<group id="260" type="multinuc" parent="386" relname="span"/>
		<group id="261" type="multinuc" parent="262" relname="span"/>
		<group id="262" type="span" parent="263" relname="span"/>
		<group id="263" type="span" parent="264" relname="joint"/>
		<group id="264" type="multinuc" parent="393" relname="span"/>
		<group id="265" type="multinuc" parent="45" relname="elaboration"/>
		<group id="266" type="multinuc" parent="48" relname="elaboration"/>
		<group id="267" type="span" parent="438" relname="span"/>
		<group id="268" type="multinuc" parent="53" relname="solutionhood"/>
		<group id="269" type="span" parent="274" relname="comparison"/>
		<group id="270" type="multinuc" parent="56" relname="solutionhood"/>
		<group id="271" type="span" parent="391" relname="contrast"/>
		<group id="272" type="multinuc" parent="59" relname="solutionhood"/>
		<group id="273" type="span" parent="391" relname="contrast"/>
		<group id="274" type="multinuc" parent="393" relname="elaboration"/>
		<group id="275" type="span" parent="276" relname="same-unit"/>
		<group id="276" type="multinuc" parent="281" relname="span"/>
		<group id="277" type="multinuc" parent="281" relname="elaboration"/>
		<group id="278" type="span" parent="279" relname="joint"/>
		<group id="279" type="multinuc" parent="68" relname="elaboration"/>
		<group id="280" type="span" parent="67" relname="evaluation"/>
		<group id="281" type="span" parent="282" relname="span"/>
		<group id="282" type="span" />
		<group id="283" type="multinuc" parent="400" relname="span"/>
		<group id="284" type="span" parent="75" relname="elaboration"/>
		<group id="285" type="multinuc" parent="287" relname="span"/>
		<group id="286" type="multinuc" parent="287" relname="elaboration"/>
		<group id="287" type="span" parent="288" relname="span"/>
		<group id="288" type="span" parent="402" relname="joint"/>
		<group id="289" type="multinuc" parent="290" relname="evaluation"/>
		<group id="290" type="span" parent="291" relname="span"/>
		<group id="291" type="span" parent="402" relname="joint"/>
		<group id="292" type="span" parent="398" relname="span"/>
		<group id="293" type="multinuc" parent="294" relname="span"/>
		<group id="294" type="span" parent="295" relname="span"/>
		<group id="295" type="span" parent="305" relname="span"/>
		<group id="296" type="multinuc" parent="91" relname="elaboration"/>
		<group id="297" type="span" parent="303" relname="cause"/>
		<group id="298" type="multinuc" parent="302" relname="contrast"/>
		<group id="299" type="multinuc" parent="300" relname="span"/>
		<group id="300" type="span" parent="301" relname="span"/>
		<group id="301" type="span" parent="302" relname="contrast"/>
		<group id="302" type="multinuc" parent="303" relname="span"/>
		<group id="303" type="span" parent="304" relname="span"/>
		<group id="304" type="span" parent="295" relname="elaboration"/>
		<group id="305" type="span" />
		<group id="306" type="multinuc" parent="101" relname="elaboration"/>
		<group id="307" type="span" parent="309" relname="joint"/>
		<group id="308" type="span" parent="309" relname="joint"/>
		<group id="309" type="multinuc" parent="311" relname="span"/>
		<group id="310" type="span" parent="313" relname="span"/>
		<group id="311" type="span" parent="312" relname="span"/>
		<group id="312" type="span" parent="310" relname="elaboration"/>
		<group id="313" type="span" parent="316" relname="joint"/>
		<group id="314" type="span" parent="109" relname="cause"/>
		<group id="315" type="span" parent="316" relname="joint"/>
		<group id="316" type="multinuc" />
		<group id="317" type="multinuc" parent="111" relname="elaboration"/>
		<group id="318" type="multinuc" parent="319" relname="joint"/>
		<group id="319" type="multinuc" parent="324" relname="joint"/>
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" parent="319" relname="joint"/>
		<group id="322" type="span" parent="124" relname="evaluation"/>
		<group id="323" type="span" parent="324" relname="joint"/>
		<group id="324" type="multinuc" />
		<group id="325" type="span" parent="329" relname="span"/>
		<group id="326" type="multinuc" parent="327" relname="span"/>
		<group id="327" type="span" parent="328" relname="span"/>
		<group id="328" type="span" parent="325" relname="evaluation"/>
		<group id="329" type="span" />
		<group id="330" type="multinuc" parent="134" relname="elaboration"/>
		<group id="331" type="multinuc" parent="333" relname="restatement"/>
		<group id="332" type="span" parent="333" relname="restatement"/>
		<group id="333" type="multinuc" parent="136" relname="elaboration"/>
		<group id="335" type="multinuc" parent="412" relname="span"/>
		<group id="336" type="multinuc" parent="414" relname="span"/>
		<group id="338" type="span" parent="414" relname="evidence"/>
		<group id="339" type="span" parent="155" relname="solutionhood"/>
		<group id="340" type="multinuc" parent="342" relname="span"/>
		<group id="341" type="span" parent="342" relname="evaluation"/>
		<group id="342" type="span" parent="343" relname="span"/>
		<group id="343" type="span" parent="162" relname="elaboration"/>
		<group id="344" type="span" />
		<group id="345" type="multinuc" parent="349" relname="span"/>
		<group id="346" type="multinuc" parent="421" relname="span"/>
		<group id="348" type="span" parent="349" relname="evidence"/>
		<group id="349" type="span" parent="350" relname="span"/>
		<group id="350" type="span" parent="423" relname="span"/>
		<group id="353" type="multinuc" parent="354" relname="span"/>
		<group id="354" type="span" parent="355" relname="span"/>
		<group id="355" type="span" parent="356" relname="joint"/>
		<group id="356" type="multinuc" parent="357" relname="contrast"/>
		<group id="357" type="multinuc" parent="350" relname="evaluation"/>
		<group id="358" type="span" parent="427" relname="preparation"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="363" relname="span"/>
		<group id="361" type="multinuc" parent="447" relname="span"/>
		<group id="362" type="multinuc" parent="195" relname="solutionhood"/>
		<group id="363" type="span" parent="364" relname="joint"/>
		<group id="364" type="multinuc" parent="427" relname="span"/>
		<group id="365" type="span" parent="425" relname="contrast"/>
		<group id="366" type="multinuc" parent="368" relname="joint"/>
		<group id="367" type="span" parent="368" relname="joint"/>
		<group id="368" type="multinuc" parent="475" relname="preparation"/>
		<group id="369" type="multinuc" parent="370" relname="joint"/>
		<group id="370" type="multinuc" parent="374" relname="joint"/>
		<group id="371" type="multinuc" parent="374" relname="joint"/>
		<group id="372" type="span" parent="212" relname="evaluation"/>
		<group id="373" type="span" parent="374" relname="joint"/>
		<group id="374" type="multinuc" parent="204" relname="background"/>
		<group id="375" type="multinuc" parent="376" relname="joint"/>
		<group id="376" type="multinuc" parent="219" relname="elaboration"/>
		<group id="377" type="span" parent="218" relname="evidence"/>
		<group id="378" type="span" parent="435" relname="joint"/>
		<group id="379" type="multinuc" parent="381" relname="contrast"/>
		<group id="380" type="span" parent="434" relname="contrast"/>
		<group id="381" type="multinuc" parent="435" relname="joint"/>
		<group id="382" type="span" parent="383" relname="span"/>
		<group id="383" type="span" parent="384" relname="span"/>
		<group id="384" type="span" />
		<group id="385" type="span" />
		<group id="386" type="span" parent="387" relname="span"/>
		<group id="387" type="span" />
		<group id="388" type="span" parent="389" relname="span"/>
		<group id="389" type="span" parent="386" relname="solutionhood"/>
		<group id="390" type="span" parent="264" relname="joint"/>
		<group id="391" type="multinuc" parent="274" relname="comparison"/>
		<group id="392" type="span" parent="274" relname="comparison"/>
		<group id="393" type="span" parent="394" relname="span"/>
		<group id="394" type="span" />
		<group id="395" type="span" parent="279" relname="joint"/>
		<group id="396" type="multinuc" parent="71" relname="elaboration"/>
		<group id="397" type="span" parent="277" relname="joint"/>
		<group id="398" type="span" />
		<group id="399" type="span" parent="76" relname="elaboration"/>
		<group id="400" type="span" parent="399" relname="span"/>
		<group id="401" type="span" parent="400" relname="evaluation"/>
		<group id="402" type="multinuc" parent="79" relname="elaboration"/>
		<group id="403" type="span" parent="404" relname="span"/>
		<group id="404" type="span" />
		<group id="405" type="span" parent="403" relname="span"/>
		<group id="406" type="span" parent="318" relname="joint"/>
		<group id="407" type="span" parent="408" relname="contrast"/>
		<group id="408" type="multinuc" parent="122" relname="elaboration"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" />
		<group id="412" type="span" parent="413" relname="span"/>
		<group id="413" type="span" parent="443" relname="elaboration"/>
		<group id="414" type="span" parent="415" relname="span"/>
		<group id="415" type="span" parent="412" relname="evaluation"/>
		<group id="416" type="span" parent="420" relname="joint"/>
		<group id="417" type="span" parent="420" relname="joint"/>
		<group id="418" type="span" parent="420" relname="joint"/>
		<group id="419" type="span" parent="420" relname="joint"/>
		<group id="420" type="multinuc" />
		<group id="421" type="span" parent="422" relname="span"/>
		<group id="422" type="span" parent="467" relname="elaboration"/>
		<group id="423" type="span" />
		<group id="424" type="span" parent="425" relname="contrast"/>
		<group id="425" type="multinuc" parent="192" relname="elaboration"/>
		<group id="426" type="span" parent="364" relname="joint"/>
		<group id="427" type="span" parent="428" relname="span"/>
		<group id="428" type="span" />
		<group id="434" type="multinuc" parent="381" relname="contrast"/>
		<group id="435" type="multinuc" />
		<group id="436" type="span" parent="437" relname="span"/>
		<group id="437" type="span" parent="251" relname="evaluation"/>
		<group id="438" type="span" parent="392" relname="span"/>
		<group id="439" type="span" parent="317" relname="joint"/>
		<group id="440" type="span" parent="317" relname="joint"/>
		<group id="441" type="multinuc" parent="326" relname="joint"/>
		<group id="442" type="multinuc" parent="143" relname="elaboration"/>
		<group id="443" type="span" parent="465" relname="span"/>
		<group id="444" type="span" parent="141" relname="evaluation"/>
		<group id="445" type="multinuc" parent="184" relname="elaboration"/>
		<group id="446" type="span" parent="359" relname="span"/>
		<group id="447" type="span" parent="448" relname="span"/>
		<group id="448" type="span" parent="360" relname="elaboration"/>
		<group id="449" type="multinuc" parent="208" relname="condition"/>
		<group id="450" type="span" parent="371" relname="joint"/>
		<group id="465" type="span" parent="142" relname="elaboration"/>
		<group id="466" type="span" parent="167" relname="solutionhood"/>
		<group id="467" type="span" parent="468" relname="span"/>
		<group id="468" type="span" parent="170" relname="elaboration"/>
		<group id="471" type="span" />
		<group id="472" type="span" parent="330" relname="joint"/>
		<group id="473" type="multinuc" parent="357" relname="contrast"/>
		<group id="474" type="span" parent="475" relname="span"/>
		<group id="475" type="span" parent="477" relname="span"/>
		<group id="476" type="span" parent="203" relname="cause"/>
		<group id="477" type="span" />
	</body>
</rst>