<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://veronikahlebova.ru/kak-rasskazat-detyam-o-granitsah/</segment>
		<segment id="2" >Как рассказать детям о границах</segment>
		<segment id="3" parent="111" relname="preparation">В школе произошло неприятное происшествие.</segment>
		<segment id="4" parent="109" relname="joint">Подростки держали девочку за руки,</segment>
		<segment id="5" parent="109" relname="joint">пачкали ее грязью и землей,</segment>
		<segment id="6" parent="109" relname="joint">и снимали происходящее на видео,</segment>
		<segment id="7" parent="110" relname="purpose">чтобы выложить на ютубе.</segment>
		<segment id="8" parent="113" relname="contrast">Над девочкой совершалось насилие,</segment>
		<segment id="9" parent="113" relname="contrast">но остальные считали происходящее «экспериментом».</segment>
		<segment id="10" parent="115" relname="span">Взрослые в ужасе и гневе.</segment>
		<segment id="11" parent="116" relname="span">Как рассказать детям о границах,</segment>
		<segment id="12" parent="11" relname="condition">не превращаясь в насильников и паникеров?</segment>
		<segment id="13" parent="118" relname="preparation">…Один мальчик (11 лет) хочет снять видео для ютуба.</segment>
		<segment id="14" parent="118" relname="span">Ему приходит в голову идея:</segment>
		<segment id="15" parent="182" relname="span">снять одноклассницу в ролике.</segment>
		<segment id="16" parent="119" relname="joint">Ее можно измазать грязью,</segment>
		<segment id="17" parent="119" relname="joint">и снять это на камеру.</segment>
		<segment id="18" parent="124" relname="sequence">Он называет задумку словом «эксперимент».</segment>
		<segment id="19" parent="121" relname="span">Он просит друзей помочь ему:</segment>
		<segment id="20" parent="120" relname="joint">один будет держать девочку,</segment>
		<segment id="21" parent="120" relname="joint">другой – соответственно, пачкать.</segment>
		<segment id="22" parent="122" relname="span">Нет, двое будут держать,</segment>
		<segment id="23" parent="22" relname="cause">иначе она убежит.</segment>
		<segment id="24" parent="134" relname="span">Друзья начинают осуществлять свой план.</segment>
		<segment id="25" parent="126" relname="span">Девочке совсем не нравится то, что происходит.</segment>
		<segment id="26" parent="125" relname="joint">Она хочет вырваться</segment>
		<segment id="27" parent="125" relname="joint">и убежать.</segment>
		<segment id="28" parent="127" relname="span">Но мальчики входят в азарт:</segment>
		<segment id="29" parent="28" relname="elaboration">эксперимент нужно продолжать.</segment>
		<segment id="30" parent="128" relname="joint">Один из друзей не держит девочку:</segment>
		<segment id="31" parent="128" relname="joint">он наблюдает.</segment>
		<segment id="32" parent="129" relname="span">Другой уходит:</segment>
		<segment id="33" parent="195" relname="span">«Я в этом не участвую»,</segment>
		<segment id="34" parent="33" relname="attribution">— говорит он.</segment>
		<segment id="35" parent="36" relname="cause">…Ролик снят;</segment>
		<segment id="36" parent="130" relname="span">девочку отпускают.</segment>
		<segment id="37" parent="135" relname="sequence">Все расходятся по домам.</segment>
		<segment id="38" parent="135" relname="sequence">На следующий день начинается скандал.</segment>
		<segment id="39" parent="138" relname="preparation">Прислушайтесь к себе.</segment>
		<segment id="40" parent="136" relname="joint">Какие чувства вызывает у вас эта история?</segment>
		<segment id="41" parent="136" relname="joint">Что вы чувствуете к девочке? А к мальчикам?</segment>
		<segment id="42" parent="137" relname="span">Как вам кажется, почему некоторые из них не остановились,</segment>
		<segment id="43" parent="42" relname="condition">когда она просила ее отпустить?</segment>
		<segment id="44" parent="141" relname="span">Конечно, возникают сильные чувства.</segment>
		<segment id="45" parent="140" relname="span">В памяти начинают всплывать множество историй с собственным участием.</segment>
		<segment id="46" parent="45" relname="evidence">Каждый из нас был когда-то жертвой, которая не могла уйти.</segment>
		<segment id="47" parent="143" relname="joint">Многие из нас бывали и на другой стороне.</segment>
		<segment id="48" parent="143" relname="joint">Многие бывали наблюдателями.</segment>
		<segment id="49" parent="142" relname="joint">Мы ничего не знали о насилии,</segment>
		<segment id="50" parent="142" relname="joint">где проходят границы,</segment>
		<segment id="51" parent="142" relname="joint">и на что ориентироваться.</segment>
		<segment id="52" parent="192" relname="span">Мы видели, насколько взрослым сносит крышу</segment>
		<segment id="53" parent="52" relname="cause">от подобных историй.</segment>
		<segment id="54" parent="144" relname="joint">Мы видели, как всплывали их страхи,</segment>
		<segment id="55" parent="144" relname="joint">начинались угрозы, запугивания, обобщения…</segment>
		<segment id="56" parent="193" relname="joint">Что мы пойдем по наклонной,</segment>
		<segment id="57" parent="193" relname="joint">и станем преступниками. Или просто ужасными людьми.</segment>
		<segment id="58" parent="194" relname="span">Мы узнавали, насколько мы ужасные,</segment>
		<segment id="59" parent="146" relname="joint">что не вступились,</segment>
		<segment id="60" parent="146" relname="joint">промолчали,</segment>
		<segment id="61" parent="146" relname="joint">участвовали.</segment>
		<segment id="62" parent="147" relname="joint">Мы переживали стыд, вину и плохость,</segment>
		<segment id="63" parent="147" relname="joint">мы защищались отмораживанием чувств и агрессией.</segment>
		<segment id="64" parent="148" relname="contrast">Но мы так и не поняли, где же проходят границы.</segment>
		<segment id="65" parent="151" relname="span">…Между тем, такие случаи нужны</segment>
		<segment id="66" parent="196" relname="span">именно для того, чтобы взрослые задумывались о том, что они рассказывают своим детям о границах личности.</segment>
		<segment id="67" parent="150" relname="joint">Где они проходят,</segment>
		<segment id="68" parent="150" relname="joint">и куда заходить нельзя.</segment>
		<segment id="69" parent="152" relname="span">Как можно поступать,</segment>
		<segment id="70" parent="69" relname="condition">если твои границы нарушают.</segment>
		<segment id="71" parent="153" relname="span">Нам нужно знать, что не присоединяться к насилию можно,</segment>
		<segment id="72" parent="71" relname="evaluation">и это хороший выбор.</segment>
		<segment id="73" parent="154" relname="span">Нам нужно знать, что защищаться от насилия можно,</segment>
		<segment id="74" parent="73" relname="evaluation">и это прекрасный выбор.</segment>
		<segment id="75" parent="161" relname="span">….В этой истории так все и случилось.</segment>
		<segment id="76" parent="158" relname="comparison">Одни перепуганные родители навешали ярлыков,</segment>
		<segment id="77" parent="158" relname="comparison">другие потребовали исключения.</segment>
		<segment id="78" parent="159" relname="span">Учителя и администрация не отставали:</segment>
		<segment id="79" parent="80" relname="cause">угроз и осуждения было достаточно</segment>
		<segment id="80" parent="185" relname="span">для того, чтобы дети, совершившие ошибку, начали защищаться.</segment>
		<segment id="81" parent="82" relname="solutionhood">Что же необходимо сделать, в первую очередь?</segment>
		<segment id="82" parent="186" relname="span">Рассказать о границах.</segment>
		<segment id="83" parent="166" relname="joint">«Нельзя совершать с другим человеком такие действия, на которые он не давал согласия.</segment>
		<segment id="84" parent="162" relname="span">Нельзя удерживать,</segment>
		<segment id="85" parent="84" relname="condition">если он хочет уйти.</segment>
		<segment id="86" parent="163" relname="span">Нельзя настаивать,</segment>
		<segment id="87" parent="86" relname="condition">если он не хочет участвовать в эксперименте.</segment>
		<segment id="88" parent="164" relname="span">Его «нет» является достаточным основанием,</segment>
		<segment id="89" parent="88" relname="purpose">чтобы оставить его в покое.</segment>
		<segment id="90" parent="91" relname="condition">Если над человеком совершают действия против его воли,</segment>
		<segment id="91" parent="165" relname="span">это насилие.</segment>
		<segment id="92" parent="166" relname="joint">Мы против насилия по отношению к кому бы то ни было, в том числе по отношению к тем, кто совершил ошибку.»</segment>
		<segment id="93" parent="168" relname="span">Это хорошие ориентиры,</segment>
		<segment id="94" parent="167" relname="joint">чтобы дети могли разобраться,</segment>
		<segment id="95" parent="167" relname="joint">и опираться на них.</segment>
		<segment id="96" parent="170" relname="span">Вина и стыд им не помогут:</segment>
		<segment id="97" parent="169" relname="span">они оттягивают все душевные силы</segment>
		<segment id="98" parent="97" relname="purpose">на то, чтобы справиться с этими чувствами.</segment>
		<segment id="99" parent="173" relname="joint">Разберитесь со своими травмами, которые резонируют в подобных ситуациях.</segment>
		<segment id="100" parent="173" relname="joint">Попробуйте увидеть, как вы мгновенно превращаетесь в жертв и насильников.</segment>
		<segment id="101" parent="102" relname="condition">Если дети увидят адекватную реакцию взрослых,</segment>
		<segment id="102" parent="174" relname="span">они смогут задуматься над уроком.</segment>
		<segment id="103" parent="176" relname="span">И это единственный шанс усвоить урок:</segment>
		<segment id="104" parent="175" relname="joint">взрослые должны быть взрослыми,</segment>
		<segment id="105" parent="175" relname="joint">и реагировать по-взрослому.</segment>
		<segment id="106" parent="178" relname="cause">Тогда и дети смогут быть детьми, которые могли чего-то не знать,</segment>
		<segment id="107" parent="177" relname="joint">и научиться,</segment>
		<segment id="108" parent="177" relname="joint">извлечь бесценный опыт для своей жизни.</segment>
		<group id="109" type="multinuc" parent="110" relname="span"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="112" relname="span"/>
		<group id="112" type="span" parent="114" relname="span"/>
		<group id="113" type="multinuc" parent="112" relname="elaboration"/>
		<group id="114" type="span" parent="10" relname="cause"/>
		<group id="115" type="span" parent="116" relname="background"/>
		<group id="116" type="span" parent="117" relname="span"/>
		<group id="117" type="span" />
		<group id="118" type="span" parent="191" relname="span"/>
		<group id="119" type="multinuc" parent="15" relname="elaboration"/>
		<group id="120" type="multinuc" parent="19" relname="elaboration"/>
		<group id="121" type="span" parent="123" relname="contrast"/>
		<group id="122" type="span" parent="123" relname="contrast"/>
		<group id="123" type="multinuc" parent="124" relname="sequence"/>
		<group id="124" type="multinuc" parent="24" relname="background"/>
		<group id="125" type="multinuc" parent="25" relname="evidence"/>
		<group id="126" type="span" parent="133" relname="contrast"/>
		<group id="127" type="span" parent="132" relname="span"/>
		<group id="128" type="multinuc" parent="131" relname="joint"/>
		<group id="129" type="span" parent="131" relname="joint"/>
		<group id="130" type="span" parent="135" relname="sequence"/>
		<group id="131" type="multinuc" parent="127" relname="elaboration"/>
		<group id="132" type="span" parent="133" relname="contrast"/>
		<group id="133" type="multinuc" parent="135" relname="sequence"/>
		<group id="134" type="span" parent="135" relname="sequence"/>
		<group id="135" type="multinuc" />
		<group id="136" type="multinuc" parent="138" relname="span"/>
		<group id="137" type="span" parent="136" relname="joint"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="141" relname="solutionhood"/>
		<group id="140" type="span" parent="44" relname="elaboration"/>
		<group id="141" type="span" parent="183" relname="span"/>
		<group id="142" type="multinuc" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="149" relname="joint"/>
		<group id="144" type="multinuc" parent="145" relname="joint"/>
		<group id="145" type="multinuc" parent="149" relname="joint"/>
		<group id="146" type="multinuc" parent="58" relname="cause"/>
		<group id="147" type="multinuc" parent="148" relname="contrast"/>
		<group id="148" type="multinuc" parent="149" relname="joint"/>
		<group id="149" type="multinuc" />
		<group id="150" type="multinuc" parent="66" relname="elaboration"/>
		<group id="151" type="span" parent="157" relname="span"/>
		<group id="152" type="span" parent="156" relname="span"/>
		<group id="153" type="span" parent="155" relname="joint"/>
		<group id="154" type="span" parent="155" relname="joint"/>
		<group id="155" type="multinuc" parent="152" relname="elaboration"/>
		<group id="156" type="span" parent="151" relname="elaboration"/>
		<group id="157" type="span" />
		<group id="158" type="multinuc" parent="160" relname="comparison"/>
		<group id="159" type="span" parent="160" relname="comparison"/>
		<group id="160" type="multinuc" parent="75" relname="evidence"/>
		<group id="161" type="span" />
		<group id="162" type="span" parent="166" relname="joint"/>
		<group id="163" type="span" parent="166" relname="joint"/>
		<group id="164" type="span" parent="166" relname="joint"/>
		<group id="165" type="span" parent="166" relname="joint"/>
		<group id="166" type="multinuc" parent="189" relname="span"/>
		<group id="167" type="multinuc" parent="93" relname="purpose"/>
		<group id="168" type="span" parent="171" relname="comparison"/>
		<group id="169" type="span" parent="96" relname="elaboration"/>
		<group id="170" type="span" parent="171" relname="comparison"/>
		<group id="171" type="multinuc" parent="189" relname="elaboration"/>
		<group id="172" type="multinuc" parent="187" relname="span"/>
		<group id="173" type="multinuc" parent="172" relname="joint"/>
		<group id="174" type="span" parent="181" relname="span"/>
		<group id="175" type="multinuc" parent="103" relname="elaboration"/>
		<group id="176" type="span" parent="179" relname="condition"/>
		<group id="177" type="multinuc" parent="178" relname="span"/>
		<group id="178" type="span" parent="179" relname="span"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" parent="174" relname="elaboration"/>
		<group id="181" type="span" parent="172" relname="joint"/>
		<group id="182" type="span" parent="14" relname="elaboration"/>
		<group id="183" type="span" />
		<group id="185" type="span" parent="78" relname="elaboration"/>
		<group id="186" type="span" parent="187" relname="preparation"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" />
		<group id="189" type="span" parent="190" relname="span"/>
		<group id="190" type="span" parent="172" relname="joint"/>
		<group id="191" type="span" parent="124" relname="sequence"/>
		<group id="192" type="span" parent="145" relname="joint"/>
		<group id="193" type="multinuc" parent="144" relname="joint"/>
		<group id="194" type="span" parent="149" relname="joint"/>
		<group id="195" type="span" parent="32" relname="elaboration"/>
		<group id="196" type="span" parent="65" relname="purpose"/>
	</body>
</rst>