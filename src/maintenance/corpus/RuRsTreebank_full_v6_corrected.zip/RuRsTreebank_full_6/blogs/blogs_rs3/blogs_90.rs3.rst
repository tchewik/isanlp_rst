<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://www.facebook.com/mitya.aleshkovskiy/posts/10220212549123338</segment>
		<segment id="2" parent="70" relname="span">Новость о том, что в России будут создавать филиалы колоний при крупных предприятиях</segment>
		<segment id="3" parent="2" relname="attribution">( https://takiedela.ru/news/2019/07/22/ik-pri-predpriyatiyakh/ ),</segment>
		<segment id="4" parent="71" relname="same-unit">кажется шуткой,</segment>
		<segment id="5" parent="72" relname="contrast">но, увы, ей не является.</segment>
		<segment id="6" parent="73" relname="evaluation">Это совсем не смешно, друзья.</segment>
		<segment id="7" parent="110" relname="span">И не смешно это по двум причинам.</segment>
		<segment id="8" parent="81" relname="preparation">Во-первых, по чисто экономическим причинам.</segment>
		<segment id="9" parent="76" relname="span">Использовать дешевый (почти бесплатный) труд заключенных,</segment>
		<segment id="10" parent="75" relname="span">это, вероятно последняя надежда для нашей экономики и наших производств,</segment>
		<segment id="11" parent="10" relname="elaboration">не способных выдерживать хоть сколько-нибудь серьезную конкуренцию.</segment>
		<segment id="12" parent="77" relname="span">И эта мера, как обычно, лишь заплатка на очередной заплатке, которая на еще одной заплатке,</segment>
		<segment id="13" parent="12" relname="purpose">призванной сдержать растерзанную экономику России.</segment>
		<segment id="14" parent="78" relname="joint">Налоги снижать нельзя,</segment>
		<segment id="15" parent="78" relname="joint">облегчать условия работы нельзя,</segment>
		<segment id="16" parent="78" relname="joint">снижать риски для предпринимателей нельзя,</segment>
		<segment id="17" parent="79" relname="span">значит что можно?</segment>
		<segment id="18" parent="120" relname="span">Заставить заключенных работать.</segment>
		<segment id="19" parent="83" relname="contrast">Мы же понимаем, что как бы это не подавалось в медиа и документах,</segment>
		<segment id="20" parent="83" relname="contrast">в реальности это будет не добровольная работа, а принудительная?</segment>
		<segment id="21" parent="84" relname="joint">Мы же понимаем, что заключенные не будут получать за это никакой зарплаты?</segment>
		<segment id="22" parent="94" relname="span">Более того, это ведь уже сейчас происходит.</segment>
		<segment id="23" parent="87" relname="span">Вспомните, как в прошлом году начальника тюрьмы</segment>
		<segment id="24" parent="23" relname="background">в которой сидела Nadya Tolokonnikova​</segment>
		<segment id="25" parent="88" relname="same-unit">отстранили от должности</segment>
		<segment id="26" parent="121" relname="span">за то, что у него на зоне процветал рабский труд.</segment>
		<segment id="27" parent="91" relname="span">Заключался он в том, что "осужденные женщины занимались пошивом одежды с семи утра до часу ночи, выполняя левые заказы"</segment>
		<segment id="28" parent="27" relname="attribution">(https://www.fontanka.ru/2018/12/24/115/).</segment>
		<segment id="29" parent="93" relname="joint">То есть, понимаете, это уже есть.</segment>
		<segment id="30" parent="93" relname="joint">И будет только хуже.</segment>
		<segment id="31" parent="96" relname="span">Ну и вторая причина, почему это совсем не смешно, заключается в том, что мы в одном шаге, буквально, от нового ГУЛАГа.</segment>
		<segment id="32" parent="97" relname="joint">И дело даже не в том, что мы его строим заново,</segment>
		<segment id="33" parent="131" relname="same-unit">не в том, что</segment>
		<segment id="34" parent="35" relname="cause">за политические высказывания и политическую деятельность</segment>
		<segment id="35" parent="130" relname="span">люди отправляются в тюрьму.</segment>
		<segment id="36" parent="99" relname="span">Дело в том, что все молчат:</segment>
		<segment id="37" parent="98" relname="joint">либо боятся,</segment>
		<segment id="38" parent="98" relname="joint">либо плевать хотели,</segment>
		<segment id="39" parent="98" relname="joint">думают, что их это не касается.</segment>
		<segment id="40" parent="41" relname="solutionhood">Просто ответьте себе на вопрос — могут ли в сегодняшней России невиновного человека отправить в тюрьму?</segment>
		<segment id="41" parent="122" relname="span">Конечно могут.</segment>
		<segment id="42" parent="123" relname="solutionhood">А будут ли за него бороться люди?</segment>
		<segment id="43" parent="123" relname="span">Иногда.</segment>
		<segment id="44" parent="100" relname="span">Мы знаем единичные случаи, когда людей получается отстоять.</segment>
		<segment id="45" parent="132" relname="span">И всегда эти победы связаны</segment>
		<segment id="46" parent="45" relname="cause">исключительно с давлением общества,</segment>
		<segment id="47" parent="132" relname="cause">потому, что на государственные институты вроде судов, следствия и прочее, рассчитывать не приходится.</segment>
		<segment id="48" parent="105" relname="contrast">В итоге получается, что в любой момент любого человека могут отправить за решетку</segment>
		<segment id="49" parent="105" relname="contrast">и вряд ли кто-либо будет за него бороться.</segment>
		<segment id="50" parent="107" relname="span">Поэтому самое страшное в этой новости именно то, что нас, в принципе, вообще ничего не отделяет от возвращения в ГУЛАГ уже сейчас.</segment>
		<segment id="51" parent="106" relname="contrast">Мы балансируем над пропастью,</segment>
		<segment id="52" parent="106" relname="contrast">но между нами и обрывом нет ничего, ни одной преграды, ничего, что могло бы нас остановить.</segment>
		<segment id="53" parent="112" relname="span">Единственное, что может нам помочь — это сделать шаг вперед.</segment>
		<segment id="54" parent="113" relname="span">Шаг к тому,</segment>
		<segment id="55" parent="54" relname="purpose">чтобы сделать невозможным повторение трагических событий ХХ века в современной России.</segment>
		<segment id="56" parent="115" relname="span">Что это за шаг?</segment>
		<segment id="57" parent="133" relname="span">В моем представлении — все, что связано с сохранением исторической памяти о жертвах советских репрессий, все, что связано с называнием своими именами палачей, судей, доносчиков, все, что связано с правдивой историей нашей страны в советский период, все это помогает нам сделать этот шаг вперед.</segment>
		<segment id="58" parent="119" relname="contrast">Мы должны перевернуть эту страницу в нашей истории.</segment>
		<segment id="59" parent="116" relname="span">Но у нас никогда не получится этого сделать,</segment>
		<segment id="60" parent="135" relname="span">пока мы не почувствуем свою персональную ответственность</segment>
		<segment id="61" parent="134" relname="joint">за то, что происходило,</segment>
		<segment id="62" parent="134" relname="joint">происходит</segment>
		<segment id="63" parent="134" relname="joint">и будет происходить в нашей стране.</segment>
		<segment id="64" parent="127" relname="span">Пока мы не поймем,</segment>
		<segment id="65" parent="117" relname="joint">как мы участвуем,</segment>
		<segment id="66" parent="117" relname="joint">участвовали</segment>
		<segment id="67" parent="117" relname="joint">или будем участвовать в этом процессе.</segment>
		<segment id="68" parent="118" relname="contrast">Пока участие не станет общественной нормой,</segment>
		<segment id="69" parent="118" relname="contrast">а безучастность не перестанет ей быть.</segment>
		<group id="70" type="span" parent="71" relname="same-unit"/>
		<group id="71" type="multinuc" parent="72" relname="contrast"/>
		<group id="72" type="multinuc" parent="73" relname="span"/>
		<group id="73" type="span" parent="74" relname="span"/>
		<group id="74" type="span" parent="111" relname="span"/>
		<group id="75" type="span" parent="9" relname="evaluation"/>
		<group id="76" type="span" parent="81" relname="span"/>
		<group id="77" type="span" parent="80" relname="span"/>
		<group id="78" type="multinuc" parent="17" relname="cause"/>
		<group id="79" type="span" parent="18" relname="solutionhood"/>
		<group id="80" type="span" parent="76" relname="elaboration"/>
		<group id="81" type="span" parent="82" relname="span"/>
		<group id="82" type="span" parent="95" relname="joint"/>
		<group id="83" type="multinuc" parent="84" relname="joint"/>
		<group id="84" type="multinuc" parent="85" relname="span"/>
		<group id="85" type="span" parent="86" relname="span"/>
		<group id="86" type="span" parent="95" relname="joint"/>
		<group id="87" type="span" parent="88" relname="same-unit"/>
		<group id="88" type="multinuc" parent="89" relname="span"/>
		<group id="89" type="span" parent="90" relname="span"/>
		<group id="90" type="span" parent="92" relname="restatement"/>
		<group id="91" type="span" parent="26" relname="elaboration"/>
		<group id="92" type="multinuc" parent="22" relname="evidence"/>
		<group id="93" type="multinuc" parent="92" relname="restatement"/>
		<group id="94" type="span" parent="85" relname="elaboration"/>
		<group id="95" type="multinuc" parent="109" relname="joint"/>
		<group id="96" type="span" parent="129" relname="span"/>
		<group id="97" type="multinuc" parent="104" relname="contrast"/>
		<group id="98" type="multinuc" parent="36" relname="cause"/>
		<group id="99" type="span" parent="104" relname="contrast"/>
		<group id="100" type="span" parent="102" relname="span"/>
		<group id="101" type="span" parent="100" relname="elaboration"/>
		<group id="102" type="span" parent="43" relname="evidence"/>
		<group id="103" type="multinuc" parent="96" relname="elaboration"/>
		<group id="104" type="multinuc" parent="31" relname="elaboration"/>
		<group id="105" type="multinuc" parent="108" relname="span"/>
		<group id="106" type="multinuc" parent="50" relname="evaluation"/>
		<group id="107" type="span" parent="125" relname="span"/>
		<group id="108" type="span" parent="107" relname="cause"/>
		<group id="109" type="multinuc" parent="7" relname="elaboration"/>
		<group id="110" type="span" parent="74" relname="cause"/>
		<group id="111" type="span" />
		<group id="112" type="span" parent="114" relname="span"/>
		<group id="113" type="span" parent="112" relname="elaboration"/>
		<group id="114" type="span" parent="56" relname="preparation"/>
		<group id="115" type="span" parent="133" relname="solutionhood"/>
		<group id="116" type="span" parent="119" relname="contrast"/>
		<group id="117" type="multinuc" parent="64" relname="elaboration"/>
		<group id="118" type="multinuc" parent="128" relname="comparison"/>
		<group id="119" type="multinuc" parent="57" relname="elaboration"/>
		<group id="120" type="span" parent="77" relname="evidence"/>
		<group id="121" type="span" parent="89" relname="cause"/>
		<group id="122" type="span" parent="103" relname="contrast"/>
		<group id="123" type="span" parent="124" relname="span"/>
		<group id="124" type="span" parent="103" relname="contrast"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="109" relname="joint"/>
		<group id="127" type="span" parent="128" relname="comparison"/>
		<group id="128" type="multinuc" parent="59" relname="condition"/>
		<group id="129" type="span" parent="125" relname="cause"/>
		<group id="130" type="span" parent="131" relname="same-unit"/>
		<group id="131" type="multinuc" parent="97" relname="joint"/>
		<group id="132" type="span" parent="101" relname="span"/>
		<group id="133" type="span" parent="136" relname="span"/>
		<group id="134" type="multinuc" parent="60" relname="cause"/>
		<group id="135" type="span" parent="128" relname="comparison"/>
		<group id="136" type="span" />
	</body>
</rst>