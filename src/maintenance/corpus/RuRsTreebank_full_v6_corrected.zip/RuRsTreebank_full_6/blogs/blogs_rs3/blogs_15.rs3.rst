<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://my-first-time.livejournal.com/569638.html</segment>
		<segment id="2" >Первый раз сдача экзамена по ПДД</segment>
		<segment id="3" parent="152" relname="contrast">Была ранняя ранняя весна,</segment>
		<segment id="4" parent="150" relname="joint">но солнышко уже во всю припекало, уничтожая зимнее господство,</segment>
		<segment id="5" parent="150" relname="joint">пели ручьи,</segment>
		<segment id="6" parent="149" relname="joint">недобитые сугробы скукоживались</segment>
		<segment id="7" parent="149" relname="joint">и темнели.</segment>
		<segment id="8" parent="153" relname="contrast">Было раннее, раннее утро,</segment>
		<segment id="9" parent="153" relname="contrast">но я уже одетая, умытая, причесанная и даже почти позавтракавшая тряслась в вагоне метро уносившем меня в далекое Строгино.</segment>
		<segment id="10" parent="156" relname="joint">Отражение на темных окнах, мелькание станций, огней.</segment>
		<segment id="11" parent="155" relname="joint">Глаза мои выражали решительность и собранность.</segment>
		<segment id="12" parent="155" relname="joint">Сейчас или никогда.</segment>
		<segment id="13" parent="155" relname="joint">Полная и безоговорочная уверенность.</segment>
		<segment id="14" parent="155" relname="joint">800 вопросов наизусть.</segment>
		<segment id="15" parent="155" relname="joint">Каждый ответ как фотография в мозгу.</segment>
		<segment id="16" parent="154" relname="joint">Главное успеть ко времени сбора</segment>
		<segment id="17" parent="154" relname="joint">и в 8.00 быть около зала ПДД.</segment>
		<segment id="18" parent="155" relname="joint">Метро не ускоришь.</segment>
		<segment id="19" parent="155" relname="joint">По переходу бегом.</segment>
		<segment id="20" parent="155" relname="joint">Время, время.</segment>
		<segment id="21" parent="160" relname="span">В ту пору экзамены можно было сдавать экстерном.</segment>
		<segment id="22" parent="157" relname="sequence">Подала документы,</segment>
		<segment id="23" parent="157" relname="sequence">записалась</segment>
		<segment id="24" parent="158" relname="span">и вуаля - такого-то числа к такому-то времени и ни минутой позже быть у зала</segment>
		<segment id="25" parent="24" relname="cause">- вас вызовут.</segment>
		<segment id="26" parent="255" relname="span">И вот я неслась высунув язык,</segment>
		<segment id="27" parent="26" relname="cause">боясь опоздать, огибая скользкие подтеки на тротуарах, медлительных прохожих и умиляясь начавшемуся яркому рассвету.</segment>
		<segment id="28" parent="256" relname="evaluation">- Сегодня будет великолепный день!</segment>
		<segment id="29" parent="162" relname="span">Четко в 8.00 я запыхавшаяся и взмокшая, стояла около дверей зала ПДД в окружении таких же страждущих.</segment>
		<segment id="30" parent="161" relname="joint">Кто-то читал бумажные билеты шелестя страницами,</segment>
		<segment id="31" parent="161" relname="joint">кто-то из особо продвинутых щелкал ответы на экране смартфонов.</segment>
		<segment id="32" parent="162" relname="evaluation">Успела!</segment>
		<segment id="33" parent="230" relname="span">Народу тьма...</segment>
		<segment id="34" parent="35" relname="solutionhood">И все к 8-ми?</segment>
		<segment id="35" parent="243" relname="span">Похоже что так... Эх...</segment>
		<segment id="36" parent="164" relname="contrast">Я думала что это будет быстро,</segment>
		<segment id="37" parent="164" relname="contrast">но вероятно все как всегда.</segment>
		<segment id="38" parent="165" relname="concession">И зачем я так неслась сшибая прохожих.</segment>
		<segment id="39" parent="166" relname="joint">Стою,</segment>
		<segment id="40" parent="166" relname="joint">перевожу дух.</segment>
		<segment id="41" parent="237" relname="comparison">Вокруг шастают гаишники туда-сюда, туда-сюда. С бумажками и без.</segment>
		<segment id="42" parent="237" relname="comparison">Некоторые как зомби )))</segment>
		<segment id="43" parent="238" relname="sequence">Уже 8.15,</segment>
		<segment id="44" parent="238" relname="sequence">уже 8.30...</segment>
		<segment id="45" parent="239" relname="span">все ждут. Кого? Чего?</segment>
		<segment id="46" parent="168" relname="joint">Читают,</segment>
		<segment id="47" parent="168" relname="joint">щелкают,</segment>
		<segment id="48" parent="168" relname="joint">волнуются,</segment>
		<segment id="49" parent="168" relname="joint">шепчутся,</segment>
		<segment id="50" parent="169" relname="joint">гаишники ходят...</segment>
		<segment id="51" parent="170" relname="joint">Подпирая стену жду и я.</segment>
		<segment id="52" parent="233" relname="span">Выковорила из рюкзака бутылочку чая нестиа.</segment>
		<segment id="53" parent="234" relname="joint">Вкусно...</segment>
		<segment id="54" parent="234" relname="joint">Зашибись...</segment>
		<segment id="55" parent="171" relname="evaluation">Когда же наконец начнется действо?</segment>
		<segment id="56" parent="176" relname="span">8.45 что-то зашевелилось в воздухе.</segment>
		<segment id="57" parent="174" relname="sequence">Мимо нас проследовал высокий гаишник в руках которого были какие-то папки</segment>
		<segment id="58" parent="174" relname="sequence">и устремился прямо к залу,</segment>
		<segment id="59" parent="174" relname="sequence">вставил ключ в замок,</segment>
		<segment id="60" parent="174" relname="sequence">открыл дверь...</segment>
		<segment id="61" parent="175" relname="joint">Народ зашептался,</segment>
		<segment id="62" parent="175" relname="joint">оживился, кто-то с еще большим усердием стал шелестеть билетами,</segment>
		<segment id="63" parent="175" relname="joint">щелкать смартфонами, стараясь хоть в последнюю минутку, хоть что-то уловить.</segment>
		<segment id="64" parent="177" relname="evaluation">Началось!</segment>
		<segment id="65" parent="178" relname="sequence">Гаишник зашел внутрь зала</segment>
		<segment id="66" parent="178" relname="sequence">и закрыл за собой дверь. И тишина...</segment>
		<segment id="67" parent="180" relname="span">Народ выдохнул.</segment>
		<segment id="68" parent="182" relname="joint">9.00 подпираю стену,</segment>
		<segment id="69" parent="182" relname="joint">отхлебываю еще пару глотков чая</segment>
		<segment id="70" parent="258" relname="joint">и думаю что же там делает этот самый гаишник за закрытой дверью</segment>
		<segment id="71" parent="258" relname="joint">и вообще как там в этом зале что там, понятно что компьютеры,</segment>
		<segment id="72" parent="259" relname="contrast">но все же как там?</segment>
		<segment id="73" parent="183" relname="sequence">9.10 дверь открывается</segment>
		<segment id="74" parent="183" relname="sequence">и выходит наш гаишник со стопкой папок</segment>
		<segment id="75" parent="183" relname="sequence">и начинает зачитывать фамилии тех счасливчиков которые войдут внутрь.</segment>
		<segment id="76" parent="184" relname="sequence">Зачитывает по папкам</segment>
		<segment id="77" parent="184" relname="sequence">и после откладывает папки вниз,</segment>
		<segment id="78" parent="184" relname="sequence">зачитывает</segment>
		<segment id="79" parent="184" relname="sequence">и откладывает.</segment>
		<segment id="80" parent="186" relname="span">Десять человек в числе которых оказалась и я.</segment>
		<segment id="81" parent="80" relname="elaboration">Моя фамилия прозвучала предпоследней.</segment>
		<segment id="82" parent="235" relname="sequence">Быстренько чай в рюкзак</segment>
		<segment id="83" parent="235" relname="sequence">и вот я уже вхожу в зал.</segment>
		<segment id="84" parent="85" relname="background">По периферии зала стоят столы с пронумерованными компьютерами. Около двери вешалка. У противоположной от двери стены письменный стол с компьютером и папками, бумагами.</segment>
		<segment id="85" parent="188" relname="span">Все названные выстроились около вешалки.</segment>
		<segment id="86" parent="236" relname="contrast">- Пожалуйста все вещи - сумки, рюкзаки, верхнюю одежду оставляйте здесь.</segment>
		<segment id="87" parent="236" relname="contrast">С собой только паспорт.</segment>
		<segment id="88" parent="192" relname="joint">Гаишник сел за свой стол.</segment>
		<segment id="89" parent="193" relname="span">И стал вызывать к себе по одному</segment>
		<segment id="90" parent="89" relname="purpose">для регистрации и назначения компьютера.</segment>
		<segment id="91" parent="195" relname="sequence">Курточку пристроила на вешалку, рюкзак туда же.</segment>
		<segment id="92" parent="194" relname="joint">Стою жду когда прозвучит моя фамилия,</segment>
		<segment id="93" parent="194" relname="joint">тереблю паспорт.</segment>
		<segment id="94" parent="198" relname="span">И меня начинает постепенно накрывать волнение.</segment>
		<segment id="95" parent="196" relname="joint">Прямо вот до сего момента я нисколько не волновалась</segment>
		<segment id="96" parent="196" relname="joint">и была собрана</segment>
		<segment id="97" parent="196" relname="joint">и уверена</segment>
		<segment id="98" parent="260" relname="contrast">и тут вдруг аж до дрожания в руках.</segment>
		<segment id="99" parent="197" relname="joint">Ладошки мокрые...</segment>
		<segment id="100" parent="261" relname="evaluation">Прямо ВСД сплошное )))</segment>
		<segment id="101" parent="248" relname="solutionhood">Да что мне терять-то?</segment>
		<segment id="102" parent="200" relname="joint">Ну не сдам сейчас,</segment>
		<segment id="103" parent="250" relname="span">так потом сдам.</segment>
		<segment id="104" parent="201" relname="joint">Ну да ладно уж... мне-то да волноваться...</segment>
		<segment id="105" parent="106" relname="condition">да при моей работе</segment>
		<segment id="106" parent="263" relname="span">я вообще уже должна забыть что такое волнение.</segment>
		<segment id="107" parent="264" relname="span">Вздрогнула</segment>
		<segment id="108" parent="107" relname="cause">услышав свою фамилию.</segment>
		<segment id="109" parent="204" relname="sequence">Подошла к столу,</segment>
		<segment id="110" parent="204" relname="sequence">отдала паспорт. Вдох-выдох.</segment>
		<segment id="111" parent="206" relname="evaluation">Все будет хорошо!</segment>
		<segment id="112" parent="208" relname="joint">Он что-то там записал,</segment>
		<segment id="113" parent="208" relname="joint">вернул паспорт.</segment>
		<segment id="114" parent="209" relname="span">- Идите за 14 компьютер.</segment>
		<segment id="115" parent="210" relname="joint">Пошла,</segment>
		<segment id="116" parent="210" relname="joint">села.</segment>
		<segment id="117" parent="211" relname="joint">Все волнение куда-то разом и исчезло.</segment>
		<segment id="118" parent="211" relname="joint">Уверенность и четкость снова со мной.</segment>
		<segment id="119" parent="214" relname="joint">Далее, когда все расселись,</segment>
		<segment id="120" parent="214" relname="joint">прошел короткий инструктаж как пользоваться программой.</segment>
		<segment id="121" parent="216" relname="sequence">На экране увидела свою фамилию.</segment>
		<segment id="122" parent="215" relname="joint">Нажала пробел</segment>
		<segment id="123" parent="215" relname="joint">и экзамен начался.</segment>
		<segment id="124" parent="219" relname="joint">Каждый свой ответ надо было помимо выбранной цифры подтверждать пробелом.</segment>
		<segment id="125" parent="218" relname="span">Отщелкалась за 2 минуты. Без единой ошибки.</segment>
		<segment id="126" parent="217" relname="span">"Экзамен сдан!"</segment>
		<segment id="127" parent="126" relname="attribution">гласила зеленая надпись посередине компьютера.</segment>
		<segment id="128" parent="222" relname="joint">Сижу жду что будет дальше.</segment>
		<segment id="129" parent="222" relname="joint">Мыслей в голове почти никаких. Лишь надпись на экране мелькает.</segment>
		<segment id="130" parent="265" relname="span">Снова вздрогнула,</segment>
		<segment id="131" parent="130" relname="cause">услышав свою фамилию.</segment>
		<segment id="132" parent="223" relname="sequence">Гаишник поставил отметку о сдаче,</segment>
		<segment id="133" parent="223" relname="sequence">отдал документы.</segment>
		<segment id="134" parent="266" relname="sequence">- Теперь записывайтесь на площадку.</segment>
		<segment id="135" parent="136" relname="cause">Закрыв за собой дверь зала ПДД</segment>
		<segment id="136" parent="267" relname="span">выдохнула</segment>
		<segment id="137" parent="224" relname="joint">и победоносная счастливая улыбка озарило мое личико )))</segment>
		<segment id="138" parent="225" relname="evaluation">- Да! Один этап есть!</segment>
		<segment id="139" parent="227" relname="joint">Ехала в метро</segment>
		<segment id="140" parent="227" relname="joint">и сердце мое ликовало,</segment>
		<segment id="141" parent="227" relname="joint">на улице заливалось солнце,</segment>
		<segment id="142" parent="227" relname="joint">капала капель с крыш,</segment>
		<segment id="143" parent="227" relname="joint">а я шла</segment>
		<segment id="144" parent="227" relname="joint">и счастливо жмурилась.</segment>
		<segment id="145" parent="252" relname="span">Но не расслабляться!</segment>
		<segment id="146" parent="253" relname="span">У меня осталось самое ответственное - площадка.</segment>
		<segment id="147" parent="229" relname="span">И это уже совсем другая история</segment>
		<segment id="148" parent="147" relname="elaboration">о которой я здесь непременно напишу.</segment>
		<group id="149" type="multinuc" parent="150" relname="joint"/>
		<group id="150" type="multinuc" parent="151" relname="span"/>
		<group id="151" type="span" parent="152" relname="contrast"/>
		<group id="152" type="multinuc" parent="241" relname="background"/>
		<group id="153" type="multinuc" parent="156" relname="joint"/>
		<group id="154" type="multinuc" parent="155" relname="joint"/>
		<group id="155" type="multinuc" parent="156" relname="joint"/>
		<group id="156" type="multinuc" parent="241" relname="span"/>
		<group id="157" type="multinuc" parent="159" relname="span"/>
		<group id="158" type="span" parent="157" relname="sequence"/>
		<group id="159" type="span" parent="21" relname="elaboration"/>
		<group id="160" type="span" parent="255" relname="background"/>
		<group id="161" type="multinuc" parent="29" relname="elaboration"/>
		<group id="162" type="span" parent="163" relname="span"/>
		<group id="163" type="span" parent="167" relname="joint"/>
		<group id="164" type="multinuc" parent="165" relname="span"/>
		<group id="165" type="span" parent="244" relname="span"/>
		<group id="166" type="multinuc" parent="167" relname="joint"/>
		<group id="167" type="multinuc" />
		<group id="168" type="multinuc" parent="169" relname="joint"/>
		<group id="169" type="multinuc" parent="45" relname="elaboration"/>
		<group id="170" type="multinuc" parent="171" relname="span"/>
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" parent="173" relname="joint"/>
		<group id="173" type="multinuc" />
		<group id="174" type="multinuc" parent="56" relname="elaboration"/>
		<group id="175" type="multinuc" parent="176" relname="elaboration"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" parent="179" relname="span"/>
		<group id="178" type="multinuc" parent="67" relname="cause"/>
		<group id="179" type="span" parent="181" relname="joint"/>
		<group id="180" type="span" parent="181" relname="joint"/>
		<group id="181" type="multinuc" />
		<group id="182" type="multinuc" parent="246" relname="sequence"/>
		<group id="183" type="multinuc" parent="185" relname="sequence"/>
		<group id="184" type="multinuc" parent="185" relname="sequence"/>
		<group id="185" type="multinuc" parent="189" relname="span"/>
		<group id="186" type="span" parent="187" relname="joint"/>
		<group id="187" type="multinuc" parent="189" relname="elaboration"/>
		<group id="188" type="span" parent="247" relname="span"/>
		<group id="189" type="span" parent="245" relname="span"/>
		<group id="190" type="span" parent="191" relname="sequence"/>
		<group id="191" type="multinuc" />
		<group id="192" type="multinuc" parent="191" relname="sequence"/>
		<group id="193" type="span" parent="192" relname="joint"/>
		<group id="194" type="multinuc" parent="195" relname="sequence"/>
		<group id="195" type="multinuc" parent="203" relname="joint"/>
		<group id="196" type="multinuc" parent="260" relname="contrast"/>
		<group id="197" type="multinuc" parent="261" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" parent="202" relname="span"/>
		<group id="200" type="multinuc" parent="248" relname="span"/>
		<group id="201" type="multinuc" parent="103" relname="evaluation"/>
		<group id="202" type="span" parent="203" relname="joint"/>
		<group id="203" type="multinuc" parent="191" relname="sequence"/>
		<group id="204" type="multinuc" parent="205" relname="sequence"/>
		<group id="205" type="multinuc" parent="206" relname="span"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="216" relname="sequence"/>
		<group id="208" type="multinuc" parent="114" relname="attribution"/>
		<group id="209" type="span" parent="216" relname="sequence"/>
		<group id="210" type="multinuc" parent="212" relname="span"/>
		<group id="211" type="multinuc" parent="212" relname="elaboration"/>
		<group id="212" type="span" parent="213" relname="span"/>
		<group id="213" type="span" parent="216" relname="sequence"/>
		<group id="214" type="multinuc" parent="216" relname="sequence"/>
		<group id="215" type="multinuc" parent="220" relname="span"/>
		<group id="216" type="multinuc" />
		<group id="217" type="span" parent="125" relname="elaboration"/>
		<group id="218" type="span" parent="219" relname="joint"/>
		<group id="219" type="multinuc" parent="220" relname="elaboration"/>
		<group id="220" type="span" parent="221" relname="span"/>
		<group id="221" type="span" parent="216" relname="sequence"/>
		<group id="222" type="multinuc" parent="216" relname="sequence"/>
		<group id="223" type="multinuc" parent="266" relname="sequence"/>
		<group id="224" type="multinuc" parent="225" relname="span"/>
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" parent="216" relname="sequence"/>
		<group id="227" type="multinuc" parent="228" relname="contrast"/>
		<group id="228" type="multinuc" parent="254" relname="span"/>
		<group id="229" type="span" parent="146" relname="elaboration"/>
		<group id="230" type="span" parent="232" relname="span"/>
		<group id="231" type="span" parent="167" relname="joint"/>
		<group id="232" type="span" parent="231" relname="span"/>
		<group id="233" type="span" parent="170" relname="joint"/>
		<group id="234" type="multinuc" parent="52" relname="evaluation"/>
		<group id="235" type="multinuc" parent="187" relname="joint"/>
		<group id="236" type="multinuc" parent="188" relname="elaboration"/>
		<group id="237" type="multinuc" parent="167" relname="joint"/>
		<group id="238" type="multinuc" parent="239" relname="background"/>
		<group id="239" type="span" parent="240" relname="span"/>
		<group id="240" type="span" parent="173" relname="joint"/>
		<group id="241" type="span" parent="242" relname="span"/>
		<group id="242" type="span" />
		<group id="243" type="span" parent="33" relname="elaboration"/>
		<group id="244" type="span" parent="230" relname="evaluation"/>
		<group id="245" type="span" parent="246" relname="sequence"/>
		<group id="246" type="multinuc" parent="190" relname="span"/>
		<group id="247" type="span" parent="191" relname="sequence"/>
		<group id="248" type="span" parent="249" relname="span"/>
		<group id="249" type="span" parent="251" relname="span"/>
		<group id="250" type="span" parent="200" relname="joint"/>
		<group id="251" type="span" parent="199" relname="evaluation"/>
		<group id="252" type="span" parent="228" relname="contrast"/>
		<group id="253" type="span" parent="145" relname="cause"/>
		<group id="254" type="span" />
		<group id="255" type="span" parent="256" relname="span"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" />
		<group id="258" type="multinuc" parent="259" relname="contrast"/>
		<group id="259" type="multinuc" parent="246" relname="sequence"/>
		<group id="260" type="multinuc" parent="197" relname="joint"/>
		<group id="261" type="span" parent="262" relname="span"/>
		<group id="262" type="span" parent="94" relname="elaboration"/>
		<group id="263" type="span" parent="201" relname="joint"/>
		<group id="264" type="span" parent="205" relname="sequence"/>
		<group id="265" type="span" parent="222" relname="joint"/>
		<group id="266" type="multinuc" parent="216" relname="sequence"/>
		<group id="267" type="span" parent="224" relname="joint"/>
	</body>
</rst>