<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >﻿https://odin-moy-den.livejournal.com/2216337.html</segment>
		<segment id="2" >ОМНГ (из жизни таксиста одного городка)</segment>
		<segment id="3" parent="181" relname="span">Привет. Я — Сергей.</segment>
		<segment id="4" parent="180" relname="joint">Живу в одном из городков нашей планеты.</segment>
		<segment id="5" parent="180" relname="joint">И в этом же городке занимаюсь работой в такси.</segment>
		<segment id="6" parent="182" relname="joint">Многие мне говорят, что всех денег не заработаешь</segment>
		<segment id="7" parent="183" relname="span">и работать на Новый год совсем не стоит,</segment>
		<segment id="8" parent="7" relname="elaboration">особенно когда ты не в найме, а самостоятелен.</segment>
		<segment id="9" parent="184" relname="contrast">По поводу денег я согласен, конечно.</segment>
		<segment id="10" parent="186" relname="same-unit">Но уверен,</segment>
		<segment id="11" parent="12" relname="condition">что те деньги, которые заработать можно,</segment>
		<segment id="12" parent="185" relname="span">зарабатывать нужно.</segment>
		<segment id="13" parent="331" relname="joint">Тем более, когда твой род деятельности соответствует ситуации.</segment>
		<segment id="14" parent="190" relname="span">Поэтому собираюсь провести новогоднюю ночь за рулём и поделиться со всеми, кому будет  интересно.</segment>
		<segment id="15" parent="14" relname="elaboration">Под катом 70+ фотографий. IMG</segment>
		<segment id="16" parent="191" relname="contrast">Наверное, после такого вступления, название поста все уже расшифровали.</segment>
		<segment id="17" parent="191" relname="contrast">Но на всякий случай сделаю это и я. IMG</segment>
		<segment id="18" parent="326" relname="span">Один мой Новый год. IMG</segment>
		<segment id="19" parent="327" relname="span">Итак, поехали... IMG</segment>
		<segment id="20" parent="328" relname="sequence">Вставать запланировал по-раньше.</segment>
		<segment id="21" parent="22" relname="cause">Будильник сработал,</segment>
		<segment id="22" parent="192" relname="span">поэтому всё закрутилось. IMG</segment>
		<segment id="23" parent="197" relname="span">Мелодия в будильнике у меня весёлая.</segment>
		<segment id="24" parent="194" relname="same-unit">Все говорят,</segment>
		<segment id="25" parent="26" relname="condition">что установив её,</segment>
		<segment id="26" parent="193" relname="span">я поступил очень эгоистично</segment>
		<segment id="27" parent="195" relname="span">и в этот момент никому не даю спать. IMG</segment>
		<segment id="28" parent="196" relname="contrast">Но эта мелодия каждый раз напоминает мне, что нужно пожелать доброго утра одной моей очень хорошей знакомой...</segment>
		<segment id="29" parent="203" relname="preparation">Чем сразу быстренько и займусь) IMG</segment>
		<segment id="30" parent="202" relname="contrast">Уж не подумайте, что таким образом я её могу разбудить.</segment>
		<segment id="31" parent="201" relname="same-unit">Просто,</segment>
		<segment id="32" parent="33" relname="condition">когда она проснётся,</segment>
		<segment id="33" parent="199" relname="span">то как минимум одно «Доброе утро» у неё уже будет</segment>
		<segment id="34" parent="200" relname="joint">и она, может быть, улыбнётся) IMG</segment>
		<segment id="35" parent="207" relname="preparation">Теперь нужно проснуться...</segment>
		<segment id="36" parent="205" relname="sequence">50 приседаний, 30 отжиманий от пола и 20 пресса очень даже помогают.</segment>
		<segment id="37" parent="205" relname="sequence">Теперь утренний холодный душ и...</segment>
		<segment id="38" parent="206" relname="span">Просыпание прошло успешно!)</segment>
		<segment id="39" parent="38" relname="concession">Фотки не выкладываю))) IMG</segment>
		<segment id="40" parent="210" relname="joint">Времени мало, поэтому всё делаю быстро! IMG</segment>
		<segment id="41" parent="211" relname="sequence">Теперь нужно позавтракать</segment>
		<segment id="42" parent="212" relname="span">и заняться ещё одним важным делом.</segment>
		<segment id="43" parent="42" relname="elaboration">Должно хватить минут 30. IMG</segment>
		<segment id="44" parent="219" relname="span">Важное дело...</segment>
		<segment id="45" parent="218" relname="span">После каждой «рабочей смены» выделяю 10 usd на покупку «биточков».</segment>
		<segment id="46" parent="215" relname="joint">Утром они уже на счету биржи криптовалют.</segment>
		<segment id="47" parent="215" relname="joint">И с ними необходимо поработать.</segment>
		<segment id="48" parent="213" relname="contrast">Что с ними делаю — отдельная тема.</segment>
		<segment id="49" parent="214" relname="span">Но за год уже накопился норм капиталец).</segment>
		<segment id="50" parent="49" relname="cause">Ведь не всю жизнь в такси «танцевать») IMG</segment>
		<segment id="51" parent="211" relname="sequence">Провожающие... Будильник разбудил не только меня) IMG</segment>
		<segment id="52" parent="224" relname="preparation">Теперь бегом на «дачу».</segment>
		<segment id="53" parent="54" relname="cause">Она в гараже,</segment>
		<segment id="54" parent="221" relname="span">бежать не далеко)</segment>
		<segment id="55" parent="221" relname="elaboration">График опережаю на 4 минуты) IMG</segment>
		<segment id="56" parent="222" relname="evaluation">Водные процедуры важны не только мне.</segment>
		<segment id="57" parent="226" relname="span">Мчимся в «баню» IMG</segment>
		<segment id="58" parent="223" relname="contrast">Там ещё спят...</segment>
		<segment id="59" parent="223" relname="contrast">Но есть волшебный звоночек!) IMG</segment>
		<segment id="60" parent="225" relname="sequence">Мойка, коврики, пылесос... IMG</segment>
		<segment id="61" parent="225" relname="sequence">И вот она — моя «дачка») IMG</segment>
		<segment id="62" parent="229" relname="span">Теперь заправка.</segment>
		<segment id="63" parent="228" relname="joint">Здесь у меня скидка почти 25%.</segment>
		<segment id="64" parent="228" relname="joint">Полный бак (а это почти на 550 км) совсем не помешает. IMG</segment>
		<segment id="65" parent="236" relname="sequence">Работу начинаем с моего любимого американо с мохито в любимой «чашке» и... IMG</segment>
		<segment id="66" parent="231" relname="sequence">Как-то заехал на АЗС и внимание привлекла книга с приятным названием и переплётом любимого цвета))</segment>
		<segment id="67" parent="230" relname="span">Полистал...</segment>
		<segment id="68" parent="67" relname="evaluation">Процесс затянулся минут на 20.</segment>
		<segment id="69" parent="232" relname="contrast">Мысли основателей философского направления под названием стоицизм.</segment>
		<segment id="70" parent="232" relname="contrast">А я то думал, что в этом направлении думаю только я)))</segment>
		<segment id="71" parent="233" relname="span">Оказалось, что всё уже давно придумано! IMG</segment>
		<segment id="72" parent="241" relname="span">Книга очень интересно построена.</segment>
		<segment id="73" parent="237" relname="contrast">Её не нужно «глотать».</segment>
		<segment id="74" parent="234" relname="span">В ней 366 изречений Великих,</segment>
		<segment id="75" parent="74" relname="elaboration">каждое из которых рассчитано на размышления в течение дня.</segment>
		<segment id="76" parent="234" relname="condition">В моём случае — в течение рабочей смены вместо сквернословия и нервов в пробках))</segment>
		<segment id="77" parent="239" relname="contrast">Даже привязка к календарю есть.</segment>
		<segment id="78" parent="79" relname="cause">Правда я начал не 1-го января, а чуть раньше,</segment>
		<segment id="79" parent="235" relname="span">поэтому мой календарь немного сдвинут)</segment>
		<segment id="80" parent="245" relname="span">Сегодня будем размышлять над следующим изречением</segment>
		<segment id="81" parent="80" relname="condition">(тем, кто не знает иностранных языков — Google в помощь)</segment>
		<segment id="82" parent="246" relname="same-unit">IMG</segment>
		<segment id="83" parent="255" relname="span">Пора в работу! IMG</segment>
		<segment id="84" parent="339" relname="span">Начинаем в UBER.</segment>
		<segment id="85" parent="337" relname="span">Рекламная наклейка на бортах авто предполагает премию около 300 usd</segment>
		<segment id="86" parent="85" relname="condition">в случае выполнения 500 поездок в месяц.</segment>
		<segment id="87" parent="337" relname="elaboration">Мне осталось 19.</segment>
		<segment id="88" parent="252" relname="span">Нормальные площадки включили таймер.</segment>
		<segment id="89" parent="253" relname="span">Можно работать не больше 12 часов</segment>
		<segment id="90" parent="89" relname="condition">(без учета отключений в процессе работы).</segment>
		<segment id="91" parent="254" relname="sequence">После этого необходимо сделать паузу не меньше 6-ти часов.</segment>
		<segment id="92" parent="256" relname="span">Буду работать на этой площадке до окончания таймера.</segment>
		<segment id="93" parent="260" relname="sequence">После выхода на линию практически сразу первый заказ... IMG</segment>
		<segment id="94" parent="260" relname="sequence">Включаем навигацию.</segment>
		<segment id="95" parent="260" relname="sequence">Поехали... IMG</segment>
		<segment id="96" parent="261" relname="contrast">Городок только просыпается перед Новым годом.</segment>
		<segment id="97" parent="262" relname="span">Но заказов уже много. IMG</segment>
		<segment id="98" parent="263" relname="joint">Светает быстро.</segment>
		<segment id="99" parent="263" relname="joint">Работа кипит... IMG</segment>
		<segment id="100" parent="266" relname="joint">Есть в нашем городке и железнодорожный вокзал.</segment>
		<segment id="101" parent="266" relname="joint">Иногда сюда приезжают приезжие.</segment>
		<segment id="102" parent="265" relname="span">За одним из таких сейчас еду. IMG</segment>
		<segment id="103" parent="104" relname="cause">Приезжий очень любит наш городок</segment>
		<segment id="104" parent="264" relname="span">и решил поселиться в Hilton. IMG</segment>
		<segment id="105" parent="265" relname="elaboration">Центральные улица и площадь. IMG Есть и речушка... IMG И Дворец пионеров. Правда, сейчас как-то по-другому называется... IMG И золотые купола... Но не для шансона, а для верян и туристов. IMG И память о подвигах наших дедов мы чтим, хоть бы кто что не говорил... IMG А на этом бульваре в рабочие дни обычно пробки. IMG 10 минут от центра. Почти центр...) IMG Кто-то построил себе гаражик) IMG Не Европа поди пока. На тротуарах парковаться можно) IMG</segment>
		<segment id="106" parent="277" relname="preparation">А это административная часть городка. IMG</segment>
		<segment id="107" parent="275" relname="span">Здесь заседают очень серьёзные пацаны.</segment>
		<segment id="108" parent="267" relname="contrast">У них очень важная работа:</segment>
		<segment id="109" parent="268" relname="span">нажимать кнопки «за-против-воздержался».</segment>
		<segment id="110" parent="269" relname="span">Воздерживаются редко.</segment>
		<segment id="111" parent="270" relname="span">Только когда по какой-то причине антибиотики принимают.</segment>
		<segment id="112" parent="111" relname="background">Ведь всем известно, что антибиотики и алкоголь вместе нельзя. IMG</segment>
		<segment id="113" parent="274" relname="span">Кабинет министров.</segment>
		<segment id="114" parent="272" relname="same-unit">Вот всегда,</segment>
		<segment id="115" parent="116" relname="condition">когда проезжаю мимо,</segment>
		<segment id="116" parent="271" relname="span">задаюсь вопросом: зачем в кабинете столько окон?</segment>
		<segment id="117" parent="273" relname="contrast">Но этот вопрос скорее к дизайнерам интерьеров-экстерьеров... IMG</segment>
		<segment id="118" parent="282" relname="span">Поднимаемся по улочке... IMG</segment>
		<segment id="119" parent="118" relname="elaboration">А вот и ёлочка!)</segment>
		<segment id="120" parent="283" relname="joint">Сегодня здесь и выпить-закусить можно,</segment>
		<segment id="121" parent="283" relname="joint">и просто пройтись... IMG</segment>
		<segment id="122" parent="284" relname="elaboration">И HYATT рядом.</segment>
		<segment id="123" parent="286" relname="sequence">Можно, к примеру, познакомиться под ёлочкой с красивой девушкой,</segment>
		<segment id="124" parent="286" relname="sequence">рядом выпить-закусить</segment>
		<segment id="125" parent="286" relname="sequence">и пригласить её на утренний «завтрак в постель» в HYATT.</segment>
		<segment id="126" parent="289" relname="contrast">Думаю, вероятность отказа очень низкая!</segment>
		<segment id="127" parent="128" relname="solutionhood">Ой... Чего это я?</segment>
		<segment id="128" parent="288" relname="span">У меня размышления над изречением Марка Аврелия ведь... IMG</segment>
		<segment id="129" parent="293" relname="span">Как и во всех городках, в нашем тоже есть рынок.</segment>
		<segment id="130" parent="129" relname="elaboration">Кстати, на некоторых торговых точках здесь можно рассчитаться криптой... IMG</segment>
		<segment id="131" parent="299" relname="span">Ну а вот и трофей)</segment>
		<segment id="132" parent="131" relname="background">У таксистов они часто случаются.</segment>
		<segment id="133" parent="297" relname="span">Вез девушку из супермаркета с двумя полными пакетами.</segment>
		<segment id="134" parent="294" relname="contrast">Не ставила в багажник,</segment>
		<segment id="135" parent="294" relname="contrast">взяла с собой в салон.</segment>
		<segment id="136" parent="297" relname="evaluation">Видно выпало...</segment>
		<segment id="137" parent="295" relname="contrast">Надеюсь, носиться возвращать не придется)</segment>
		<segment id="138" parent="296" relname="joint">Можно стекла протирать в авто,</segment>
		<segment id="139" parent="298" relname="contrast">а можно просто в сервант поставить.</segment>
		<segment id="140" parent="298" relname="contrast">Правда, серванта у меня нет) IMG</segment>
		<segment id="141" parent="305" relname="sequence">Пробка... Можно поразмышлять о мысли Марка Аврелия) IMG</segment>
		<segment id="142" parent="333" relname="joint">Время сделать перерывчик</segment>
		<segment id="143" parent="333" relname="joint">и перекусить... IMG</segment>
		<segment id="144" parent="334" relname="elaboration">Как всегда — АЗС) IMG</segment>
		<segment id="145" parent="335" relname="elaboration">Сегодня у нас запеченные в сухарях куриные грудки с соусом барбекю, чиабата с сыром и чай с чёрной смородиной и базиликом. IMG</segment>
		<segment id="146" parent="147" relname="evaluation">Так хочется сотворить что-то новогоднее...</segment>
		<segment id="147" parent="310" relname="span">Идея приходит конечно же на АЗС.</segment>
		<segment id="148" parent="308" relname="span">Увидел шоколад.</segment>
		<segment id="149" parent="307" relname="comparison">С новогодней скидкой. Чуть меньше 1,3 usd за штучку.</segment>
		<segment id="150" parent="151" relname="condition">Если не изменяет память,</segment>
		<segment id="151" parent="306" relname="span">дешевле, чем в Duty Free.</segment>
		<segment id="152" parent="311" relname="contrast">Беру 10 штучек для клиентов!</segment>
		<segment id="153" parent="311" relname="contrast">И пусть только откажутся фоткаться)) IMG</segment>
		<segment id="154" parent="313" relname="span">Вот что вышло)) IMG</segment>
		<segment id="155" parent="154" relname="elaboration">Шоколад закончился)</segment>
		<segment id="156" parent="316" relname="preparation">Работаем дальше!) IMG</segment>
		<segment id="157" parent="316" relname="span">Перед самым Новым годом сработал таймер UBER.</segment>
		<segment id="158" parent="159" relname="cause">Самое важное, что есть 19 поездок с бооольшим запасом!)</segment>
		<segment id="159" parent="315" relname="span">Премия будет!)</segment>
		<segment id="160" parent="320" relname="sequence">Переключаюсь в Яндекс)</segment>
		<segment id="161" parent="324" relname="span">И работаю пока не почувствую усталость и опасность!) IMG</segment>
		<segment id="162" parent="325" relname="span">Всё! На этом, пожалуй, всё!</segment>
		<segment id="163" parent="318" relname="joint">Хоть от заказов отбоя нет</segment>
		<segment id="164" parent="318" relname="joint">и коэффициенты высокие,</segment>
		<segment id="165" parent="319" relname="contrast">но как раз тот случай, что всех денег не заработаешь) IMG</segment>
		<segment id="166" parent="323" relname="span">Дома! Так получилось, что уже через 2 минуты!) IMG</segment>
		<segment id="167" parent="166" relname="elaboration">Намотал по нашему городку аж 532 км) IMG</segment>
		<segment id="168" parent="320" relname="sequence">До вечера отдыхаю.</segment>
		<segment id="169" parent="322" relname="span">А вечером...</segment>
		<segment id="170" parent="321" relname="span">Костёр, сосиски...</segment>
		<segment id="171" parent="170" relname="elaboration">И будет это где-то так... IMG</segment>
		<segment id="172" >С Новым годом!)</segment>
		<segment id="173" >P.S. Огромное спасибо замечательной и прекрасной Маше</segment>
		<segment id="174" >за поддержку и помощь в создании поста!)</segment>
		<segment id="175" >P.P.S. Большое спасибо древнегреческим мыслителям</segment>
		<segment id="176" >за возможность не нервничать</segment>
		<segment id="177" >и не сквернословить в городских пробках!)</segment>
		<segment id="178" >P.P.P.S. Отдельное спасибо Сатоси Накамото</segment>
		<segment id="179" >за возможность в разы увеличивать заработанные кровью и потом деньги без крови и пота!)</segment>
		<group id="180" type="multinuc" parent="3" relname="elaboration"/>
		<group id="181" type="span" parent="189" relname="preparation"/>
		<group id="182" type="multinuc" parent="187" relname="span"/>
		<group id="183" type="span" parent="182" relname="joint"/>
		<group id="184" type="multinuc" parent="187" relname="evaluation"/>
		<group id="185" type="span" parent="186" relname="same-unit"/>
		<group id="186" type="multinuc" parent="331" relname="joint"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" parent="190" relname="cause"/>
		<group id="189" type="span" parent="249" relname="span"/>
		<group id="190" type="span" parent="189" relname="span"/>
		<group id="191" type="multinuc" parent="18" relname="preparation"/>
		<group id="192" type="span" parent="198" relname="span"/>
		<group id="193" type="span" parent="194" relname="same-unit"/>
		<group id="194" type="multinuc" parent="27" relname="evaluation"/>
		<group id="195" type="span" parent="196" relname="contrast"/>
		<group id="196" type="multinuc" parent="23" relname="elaboration"/>
		<group id="197" type="span" parent="192" relname="elaboration"/>
		<group id="198" type="span" parent="328" relname="sequence"/>
		<group id="199" type="span" parent="201" relname="same-unit"/>
		<group id="200" type="multinuc" parent="202" relname="contrast"/>
		<group id="201" type="multinuc" parent="200" relname="joint"/>
		<group id="202" type="multinuc" parent="203" relname="span"/>
		<group id="203" type="span" parent="204" relname="span"/>
		<group id="204" type="span" />
		<group id="205" type="multinuc" parent="207" relname="span"/>
		<group id="206" type="span" parent="210" relname="joint"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" />
		<group id="210" type="multinuc" parent="208" relname="evaluation"/>
		<group id="211" type="multinuc" />
		<group id="212" type="span" parent="220" relname="span"/>
		<group id="213" type="multinuc" parent="216" relname="elaboration"/>
		<group id="214" type="span" parent="213" relname="contrast"/>
		<group id="215" type="multinuc" parent="216" relname="span"/>
		<group id="216" type="span" parent="217" relname="span"/>
		<group id="217" type="span" parent="45" relname="elaboration"/>
		<group id="218" type="span" parent="44" relname="elaboration"/>
		<group id="219" type="span" parent="212" relname="elaboration"/>
		<group id="220" type="span" parent="211" relname="sequence"/>
		<group id="221" type="span" parent="222" relname="span"/>
		<group id="222" type="span" parent="224" relname="span"/>
		<group id="223" type="multinuc" parent="57" relname="elaboration"/>
		<group id="224" type="span" parent="227" relname="span"/>
		<group id="225" type="multinuc" />
		<group id="226" type="span" parent="225" relname="sequence"/>
		<group id="227" type="span" parent="225" relname="sequence"/>
		<group id="228" type="multinuc" parent="62" relname="elaboration"/>
		<group id="229" type="span" parent="236" relname="sequence"/>
		<group id="230" type="span" parent="231" relname="sequence"/>
		<group id="231" type="multinuc" parent="243" relname="preparation"/>
		<group id="232" type="multinuc" parent="71" relname="evidence"/>
		<group id="233" type="span" parent="241" relname="background"/>
		<group id="234" type="span" parent="238" relname="span"/>
		<group id="235" type="span" parent="239" relname="contrast"/>
		<group id="236" type="multinuc" />
		<group id="237" type="multinuc" parent="240" relname="joint"/>
		<group id="238" type="span" parent="237" relname="contrast"/>
		<group id="239" type="multinuc" parent="240" relname="joint"/>
		<group id="240" type="multinuc" parent="248" relname="span"/>
		<group id="241" type="span" parent="242" relname="span"/>
		<group id="242" type="span" parent="243" relname="span"/>
		<group id="243" type="span" parent="244" relname="span"/>
		<group id="244" type="span" />
		<group id="245" type="span" parent="246" relname="same-unit"/>
		<group id="246" type="multinuc" parent="248" relname="elaboration"/>
		<group id="247" type="span" parent="72" relname="elaboration"/>
		<group id="248" type="span" parent="247" relname="span"/>
		<group id="249" type="span" />
		<group id="252" type="span" parent="254" relname="sequence"/>
		<group id="253" type="span" parent="88" relname="elaboration"/>
		<group id="254" type="multinuc" parent="92" relname="cause"/>
		<group id="255" type="span" parent="258" relname="preparation"/>
		<group id="256" type="span" parent="257" relname="joint"/>
		<group id="257" type="multinuc" parent="258" relname="span"/>
		<group id="258" type="span" parent="259" relname="span"/>
		<group id="259" type="span" />
		<group id="260" type="multinuc" />
		<group id="261" type="multinuc" parent="260" relname="sequence"/>
		<group id="262" type="span" parent="261" relname="contrast"/>
		<group id="263" type="multinuc" parent="97" relname="elaboration"/>
		<group id="264" type="span" parent="102" relname="elaboration"/>
		<group id="265" type="span" parent="279" relname="span"/>
		<group id="266" type="multinuc" parent="280" relname="background"/>
		<group id="267" type="multinuc" parent="107" relname="evaluation"/>
		<group id="268" type="span" parent="267" relname="contrast"/>
		<group id="269" type="span" parent="109" relname="elaboration"/>
		<group id="270" type="span" parent="110" relname="condition"/>
		<group id="271" type="span" parent="272" relname="same-unit"/>
		<group id="272" type="multinuc" parent="273" relname="contrast"/>
		<group id="273" type="multinuc" parent="113" relname="evaluation"/>
		<group id="274" type="span" parent="276" relname="joint"/>
		<group id="275" type="span" parent="276" relname="joint"/>
		<group id="276" type="multinuc" parent="277" relname="span"/>
		<group id="277" type="span" parent="278" relname="span"/>
		<group id="278" type="span" />
		<group id="279" type="span" parent="280" relname="span"/>
		<group id="280" type="span" parent="281" relname="span"/>
		<group id="281" type="span" parent="260" relname="sequence"/>
		<group id="282" type="span" parent="285" relname="preparation"/>
		<group id="283" type="multinuc" parent="284" relname="span"/>
		<group id="284" type="span" parent="285" relname="span"/>
		<group id="285" type="span" parent="292" relname="span"/>
		<group id="286" type="multinuc" parent="287" relname="span"/>
		<group id="287" type="span" parent="290" relname="span"/>
		<group id="288" type="span" parent="289" relname="contrast"/>
		<group id="289" type="multinuc" parent="287" relname="evaluation"/>
		<group id="290" type="span" parent="291" relname="span"/>
		<group id="291" type="span" />
		<group id="292" type="span" parent="290" relname="background"/>
		<group id="293" type="span" parent="303" relname="preparation"/>
		<group id="294" type="multinuc" parent="133" relname="elaboration"/>
		<group id="295" type="multinuc" parent="300" relname="span"/>
		<group id="296" type="multinuc" parent="301" relname="purpose"/>
		<group id="297" type="span" parent="332" relname="span"/>
		<group id="298" type="multinuc" parent="296" relname="joint"/>
		<group id="299" type="span" parent="303" relname="span"/>
		<group id="300" type="span" parent="301" relname="span"/>
		<group id="301" type="span" parent="302" relname="span"/>
		<group id="302" type="span" parent="299" relname="elaboration"/>
		<group id="303" type="span" parent="304" relname="span"/>
		<group id="304" type="span" />
		<group id="305" type="multinuc" />
		<group id="306" type="span" parent="307" relname="comparison"/>
		<group id="307" type="multinuc" parent="148" relname="elaboration"/>
		<group id="308" type="span" parent="312" relname="span"/>
		<group id="309" type="multinuc" parent="313" relname="solutionhood"/>
		<group id="310" type="span" parent="308" relname="preparation"/>
		<group id="311" type="multinuc" parent="309" relname="joint"/>
		<group id="312" type="span" parent="309" relname="joint"/>
		<group id="313" type="span" parent="314" relname="span"/>
		<group id="314" type="span" />
		<group id="315" type="span" parent="157" relname="evaluation"/>
		<group id="316" type="span" parent="317" relname="span"/>
		<group id="317" type="span" parent="320" relname="sequence"/>
		<group id="318" type="multinuc" parent="319" relname="contrast"/>
		<group id="319" type="multinuc" parent="162" relname="evaluation"/>
		<group id="320" type="multinuc" />
		<group id="321" type="span" parent="169" relname="elaboration"/>
		<group id="322" type="span" />
		<group id="323" type="span" parent="320" relname="sequence"/>
		<group id="324" type="span" parent="320" relname="sequence"/>
		<group id="325" type="span" parent="161" relname="evaluation"/>
		<group id="326" type="span" parent="19" relname="preparation"/>
		<group id="327" type="span" parent="329" relname="preparation"/>
		<group id="328" type="multinuc" parent="329" relname="span"/>
		<group id="329" type="span" parent="330" relname="span"/>
		<group id="330" type="span" />
		<group id="331" type="multinuc" parent="184" relname="contrast"/>
		<group id="332" type="span" parent="295" relname="contrast"/>
		<group id="333" type="multinuc" parent="334" relname="span"/>
		<group id="334" type="span" parent="335" relname="span"/>
		<group id="335" type="span" parent="336" relname="span"/>
		<group id="336" type="span" parent="305" relname="sequence"/>
		<group id="337" type="span" parent="338" relname="span"/>
		<group id="338" type="span" parent="84" relname="elaboration"/>
		<group id="339" type="span" parent="83" relname="elaboration"/>
	</body>
</rst>