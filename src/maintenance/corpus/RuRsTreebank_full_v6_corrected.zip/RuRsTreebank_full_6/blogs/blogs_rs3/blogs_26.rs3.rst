<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://lena-miro.ru/1393544.html</segment>
		<segment id="2" >Три секрета питания</segment>
		<segment id="3" parent="147" relname="span">На днях стала свидетелем беседы тренера с подопечной.</segment>
		<segment id="4" parent="3" relname="elaboration">Идиот с жизнерадостной улыбкой дебила нагрузил девку так, что она чуть не свалилась в обморок.</segment>
		<segment id="5" parent="77" relname="contrast">– Ты ела сегодня?</segment>
		<segment id="6" parent="79" relname="span">– Ела!</segment>
		<segment id="7" parent="78" relname="span">– Что ела?</segment>
		<segment id="8" parent="7" relname="elaboration">– Омлет с помидорами, яблоко, ветчину!</segment>
		<segment id="9" parent="80" relname="span">– Хм, а почему тогда «заваливаешься» на тренировке?</segment>
		<segment id="10" parent="9" relname="evaluation">Странно это, всё очень странно!</segment>
		<segment id="11" parent="81" relname="contrast">Дебил. Идиот.</segment>
		<segment id="12" parent="81" relname="contrast">Бедная девочка! IMG</segment>
		<segment id="13" parent="86" relname="contrast">Вы знаете, что построение тела зависит от питания не меньше, чем от занятий.</segment>
		<segment id="14" parent="87" relname="joint">Но правильное питание – тема очень индивидуальная,</segment>
		<segment id="15" parent="87" relname="joint">а урезание калорий – не всегда путь к похудению.</segment>
		<segment id="16" parent="88" relname="span">Поговорим о секретах питания?</segment>
		<segment id="17" parent="89" relname="span">Секрет первый состоит в том, что мышцам</segment>
		<segment id="18" parent="17" relname="purpose">для роста,</segment>
		<segment id="19" parent="89" relname="concession">вопреки расхожему стереотипу,</segment>
		<segment id="20" parent="91" relname="same-unit">нужны не только и не столько белки, сколько углеводы.</segment>
		<segment id="21" parent="92" relname="span">Они же, сложные углеводы, дают силы</segment>
		<segment id="22" parent="21" relname="purpose">для тренировки.</segment>
		<segment id="23" parent="95" relname="contrast">Я понимаю, что большинству нужно худеть,</segment>
		<segment id="24" parent="95" relname="contrast">но одного ограничения калорий для этого недостаточно.</segment>
		<segment id="25" parent="97" relname="condition">Скинув пять килограмм на диете,</segment>
		<segment id="26" parent="97" relname="span">вы моментально их наберёте,</segment>
		<segment id="27" parent="100" relname="span">как только начнёте есть.</segment>
		<segment id="28" parent="99" relname="span">А вы – начнёте,</segment>
		<segment id="29" parent="28" relname="cause">потому что постоянно сидеть на дефиците калорий физиологически невозможно.</segment>
		<segment id="30" parent="106" relname="span">Качественно и надолго похудеть можно лишь построив мышцы.</segment>
		<segment id="31" parent="103" relname="joint">Во-первых, тело будет красивым,</segment>
		<segment id="32" parent="102" relname="span">а во-вторых, мышцам нужно больше калорий,</segment>
		<segment id="33" parent="32" relname="condition">даже если вы лежите себе на диване.</segment>
		<segment id="34" parent="104" relname="span">Отказ от всех углеводов</segment>
		<segment id="35" parent="34" relname="purpose">позволит, конечно, сбросить вес,</segment>
		<segment id="36" parent="104" relname="evaluation">но такая диета бесполезна. IMG</segment>
		<segment id="37" parent="110" relname="span">Потребляйте углеводы.</segment>
		<segment id="38" parent="109" relname="span">Конечно, не быстрые – не сахар и не фруктозу, а сложные – кашу.</segment>
		<segment id="39" parent="108" relname="contrast">За два часа перед тренировкой необходимо поесть, но не омлет-яблоко-ветчину, а овсянку с бананом.</segment>
		<segment id="40" parent="108" relname="contrast">В противном случае, тренировку можно считать напрасной тратой времени и сил – толка от неё не будет.</segment>
		<segment id="41" parent="113" relname="contrast">Секрет второй: правильное питание – это не одинаковый набор продуктов для всех,</segment>
		<segment id="42" parent="113" relname="contrast">а зависит от целей на нынешнем этапе строительства тела.</segment>
		<segment id="43" parent="123" relname="span">Я уже писала, каким должен быть алгоритм похудения:</segment>
		<segment id="44" parent="114" relname="span">сначала вы худеете,</segment>
		<segment id="45" parent="44" relname="condition">начав тренировки,</segment>
		<segment id="46" parent="114" relname="elaboration">доводите процент жира в организме до 15-17 единиц,</segment>
		<segment id="47" parent="116" relname="sequence">затем набираете мышечную массу,</segment>
		<segment id="48" parent="116" relname="sequence">а после этого снова худеете. IMG</segment>
		<segment id="49" parent="50" relname="evaluation">Очевидно, что</segment>
		<segment id="50" parent="149" relname="span">питание на каждом из этих этапов должно быть разное.</segment>
		<segment id="51" parent="118" relname="span">Почему большинство тренирующихся замирают на первом этапе?</segment>
		<segment id="52" parent="51" relname="cause">Да потому, что питание – пусть и правильное! – первого этапа не подходит для второго!</segment>
		<segment id="53" parent="54" relname="condition">Если на первой стадии достаточно урезать количество калорий,</segment>
		<segment id="54" parent="119" relname="span">то на втором нужно создать их профицит за счёт правильного распределения БЖУ.</segment>
		<segment id="55" parent="120" relname="contrast">Нельзя питаться всегда одинаково – результата не будет.</segment>
		<segment id="56" parent="120" relname="contrast">Составляйте своё меню в зависимости от целей.</segment>
		<segment id="57" parent="127" relname="contrast">Секрет третий: понимайте то, для чего вы едите.</segment>
		<segment id="58" parent="127" relname="contrast">Не нужно становиться заложниками правильного питания.</segment>
		<segment id="59" parent="60" relname="solutionhood">До дрожи в коленках хочется заточить сладкое?</segment>
		<segment id="60" parent="128" relname="span">Да съешьте, в конце-то концов!</segment>
		<segment id="61" parent="131" relname="span">Но перед или сразу после тренировки.</segment>
		<segment id="62" parent="130" relname="joint">Эта конфетка или ложка варенья просто сразу сгорит,</segment>
		<segment id="63" parent="130" relname="joint">а вы безнаказанно удовлетворите свою тягу к сладкому.</segment>
		<segment id="64" parent="132" relname="span">Не будьте маньячками,</segment>
		<segment id="65" parent="64" relname="evaluation">скрупулёзный подсчёт калорий годами – это уже диагноз дурдома.</segment>
		<segment id="66" parent="134" relname="contrast">Достаточно принципиально соблюдать режим правильного питания,</segment>
		<segment id="67" parent="134" relname="contrast">а небольшие огрехи в еде не повредят.</segment>
		<segment id="68" parent="69" relname="condition">Если в первой половине дня или перед/после тренировки вам нужны углеводы,</segment>
		<segment id="69" parent="136" relname="span">то во второй половине дня предпочтение следует отдать белковой пище.</segment>
		<segment id="70" parent="139" relname="solutionhood">Для чего вы едите то или иное блюдо?</segment>
		<segment id="71" parent="137" relname="joint">Углеводы – это сила.</segment>
		<segment id="72" parent="137" relname="joint">Белки – это инструмент строительства мышц.</segment>
		<segment id="73" parent="137" relname="joint">Правильные жиры – это здоровье сосудов, внутренних органов, эластичность кожи.</segment>
		<segment id="74" parent="75" relname="condition">Когда вам, например, нужна сила,</segment>
		<segment id="75" parent="148" relname="span">ешьте кашу.</segment>
		<segment id="76" >Всё ясно? Вопросы?</segment>
		<group id="77" type="multinuc" parent="83" relname="span"/>
		<group id="78" type="span" parent="6" relname="elaboration"/>
		<group id="79" type="span" parent="82" relname="contrast"/>
		<group id="80" type="span" parent="82" relname="contrast"/>
		<group id="81" type="multinuc" parent="83" relname="evaluation"/>
		<group id="82" type="multinuc" parent="77" relname="contrast"/>
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" parent="85" relname="span"/>
		<group id="85" type="span" />
		<group id="86" type="multinuc" parent="16" relname="preparation"/>
		<group id="87" type="multinuc" parent="86" relname="contrast"/>
		<group id="88" type="span" parent="94" relname="solutionhood"/>
		<group id="89" type="span" parent="90" relname="span"/>
		<group id="90" type="span" parent="91" relname="same-unit"/>
		<group id="91" type="multinuc" parent="93" relname="span"/>
		<group id="92" type="span" parent="96" relname="span"/>
		<group id="93" type="span" parent="94" relname="span"/>
		<group id="94" type="span" parent="112" relname="span"/>
		<group id="95" type="multinuc" parent="92" relname="evaluation"/>
		<group id="96" type="span" parent="93" relname="elaboration"/>
		<group id="97" type="span" parent="98" relname="span"/>
		<group id="98" type="span" parent="101" relname="contrast"/>
		<group id="99" type="span" parent="27" relname="evaluation"/>
		<group id="100" type="span" parent="26" relname="condition"/>
		<group id="101" type="multinuc" parent="110" relname="solutionhood"/>
		<group id="102" type="span" parent="103" relname="joint"/>
		<group id="103" type="multinuc" parent="30" relname="cause"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" parent="106" relname="concession"/>
		<group id="106" type="span" parent="107" relname="span"/>
		<group id="107" type="span" parent="101" relname="contrast"/>
		<group id="108" type="multinuc" parent="38" relname="elaboration"/>
		<group id="109" type="span" parent="37" relname="elaboration"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" />
		<group id="112" type="span" />
		<group id="113" type="multinuc" parent="117" relname="preparation"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="116" relname="sequence"/>
		<group id="116" type="multinuc" parent="43" relname="elaboration"/>
		<group id="117" type="span" parent="122" relname="span"/>
		<group id="118" type="span" parent="121" relname="span"/>
		<group id="119" type="span" parent="118" relname="elaboration"/>
		<group id="120" type="multinuc" parent="124" relname="span"/>
		<group id="121" type="span" parent="126" relname="span"/>
		<group id="122" type="span" parent="121" relname="background"/>
		<group id="123" type="span" parent="117" relname="span"/>
		<group id="124" type="span" parent="125" relname="span"/>
		<group id="125" type="span" />
		<group id="126" type="span" parent="124" relname="solutionhood"/>
		<group id="127" type="multinuc" parent="135" relname="preparation"/>
		<group id="128" type="span" parent="129" relname="contrast"/>
		<group id="129" type="multinuc" parent="133" relname="span"/>
		<group id="130" type="multinuc" parent="61" relname="cause"/>
		<group id="131" type="span" parent="129" relname="contrast"/>
		<group id="132" type="span" parent="133" relname="evaluation"/>
		<group id="133" type="span" parent="135" relname="span"/>
		<group id="134" type="multinuc" parent="141" relname="span"/>
		<group id="135" type="span" parent="146" relname="span"/>
		<group id="136" type="span" parent="141" relname="elaboration"/>
		<group id="137" type="multinuc" parent="138" relname="span"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="143" relname="joint"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="144" relname="span"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" />
		<group id="146" type="span" parent="144" relname="solutionhood"/>
		<group id="147" type="span" parent="84" relname="preparation"/>
		<group id="148" type="span" parent="138" relname="evaluation"/>
		<group id="149" type="span" parent="123" relname="evaluation"/>
	</body>
</rst>