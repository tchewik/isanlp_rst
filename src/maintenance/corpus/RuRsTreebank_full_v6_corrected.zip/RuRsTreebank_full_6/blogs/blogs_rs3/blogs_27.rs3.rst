<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://fitness-blog-ua.blogspot.com/2019/03/blog-post.html</segment>
		<segment id="2" >Пшено вместо киноа, клюква вместо годжи: Альтернатива экзотическим продуктам IMG</segment>
		<segment id="3" parent="75" relname="contrast">Сегодняшнего покупателя сложно удивить экзотикой.</segment>
		<segment id="4" parent="76" relname="span">Но большинству из этих продуктов есть более привычные нам альтернативы,</segment>
		<segment id="5" parent="77" relname="span">о которых часто незаслуженно забывают</segment>
		<segment id="6" parent="5" relname="cause">из-за «модности» необычной еды.</segment>
		<segment id="7" parent="134" relname="span">Начнем с самых трендовых продуктов.</segment>
		<segment id="8" parent="78" relname="joint">Так, например, киноа богата клетчаткой, витаминами,</segment>
		<segment id="9" parent="78" relname="joint">хорошо насыщает</segment>
		<segment id="10" parent="78" relname="joint">и при этом не содержит глютена.</segment>
		<segment id="11" parent="80" relname="span">Такими же характеристиками обладает обычное пшено</segment>
		<segment id="12" parent="79" relname="joint">– экономно</segment>
		<segment id="13" parent="79" relname="joint">и полезно.</segment>
		<segment id="14" parent="82" relname="comparison">В семенах чиа много полезных жирных кислот, белка, клетчатки.</segment>
		<segment id="15" parent="82" relname="comparison">Так же, как и в семенах льна, где есть и жирные кислоты, и Омега-3, ферменты, растительный белок и витамин А.</segment>
		<segment id="16" parent="83" relname="span">Наряду с киноа, большой популярностью сейчас пользуется булгур.</segment>
		<segment id="17" parent="16" relname="elaboration">В этой крупе сохраняются все полезные составляющие пшеничного зерна, в частности витамины группы В, Е, К, а также различные микроэлементы.</segment>
		<segment id="18" parent="87" relname="span">Заменить его также можно пшеном или бурым рисом.</segment>
		<segment id="19" parent="84" relname="joint">Последний богат клетчаткой,</segment>
		<segment id="20" parent="85" relname="span">в нем присутствуют витамины группы В, особенно много В9,</segment>
		<segment id="21" parent="20" relname="elaboration">который отвечает за передачу нервных импульсов,</segment>
		<segment id="22" parent="86" relname="same-unit">а также фолиевая кислота и марганец.</segment>
		<segment id="23" parent="89" relname="evaluation">Продукт оказывает благотворное действие на состоянии кожного покрова, волос и ногтей.</segment>
		<segment id="24" parent="91" relname="contrast">Спельта также является одним из видов пшеницы.</segment>
		<segment id="25" parent="94" relname="span">Но от своих «собратьев» она отличается повышенным содержанием белка, ценных аминокислот, витаминов, цинка и магния.</segment>
		<segment id="26" parent="92" relname="span">В ней содержатся все питательные вещества,</segment>
		<segment id="27" parent="26" relname="purpose">необходимые человеку для нормальной жизнедеятельности,</segment>
		<segment id="28" parent="93" relname="span">поэтому она считается особенно полезной.</segment>
		<segment id="29" parent="95" relname="span">Заменить ее может овсяная крупа.</segment>
		<segment id="30" parent="135" relname="joint">Она является служит источником важных витаминов, минералов и волокон,</segment>
		<segment id="31" parent="135" relname="joint">богата антиоксидантами, омега-3 и фолиевой кислотой.</segment>
		<segment id="32" parent="97" relname="span">Еще один разрекламированный суперфуд – ягоды годжи,</segment>
		<segment id="33" parent="99" relname="span">которые позиционируют как универсальное средство.</segment>
		<segment id="34" parent="98" relname="joint">Они и омолаживают,</segment>
		<segment id="35" parent="98" relname="joint">тонизируют,</segment>
		<segment id="36" parent="98" relname="joint">улучшают зрение, работу сердца,</segment>
		<segment id="37" parent="98" relname="joint">содержат много антиоксидантов и витаминов.</segment>
		<segment id="38" parent="102" relname="span">Как и знакомая всем нам клюква.</segment>
		<segment id="39" parent="101" relname="span">Ее ягоды богаты витаминами группы В, калием, кальцием, магнием, йодом, железом, медью, серебром, барием, свинцом, марганцем, органическими кислотами, пектином, дубильными веществами.</segment>
		<segment id="40" parent="100" relname="joint">Такой полезный состав витаминов и микроэлементов помогает вывести токсины из организма,</segment>
		<segment id="41" parent="100" relname="joint">положительно влияет на сердечно-сосудистую систему и уровень холестерина.</segment>
		<segment id="42" parent="104" relname="comparison">В два раза больше, чем в ягодах годжи, антиоксидантов в индийском крыжовнике амла.</segment>
		<segment id="43" parent="106" relname="span">Полноценная его замена – черноплодная рябина (арония).</segment>
		<segment id="44" parent="105" relname="joint">Она улучшает зрение,</segment>
		<segment id="45" parent="105" relname="joint">обеспечивает здоровье кровеносной системе,</segment>
		<segment id="46" parent="105" relname="joint">предотвращает атеросклероз.</segment>
		<segment id="47" parent="106" relname="elaboration">А по своему составу витаминов и антиоксидантов похожа на амлу.</segment>
		<segment id="48" parent="108" relname="span">Другие ягоды – асаи,</segment>
		<segment id="49" parent="48" relname="background">которые собирают в далекой Амазонии,</segment>
		<segment id="50" parent="109" relname="same-unit">содержат много антиоксидатов, кальция, магния, цинка и витамины А и Е.</segment>
		<segment id="51" parent="126" relname="contrast">Вместо них смело можно брать всем привычные ягоды: чернику, ежевику, вишню.</segment>
		<segment id="52" parent="112" relname="span">Но самая лучшая альтернатива - шиповник.</segment>
		<segment id="53" parent="111" relname="joint">Витаминов в нем даже больше, чем в амазонской ягоде,</segment>
		<segment id="54" parent="111" relname="joint">и он прекрасный антиоксидант.</segment>
		<segment id="55" parent="112" relname="evaluation">Того же витамина С в 10 раз больше, чем в черной смородине и в 50 раз больше, чем в лимоне.</segment>
		<segment id="56" parent="115" relname="span">Творожные сыры типа рикотты и маскарпоне можно заменять даже более диетическими вариантами.</segment>
		<segment id="57" parent="114" relname="joint">Оригинальные сыры имеют высокое содержание белка и кальция,</segment>
		<segment id="58" parent="114" relname="joint">стимулируют мозговую деятельность,</segment>
		<segment id="59" parent="114" relname="joint">укрепляют иммунитет,</segment>
		<segment id="60" parent="114" relname="joint">улучшают состояние кожи и волос.</segment>
		<segment id="61" parent="115" relname="elaboration">На их основе можно делать множество полезных десертов.</segment>
		<segment id="62" parent="118" relname="same-unit">Но абсолютно равноценной заменой станет пастообразный творог</segment>
		<segment id="63" parent="117" relname="span">(либо зернистый,</segment>
		<segment id="64" parent="63" relname="elaboration">который нужно перетереть блендером).</segment>
		<segment id="65" parent="66" relname="purpose">Для замены рикотты</segment>
		<segment id="66" parent="123" relname="span">можно использовать творог невысокой жирности (3-5%),</segment>
		<segment id="67" parent="123" relname="background">маскарпоне – более жирный,</segment>
		<segment id="68" parent="125" relname="joint">либо смешать с жирными сливками.</segment>
		<segment id="69" parent="129" relname="preparation">Аналоги других молочных продуктов еще более простые.</segment>
		<segment id="70" parent="120" relname="span">Например, вместо греческого йогурта всегда можно взять густой йогурт без наполнителей, например, термизированный</segment>
		<segment id="71" parent="121" relname="span">– за счет технологии приготовления он остается густым</segment>
		<segment id="72" parent="71" relname="condition">даже при невысокой жирности.</segment>
		<segment id="73" parent="122" relname="joint">При этом такой йогурт обладает всеми полезными свойствами греческого аналога – низкая калорийность, стабилизация уровня сахара в организме, высокое содержание кальция, нормализация пищеварения.</segment>
		<group id="75" type="multinuc" parent="7" relname="preparation"/>
		<group id="76" type="span" parent="75" relname="contrast"/>
		<group id="77" type="span" parent="4" relname="evaluation"/>
		<group id="78" type="multinuc" parent="81" relname="comparison"/>
		<group id="79" type="multinuc" parent="11" relname="evaluation"/>
		<group id="80" type="span" parent="81" relname="comparison"/>
		<group id="81" type="multinuc" parent="131" relname="joint"/>
		<group id="82" type="multinuc" parent="131" relname="joint"/>
		<group id="83" type="span" parent="90" relname="comparison"/>
		<group id="84" type="multinuc" parent="89" relname="span"/>
		<group id="85" type="span" parent="86" relname="same-unit"/>
		<group id="86" type="multinuc" parent="84" relname="joint"/>
		<group id="87" type="span" parent="90" relname="comparison"/>
		<group id="88" type="span" parent="18" relname="elaboration"/>
		<group id="89" type="span" parent="88" relname="span"/>
		<group id="90" type="multinuc" parent="131" relname="joint"/>
		<group id="91" type="multinuc" parent="96" relname="comparison"/>
		<group id="92" type="span" parent="28" relname="cause"/>
		<group id="93" type="span" parent="25" relname="evaluation"/>
		<group id="94" type="span" parent="91" relname="contrast"/>
		<group id="95" type="span" parent="96" relname="comparison"/>
		<group id="96" type="multinuc" />
		<group id="97" type="span" parent="103" relname="comparison"/>
		<group id="98" type="multinuc" parent="33" relname="elaboration"/>
		<group id="99" type="span" parent="32" relname="evaluation"/>
		<group id="100" type="multinuc" parent="39" relname="evaluation"/>
		<group id="101" type="span" parent="38" relname="elaboration"/>
		<group id="102" type="span" parent="103" relname="comparison"/>
		<group id="103" type="multinuc" />
		<group id="104" type="multinuc" />
		<group id="105" type="multinuc" parent="43" relname="elaboration"/>
		<group id="106" type="span" parent="107" relname="span"/>
		<group id="107" type="span" parent="104" relname="comparison"/>
		<group id="108" type="span" parent="109" relname="same-unit"/>
		<group id="109" type="multinuc" parent="110" relname="comparison"/>
		<group id="110" type="multinuc" />
		<group id="111" type="multinuc" parent="52" relname="evaluation"/>
		<group id="112" type="span" parent="113" relname="span"/>
		<group id="113" type="span" parent="126" relname="contrast"/>
		<group id="114" type="multinuc" parent="56" relname="elaboration"/>
		<group id="115" type="span" parent="116" relname="span"/>
		<group id="116" type="span" parent="119" relname="contrast"/>
		<group id="117" type="span" parent="118" relname="same-unit"/>
		<group id="118" type="multinuc" parent="127" relname="span"/>
		<group id="119" type="multinuc" />
		<group id="120" type="span" parent="122" relname="joint"/>
		<group id="121" type="span" parent="70" relname="cause"/>
		<group id="122" type="multinuc" parent="129" relname="span"/>
		<group id="123" type="span" parent="124" relname="span"/>
		<group id="124" type="span" parent="125" relname="joint"/>
		<group id="125" type="multinuc" parent="128" relname="joint"/>
		<group id="126" type="multinuc" parent="110" relname="comparison"/>
		<group id="127" type="span" parent="128" relname="joint"/>
		<group id="128" type="multinuc" parent="119" relname="contrast"/>
		<group id="129" type="span" parent="130" relname="span"/>
		<group id="130" type="span" />
		<group id="131" type="multinuc" parent="132" relname="span"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" />
		<group id="134" type="span" parent="132" relname="preparation"/>
		<group id="135" type="multinuc" parent="29" relname="elaboration"/>
	</body>
</rst>