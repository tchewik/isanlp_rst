<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://marina-yudenich.livejournal.com/1393035.html</segment>
		<segment id="2" >Странная история министра Улюкаева и очень редкого вина</segment>
		<segment id="3" parent="124" relname="span">Тут все будет конечно не так готично как в случае доктора Джекила,</segment>
		<segment id="4" parent="123" relname="span">потому пера Стивенсона не потребуется,</segment>
		<segment id="5" parent="4" relname="cause">хватит и моего.</segment>
		<segment id="6" parent="125" relname="span">Но тут все тоже очень и очень странно,</segment>
		<segment id="7" parent="6" relname="concession">хотя местами, напротив, очень смешно.</segment>
		<segment id="8" parent="127" relname="span">Ну смотрите.</segment>
		<segment id="9" parent="128" relname="preparation">Сначала про суд.</segment>
		<segment id="10" parent="128" relname="span">Это самый странный процесс такого рода в новейшей истории России,</segment>
		<segment id="11" parent="10" relname="evaluation">я берусь утверждать это совершенно определенно.</segment>
		<segment id="12" parent="130" relname="joint">И дело даже не в том, что на взятке взяли с поличным</segment>
		<segment id="13" parent="130" relname="joint">и довели до суда чиновника такого уровня.</segment>
		<segment id="14" parent="138" relname="span">Этот процесс изобилует странностями, которые быть может скоро войдут у учебники, а может - какую занятную беллетристику.</segment>
		<segment id="15" parent="137" relname="span">Притом - что самое удивительное - странной взбалмошной и нервной в этом процессе выглядит прокуратура.</segment>
		<segment id="16" parent="131" relname="joint">Потому как подсудимые бывает чудят,</segment>
		<segment id="17" parent="131" relname="joint">защита порой любит выхватить кролика из цилиндра</segment>
		<segment id="18" parent="131" relname="joint">или вытряхнуть какую иную живность из рукава.</segment>
		<segment id="19" parent="132" relname="joint">Прокурорские же обычно спокойны</segment>
		<segment id="20" parent="132" relname="joint">и невозмутимы как скалы.</segment>
		<segment id="21" parent="133" relname="joint">Порой скучны.</segment>
		<segment id="22" parent="133" relname="joint">Порой слабоваты в риторике.</segment>
		<segment id="23" parent="210" relname="solutionhood">Но чтобы так чудить?</segment>
		<segment id="24" parent="134" relname="contrast">Небывало.</segment>
		<segment id="25" parent="134" relname="contrast">И вот.</segment>
		<segment id="26" parent="223" relname="contrast">Про внезапно обнародованную прослушку переговоров двух очень больших дядек</segment>
		<segment id="27" parent="223" relname="contrast">- чего раньше не было никогда,</segment>
		<segment id="28" parent="224" relname="concession">хотя бы по соображениям сохранности государственной тайны</segment>
		<segment id="29" parent="226" relname="same-unit">- я уже писала.</segment>
		<segment id="30" parent="143" relname="preparation">Теперь собственно про Сечина-свидетеля.</segment>
		<segment id="31" parent="141" relname="span">Его сначала допрашивают в качестве свидетеля</segment>
		<segment id="32" parent="31" relname="condition">(по-взрослому - со следственными действиями на месте совершения преступления),</segment>
		<segment id="33" parent="142" relname="sequence">приобщают показания к делу</segment>
		<segment id="34" parent="212" relname="contrast">и - sic! - не включают в число свидетелей, подлежащих вызову в судебное заседание.</segment>
		<segment id="35" parent="145" relname="span">С тем и идут в суд.</segment>
		<segment id="36" parent="146" relname="sequence">Потом в судебном процессе внезапно (!) решают, что вызвать Сечина в суд все-таки нужно</segment>
		<segment id="37" parent="146" relname="sequence">и торжественно сообщают об этом ошарашенному судье.</segment>
		<segment id="38" parent="148" relname="span">Потом начинается странная</segment>
		<segment id="39" parent="38" relname="evaluation">- если не сказать мышиная -</segment>
		<segment id="40" parent="149" relname="same-unit">возня с явкой Сечина в суд,</segment>
		<segment id="41" parent="151" relname="span">в которую зачем-то пристегиваются судебные приставы</segment>
		<segment id="42" parent="41" relname="evaluation">(как будто на следственные действия Сечина доставляли они),</segment>
		<segment id="43" parent="154" relname="joint">история обрастает мифами о закрытой приемной (или экспедиции?) «Роснефти»,</segment>
		<segment id="44" parent="153" relname="joint">народ рисует комиксы,</segment>
		<segment id="45" parent="153" relname="joint">ваяет мультики</segment>
		<segment id="46" parent="155" relname="span">-  словом, танцуют все.</segment>
		<segment id="47" parent="158" relname="span">Потом выясняется, что показания Сечина прокуратуре как бы и не нужны,</segment>
		<segment id="48" parent="157" relname="comparison">притом не нужны настолько,</segment>
		<segment id="49" parent="157" relname="comparison">что их даже не хотят зачитать в процессе.</segment>
		<segment id="50" parent="159" relname="span">Защита при этом хихикает в сторонке,</segment>
		<segment id="51" parent="50" relname="cause">не веря своему внезапному счастью.</segment>
		<segment id="52" parent="160" relname="span">Защите Сечин вообще не нужен: ни письменно, ни устно.</segment>
		<segment id="53" parent="54" relname="attribution">Они прямо говорят,</segment>
		<segment id="54" parent="236" relname="span">что это просто способ обжаловать приговор.</segment>
		<segment id="55" parent="56" relname="preparation">Идем дальше.</segment>
		<segment id="56" parent="162" relname="span">Прокурор совершает совершенно удивительное процессуальное действие  - взвешивание сумки с деньгами. 22 килограмма чистого валютного веса.</segment>
		<segment id="57" parent="215" relname="solutionhood">Зачем?</segment>
		<segment id="58" parent="214" relname="span">Я правда не знаю.</segment>
		<segment id="59" parent="60" relname="condition">И если уж следовать прокурорской логике в этом процессе,</segment>
		<segment id="60" parent="164" relname="span">то потом нужно было набить эту же сумку бутылками с вином.</segment>
		<segment id="61" parent="165" relname="sequence">И тоже взвесить.</segment>
		<segment id="62" parent="165" relname="sequence">И дать поднять подсудимому.</segment>
		<segment id="63" parent="165" relname="sequence">И попросить пронести по залу.</segment>
		<segment id="64" parent="165" relname="sequence">И сверить походку на видео и в зале суда.</segment>
		<segment id="65" parent="167" relname="evaluation">Ибо сумка с жидкостями, даже идеально упакованными, ведет себя в руках совершенно иначе, чем сумка с твердым наполнителем.</segment>
		<segment id="66" parent="171" relname="span">И вот теперь о вине.</segment>
		<segment id="67" parent="170" relname="joint">Это самое странное</segment>
		<segment id="68" parent="170" relname="joint">и одновременно самое уморительное в этой истории.</segment>
		<segment id="69" parent="172" relname="span">Реконструируем события по версии экс-министра Улюкаева.</segment>
		<segment id="70" parent="173" relname="span">Когда-то</segment>
		<segment id="71" parent="70" relname="elaboration">- вроде как на Гоа дело было -</segment>
		<segment id="72" parent="73" relname="attribution">Сечин пообещал</segment>
		<segment id="73" parent="237" relname="span">угостить его таким вином, которое он еще не пробовал.</segment>
		<segment id="74" parent="234" relname="attribution">И вот спустя месяц, в промозглой ноябрьской Москве Сечин звонит Улюкаеву говорит,</segment>
		<segment id="75" parent="175" relname="joint">что «весь объем собрали»</segment>
		<segment id="76" parent="175" relname="joint">и приглашает заехать в офис.</segment>
		<segment id="77" parent="195" relname="sequence">И Улюкаев думает, что за вином, которого он никогда еще не пробовал.</segment>
		<segment id="78" parent="177" relname="same-unit">И</segment>
		<segment id="79" parent="80" relname="condition">- отменив запланированное совещание -</segment>
		<segment id="80" parent="176" relname="span">мчится на Софийскую набережную. За вином, которого он никогда не пробовал.</segment>
		<segment id="81" parent="227" relname="same-unit">И на Софийской набережной,</segment>
		<segment id="82" parent="83" relname="condition">едва заглянув в кабинет Сечина,</segment>
		<segment id="83" parent="228" relname="span">федеральный министр буквально бежит к ёлке, растущей во дворе у гаража,</segment>
		<segment id="84" parent="178" relname="sequence">и под этой самой елкой у гаража берет сумку.</segment>
		<segment id="85" parent="179" relname="cause">Будучи уверен, что там вино, которого он никогда не пробовал.</segment>
		<segment id="86" parent="87" relname="condition">И схватив под елкой сумку весом в 22 аж килограмма,</segment>
		<segment id="87" parent="181" relname="span">несет её в машину.</segment>
		<segment id="88" parent="181" relname="evaluation">Конечно же, потому что там вино, которого он никогда не пробовал.</segment>
		<segment id="89" parent="196" relname="span">И уже у машины, без единого мяу молча берет у Сечина ключи от этой сумки.</segment>
		<segment id="90" parent="183" relname="joint">Потому что там вино, которое… ну вы уже знаете,</segment>
		<segment id="91" parent="183" relname="joint">и вина всегда перевозят именно так - с ключами отдельно.</segment>
		<segment id="92" parent="184" relname="contrast">И собственноручно кладет сумку в машину,</segment>
		<segment id="93" parent="184" relname="contrast">а ключи оставляет при себе.</segment>
		<segment id="94" parent="185" relname="cause">Потому что там вино, которое он никогда не пробовал.</segment>
		<segment id="95" parent="238" relname="contrast">И не говорит дарителю даже «спасибо». Ну если за вино. Которого он никогда не пробовал.</segment>
		<segment id="96" parent="197" relname="span">И что тут сказать.</segment>
		<segment id="97" parent="187" relname="joint">Предупреждал вас козлов Уильям наш Шекспир,</segment>
		<segment id="98" parent="187" relname="joint">вот прямо вопиил, к вам обращаясь:</segment>
		<segment id="99" parent="188" relname="span">«Не пей вина, Гертруда!»</segment>
		<segment id="100" parent="189" relname="restatement">Козленочком станешь. А то и целым козлом.</segment>
		<segment id="101" parent="229" relname="contrast">А вы все не напьетесь никак.</segment>
		<segment id="102" parent="192" relname="preparation">И кстати уж о вине.</segment>
		<segment id="103" parent="230" relname="restatement">Сумка, набитая бутылками вина, которого никогда не пробовал федеральный министр и один из самых известных сибаритов в правительстве</segment>
		<segment id="104" parent="230" relname="restatement">(то есть очень дорого вина )</segment>
		<segment id="105" parent="231" relname="elaboration">- это по самым скромным подсчетам несколько десятков тысяч долларов,</segment>
		<segment id="106" parent="232" relname="evaluation">что тоже вполне взятка в особо крупных.</segment>
		<segment id="107" parent="193" relname="evaluation">Впрочем, это уже совсем другая история.</segment>
		<segment id="108" parent="201" relname="condition">Ну и последнее. Уже безо всяких шуток.</segment>
		<segment id="109" parent="110" relname="attribution">Когда экс-министр Улюкаев говорит,</segment>
		<segment id="110" parent="200" relname="span">что ставшее уже сакраментальным сечинское «весь объем собрали» он отнес на счет сделки про продаже госпакета «Роснефти»,</segment>
		<segment id="111" parent="201" relname="span">он просто врёт.</segment>
		<segment id="112" parent="202" relname="elaboration">Притом врёт довольно беспомощно и глупо. Либо в расчете на то, что публика - совсем уж дура.</segment>
		<segment id="113" parent="204" relname="contrast">Потому как разговор про «объемы», которые собрали, происходит в ноябре,</segment>
		<segment id="114" parent="218" relname="contrast">а сделка по продаже госпакета РН сложилась в декабре.</segment>
		<segment id="115" parent="219" relname="contrast">И знать о ней принимающий «объёмы» министр не мог просто вот тупо никак.  По определению.</segment>
		<segment id="116" parent="207" relname="same-unit">Но спешно</segment>
		<segment id="117" parent="118" relname="condition">- отменив назначенное совещание -</segment>
		<segment id="118" parent="206" relname="span">едет в офис «Роснефти» по первому звонку Сечина.</segment>
		<segment id="119" parent="220" relname="elaboration">Зачем?</segment>
		<segment id="120" parent="209" relname="span">Так за вином. Которого Улюкаев никогда не пробовал.</segment>
		<segment id="121" parent="208" relname="span">Теперь уж не попробует наверное.</segment>
		<segment id="122" parent="121" relname="evaluation">Что грустно.</segment>
		<group id="123" type="span" parent="3" relname="cause"/>
		<group id="124" type="span" parent="126" relname="contrast"/>
		<group id="125" type="span" parent="126" relname="contrast"/>
		<group id="126" type="multinuc" parent="8" relname="preparation"/>
		<group id="127" type="span" />
		<group id="128" type="span" parent="129" relname="span"/>
		<group id="129" type="span" parent="140" relname="span"/>
		<group id="130" type="multinuc" parent="139" relname="contrast"/>
		<group id="131" type="multinuc" parent="136" relname="contrast"/>
		<group id="132" type="multinuc" parent="133" relname="joint"/>
		<group id="133" type="multinuc" parent="135" relname="contrast"/>
		<group id="134" type="multinuc" parent="210" relname="span"/>
		<group id="135" type="multinuc" parent="136" relname="contrast"/>
		<group id="136" type="multinuc" parent="15" relname="evaluation"/>
		<group id="137" type="span" parent="14" relname="elaboration"/>
		<group id="138" type="span" parent="139" relname="contrast"/>
		<group id="139" type="multinuc" parent="129" relname="elaboration"/>
		<group id="140" type="span" />
		<group id="141" type="span" parent="142" relname="sequence"/>
		<group id="142" type="multinuc" parent="212" relname="contrast"/>
		<group id="143" type="span" parent="144" relname="span"/>
		<group id="144" type="span" parent="35" relname="preparation"/>
		<group id="145" type="span" parent="213" relname="contrast"/>
		<group id="146" type="multinuc" parent="213" relname="contrast"/>
		<group id="147" type="multinuc" />
		<group id="148" type="span" parent="149" relname="same-unit"/>
		<group id="149" type="multinuc" parent="150" relname="span"/>
		<group id="150" type="span" parent="152" relname="span"/>
		<group id="151" type="span" parent="150" relname="elaboration"/>
		<group id="152" type="span" parent="155" relname="cause"/>
		<group id="153" type="multinuc" parent="154" relname="joint"/>
		<group id="154" type="multinuc" parent="46" relname="evaluation"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="147" relname="sequence"/>
		<group id="157" type="multinuc" parent="47" relname="elaboration"/>
		<group id="158" type="span" parent="147" relname="sequence"/>
		<group id="159" type="span" parent="161" relname="span"/>
		<group id="160" type="span" parent="159" relname="elaboration"/>
		<group id="161" type="span" parent="147" relname="sequence"/>
		<group id="162" type="span" parent="163" relname="span"/>
		<group id="163" type="span" parent="169" relname="span"/>
		<group id="164" type="span" parent="166" relname="joint"/>
		<group id="165" type="multinuc" parent="166" relname="joint"/>
		<group id="166" type="multinuc" parent="167" relname="span"/>
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="214" relname="elaboration"/>
		<group id="169" type="span" />
		<group id="170" type="multinuc" parent="66" relname="evaluation"/>
		<group id="171" type="span" parent="69" relname="preparation"/>
		<group id="172" type="span" parent="198" relname="span"/>
		<group id="173" type="span" parent="174" relname="same-unit"/>
		<group id="174" type="multinuc" parent="195" relname="sequence"/>
		<group id="175" type="multinuc" parent="234" relname="span"/>
		<group id="176" type="span" parent="177" relname="same-unit"/>
		<group id="177" type="multinuc" parent="195" relname="sequence"/>
		<group id="178" type="multinuc" parent="179" relname="span"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" parent="195" relname="sequence"/>
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" parent="195" relname="sequence"/>
		<group id="183" type="multinuc" parent="89" relname="cause"/>
		<group id="184" type="multinuc" parent="185" relname="span"/>
		<group id="185" type="span" parent="186" relname="span"/>
		<group id="186" type="span" parent="238" relname="contrast"/>
		<group id="187" type="multinuc" parent="99" relname="attribution"/>
		<group id="188" type="span" parent="189" relname="restatement"/>
		<group id="189" type="multinuc" parent="190" relname="span"/>
		<group id="190" type="span" parent="229" relname="contrast"/>
		<group id="191" type="span" parent="217" relname="span"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" parent="194" relname="span"/>
		<group id="194" type="span" parent="191" relname="elaboration"/>
		<group id="195" type="multinuc" parent="172" relname="elaboration"/>
		<group id="196" type="span" parent="195" relname="sequence"/>
		<group id="197" type="span" parent="198" relname="evaluation"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" />
		<group id="200" type="span" parent="111" relname="condition"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" parent="203" relname="span"/>
		<group id="203" type="span" parent="205" relname="span"/>
		<group id="204" type="multinuc" parent="203" relname="cause"/>
		<group id="205" type="span" />
		<group id="206" type="span" parent="207" relname="same-unit"/>
		<group id="207" type="multinuc" parent="220" relname="span"/>
		<group id="208" type="span" parent="120" relname="evaluation"/>
		<group id="209" type="span" parent="222" relname="span"/>
		<group id="210" type="span" parent="211" relname="span"/>
		<group id="211" type="span" parent="135" relname="contrast"/>
		<group id="212" type="multinuc" parent="143" relname="span"/>
		<group id="213" type="multinuc" parent="147" relname="sequence"/>
		<group id="214" type="span" parent="215" relname="span"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" parent="163" relname="elaboration"/>
		<group id="217" type="span" parent="96" relname="elaboration"/>
		<group id="218" type="multinuc" parent="204" relname="contrast"/>
		<group id="219" type="multinuc" parent="218" relname="contrast"/>
		<group id="220" type="span" parent="221" relname="span"/>
		<group id="221" type="span" parent="209" relname="solutionhood"/>
		<group id="222" type="span" parent="219" relname="contrast"/>
		<group id="223" type="multinuc" parent="224" relname="span"/>
		<group id="224" type="span" parent="225" relname="span"/>
		<group id="225" type="span" parent="226" relname="same-unit"/>
		<group id="226" type="multinuc" />
		<group id="227" type="multinuc" parent="178" relname="sequence"/>
		<group id="228" type="span" parent="227" relname="same-unit"/>
		<group id="229" type="multinuc" parent="191" relname="span"/>
		<group id="230" type="multinuc" parent="231" relname="span"/>
		<group id="231" type="span" parent="232" relname="span"/>
		<group id="232" type="span" parent="192" relname="span"/>
		<group id="233" type="span" parent="195" relname="sequence"/>
		<group id="234" type="span" parent="233" relname="span"/>
		<group id="236" type="span" parent="52" relname="evidence"/>
		<group id="237" type="span" parent="174" relname="same-unit"/>
		<group id="238" type="multinuc" parent="195" relname="sequence"/>
	</body>
</rst>