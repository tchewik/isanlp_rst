<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://kosmetista.ru/blog/uhodovaya-kosmetika/97696.html</segment>
		<segment id="2" >Бюджетная косметика с пребиотиками от Chocolatte</segment>
		<segment id="3" parent="4" relname="cause">Популярная идея микробиома, косметики с про/пребиотиками не обошла меня стороной,</segment>
		<segment id="4" parent="95" relname="span">поэтому я не удержалась от покупки.</segment>
		<segment id="5" parent="96" relname="span">Для себя выбрала пребиотики.</segment>
		<segment id="6" parent="7" relname="cause">Что из этого вышло,</segment>
		<segment id="7" parent="97" relname="span">читайте под катом.</segment>
		<segment id="8" parent="99" relname="elaboration">IMG</segment>
		<segment id="9" parent="10" relname="preparation">Био-тоник с пребиотиками Идеал Chocolatte для проблемной кожи</segment>
		<segment id="10" parent="101" relname="span">Тоник изготовлен на основе гидролатов сосны, иссопа и шалфея.</segment>
		<segment id="11" parent="102" relname="span">В него включен комплекс лизатов лакто/бифидо/пропионовых бактерий. Все.</segment>
		<segment id="12" parent="11" relname="evaluation">Состав максимально прост и лаконичен.</segment>
		<segment id="13" parent="14" relname="attribution">Производитель сообщает,</segment>
		<segment id="14" parent="180" relname="span">что возможно выпадение осадка.</segment>
		<segment id="15" parent="104" relname="elaboration">IMG</segment>
		<segment id="16" parent="107" relname="joint">Этот тоник призван нормализовать микрофлору кожи,</segment>
		<segment id="17" parent="106" relname="span">предотвращать рост патогенных бактерий,</segment>
		<segment id="18" parent="17" relname="elaboration">которые вызывают воспалительные процессы.</segment>
		<segment id="19" parent="112" relname="span">Его преимущество заключается в хорошем составе:</segment>
		<segment id="20" parent="108" relname="joint">гидролаты сосны и шалфея имеют антисептические и антибактериальные свойства,</segment>
		<segment id="21" parent="108" relname="joint">оказывают противогрибковое воздействие.</segment>
		<segment id="22" parent="109" relname="joint">Гидролат иссопа хорош для кожи, склонной к аллергии и раздражениям,</segment>
		<segment id="23" parent="109" relname="joint">имеет противовоспалительное, успокаивающее действие.</segment>
		<segment id="24" parent="110" relname="joint">Пребиотики выравнивают микрофлору кожи,</segment>
		<segment id="25" parent="110" relname="joint">предотвращают рост патогенных бактерий.</segment>
		<segment id="26" parent="119" relname="joint">Тоник находится в бутылке из плотного пластика.</segment>
		<segment id="27" parent="28" relname="evaluation">Распылитель хороший,</segment>
		<segment id="28" parent="172" relname="span">мелкодисперсный.</segment>
		<segment id="29" parent="114" relname="contrast">Тоник водичковой текстуры, прозрачный,</segment>
		<segment id="30" parent="181" relname="comparison">но в нем плавают микрочастички,</segment>
		<segment id="31" parent="181" relname="comparison">похожие на частички растений.</segment>
		<segment id="32" parent="33" relname="cause">Выпадает небольшой осадок.</segment>
		<segment id="33" parent="115" relname="span">Всегда встряхиваю перед применением.</segment>
		<segment id="34" parent="116" relname="joint">Орошаю им лицо из распылителя сразу после умывания</segment>
		<segment id="35" parent="116" relname="joint">или протираю ватным диском.</segment>
		<segment id="36" parent="119" relname="joint">Запах практически отсутствует.</segment>
		<segment id="37" parent="120" relname="elaboration">IMG</segment>
		<segment id="38" parent="39" relname="cause">Обычно я использовала этот тоник в тандеме с кремом,</segment>
		<segment id="39" parent="196" relname="span">поэтому не могу сказать, что он как-то особенно повлиял на мою кожу.</segment>
		<segment id="40" parent="196" relname="evaluation">Хуже не сделал точно.</segment>
		<segment id="41" parent="197" relname="evaluation">Могу отметить, что красноты стало меньше.</segment>
		<segment id="42" parent="43" relname="condition">Если не нанести после тоника крем или другой уход,</segment>
		<segment id="43" parent="125" relname="span">мою чувствительную комбикожу начинает стягивать.</segment>
		<segment id="44" parent="127" relname="span">По эффекту не нашла различий с чистым гидролатом иссопа, шалфея или сосны.</segment>
		<segment id="45" parent="44" relname="background">Все 3 у меня были в разные периоды жизни.</segment>
		<segment id="46" parent="128" relname="elaboration">Объем: 100 мл Срок годности: 12 мес. с даты производства 200₽цена 7/10оценка 30 дней, 2р/в деньиспользование</segment>
		<segment id="47" parent="48" relname="preparation">​Гель-крем для лица БИОАКТИВ с пребиотиком Chocolatte</segment>
		<segment id="48" parent="129" relname="span">Самым интересным продуктом марки для меня стал гель-крем для лица Био-актив с 5% содержанием пребиотика Biolin P.</segment>
		<segment id="49" parent="129" relname="elaboration">IMG</segment>
		<segment id="50" parent="131" relname="span">Biolin P — это смесь натуральных полисахаридов: инулин (Inulin),</segment>
		<segment id="51" parent="50" relname="background">который получают из корня цикория,</segment>
		<segment id="52" parent="132" relname="span">и глюко-олигосахаридов (Alpha-glucan oligosaccharide),</segment>
		<segment id="53" parent="52" relname="background">которые получают из сахарной свеклы.</segment>
		<segment id="54" parent="55" relname="purpose">Для удобства</segment>
		<segment id="55" parent="134" relname="span">выложу полный состав здесь.</segment>
		<segment id="56" parent="134" relname="evidence">Состав: вода родниковая, аргановое масло, Biolin® (инулин, альфа-глюкан олигосахарид), сквалан, коньяковый глюкоманнан, д-пантенол, лецитин, AMISOL TRIO™ (фосфолипиды, фитостеролы, гликолипиды, глицин сои, витамин F), витамины А и Е, шаромикс 705, концентрат коллоидного серебра.</segment>
		<segment id="57" parent="140" relname="joint">Гель находится в бутылочке из плотного пластика,</segment>
		<segment id="58" parent="139" relname="span">дозатор помповый,</segment>
		<segment id="59" parent="58" relname="evaluation">удобный.</segment>
		<segment id="60" parent="141" relname="span">Выдает нужное количество крема.</segment>
		<segment id="61" parent="60" relname="evidence">Одного нажатия хватает на лицо и шею.</segment>
		<segment id="62" parent="142" relname="elaboration">IMG</segment>
		<segment id="63" parent="146" relname="span">Текстура у этого гель-крема очень необычная,</segment>
		<segment id="64" parent="145" relname="joint">немного желейная,</segment>
		<segment id="65" parent="145" relname="joint">держит форму.</segment>
		<segment id="66" parent="148" relname="contrast">Масло в составе не ощущается,</segment>
		<segment id="67" parent="147" relname="span">зато есть ощущение, что присутствует муцин улитки,</segment>
		<segment id="68" parent="67" relname="cause">потому что консистенция крема какая-то тягучая.</segment>
		<segment id="69" >Если говорить открыто, я бы сказала «сопливая».</segment>
		<segment id="70" parent="151" relname="joint">При этом она легкая,</segment>
		<segment id="71" parent="151" relname="joint">хорошо распределяется,</segment>
		<segment id="72" parent="151" relname="joint">впитывается быстро, буквально за секунды.</segment>
		<segment id="73" parent="154" relname="joint">Аромат специфический, травяной с отголосками чего-то молочного.</segment>
		<segment id="74" parent="155" relname="elaboration">IMG IMG</segment>
		<segment id="75" parent="76" relname="attribution">Марка позиционирует этот крем,</segment>
		<segment id="76" parent="182" relname="span">как восстанавливающий естественный баланс кожи и оптимальный уровень pH, защищающий кожу от раздражающих факторов внешней среды, устраняющий сухость, шелушения, покраснения, зуд и акне.</segment>
		<segment id="77" parent="157" relname="span">У меня проблемная кожа, акне в ремиссии, постакне, чувствительность.</segment>
		<segment id="78" parent="77" relname="evidence">После умывания всегда бывают покраснения.</segment>
		<segment id="79" parent="201" relname="joint">Я пользовалась кремом на протяжении 1.5 месяцев</segment>
		<segment id="80" parent="202" relname="span">и могу отметить несколько важных особенностей:</segment>
		<segment id="81" parent="160" relname="span">1. Крем недостаточно хорошо увлажняет мою комбикожу в холодное время года.</segment>
		<segment id="82" parent="83" relname="condition">Если пользоваться только им и тоником,</segment>
		<segment id="83" parent="159" relname="span">то через несколько часов появляется желание нанести увлажняющий крем.</segment>
		<segment id="84" parent="161" relname="joint">2. Кожа стала меньше краснеть,</segment>
		<segment id="85" parent="161" relname="joint">реагировать на негативные окружающие факторы (погода, холод, ветер, косметические средства).</segment>
		<segment id="86" parent="200" relname="span">3. Не могу сказать, что биолин как-то подействовал на мое акне,</segment>
		<segment id="87" parent="86" relname="cause">потому что сейчас у меня прыщей особо нет,</segment>
		<segment id="88" parent="164" relname="span">но этот гель-крем не сделал мою кожу хуже,</segment>
		<segment id="89" parent="163" relname="joint">не забил поры,</segment>
		<segment id="90" parent="163" relname="joint">не спровоцировал высыпания.</segment>
		<segment id="91" parent="164" relname="evaluation">Уже большой плюс.</segment>
		<segment id="92" parent="204" relname="evaluation">Думаю, что этот крем подошел бы жирной проблемной коже с акне и чувствительностью в теплое время года.</segment>
		<segment id="93" parent="203" relname="elaboration">Объем: 30 мл Срок годности: 9 мес. с даты изготовления</segment>
		<segment id="94" >Вы пользовались косметикой с пребиотиками? Что понравилось больше всего?</segment>
		<group id="95" type="span" parent="5" relname="preparation"/>
		<group id="96" type="span" parent="98" relname="joint"/>
		<group id="97" type="span" parent="98" relname="joint"/>
		<group id="98" type="multinuc" parent="99" relname="span"/>
		<group id="99" type="span" parent="100" relname="span"/>
		<group id="100" type="span" />
		<group id="101" type="span" parent="103" relname="span"/>
		<group id="102" type="span" parent="101" relname="evidence"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" />
		<group id="106" type="span" parent="107" relname="joint"/>
		<group id="107" type="multinuc" parent="113" relname="joint"/>
		<group id="108" type="multinuc" parent="111" relname="joint"/>
		<group id="109" type="multinuc" parent="111" relname="joint"/>
		<group id="110" type="multinuc" parent="111" relname="joint"/>
		<group id="111" type="multinuc" parent="19" relname="evidence"/>
		<group id="112" type="span" parent="113" relname="joint"/>
		<group id="113" type="multinuc" />
		<group id="114" type="multinuc" parent="117" relname="span"/>
		<group id="115" type="span" parent="173" relname="sequence"/>
		<group id="116" type="multinuc" parent="173" relname="sequence"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" parent="119" relname="joint"/>
		<group id="119" type="multinuc" parent="120" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" />
		<group id="125" type="span" parent="174" relname="comparison"/>
		<group id="127" type="span" parent="174" relname="comparison"/>
		<group id="128" type="span" parent="175" relname="span"/>
		<group id="129" type="span" parent="130" relname="span"/>
		<group id="130" type="span" parent="137" relname="preparation"/>
		<group id="131" type="span" parent="133" relname="same-unit"/>
		<group id="132" type="span" parent="133" relname="same-unit"/>
		<group id="133" type="multinuc" parent="136" relname="span"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="136" relname="elaboration"/>
		<group id="136" type="span" parent="137" relname="span"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="176" relname="span"/>
		<group id="139" type="span" parent="143" relname="span"/>
		<group id="140" type="multinuc" parent="142" relname="span"/>
		<group id="141" type="span" parent="139" relname="elaboration"/>
		<group id="142" type="span" parent="144" relname="span"/>
		<group id="143" type="span" parent="140" relname="joint"/>
		<group id="144" type="span" parent="138" relname="elaboration"/>
		<group id="145" type="multinuc" parent="63" relname="elaboration"/>
		<group id="146" type="span" parent="154" relname="joint"/>
		<group id="147" type="span" parent="152" relname="span"/>
		<group id="148" type="multinuc" parent="150" relname="span"/>
		<group id="150" type="span" parent="154" relname="joint"/>
		<group id="151" type="multinuc" parent="177" relname="joint"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" parent="148" relname="contrast"/>
		<group id="154" type="multinuc" parent="155" relname="span"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" />
		<group id="157" type="span" parent="169" relname="joint"/>
		<group id="159" type="span" parent="81" relname="evidence"/>
		<group id="160" type="span" parent="166" relname="joint"/>
		<group id="161" type="multinuc" parent="166" relname="joint"/>
		<group id="163" type="multinuc" parent="88" relname="evidence"/>
		<group id="164" type="span" parent="178" relname="span"/>
		<group id="165" type="multinuc" parent="166" relname="joint"/>
		<group id="166" type="multinuc" parent="204" relname="span"/>
		<group id="169" type="multinuc" parent="206" relname="preparation"/>
		<group id="172" type="span" parent="119" relname="joint"/>
		<group id="173" type="multinuc" parent="117" relname="elaboration"/>
		<group id="174" type="multinuc" parent="128" relname="span"/>
		<group id="175" type="span" parent="198" relname="elaboration"/>
		<group id="176" type="span" />
		<group id="177" type="multinuc" parent="147" relname="evaluation"/>
		<group id="178" type="span" parent="165" relname="contrast"/>
		<group id="180" type="span" parent="103" relname="elaboration"/>
		<group id="181" type="multinuc" parent="114" relname="contrast"/>
		<group id="182" type="span" parent="169" relname="joint"/>
		<group id="196" type="span" parent="197" relname="span"/>
		<group id="197" type="span" parent="198" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" />
		<group id="200" type="span" parent="165" relname="contrast"/>
		<group id="201" type="multinuc" parent="206" relname="span"/>
		<group id="202" type="span" parent="201" relname="joint"/>
		<group id="203" type="span" parent="205" relname="span"/>
		<group id="204" type="span" parent="203" relname="span"/>
		<group id="205" type="span" parent="80" relname="elaboration"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" />
	</body>
</rst>