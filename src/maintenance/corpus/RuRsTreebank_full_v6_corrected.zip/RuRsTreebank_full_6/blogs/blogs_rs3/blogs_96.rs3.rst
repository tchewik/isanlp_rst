<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://ru-travel.livejournal.com/33786605.html</segment>
		<segment id="2" >Ренон, Доломитовые Альпы: красота, от которой захватывает дух</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="172" relname="same-unit">К моему большому везению, мне удалось посмотреть немало разных уголков Италии: и живописные тосканские холмы, и завораживающее Лигурийское море,</segment>
		<segment id="5" parent="171" relname="span">и Венецию,</segment>
		<segment id="6" parent="170" relname="same-unit">которая,</segment>
		<segment id="7" parent="8" relname="concession">несмотря на всё свою "туристичность",</segment>
		<segment id="8" parent="169" relname="span">всё равно кажется каким-то другим миром.</segment>
		<segment id="9" parent="173" relname="contrast">Но ничего из этого так сильно меня не поразило, как итальянские Альпы. IMG</segment>
		<segment id="10" parent="343" relname="span">Напоминаю, что у меня есть телеграм-канал,</segment>
		<segment id="11" parent="10" relname="elaboration">где я пишу про жизнь, учебу и путешествия в Италии.</segment>
		<segment id="12" parent="177" relname="span">Всем известные Альпы занимают территорию 8 стран, среди которых и Италия:</segment>
		<segment id="13" parent="179" relname="span">горные хребты отделяют страну от расположенных севернее Австрии, Швейцарии и Франции.</segment>
		<segment id="14" parent="178" relname="span">Самые известные их них - Доломитовые - имеют статус наследия ЮНЕСКО</segment>
		<segment id="15" parent="14" relname="evaluation">и славятся своей неземной красотой.</segment>
		<segment id="16" parent="181" relname="same-unit">Неслучайно,</segment>
		<segment id="17" parent="18" relname="attribution">архитектор Ле Корбюзье утверждал,</segment>
		<segment id="18" parent="180" relname="span">что итальянские Альпы – это самое красивое архитектурное сооружение в мире. IMG</segment>
		<segment id="19" parent="344" relname="cause">Доломиты занимают обширный кусок на карте Италии,</segment>
		<segment id="20" parent="344" relname="span">поэтому я расскажу лишь об одном из мест, куда стоит отправиться,</segment>
		<segment id="21" parent="20" relname="purpose">чтобы увидеть эту красоту своими глазами.</segment>
		<segment id="22" parent="187" relname="span">Речь идёт про Ренон (Renon) - плато в провинции Больцано на самом севере страны в регионе Южный Тироль - пограничной (во всех отношениях) зоне между Италией и Австрией.</segment>
		<segment id="23" parent="186" relname="span">Эти земли долгое время были яблоком раздора между двумя странами:</segment>
		<segment id="24" parent="185" relname="contrast">около 100 лет назад территория отошла к Италии,</segment>
		<segment id="25" parent="185" relname="contrast">но до сих пор здесь говорят больше на немецком, чем на итальянском. IMG</segment>
		<segment id="26" parent="189" relname="span">Самый простой способ добраться до Ренона - это фуникулер из города Больцано (Bolzano),</segment>
		<segment id="27" parent="26" relname="background">о котором я расскажу в следующем посте.</segment>
		<segment id="28" parent="188" relname="span">За 12 минут кабинка поднимается на высоту 950 метров над уровнем моря</segment>
		<segment id="29" parent="28" relname="evaluation">и перед тобой открываются голубые Доломитовые Альпы и зеленые (даже в это время года) поля. IMG</segment>
		<segment id="30" parent="193" relname="span">На протяжении веков эти земли были перевалочным пунктом между Италией и Германией.</segment>
		<segment id="31" parent="190" relname="joint">Здесь проходили торговые потоки,</segment>
		<segment id="32" parent="192" relname="same-unit">здесь немецкие императоры,</segment>
		<segment id="33" parent="34" relname="condition">направляясь в Ватикан на коронацию,</segment>
		<segment id="34" parent="191" relname="span">преодолевали горные массивы Альп.</segment>
		<segment id="35" parent="194" relname="span">Сегодня Ренон - это разбросанные среди гор и холмов деревни,</segment>
		<segment id="36" parent="35" relname="elaboration">где в совокупности живёт около 8 тысяч человек.</segment>
		<segment id="37" parent="196" relname="span">Впрочем, здесь всегда хватает туристов:</segment>
		<segment id="38" parent="195" relname="joint">сложно представить место, где царит такое спокойствие</segment>
		<segment id="39" parent="195" relname="joint">и можно созерцать столько потрясающие пейзажи. IMG</segment>
		<segment id="40" parent="202" relname="restatement">Мы начинаем свою прогулку в деревне Сопрабольцано (Soprabolzano), или по-немецки Oberbozen,</segment>
		<segment id="41" parent="202" relname="restatement">что переводится c итальянского и немецкого как "Над Больцано"</segment>
		<segment id="42" parent="203" relname="elaboration">- именно здесь кончается канатная дорога.</segment>
		<segment id="43" parent="206" relname="same-unit">Для того,</segment>
		<segment id="44" parent="45" relname="purpose">чтобы передвигаться по плато,</segment>
		<segment id="45" parent="205" relname="span">в 1907 году здесь построили небольшую железную дорогу.</segment>
		<segment id="46" parent="205" relname="elaboration">За 3,5 евро вот такой симпатичный трамвайчик везет всех желающих по полям, лесам и холмам к конечному пункт - деревне Коллалбо (Collalbo). IMG</segment>
		<segment id="47" parent="48" relname="condition">Впрочем, пока еще есть силы и порох в пороховницах,</segment>
		<segment id="48" parent="208" relname="span">я решаю прогуляться пешком.</segment>
		<segment id="49" parent="211" relname="span">Кстати, советую так поступать всем:</segment>
		<segment id="50" parent="209" relname="contrast">поездка на трамвайчике - опыт интересный,</segment>
		<segment id="51" parent="210" relname="span">но гораздо больше вы увидите,</segment>
		<segment id="52" parent="51" relname="condition">если пройдетесь хотя бы в одну сторону пешком. IMG</segment>
		<segment id="53" parent="216" relname="joint">По территории всего плато проходит сеть пешеходных маршрутов, которые порой идут вдоль дороги (как на фото),</segment>
		<segment id="54" parent="216" relname="joint">а порой теряются в лесной чаще.</segment>
		<segment id="55" parent="218" relname="joint">Я люблю путешествовать на своих двоих по Италии</segment>
		<segment id="56" parent="346" relname="span">и могу сказать, что здешние маршруты - лучшие,</segment>
		<segment id="57" parent="56" relname="background">что мне доводилось встречать на всём полуострове.</segment>
		<segment id="58" parent="220" relname="span">Во-первых, на них невозможно заблудиться,</segment>
		<segment id="59" parent="219" relname="joint">всё размечено</segment>
		<segment id="60" parent="219" relname="joint">и понятно.</segment>
		<segment id="61" parent="223" relname="span">Во-вторых, пройтись по ним может любой желающий:</segment>
		<segment id="62" parent="221" relname="joint">тут нет резких перепадов высот,</segment>
		<segment id="63" parent="221" relname="joint">а тропинки расчищены,</segment>
		<segment id="64" parent="222" relname="span">поэтому вам не придётся карабкаться по корням или камням.</segment>
		<segment id="65" parent="320" relname="evaluation">В конечном итоге кажется, что ты просто гуляешь по парку - гигантскому парку с видом на завораживающие горные хребты Доломитовых Альп. IMG</segment>
		<segment id="66" parent="228" relname="span">В туристическом инфоцентре Сопрабольцано,</segment>
		<segment id="67" parent="66" relname="elaboration">который находится прямо рядом со станцией фуникулера,</segment>
		<segment id="68" parent="229" relname="same-unit">мне выдали карту</segment>
		<segment id="69" parent="230" relname="joint">и посоветовали первым делом дойти до озера Косталовара (Lago di Costalovara),</segment>
		<segment id="70" parent="231" relname="sequence">куда я и направился.</segment>
		<segment id="71" parent="232" relname="span">По пути встречаются лишь отдельные домики.</segment>
		<segment id="72" parent="323" relname="joint">Некоторые из них принадлежат местным жителям,</segment>
		<segment id="73" parent="323" relname="joint">другие - сдаются туристам. IMG</segment>
		<segment id="74" parent="234" relname="joint">В Реноне достаточно сильно развит конный спорт:</segment>
		<segment id="75" parent="233" relname="span">по пути встречается немало конюшен,</segment>
		<segment id="76" parent="75" relname="evaluation">перепутать с чем-то другим их сложно.</segment>
		<segment id="77" parent="236" relname="contrast">Признаться, я не большой поклонник конных прогулок,</segment>
		<segment id="78" parent="236" relname="contrast">но на фоне таких пейзажей покатался бы с огромным удовольствием. IMG</segment>
		<segment id="79" parent="238" relname="contrast">Я приехал в Доломитовые Альпы в начале декабря,</segment>
		<segment id="80" parent="238" relname="contrast">но погода здесь стоит еще осенняя: около 8 градусов тепла, желтые или даже зеленые деревья и ослепительное солнце.</segment>
		<segment id="81" parent="239" relname="span">Сложно представить, насколько тут живописно,</segment>
		<segment id="82" parent="81" relname="condition">когда выпадает снег.</segment>
		<segment id="83" parent="240" relname="same-unit">IMG</segment>
		<segment id="84" parent="250" relname="span">Сзади виднеется Сопрабальцано со своей канатной дорогой.</segment>
		<segment id="85" parent="247" relname="same-unit">Кстати, любопытно,</segment>
		<segment id="86" parent="87" relname="concession">что несмотря на крошечные размеры здешних деревень,</segment>
		<segment id="87" parent="246" relname="span">чуть ли не в каждой есть внушительных размеров церковь. IMG</segment>
		<segment id="88" parent="249" relname="joint">Я читал отчёты других людей,</segment>
		<segment id="89" parent="248" relname="span">и они жалуются, что местные деревни не настолько красивые,</segment>
		<segment id="90" parent="89" relname="condition">как они ожидали.</segment>
		<segment id="91" parent="325" relname="evaluation">Так ли это?</segment>
		<segment id="92" parent="251" relname="span">Ну, всё они очень однотипны,</segment>
		<segment id="93" parent="92" relname="concession">хоть и достаточно милы.</segment>
		<segment id="94" parent="252" relname="joint">Дело просто в том, что Ренон - это в первую очередь Доломитовые Альпы</segment>
		<segment id="95" parent="252" relname="joint">и смотреть нужно именно горы,</segment>
		<segment id="96" parent="253" relname="contrast">а поселки с их деревянными шале - лишь приятный бонус. IMG</segment>
		<segment id="97" parent="98" relname="cause">Как я уже говорил, этот регион долго был предметом спора между Австрией и Италией,</segment>
		<segment id="98" parent="258" relname="span">поэтому здесь большое количество немецкоговорящего населения.</segment>
		<segment id="99" parent="100" relname="attribution">По данным на 2011 год,</segment>
		<segment id="100" parent="339" relname="span">95% местных жители говорят на языке Гёте.</segment>
		<segment id="101" parent="262" relname="contrast">По пути я практически никого не встречал,</segment>
		<segment id="102" parent="261" relname="same-unit">но,</segment>
		<segment id="103" parent="104" relname="condition">когда это случалось,</segment>
		<segment id="104" parent="260" relname="span">я слышал "Hallo", а не "Ciao". IMG</segment>
		<segment id="105" parent="265" relname="span">Наконец мы доходим до озера Косталовара.</segment>
		<segment id="106" parent="264" relname="contrast">Летом здесь купаются,</segment>
		<segment id="107" parent="264" relname="contrast">но сейчас вода покрыта кромкой льда. IMG</segment>
		<segment id="108" parent="278" relname="preparation">Следующая точка - деревня Коллалбо, самая большая по населению на всём плато.</segment>
		<segment id="109" parent="273" relname="span">К ней ведёт живописная тропа Фрейда.</segment>
		<segment id="110" parent="272" relname="span">Дело в том, что отец психоанализа некоторое время жил здесь.</segment>
		<segment id="111" parent="268" relname="same-unit">В 1911 году</segment>
		<segment id="112" parent="266" relname="attribution">учёный написал в письме,</segment>
		<segment id="113" parent="266" relname="span">что ему срочно требуется место,</segment>
		<segment id="114" parent="113" relname="purpose">где он сможет побыть один, окруженный лесом.</segment>
		<segment id="115" parent="270" relname="span">Два месяца спустя психолог приехал в Коллалбо с женой,</segment>
		<segment id="116" parent="117" relname="cause">где ему настолько понравилось,</segment>
		<segment id="117" parent="269" relname="span">что он даже не стал спускаться в "городскую" часть региона. IMG</segment>
		<segment id="118" parent="274" relname="span">Насколько я слышал, тропа Фрейда</segment>
		<segment id="119" parent="118" relname="evaluation">(звучит странно, я знаю)</segment>
		<segment id="120" parent="275" relname="same-unit">- одно из самых красивых мест плато.</segment>
		<segment id="121" parent="276" relname="evaluation">Спорить не буду, все 40 минут, которые я потратил на этот маршрут, меня не покидало чувство, что будет сложно найти место, которое впечатлит меня сильнее, чем Доломитовые Альпы. IMG</segment>
		<segment id="122" parent="284" relname="contrast">Разумеется, мне не пришло в голову сделать подходящий снимок,</segment>
		<segment id="123" parent="281" relname="same-unit">но,</segment>
		<segment id="124" parent="125" relname="condition">гуляя по Ренону.</segment>
		<segment id="125" parent="280" relname="span">встречаешь немало скамеек и столиков,</segment>
		<segment id="126" parent="282" relname="span">поэтому смело запасайтесь съестными припасами,</segment>
		<segment id="127" parent="126" relname="purpose">чтобы сделать самый живописный перекус в вашей жизни. IMG</segment>
		<segment id="128" parent="285" relname="span">Кстати, помимо традиционных шале, здесь встречаются и вот таким модерновые домики.</segment>
		<segment id="129" parent="128" relname="evaluation">На мой взгляд, выглядит клево. IMG</segment>
		<segment id="130" parent="287" relname="joint">Доломитовых Альп не бывает мало. IMG</segment>
		<segment id="131" parent="288" relname="restatement">Наконец я дохожу до Коллалбо (Collalbo),</segment>
		<segment id="132" parent="288" relname="restatement">он же Клобенштейн (Klobenstein),</segment>
		<segment id="133" parent="289" relname="cause">поскольку все названия здесь дублируются на немецком.</segment>
		<segment id="134" parent="292" relname="span">Кстати, это распространяется на любой текст:</segment>
		<segment id="135" parent="291" relname="contrast">начиная от дорожных знаков</segment>
		<segment id="136" parent="291" relname="contrast">и заканчивая надписью "Спасибо" на товарных чеках. IMG</segment>
		<segment id="137" parent="294" relname="span">В Коллалбо можно перекусить в одном из ресторанов,</segment>
		<segment id="138" parent="137" relname="elaboration">которые, правда, в будни пустуют. IMG</segment>
		<segment id="139" parent="298" relname="preparation">Помните, я говорил про церковь? IMG</segment>
		<segment id="140" parent="297" relname="span">Здесь меня очень поразили вот такие скульптурные группы.</segment>
		<segment id="141" parent="296" relname="joint">Вдоль трассы достаточно часто встречаются деревянные панели с изображением Иисуса,</segment>
		<segment id="142" parent="296" relname="joint">нередко они стоят в чистом поле, но порой и рядом с жилыми домами.</segment>
		<segment id="143" parent="297" relname="elaboration">Вот в этом случае кто-то украсил панель горшками с растениями. IMG</segment>
		<segment id="144" parent="301" relname="span">По пути открываются виды на долину.</segment>
		<segment id="145" parent="300" relname="span">Местами лес сменяется небольшими поселками или виноградниками</segment>
		<segment id="146" parent="324" relname="span">- регион славится своим вином,</segment>
		<segment id="147" parent="146" relname="elaboration">в частности здесь делают отличный Гевюрцтраминер. IMG</segment>
		<segment id="148" parent="305" relname="span">А вот и местные жители.</segment>
		<segment id="149" parent="304" relname="contrast">Я где-то читал, что в Реноне обитают альпаки,</segment>
		<segment id="150" parent="303" relname="same-unit">но</segment>
		<segment id="151" parent="152" relname="attribution">Вики утверждает,</segment>
		<segment id="152" parent="302" relname="span">что на самом деле в этой части мира они не водятся.</segment>
		<segment id="153" parent="305" relname="elaboration">На мой взгляд, это просто козочки. IMG</segment>
		<segment id="154" parent="312" relname="preparation">Вот я и дошёл до последней намеченной на карте точки - земляных пирамид Ренона (Piramidi di roccia del Renon).</segment>
		<segment id="155" parent="309" relname="span">Это такие глиняные конусы, на вершине которых балансируют камни.</segment>
		<segment id="156" parent="308" relname="span">Раньше это были просто холмы,</segment>
		<segment id="157" parent="156" relname="elaboration">которые со временем размывались дождями.</segment>
		<segment id="158" parent="159" relname="condition">Там, где лежали камни,</segment>
		<segment id="159" parent="310" relname="span">земля сохранилась в форме вот таких причудливых столбиков.</segment>
		<segment id="160" parent="321" relname="contrast">Выглядит забавно, но не более. IMG</segment>
		<segment id="161" parent="321" relname="contrast">Зато отсюда открывается завораживающий вид на небольшую деревеньку. IMG</segment>
		<segment id="162" parent="163" relname="cause">К этому моменту я прошёл уже около 10 км пешком,</segment>
		<segment id="163" parent="314" relname="span">поэтому ноги немного напоминают о себе</segment>
		<segment id="164" parent="315" relname="joint">и я решаю вернуться обратно.</segment>
		<segment id="165" parent="316" relname="sequence">На трамвайчике я возвращаюсь назад в Сопрабальцано,</segment>
		<segment id="166" parent="317" relname="span">откуда спускаюсь в Больцано - уютному городу,</segment>
		<segment id="167" parent="318" relname="span">где царит рождественская атмосфера и</segment>
		<segment id="168" parent="167" relname="background">о котором я расскажу в следующий раз.</segment>
		<group id="169" type="span" parent="170" relname="same-unit"/>
		<group id="170" type="multinuc" parent="5" relname="evaluation"/>
		<group id="171" type="span" parent="172" relname="same-unit"/>
		<group id="172" type="multinuc" parent="173" relname="contrast"/>
		<group id="173" type="multinuc" parent="175" relname="span"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" />
		<group id="177" type="span" parent="182" relname="span"/>
		<group id="178" type="span" parent="13" relname="elaboration"/>
		<group id="179" type="span" parent="12" relname="elaboration"/>
		<group id="180" type="span" parent="181" relname="same-unit"/>
		<group id="181" type="multinuc" parent="177" relname="evaluation"/>
		<group id="182" type="span" />
		<group id="185" type="multinuc" parent="23" relname="elaboration"/>
		<group id="186" type="span" parent="22" relname="background"/>
		<group id="187" type="span" parent="199" relname="span"/>
		<group id="188" type="span" parent="189" relname="elaboration"/>
		<group id="189" type="span" parent="334" relname="span"/>
		<group id="190" type="multinuc" parent="30" relname="elaboration"/>
		<group id="191" type="span" parent="192" relname="same-unit"/>
		<group id="192" type="multinuc" parent="190" relname="joint"/>
		<group id="193" type="span" parent="198" relname="comparison"/>
		<group id="194" type="span" parent="197" relname="span"/>
		<group id="195" type="multinuc" parent="37" relname="cause"/>
		<group id="196" type="span" parent="194" relname="evaluation"/>
		<group id="197" type="span" parent="198" relname="comparison"/>
		<group id="198" type="multinuc" parent="199" relname="elaboration"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" />
		<group id="202" type="multinuc" parent="203" relname="span"/>
		<group id="203" type="span" parent="204" relname="span"/>
		<group id="204" type="span" parent="214" relname="preparation"/>
		<group id="205" type="span" parent="207" relname="span"/>
		<group id="206" type="multinuc" parent="213" relname="contrast"/>
		<group id="207" type="span" parent="206" relname="same-unit"/>
		<group id="208" type="span" parent="212" relname="span"/>
		<group id="209" type="multinuc" parent="49" relname="cause"/>
		<group id="210" type="span" parent="209" relname="contrast"/>
		<group id="211" type="span" parent="208" relname="evaluation"/>
		<group id="212" type="span" parent="213" relname="contrast"/>
		<group id="213" type="multinuc" parent="214" relname="span"/>
		<group id="214" type="span" parent="215" relname="span"/>
		<group id="215" type="span" />
		<group id="216" type="multinuc" parent="226" relname="preparation"/>
		<group id="218" type="multinuc" parent="225" relname="span"/>
		<group id="219" type="multinuc" parent="58" relname="cause"/>
		<group id="220" type="span" parent="224" relname="joint"/>
		<group id="221" type="multinuc" parent="64" relname="cause"/>
		<group id="222" type="span" parent="61" relname="cause"/>
		<group id="223" type="span" parent="224" relname="joint"/>
		<group id="224" type="multinuc" parent="320" relname="span"/>
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" parent="227" relname="span"/>
		<group id="227" type="span" />
		<group id="228" type="span" parent="229" relname="same-unit"/>
		<group id="229" type="multinuc" parent="230" relname="joint"/>
		<group id="230" type="multinuc" parent="231" relname="sequence"/>
		<group id="231" type="multinuc" parent="244" relname="preparation"/>
		<group id="232" type="span" parent="243" relname="joint"/>
		<group id="233" type="span" parent="234" relname="joint"/>
		<group id="234" type="multinuc" parent="235" relname="span"/>
		<group id="235" type="span" parent="237" relname="span"/>
		<group id="236" type="multinuc" parent="235" relname="evaluation"/>
		<group id="237" type="span" parent="243" relname="joint"/>
		<group id="238" type="multinuc" parent="241" relname="span"/>
		<group id="239" type="span" parent="240" relname="same-unit"/>
		<group id="240" type="multinuc" parent="241" relname="evaluation"/>
		<group id="241" type="span" parent="242" relname="span"/>
		<group id="242" type="span" parent="243" relname="joint"/>
		<group id="243" type="multinuc" parent="244" relname="span"/>
		<group id="244" type="span" parent="245" relname="span"/>
		<group id="245" type="span" />
		<group id="246" type="span" parent="247" relname="same-unit"/>
		<group id="247" type="multinuc" parent="84" relname="elaboration"/>
		<group id="248" type="span" parent="249" relname="joint"/>
		<group id="249" type="multinuc" parent="325" relname="span"/>
		<group id="250" type="span" parent="255" relname="preparation"/>
		<group id="251" type="span" parent="254" relname="span"/>
		<group id="252" type="multinuc" parent="253" relname="contrast"/>
		<group id="253" type="multinuc" parent="251" relname="cause"/>
		<group id="254" type="span" parent="255" relname="span"/>
		<group id="255" type="span" parent="257" relname="span"/>
		<group id="257" type="span" />
		<group id="258" type="span" parent="340" relname="preparation"/>
		<group id="260" type="span" parent="261" relname="same-unit"/>
		<group id="261" type="multinuc" parent="262" relname="contrast"/>
		<group id="262" type="multinuc" parent="339" relname="elaboration"/>
		<group id="264" type="multinuc" parent="105" relname="elaboration"/>
		<group id="265" type="span" />
		<group id="266" type="span" parent="267" relname="span"/>
		<group id="267" type="span" parent="268" relname="same-unit"/>
		<group id="268" type="multinuc" parent="271" relname="sequence"/>
		<group id="269" type="span" parent="115" relname="evaluation"/>
		<group id="270" type="span" parent="271" relname="sequence"/>
		<group id="271" type="multinuc" parent="110" relname="elaboration"/>
		<group id="272" type="span" parent="109" relname="background"/>
		<group id="273" type="span" parent="278" relname="span"/>
		<group id="274" type="span" parent="275" relname="same-unit"/>
		<group id="275" type="multinuc" parent="276" relname="span"/>
		<group id="276" type="span" parent="277" relname="span"/>
		<group id="277" type="span" parent="273" relname="evaluation"/>
		<group id="278" type="span" parent="279" relname="span"/>
		<group id="279" type="span" />
		<group id="280" type="span" parent="281" relname="same-unit"/>
		<group id="281" type="multinuc" parent="282" relname="cause"/>
		<group id="282" type="span" parent="283" relname="span"/>
		<group id="283" type="span" parent="286" relname="span"/>
		<group id="284" type="multinuc" />
		<group id="285" type="span" parent="287" relname="joint"/>
		<group id="286" type="span" parent="284" relname="contrast"/>
		<group id="287" type="multinuc" parent="283" relname="elaboration"/>
		<group id="288" type="multinuc" parent="289" relname="span"/>
		<group id="289" type="span" parent="290" relname="span"/>
		<group id="290" type="span" parent="293" relname="span"/>
		<group id="291" type="multinuc" parent="134" relname="elaboration"/>
		<group id="292" type="span" parent="290" relname="elaboration"/>
		<group id="293" type="span" parent="295" relname="span"/>
		<group id="294" type="span" parent="293" relname="elaboration"/>
		<group id="295" type="span" />
		<group id="296" type="multinuc" parent="140" relname="elaboration"/>
		<group id="297" type="span" parent="298" relname="span"/>
		<group id="298" type="span" parent="299" relname="span"/>
		<group id="299" type="span" />
		<group id="300" type="span" parent="144" relname="elaboration"/>
		<group id="301" type="span" parent="307" relname="joint"/>
		<group id="302" type="span" parent="303" relname="same-unit"/>
		<group id="303" type="multinuc" parent="304" relname="contrast"/>
		<group id="304" type="multinuc" parent="148" relname="elaboration"/>
		<group id="305" type="span" parent="306" relname="span"/>
		<group id="306" type="span" parent="307" relname="joint"/>
		<group id="307" type="multinuc" />
		<group id="308" type="span" parent="311" relname="span"/>
		<group id="309" type="span" parent="312" relname="span"/>
		<group id="310" type="span" parent="308" relname="elaboration"/>
		<group id="311" type="span" parent="155" relname="background"/>
		<group id="312" type="span" parent="313" relname="span"/>
		<group id="313" type="span" />
		<group id="314" type="span" parent="315" relname="joint"/>
		<group id="315" type="multinuc" parent="316" relname="sequence"/>
		<group id="316" type="multinuc" />
		<group id="317" type="span" parent="316" relname="sequence"/>
		<group id="318" type="span" parent="166" relname="evaluation"/>
		<group id="319" type="span" parent="225" relname="elaboration"/>
		<group id="320" type="span" parent="319" relname="span"/>
		<group id="321" type="multinuc" parent="309" relname="evaluation"/>
		<group id="323" type="multinuc" parent="71" relname="elaboration"/>
		<group id="324" type="span" parent="145" relname="evaluation"/>
		<group id="325" type="span" parent="326" relname="span"/>
		<group id="326" type="span" parent="254" relname="solutionhood"/>
		<group id="334" type="span" parent="187" relname="elaboration"/>
		<group id="339" type="span" parent="340" relname="span"/>
		<group id="340" type="span" parent="341" relname="span"/>
		<group id="341" type="span" />
		<group id="343" type="span" parent="175" relname="background"/>
		<group id="344" type="span" parent="345" relname="span"/>
		<group id="345" type="span" parent="200" relname="preparation"/>
		<group id="346" type="span" parent="218" relname="joint"/>
	</body>
</rst>