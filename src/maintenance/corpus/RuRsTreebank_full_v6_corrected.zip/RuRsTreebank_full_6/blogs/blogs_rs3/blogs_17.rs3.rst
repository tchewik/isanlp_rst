<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://my-first-time.livejournal.com/568230.html</segment>
		<segment id="2" >МОИ ПЕРВЫЕ ПОИСКИ ПРОПАВШЕГО ЧЕЛОВЕКА (ТРЕНИРОВКА)</segment>
		<segment id="3" parent="113" relname="evaluation">Потеря близкого человека - настоящая беда.</segment>
		<segment id="4" parent="103" relname="contrast">Латвия, в которой я живу - маленькая страна,</segment>
		<segment id="5" parent="103" relname="contrast">но каждый год у нас пропадает без вести много людей.</segment>
		<segment id="6" parent="104" relname="joint">К счастью, многие находятся сами,</segment>
		<segment id="7" parent="104" relname="joint">кого-то находит полиция,</segment>
		<segment id="8" parent="105" relname="contrast">некоторые так и остаются в списках пропавших без вести.</segment>
		<segment id="9" parent="106" relname="span">Но иногда возникает необходимость искать человека всем миром-</segment>
		<segment id="10" parent="9" relname="elaboration">например, когда кто-то заблудился в лесу.</segment>
		<segment id="11" parent="110" relname="span">В Латвии есть волонтерская организация, добровольцы которой занимаются такими поисками.</segment>
		<segment id="12" parent="108" relname="sequence">На сайте организации я заполнила анкету-заявку,</segment>
		<segment id="13" parent="108" relname="sequence">меня приняли кандидатом в волонтеры,</segment>
		<segment id="14" parent="109" relname="span">и через несколько дней пригласили на тренировку</segment>
		<segment id="15" parent="14" relname="purpose">по поиску потерявшихся в лесу людей.</segment>
		<segment id="16" parent="130" relname="preparation">Тренировка проходила в лесу под Ригой, на заброшенном военном полигоне.</segment>
		<segment id="17" parent="117" relname="sequence">Приехало довольно много новичков - человек 50.</segment>
		<segment id="18" parent="116" relname="joint">Сначала каждый из нас должен был представиться</segment>
		<segment id="19" parent="116" relname="joint">и вкратце рассказать о себе.</segment>
		<segment id="20" parent="21" relname="attribution">Потом нам объяснили задачу</segment>
		<segment id="21" parent="203" relname="span">- в лесу спрятаны "потеряшки", которых нам предстоит найти.</segment>
		<segment id="22" parent="118" relname="span">Первыми на маршрут выходят кинологи с поисковыми собаками.</segment>
		<segment id="23" parent="22" relname="elaboration">Сегодня приехали две собаки - акита Юлэ и бордер-колли Джей.</segment>
		<segment id="24" parent="121" relname="condition">Когда поисковая собака находит в лесу человека или предмет,</segment>
		<segment id="25" parent="120" relname="joint">она лаем обозначает свою находку</segment>
		<segment id="26" parent="120" relname="joint">и ложится рядом с ней.</segment>
		<segment id="27" parent="124" relname="span">Конечно, собака ищет не человека, а поощрение, которое ей положено за находку.</segment>
		<segment id="28" parent="125" relname="span">Для Юлэ это лакомство, а для Джея - любимая игрушка.</segment>
		<segment id="29" parent="28" relname="elaboration">На фотографии Юлэ.</segment>
		<segment id="30" parent="127" relname="condition">Пока собаки работают,</segment>
		<segment id="31" parent="126" relname="joint">нас разбивают на группы</segment>
		<segment id="32" parent="126" relname="joint">и выдают карты, где для каждой группы обозначен квадрат поиска.</segment>
		<segment id="33" parent="132" relname="elaboration">К каждой группе прикрепляется опытный инструктор.</segment>
		<segment id="34" parent="134" relname="joint">Перво-наперво нас всех обрабатывают средством от клещей</segment>
		<segment id="35" parent="204" relname="attribution">и напоминают,</segment>
		<segment id="36" parent="204" relname="span">что желательно иметь с собой  питьевую воду,</segment>
		<segment id="37" parent="36" relname="purpose">потому что главная наша задача - вернуться домой невредимыми.</segment>
		<segment id="38" parent="137" relname="span">Потом каждому выдают ярко-красную нарукавную повязку и шест с красным флажком -</segment>
		<segment id="39" parent="136" relname="joint">участники поисков должны видеть друг друга</segment>
		<segment id="40" parent="136" relname="joint">и иметь опознавательный знак.</segment>
		<segment id="41" parent="138" relname="joint">Нас выводят на исходную позицию</segment>
		<segment id="42" parent="138" relname="joint">и распределяют группы по участкам.</segment>
		<segment id="43" parent="44" relname="purpose">Чтобы поски были эффективными,</segment>
		<segment id="44" parent="139" relname="span">прочесывать лес надо цепью.</segment>
		<segment id="45" parent="140" relname="span">Нас выстраивают шеренгой.</segment>
		<segment id="46" parent="45" relname="elaboration">Надо запомнить своего соседа слева и соседа справа.</segment>
		<segment id="47" parent="144" relname="joint">И впредь каждый должен сторого придерживаться своего места в шеренге</segment>
		<segment id="48" parent="144" relname="joint">и соблюдать дистанцию.</segment>
		<segment id="49" parent="145" relname="sequence">Наконец, собаки закончили свою работу в лесу,</segment>
		<segment id="50" parent="145" relname="sequence">и нам дают команду начинать движение.</segment>
		<segment id="51" parent="196" relname="span">И тут оказывается, что идти цепью не тк-то просто!</segment>
		<segment id="52" parent="147" relname="span">Идти надо медленно,</segment>
		<segment id="53" parent="52" relname="condition">внимательно осматривая все вокруг себя,</segment>
		<segment id="54" parent="149" relname="joint">и при этом нельзя ни обгонять своих товарищей,</segment>
		<segment id="55" parent="149" relname="joint">ни отставать от них .</segment>
		<segment id="56" parent="151" relname="condition">Если кто-то отстал хоть на несколько метров,</segment>
		<segment id="57" parent="150" relname="joint">вся шеренга останавливается</segment>
		<segment id="58" parent="150" relname="joint">и ждет.</segment>
		<segment id="59" parent="164" relname="span">Иначе можно пропустить что-то важное!</segment>
		<segment id="60" parent="59" relname="elaboration">Фиксировать надо любой предмет, которого не должно быть в лесу - будь то конфетный фантик, носовой платок или отпечаток обуви.</segment>
		<segment id="61" parent="62" relname="cause">Так как мы идем по заброшенному воленному полигону,</segment>
		<segment id="62" parent="155" relname="span">у нас на пути множество естественных и искусственных препятствий - ям и горок, старых блиндажей и ангаров.</segment>
		<segment id="63" parent="64" relname="cause">Все это надо надо внимательно осматривать</segment>
		<segment id="64" parent="156" relname="span">- человек может быть и в яме, и на крыше сарая.</segment>
		<segment id="65" parent="157" relname="contrast">Но каждый должен идти строго по своей линии.</segment>
		<segment id="66" parent="67" relname="condition">Если на пути у кого-то, к примеру, блиндаж,</segment>
		<segment id="67" parent="158" relname="span">осматривает его человек, на чьей линии этот блиндаж находится.</segment>
		<segment id="68" parent="160" relname="joint">Остальные стоят на своих местах</segment>
		<segment id="69" parent="160" relname="joint">и ждут, пока закончится осмотр.</segment>
		<segment id="70" parent="163" relname="sequence">Потом все вместе начинают движение дальше.</segment>
		<segment id="71" parent="167" relname="elaboration">А на этой фотографии всеобщая радость - соседняя группа нашла своего "потеряшку"</segment>
		<segment id="72" parent="169" relname="evaluation">Я все время переживала,</segment>
		<segment id="73" parent="168" relname="contrast">что наш потеряшка окажется на моей линии,</segment>
		<segment id="74" parent="168" relname="contrast">и я его не увижу.</segment>
		<segment id="75" parent="170" relname="elaboration">Собственно, так и получилось.</segment>
		<segment id="76" parent="172" relname="joint">Человек сидел на дереве (вокруг одни сосны, а тут вдруг клен)</segment>
		<segment id="77" parent="172" relname="joint">и был практически невидим среди листьев.</segment>
		<segment id="78" parent="206" relname="attribution">Он потом рассказывал,</segment>
		<segment id="79" parent="173" relname="contrast">что я смотрела на него в упор</segment>
		<segment id="80" parent="173" relname="contrast">- и не видела!</segment>
		<segment id="81" parent="175" relname="contrast">Наверное, я так и прошла бы мимо,</segment>
		<segment id="82" parent="174" relname="span">но его боковым зрение заметил мой сосед</segment>
		<segment id="83" parent="82" relname="background">- отслуживший в армии парень.</segment>
		<segment id="84" parent="177" relname="attribution">Сказал-</segment>
		<segment id="85" parent="202" relname="evaluation">армейская привычка,</segment>
		<segment id="86" parent="201" relname="joint">шел</segment>
		<segment id="87" parent="201" relname="joint">и высматривал снайпера.</segment>
		<segment id="88" parent="183" relname="contrast">Я, конечно, расстороилась,</segment>
		<segment id="89" parent="184" relname="joint">но на "разборе полетов" все меня утешали</segment>
		<segment id="90" parent="208" relname="attribution">и сказали,</segment>
		<segment id="91" parent="185" relname="comparison">что в упор действительно практически невозможно заметить человека в листве,</segment>
		<segment id="92" parent="185" relname="comparison">сбоку его видно лучше.</segment>
		<segment id="93" parent="188" relname="evaluation">И вот что странно -</segment>
		<segment id="94" parent="186" relname="joint">люди идут в лес за грибами</segment>
		<segment id="95" parent="187" relname="span">и одеваются чуть не в камуфляж,</segment>
		<segment id="96" parent="95" relname="condition">превращаясь в человека-невидимку.</segment>
		<segment id="97" parent="191" relname="span">Но такая одежда хороша лишь тогда,</segment>
		<segment id="98" parent="97" relname="condition">когда надо в лесу незаметно пописать.</segment>
		<segment id="99" parent="192" relname="span">Пожалуйста, надевайте что-то яркое,</segment>
		<segment id="100" parent="99" relname="condition">когда идете в лес,</segment>
		<segment id="101" parent="192" relname="elaboration">особенно на детей и пожилых родственников!</segment>
		<segment id="102" parent="198" relname="joint">Не теряйте друг друга!</segment>
		<group id="103" type="multinuc" parent="113" relname="span"/>
		<group id="104" type="multinuc" parent="105" relname="contrast"/>
		<group id="105" type="multinuc" parent="107" relname="contrast"/>
		<group id="106" type="span" parent="111" relname="span"/>
		<group id="107" type="multinuc" parent="112" relname="span"/>
		<group id="108" type="multinuc" parent="11" relname="elaboration"/>
		<group id="109" type="span" parent="115" relname="span"/>
		<group id="110" type="span" parent="106" relname="elaboration"/>
		<group id="111" type="span" parent="107" relname="contrast"/>
		<group id="112" type="span" parent="119" relname="span"/>
		<group id="113" type="span" parent="114" relname="span"/>
		<group id="114" type="span" parent="112" relname="preparation"/>
		<group id="115" type="span" parent="108" relname="sequence"/>
		<group id="116" type="multinuc" parent="117" relname="sequence"/>
		<group id="117" type="multinuc" parent="130" relname="span"/>
		<group id="118" type="span" parent="129" relname="span"/>
		<group id="119" type="span" />
		<group id="120" type="multinuc" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="span"/>
		<group id="122" type="span" parent="123" relname="contrast"/>
		<group id="123" type="multinuc" parent="118" relname="elaboration"/>
		<group id="124" type="span" parent="123" relname="contrast"/>
		<group id="125" type="span" parent="27" relname="elaboration"/>
		<group id="126" type="multinuc" parent="132" relname="span"/>
		<group id="127" type="span" parent="128" relname="span"/>
		<group id="128" type="span" parent="142" relname="preparation"/>
		<group id="129" type="span" parent="117" relname="sequence"/>
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" />
		<group id="132" type="span" parent="127" relname="span"/>
		<group id="133" type="multinuc" parent="142" relname="span"/>
		<group id="134" type="multinuc" parent="133" relname="sequence"/>
		<group id="136" type="multinuc" parent="38" relname="elaboration"/>
		<group id="137" type="span" parent="133" relname="sequence"/>
		<group id="138" type="multinuc" parent="133" relname="sequence"/>
		<group id="139" type="span" parent="140" relname="cause"/>
		<group id="140" type="span" parent="141" relname="span"/>
		<group id="141" type="span" parent="133" relname="sequence"/>
		<group id="142" type="span" parent="143" relname="span"/>
		<group id="143" type="span" />
		<group id="144" type="multinuc" parent="146" relname="joint"/>
		<group id="145" type="multinuc" parent="146" relname="joint"/>
		<group id="146" type="multinuc" parent="196" relname="preparation"/>
		<group id="147" type="span" parent="148" relname="contrast"/>
		<group id="148" type="multinuc" parent="51" relname="elaboration"/>
		<group id="149" type="multinuc" parent="154" relname="span"/>
		<group id="150" type="multinuc" parent="151" relname="span"/>
		<group id="151" type="span" parent="152" relname="span"/>
		<group id="152" type="span" parent="154" relname="elaboration"/>
		<group id="153" type="span" parent="165" relname="contrast"/>
		<group id="154" type="span" parent="153" relname="span"/>
		<group id="155" type="span" parent="162" relname="preparation"/>
		<group id="156" type="span" parent="157" relname="contrast"/>
		<group id="157" type="multinuc" parent="161" relname="solutionhood"/>
		<group id="158" type="span" parent="159" relname="joint"/>
		<group id="159" type="multinuc" parent="163" relname="sequence"/>
		<group id="160" type="multinuc" parent="159" relname="joint"/>
		<group id="161" type="span" parent="167" relname="span"/>
		<group id="162" type="span" parent="166" relname="span"/>
		<group id="163" type="multinuc" parent="161" relname="span"/>
		<group id="164" type="span" parent="165" relname="contrast"/>
		<group id="165" type="multinuc" parent="148" relname="contrast"/>
		<group id="166" type="span" />
		<group id="167" type="span" parent="162" relname="span"/>
		<group id="168" type="multinuc" parent="169" relname="span"/>
		<group id="169" type="span" parent="170" relname="span"/>
		<group id="170" type="span" parent="171" relname="span"/>
		<group id="171" type="span" parent="181" relname="preparation"/>
		<group id="172" type="multinuc" parent="180" relname="joint"/>
		<group id="173" type="multinuc" parent="206" relname="span"/>
		<group id="174" type="span" parent="176" relname="span"/>
		<group id="175" type="multinuc" parent="178" relname="elaboration"/>
		<group id="176" type="span" parent="175" relname="contrast"/>
		<group id="177" type="span" parent="210" relname="span"/>
		<group id="178" type="span" parent="179" relname="span"/>
		<group id="179" type="span" parent="180" relname="joint"/>
		<group id="180" type="multinuc" parent="181" relname="span"/>
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" />
		<group id="183" type="multinuc" parent="194" relname="preparation"/>
		<group id="184" type="multinuc" parent="183" relname="contrast"/>
		<group id="185" type="multinuc" parent="208" relname="span"/>
		<group id="186" type="multinuc" parent="188" relname="span"/>
		<group id="187" type="span" parent="186" relname="joint"/>
		<group id="188" type="span" parent="189" relname="span"/>
		<group id="189" type="span" parent="190" relname="contrast"/>
		<group id="190" type="multinuc" parent="194" relname="span"/>
		<group id="191" type="span" parent="190" relname="contrast"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" parent="198" relname="joint"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" parent="199" relname="solutionhood"/>
		<group id="196" type="span" parent="197" relname="span"/>
		<group id="197" type="span" />
		<group id="198" type="multinuc" parent="199" relname="span"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" />
		<group id="201" type="multinuc" parent="202" relname="span"/>
		<group id="202" type="span" parent="177" relname="span"/>
		<group id="203" type="span" parent="117" relname="sequence"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="134" relname="joint"/>
		<group id="206" type="span" parent="178" relname="span"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" parent="184" relname="joint"/>
		<group id="210" type="span" parent="174" relname="elaboration"/>
	</body>
</rst>