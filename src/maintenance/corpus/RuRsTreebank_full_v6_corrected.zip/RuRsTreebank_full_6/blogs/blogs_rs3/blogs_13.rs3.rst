<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >Георгий Красников https://www.facebook.com/permalink.php?story_fbid=999588420252352&id=100006036094815</segment>
		<segment id="2" parent="3" relname="evaluation">Поучительная история сегодняшнего дня, описывающая моё раздолбайство и уровень сервиса в России...</segment>
		<segment id="3" parent="246" relname="span">Как добраться до города в 220 км от столицы.</segment>
		<segment id="4" parent="249" relname="span">Те, с кем я давно знаком, наверное, помнят, что была у меня когда-то машина Москвич-2141.</segment>
		<segment id="5" parent="241" relname="sequence">И помнят эту весёлую историю как её угнали в Юхновском районе Калужской области,</segment>
		<segment id="6" parent="241" relname="sequence">а потом сожгли в соседнем Мосальском районе.</segment>
		<segment id="7" parent="242" relname="background">Было это в далёком 2011 году.</segment>
		<segment id="8" parent="9" relname="evaluation">Но самое весёлое в истории то,</segment>
		<segment id="9" parent="244" relname="span">что она до сих пор не закончилась.</segment>
		<segment id="10" parent="254" relname="span">Ладно, не буду пересказывать как меня донимали страховые компании спустя ровно год после покупки.</segment>
		<segment id="11" parent="250" relname="joint">Какая-то у них общая база,</segment>
		<segment id="12" parent="250" relname="joint">и лезли одна за другой.</segment>
		<segment id="13" parent="251" relname="span">Интереснее то, что мне до сих пор за него приходит транспортный налог.</segment>
		<segment id="14" parent="13" relname="elaboration">Немного, но оно потихоньку копится-копится.</segment>
		<segment id="15" parent="252" relname="span">Справок-выписок из уголовного дела об угоне</segment>
		<segment id="16" parent="15" relname="cause">из-за переездов</segment>
		<segment id="17" parent="253" relname="same-unit">не сохранилось.</segment>
		<segment id="18" parent="504" relname="condition">Когда пришёл в ГАИ года 4 назад,</segment>
		<segment id="19" parent="20" relname="attribution">выяснил,</segment>
		<segment id="20" parent="504" relname="span">что почему-то она не стоит в угоне.</segment>
		<segment id="21" parent="257" relname="span">Предлагали поставить</segment>
		<segment id="22" parent="21" relname="purpose">чтобы налог больше не приходил,</segment>
		<segment id="23" parent="259" relname="span">но я решил съездить получить справку</segment>
		<segment id="24" parent="23" relname="purpose">чтобы отменить уже начисленные налоги..</segment>
		<segment id="25" parent="259" relname="evaluation">Зря, конечно.</segment>
		<segment id="26" parent="262" relname="span">Откладывал-откладывал,</segment>
		<segment id="27" parent="26" relname="cause">ведь никогда не делай завтра то, что можно сделать послезавтра.</segment>
		<segment id="28" parent="262" relname="elaboration">Так протикало аж 7 лет.</segment>
		<segment id="29" parent="30" relname="cause">Тем не менее, сумма накопилась порядочная,</segment>
		<segment id="30" parent="264" relname="span">надо бы разрулить вопрос.</segment>
		<segment id="31" parent="478" relname="preparation">В итоге собрался ехать в Юхнов сегодня 20 декабря 2018 года.</segment>
		<segment id="32" parent="271" relname="sequence">Да, я предварительно позвонил в Юхновское РОВД,</segment>
		<segment id="33" parent="34" relname="condition">понимая сроки,</segment>
		<segment id="34" parent="270" relname="span">обрисовал ситуацию,</segment>
		<segment id="35" parent="36" relname="attribution">и уточнил</segment>
		<segment id="36" parent="503" relname="span">- есть ли смысл ехать.</segment>
		<segment id="37" parent="273" relname="joint">"Да, приезжайте,</segment>
		<segment id="38" parent="273" relname="joint">всё должно быть",</segment>
		<segment id="39" parent="476" relname="attribution">успокоил меня дежурный.</segment>
		<segment id="40" parent="280" relname="preparation">День не задался с самого начала.</segment>
		<segment id="41" parent="278" relname="contrast">Погоду вы сами знаете (-9-13 С),</segment>
		<segment id="42" parent="277" relname="span">а я по дурости не очень тепло оделся,</segment>
		<segment id="43" parent="498" relname="span">наивно полагая что буду по минимуму находиться на улице,</segment>
		<segment id="44" parent="43" relname="elaboration">только перемещаться между транспортами.</segment>
		<segment id="45" parent="277" relname="elaboration">Майка, кофта, полуосенняя куртка, толстые джинсы без ничего больше, ну хоть ботинки хорошие.</segment>
		<segment id="46" parent="288" relname="preparation">1. Киевский вокзал, 8.40 утра.</segment>
		<segment id="47" parent="48" relname="purpose">Чтобы не идти в зал с доставучими охранниками,</segment>
		<segment id="48" parent="282" relname="span">покупаю билет на электричку в автомате.</segment>
		<segment id="49" parent="282" relname="background">Стоимость билета до Малоярославца 298 рублей.</segment>
		<segment id="50" parent="284" relname="sequence">Сую тысячу.</segment>
		<segment id="51" parent="284" relname="sequence">Автомат думает,</segment>
		<segment id="52" parent="284" relname="sequence">возвращает мне 5 соток</segment>
		<segment id="53" parent="290" relname="contrast">и зависает на несколько минут.</segment>
		<segment id="54" parent="290" relname="contrast">А время идёт.</segment>
		<segment id="55" parent="284" relname="sequence">Жму кнопку "возврат сдачи",</segment>
		<segment id="56" parent="284" relname="sequence">он мне высыпает мелочью 64 рубля</segment>
		<segment id="57" parent="285" relname="span">и печатает чек</segment>
		<segment id="58" parent="57" relname="purpose">на получение оставшихся 138.</segment>
		<segment id="59" parent="286" relname="span">Придётся идти в кассу,</segment>
		<segment id="60" parent="286" relname="evaluation">избежать бессмысленного шмона-проверок не получилось.</segment>
		<segment id="61" parent="293" relname="preparation">2. Электричка "Стандарт-плюс".</segment>
		<segment id="62" parent="291" relname="joint">Цивильная и комфортная, с мягким ходом,</segment>
		<segment id="63" parent="291" relname="joint">есть вай-фай.</segment>
		<segment id="64" parent="294" relname="contrast">Два часа блаженства</segment>
		<segment id="65" parent="294" relname="contrast">и резкий контраст с тем, что будет дальше.</segment>
		<segment id="66" parent="463" relname="preparation">3. Малоярославец.</segment>
		<segment id="67" parent="298" relname="joint">Дубак конкретный.</segment>
		<segment id="68" parent="298" relname="joint">Задрипанная автостанция с кассой на улице.</segment>
		<segment id="69" parent="297" relname="span">На расписании не нахожу рейсов в Юхнов.</segment>
		<segment id="70" parent="296" relname="contrast">"А у нас нет,</segment>
		<segment id="71" parent="296" relname="contrast">это только из Калуги".</segment>
		<segment id="72" parent="461" relname="span">Несколько лет назад точно же были,</segment>
		<segment id="73" parent="72" relname="evaluation">это вот так всё деградировало?</segment>
		<segment id="74" parent="300" relname="elaboration">Самое дальнее - только до Медыни.</segment>
		<segment id="75" parent="452" relname="contrast">Яндекс-транспорт показывает проходящие рейсы из Москвы.</segment>
		<segment id="76" parent="301" relname="joint">Но где они</segment>
		<segment id="77" parent="301" relname="joint">и как проходят - не знает никто.</segment>
		<segment id="78" parent="453" relname="span">Пошёл на трассу А101 в черте города (10 минут),</segment>
		<segment id="79" parent="78" relname="elaboration">там никто не в курсе никаких автобусов</segment>
		<segment id="80" parent="81" relname="attribution">- говорят,</segment>
		<segment id="81" parent="482" relname="span">что всё на автостанцию приходит.</segment>
		<segment id="82" parent="83" relname="condition">Пока ходил,</segment>
		<segment id="83" parent="303" relname="span">какой-то большой автобус мимо проехал</segment>
		<segment id="84" parent="303" relname="evaluation">- он или не он, непонятно.</segment>
		<segment id="85" parent="315" relname="span">4. Делать нечего, еду в Медынь.</segment>
		<segment id="86" parent="313" relname="joint">Во-первых, по пути,</segment>
		<segment id="87" parent="88" relname="cause">во-вторых - ну там город поменьше,</segment>
		<segment id="88" parent="314" relname="span">должно быть очевиднее где автобусы проходят.</segment>
		<segment id="89" parent="330" relname="span">Старый побитый жизнью и продуваемый всеми ветрами пазик-3205 трясётся по кочкам трассы А-101.</segment>
		<segment id="90" parent="319" relname="span">На малоярославецкой автостанции измученные транспортом, морозом и, в целом, необустроенностью жизни, тётки ругаются с сидящей в тепле за стеклом кассиршей</segment>
		<segment id="91" parent="90" relname="cause">из-за качества купюр,</segment>
		<segment id="92" parent="316" relname="span">и с водителем</segment>
		<segment id="93" parent="317" relname="joint">- что он не прогревает пазик</segment>
		<segment id="94" parent="317" relname="joint">и не закрывает дверь,</segment>
		<segment id="95" parent="320" relname="span">из-за чего последние остатки тепла улетучиваются.</segment>
		<segment id="96" parent="320" relname="concession">Впрочем, и во время пути в пазике толком не согреешься.</segment>
		<segment id="97" parent="98" relname="condition">Едучи,</segment>
		<segment id="98" parent="483" relname="span">вспоминаю со смехом какие скандалы происходят в Москве</segment>
		<segment id="99" parent="483" relname="condition">если вдруг какой-нибудь трамвай недостаточно натоплен.</segment>
		<segment id="100" parent="500" relname="span">Все знают куда стукануть если что..</segment>
		<segment id="101" parent="326" relname="evaluation">Да, разные миры просто..</segment>
		<segment id="102" parent="465" relname="preparation">5. Медынь, автостанция.</segment>
		<segment id="103" parent="332" relname="span">Уровень задрипанности тождествен малоярославецкому.</segment>
		<segment id="104" parent="331" relname="joint">Туалет на улице - дырка в полу.</segment>
		<segment id="105" parent="331" relname="joint">Касса на обеде,</segment>
		<segment id="106" parent="331" relname="joint">только тётка с пирожками огорошивает меня что тут также ничего нет на Юхнов.</segment>
		<segment id="107" parent="333" relname="span">Надо идти "на угол" стоять на остановке,</segment>
		<segment id="108" parent="107" relname="condition">морозя задницу,</segment>
		<segment id="109" parent="335" relname="span">и "где-то с пол-второго до пятнадцати минут третьего должен быть,</segment>
		<segment id="110" parent="109" relname="background">мой племянник ездил".</segment>
		<segment id="111" parent="451" relname="joint">6. Это соседние районы ОДНОЙ области!</segment>
		<segment id="112" parent="451" relname="joint">Это 60 км по оживлённой федеральной трассе.</segment>
		<segment id="113" parent="340" relname="span">Но никакого официального транспорта нет в принципе!</segment>
		<segment id="114" parent="115" relname="solutionhood">Это как так?</segment>
		<segment id="115" parent="341" relname="span">Это какая-то полнейшая феодальная раздробленность.</segment>
		<segment id="116" parent="501" relname="span">Да, пошёл на остановку,</segment>
		<segment id="117" parent="116" relname="condition">вспомнив, что ЯТ показывал ещё один проходящий рейс из Москвы в Починок какого-то ИП Ложкин А.А.</segment>
		<segment id="118" parent="343" relname="same-unit">Но</segment>
		<segment id="119" parent="120" relname="cause">на то оно и ИП</segment>
		<segment id="120" parent="342" relname="span">что может ездить как хочет.</segment>
		<segment id="121" parent="346" relname="span">О том, что на остановке или где-то ещё была бы какая-то информация, я даже и не думаю заикаться</segment>
		<segment id="122" parent="121" relname="evaluation">- вы ж понимаете, что это абсурд.</segment>
		<segment id="123" parent="349" relname="span">Помёрзнув минут 40 на остановке с маленькими перерывами</segment>
		<segment id="124" parent="123" relname="purpose">для обогрева</segment>
		<segment id="125" parent="350" relname="same-unit">на расположенной рядом почте,</segment>
		<segment id="126" parent="351" relname="span">я не выдержал.</segment>
		<segment id="127" parent="352" relname="joint">От холода постоянно хотелось в туалет,</segment>
		<segment id="128" parent="353" relname="span">и я вернулся на вокзал</segment>
		<segment id="129" parent="354" relname="joint">с целью посетить "дырку в полу"</segment>
		<segment id="130" parent="354" relname="joint">и уехать хоть куда-нибудь.</segment>
		<segment id="131" parent="355" relname="span">Тётка меня подбодрила что "ну вот в районе двух точно должен быть,</segment>
		<segment id="132" parent="131" relname="background">племянник ездил".</segment>
		<segment id="133" parent="134" relname="condition">Присмотрев себе обратный рейс в Малоярославец на 14.25</segment>
		<segment id="134" parent="357" relname="span">я отправился снова на остановку попытать счастья.</segment>
		<segment id="135" parent="469" relname="preparation">7. На этот раз получилось.</segment>
		<segment id="136" parent="454" relname="span">Через минут 10 прибыл автобус "Москва - Юхнов"</segment>
		<segment id="137" parent="136" relname="elaboration">на котором я и уехал.</segment>
		<segment id="138" parent="360" relname="span">Да, знал бы, конечно поехал бы на автобусе сразу из Москвы.</segment>
		<segment id="139" parent="138" relname="evaluation">По уму именно так надо было делать.</segment>
		<segment id="140" parent="362" relname="joint">Но мне в голову не могло прийти что в соседней Калужской области за последнее время всё стало так печально.</segment>
		<segment id="141" parent="362" relname="joint">Что соседние райцентры не связаны друг с другом от слова НИКАК.</segment>
		<segment id="142" parent="381" relname="preparation">8. Знакомый полицейский участок.</segment>
		<segment id="143" parent="368" relname="evaluation">Конечно же всё было зря.</segment>
		<segment id="144" parent="366" relname="joint">Конечно никакого уголовного дела не сохранилось,</segment>
		<segment id="145" parent="146" relname="evaluation">и вообще я сам дурак,</segment>
		<segment id="146" parent="367" relname="span">что не снял машину с налогового учёта.</segment>
		<segment id="147" parent="371" relname="sequence">Менты вспомнили этот случай,</segment>
		<segment id="148" parent="371" relname="sequence">даже вспомнили следовательницу, ведшую это дело,</segment>
		<segment id="149" parent="371" relname="sequence">и позвонили ей.</segment>
		<segment id="150" parent="373" relname="span">Но ничего не помогло</segment>
		<segment id="151" parent="150" relname="cause">- срок давности - 3 года.</segment>
		<segment id="152" parent="471" relname="evaluation">Интересно, что</segment>
		<segment id="153" parent="374" relname="contrast">как раз летом 2014 года мы мимо ехали на фестиваль,</segment>
		<segment id="154" parent="455" relname="joint">но не получилось тогда заехать</segment>
		<segment id="155" parent="455" relname="joint">(но и это уже было поздно).</segment>
		<segment id="156" parent="375" relname="span">Интересный факт - машина была НЕ в угоне</segment>
		<segment id="157" parent="156" relname="cause">потому что её нашли!</segment>
		<segment id="158" parent="376" relname="contrast">Ну т.е. нашли обгоревший кузов,</segment>
		<segment id="159" parent="376" relname="contrast">но не важно - я должен был действовать сам.</segment>
		<segment id="160" parent="456" relname="span">9. Досада на зря ухайдаканный день</segment>
		<segment id="161" parent="160" relname="evaluation">(что можно было предугадать)</segment>
		<segment id="162" parent="458" relname="span">и большое желание свалить поскорее из этого невзрачного городишки,</segment>
		<segment id="163" parent="162" relname="elaboration">с которым у меня одни обломы связаны.</segment>
		<segment id="164" parent="383" relname="contrast">Поесть бы,</segment>
		<segment id="165" parent="383" relname="contrast">но негде.</segment>
		<segment id="166" parent="384" relname="joint">Два кафе - одно вообще какой-то непонятный фастфуд,</segment>
		<segment id="167" parent="385" relname="span">а второе занято</segment>
		<segment id="168" parent="167" relname="cause">(идут поминки).</segment>
		<segment id="169" parent="393" relname="span">С транспортом также жопа:</segment>
		<segment id="170" parent="389" relname="joint">- последний автобус на Москву ушёл 2 часа назад.</segment>
		<segment id="171" parent="389" relname="joint">- последний автобус в Малоярославец ушёл несколько месяцев или лет назад.</segment>
		<segment id="172" parent="391" relname="span">- последний автобус в Калугу</segment>
		<segment id="173" parent="390" relname="contrast">(которая в стороне и совсем не по пути,</segment>
		<segment id="174" parent="390" relname="contrast">но через неё хоть как-то можно доехать)</segment>
		<segment id="175" parent="392" relname="same-unit">будет только в 6 вечера, через 2,5 часа.</segment>
		<segment id="176" parent="394" relname="evaluation">Чего тут всё это время делать?</segment>
		<segment id="177" parent="397" relname="contrast">10. Не хотел на таком морозе и в такой одежде ехать стопом, да и настроение не то.</segment>
		<segment id="178" parent="398" relname="span">Но иных вариантов нет.</segment>
		<segment id="179" parent="178" relname="cause">Хочется поскорее закончить с этой историей.</segment>
		<segment id="180" parent="399" relname="joint">Ладно, вроде не так холодно стало,</segment>
		<segment id="181" parent="399" relname="joint">и заправка рядом на карте есть.</segment>
		<segment id="182" parent="402" relname="sequence">Пошёл на выезд</segment>
		<segment id="183" parent="405" relname="span">и сразу поймал фургончик.</segment>
		<segment id="184" parent="403" relname="joint">Кабардинец везёт хлеб</segment>
		<segment id="185" parent="404" relname="contrast">- едет в Подольск,</segment>
		<segment id="186" parent="404" relname="contrast">но по пути надо ещё заехать в Износки (райцентр в стороне от трассы между Юхновым и Медынью).</segment>
		<segment id="187" parent="408" relname="span">11. Кабардинец свернул в свои Износки,</segment>
		<segment id="188" parent="187" relname="condition">оставив меня в сумерках на повороте в деревне Курганы.</segment>
		<segment id="189" parent="414" relname="span">Стопилось безуспешно</segment>
		<segment id="190" parent="189" relname="cause">- все либо ехали мимо либо недалеко (только до Мятлево).</segment>
		<segment id="191" parent="467" relname="span">Рядом был магазинчик</segment>
		<segment id="192" parent="409" relname="joint">в который я пошёл греться</segment>
		<segment id="193" parent="409" relname="joint">и пить кофе.</segment>
		<segment id="194" parent="411" relname="sequence">Только выхожу</segment>
		<segment id="195" parent="411" relname="sequence">- едет кабардинец.</segment>
		<segment id="196" parent="410" relname="contrast">А мог бы и пропустить его.</segment>
		<segment id="197" parent="418" relname="span">12. Ехалось нормально,</segment>
		<segment id="198" parent="197" relname="concession">хоть и немного продувало.</segment>
		<segment id="199" parent="200" relname="condition">При подъезде к Подольску</segment>
		<segment id="200" parent="419" relname="span">кабардинец стал жаловаться на жизнь</segment>
		<segment id="201" parent="420" relname="joint">и предложил помочь ему на 300 рублей.</segment>
		<segment id="202" parent="459" relname="span">Ладно, не та ситуация</segment>
		<segment id="203" parent="202" relname="purpose">чтобы ругаться</segment>
		<segment id="204" parent="459" relname="cause">- я бы эти деньги на автобус потратил.</segment>
		<segment id="205" parent="422" relname="sequence">Высаживает меня в подольской промзоне в 15 минутах ходьбы от станции.</segment>
		<segment id="206" parent="207" relname="evaluation">13. Ну и вишенка на торте:</segment>
		<segment id="207" parent="425" relname="span">снова автомат станции Подольск на морозе съел всю мою мелочь.</segment>
		<segment id="208" parent="426" relname="sequence">Выбрал станцию,</segment>
		<segment id="209" parent="426" relname="sequence">стал кидать выданные предыдущим автоматом монетки.</segment>
		<segment id="210" parent="506" relname="condition">Высыпав целую горстку,</segment>
		<segment id="211" parent="212" relname="attribution">обнаружил,</segment>
		<segment id="212" parent="506" relname="span">что баланс на табло остаётся 0.</segment>
		<segment id="213" parent="507" relname="evaluation">ААААА.</segment>
		<segment id="214" parent="430" relname="contrast">В каком-то проёме за щёлкой эти монетки и остались.</segment>
		<segment id="215" parent="430" relname="contrast">И даже никаких чеков автомат не выдаёт.</segment>
		<segment id="216" parent="431" relname="joint">"Что мне делать, автомат зажевал монетки</segment>
		<segment id="217" parent="431" relname="joint">и чека не дал" спрашиваю в кассе.</segment>
		<segment id="218" parent="432" relname="span">"Ну приходите завтра в 6 утра,</segment>
		<segment id="219" parent="218" relname="cause">его будут открывать".</segment>
		<segment id="220" parent="472" relname="evaluation">Понятно, что</segment>
		<segment id="221" parent="472" relname="span">ради 20-30 рублей я не приду</segment>
		<segment id="222" parent="435" relname="contrast">даже если бы рядом жил,</segment>
		<segment id="223" parent="435" relname="contrast">а тем более в Подольск ехать.</segment>
		<segment id="224" parent="436" relname="contrast">Ладно, куплю все равно только до первой зоны билет,</segment>
		<segment id="225" parent="436" relname="contrast">не до Ржевской же брать за 130 рублей..</segment>
		<segment id="226" parent="441" relname="span">Венец путешествия - снова тёплая комфортная электричка "Стандарт-плюс"</segment>
		<segment id="227" parent="440" relname="joint">где можно погреться</segment>
		<segment id="228" parent="440" relname="joint">и поинтернетиться.</segment>
		<segment id="229" parent="442" relname="span">Вот да, такие вот реалии жизни России за МКАДом.</segment>
		<segment id="230" parent="229" relname="evaluation">Чего удивляться что все поголовно мечтают машиной обзавестись.</segment>
		<segment id="231" parent="444" relname="contrast">Что ни говори, общий относительно приличный уровень транспорта обеспечивает ТОЛЬКО железная дорога.</segment>
		<segment id="232" parent="447" relname="span">Автобусный транспорт реально много где на уровне стран 3-го мира.</segment>
		<segment id="233" parent="232" relname="elaboration">Это и подвижной состав и автовокзалы, и организация движения - всё боль и тлен..</segment>
		<segment id="234" parent="502" relname="span">Вспоминал также Туву,</segment>
		<segment id="235" parent="234" relname="elaboration">где в принципе междугородний общественный транспорт отсутствует как таковой.</segment>
		<segment id="236" >А проблема с налогом осталась.</segment>
		<segment id="237" >Кто в теме, посоветуйте, как быть.</segment>
		<segment id="238" >Есть ли возможность списать этот налог,</segment>
		<segment id="239" >или раз нет доказательств,</segment>
		<segment id="240" >то придётся платить всё?</segment>
		<group id="241" type="multinuc" parent="242" relname="span"/>
		<group id="242" type="span" parent="243" relname="span"/>
		<group id="243" type="span" parent="245" relname="contrast"/>
		<group id="244" type="span" parent="245" relname="contrast"/>
		<group id="245" type="multinuc" parent="247" relname="span"/>
		<group id="246" type="span" parent="4" relname="preparation"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" />
		<group id="249" type="span" parent="247" relname="preparation"/>
		<group id="250" type="multinuc" parent="10" relname="elaboration"/>
		<group id="251" type="span" parent="255" relname="span"/>
		<group id="252" type="span" parent="253" relname="same-unit"/>
		<group id="253" type="multinuc" parent="267" relname="preparation"/>
		<group id="254" type="span" parent="251" relname="concession"/>
		<group id="255" type="span" />
		<group id="257" type="span" parent="260" relname="span"/>
		<group id="258" type="multinuc" parent="267" relname="span"/>
		<group id="259" type="span" parent="261" relname="span"/>
		<group id="260" type="span" parent="258" relname="contrast"/>
		<group id="261" type="span" parent="265" relname="span"/>
		<group id="262" type="span" parent="263" relname="span"/>
		<group id="263" type="span" parent="261" relname="background"/>
		<group id="264" type="span" parent="265" relname="concession"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" parent="258" relname="contrast"/>
		<group id="267" type="span" parent="268" relname="span"/>
		<group id="268" type="span" parent="269" relname="span"/>
		<group id="269" type="span" />
		<group id="270" type="span" parent="271" relname="sequence"/>
		<group id="271" type="multinuc" parent="477" relname="sequence"/>
		<group id="273" type="multinuc" parent="476" relname="span"/>
		<group id="277" type="span" parent="279" relname="span"/>
		<group id="278" type="multinuc" parent="280" relname="span"/>
		<group id="279" type="span" parent="278" relname="contrast"/>
		<group id="280" type="span" parent="281" relname="span"/>
		<group id="281" type="span" />
		<group id="282" type="span" parent="283" relname="span"/>
		<group id="283" type="span" parent="288" relname="span"/>
		<group id="284" type="multinuc" parent="283" relname="elaboration"/>
		<group id="285" type="span" parent="59" relname="cause"/>
		<group id="286" type="span" parent="287" relname="span"/>
		<group id="287" type="span" parent="284" relname="sequence"/>
		<group id="288" type="span" parent="289" relname="span"/>
		<group id="289" type="span" />
		<group id="290" type="multinuc" parent="284" relname="sequence"/>
		<group id="291" type="multinuc" parent="292" relname="span"/>
		<group id="292" type="span" parent="293" relname="span"/>
		<group id="293" type="span" parent="295" relname="span"/>
		<group id="294" type="multinuc" parent="292" relname="evaluation"/>
		<group id="295" type="span" />
		<group id="296" type="multinuc" parent="69" relname="elaboration"/>
		<group id="297" type="span" parent="300" relname="span"/>
		<group id="298" type="multinuc" parent="462" relname="span"/>
		<group id="300" type="span" parent="307" relname="span"/>
		<group id="301" type="multinuc" parent="452" relname="contrast"/>
		<group id="302" type="multinuc" parent="305" relname="joint"/>
		<group id="303" type="span" parent="304" relname="span"/>
		<group id="304" type="span" parent="305" relname="joint"/>
		<group id="305" type="multinuc" />
		<group id="306" type="multinuc" parent="462" relname="elaboration"/>
		<group id="307" type="span" parent="306" relname="contrast"/>
		<group id="313" type="multinuc" parent="85" relname="cause"/>
		<group id="314" type="span" parent="313" relname="joint"/>
		<group id="315" type="span" parent="89" relname="preparation"/>
		<group id="316" type="span" parent="318" relname="same-unit"/>
		<group id="317" type="multinuc" parent="92" relname="cause"/>
		<group id="318" type="multinuc" parent="329" relname="span"/>
		<group id="319" type="span" parent="318" relname="same-unit"/>
		<group id="320" type="span" parent="321" relname="span"/>
		<group id="321" type="span" parent="325" relname="contrast"/>
		<group id="325" type="multinuc" parent="326" relname="span"/>
		<group id="326" type="span" parent="327" relname="span"/>
		<group id="327" type="span" parent="460" relname="span"/>
		<group id="329" type="span" parent="95" relname="cause"/>
		<group id="330" type="span" parent="327" relname="preparation"/>
		<group id="331" type="multinuc" parent="103" relname="elaboration"/>
		<group id="332" type="span" parent="465" relname="span"/>
		<group id="333" type="span" parent="334" relname="joint"/>
		<group id="334" type="multinuc" parent="332" relname="elaboration"/>
		<group id="335" type="span" parent="334" relname="joint"/>
		<group id="339" type="multinuc" parent="490" relname="preparation"/>
		<group id="340" type="span" parent="339" relname="contrast"/>
		<group id="341" type="span" parent="113" relname="evaluation"/>
		<group id="342" type="span" parent="343" relname="same-unit"/>
		<group id="343" type="multinuc" parent="347" relname="span"/>
		<group id="346" type="span" parent="347" relname="elaboration"/>
		<group id="347" type="span" parent="348" relname="span"/>
		<group id="348" type="span" parent="489" relname="contrast"/>
		<group id="349" type="span" parent="350" relname="same-unit"/>
		<group id="350" type="multinuc" parent="126" relname="cause"/>
		<group id="351" type="span" parent="356" relname="sequence"/>
		<group id="352" type="multinuc" parent="356" relname="sequence"/>
		<group id="353" type="span" parent="352" relname="joint"/>
		<group id="354" type="multinuc" parent="128" relname="purpose"/>
		<group id="355" type="span" parent="356" relname="sequence"/>
		<group id="356" type="multinuc" />
		<group id="357" type="span" parent="356" relname="sequence"/>
		<group id="360" type="span" parent="361" relname="contrast"/>
		<group id="361" type="multinuc" parent="468" relname="sequence"/>
		<group id="362" type="multinuc" parent="361" relname="contrast"/>
		<group id="366" type="multinuc" parent="368" relname="span"/>
		<group id="367" type="span" parent="366" relname="joint"/>
		<group id="368" type="span" parent="369" relname="span"/>
		<group id="369" type="span" parent="380" relname="span"/>
		<group id="371" type="multinuc" parent="372" relname="contrast"/>
		<group id="372" type="multinuc" parent="369" relname="elaboration"/>
		<group id="373" type="span" parent="372" relname="contrast"/>
		<group id="374" type="multinuc" parent="471" relname="span"/>
		<group id="375" type="span" parent="377" relname="restatement"/>
		<group id="376" type="multinuc" parent="377" relname="restatement"/>
		<group id="377" type="multinuc" parent="378" relname="elaboration"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="380" relname="background"/>
		<group id="380" type="span" parent="381" relname="span"/>
		<group id="381" type="span" parent="382" relname="span"/>
		<group id="382" type="span" />
		<group id="383" type="multinuc" parent="386" relname="span"/>
		<group id="384" type="multinuc" parent="386" relname="elaboration"/>
		<group id="385" type="span" parent="384" relname="joint"/>
		<group id="386" type="span" parent="387" relname="span"/>
		<group id="387" type="span" parent="388" relname="joint"/>
		<group id="388" type="multinuc" parent="394" relname="span"/>
		<group id="389" type="multinuc" parent="169" relname="elaboration"/>
		<group id="390" type="multinuc" parent="172" relname="elaboration"/>
		<group id="391" type="span" parent="392" relname="same-unit"/>
		<group id="392" type="multinuc" parent="389" relname="joint"/>
		<group id="393" type="span" parent="388" relname="joint"/>
		<group id="394" type="span" parent="395" relname="span"/>
		<group id="395" type="span" parent="396" relname="span"/>
		<group id="396" type="span" />
		<group id="397" type="multinuc" parent="400" relname="span"/>
		<group id="398" type="span" parent="397" relname="contrast"/>
		<group id="399" type="multinuc" parent="400" relname="concession"/>
		<group id="400" type="span" parent="401" relname="span"/>
		<group id="401" type="span" parent="406" relname="preparation"/>
		<group id="402" type="multinuc" parent="406" relname="span"/>
		<group id="403" type="multinuc" parent="183" relname="elaboration"/>
		<group id="404" type="multinuc" parent="403" relname="joint"/>
		<group id="405" type="span" parent="402" relname="sequence"/>
		<group id="406" type="span" parent="407" relname="span"/>
		<group id="407" type="span" />
		<group id="408" type="span" parent="416" relname="preparation"/>
		<group id="409" type="multinuc" parent="191" relname="elaboration"/>
		<group id="410" type="multinuc" parent="415" relname="sequence"/>
		<group id="411" type="multinuc" parent="410" relname="contrast"/>
		<group id="414" type="span" parent="415" relname="sequence"/>
		<group id="415" type="multinuc" parent="416" relname="span"/>
		<group id="416" type="span" parent="417" relname="span"/>
		<group id="417" type="span" />
		<group id="418" type="span" parent="423" relname="preparation"/>
		<group id="419" type="span" parent="420" relname="joint"/>
		<group id="420" type="multinuc" parent="422" relname="sequence"/>
		<group id="421" type="span" parent="420" relname="joint"/>
		<group id="422" type="multinuc" parent="423" relname="span"/>
		<group id="423" type="span" parent="424" relname="span"/>
		<group id="424" type="span" />
		<group id="425" type="span" parent="438" relname="preparation"/>
		<group id="426" type="multinuc" parent="438" relname="span"/>
		<group id="430" type="multinuc" parent="508" relname="elaboration"/>
		<group id="431" type="multinuc" parent="433" relname="sequence"/>
		<group id="432" type="span" parent="437" relname="span"/>
		<group id="433" type="multinuc" parent="426" relname="sequence"/>
		<group id="435" type="multinuc" parent="221" relname="condition"/>
		<group id="436" type="multinuc" parent="426" relname="sequence"/>
		<group id="437" type="span" parent="433" relname="sequence"/>
		<group id="438" type="span" parent="439" relname="span"/>
		<group id="439" type="span" />
		<group id="440" type="multinuc" parent="226" relname="elaboration"/>
		<group id="441" type="span" parent="443" relname="contrast"/>
		<group id="442" type="span" parent="443" relname="contrast"/>
		<group id="443" type="multinuc" parent="450" relname="contrast"/>
		<group id="444" type="multinuc" parent="450" relname="contrast"/>
		<group id="447" type="span" parent="497" relname="span"/>
		<group id="450" type="multinuc" />
		<group id="451" type="multinuc" parent="339" relname="contrast"/>
		<group id="452" type="multinuc" parent="306" relname="contrast"/>
		<group id="453" type="span" parent="302" relname="contrast"/>
		<group id="454" type="span" parent="468" relname="sequence"/>
		<group id="455" type="multinuc" parent="374" relname="contrast"/>
		<group id="456" type="span" parent="457" relname="same-unit"/>
		<group id="457" type="multinuc" parent="395" relname="preparation"/>
		<group id="458" type="span" parent="457" relname="same-unit"/>
		<group id="459" type="span" parent="421" relname="span"/>
		<group id="460" type="span" />
		<group id="461" type="span" parent="297" relname="evaluation"/>
		<group id="462" type="span" parent="463" relname="span"/>
		<group id="463" type="span" parent="464" relname="span"/>
		<group id="464" type="span" />
		<group id="465" type="span" parent="466" relname="span"/>
		<group id="466" type="span" />
		<group id="467" type="span" parent="415" relname="sequence"/>
		<group id="468" type="multinuc" parent="469" relname="span"/>
		<group id="469" type="span" parent="470" relname="span"/>
		<group id="470" type="span" />
		<group id="471" type="span" parent="378" relname="span"/>
		<group id="472" type="span" parent="473" relname="span"/>
		<group id="473" type="span" parent="432" relname="evaluation"/>
		<group id="475" type="span" parent="477" relname="sequence"/>
		<group id="476" type="span" parent="475" relname="span"/>
		<group id="477" type="multinuc" parent="478" relname="span"/>
		<group id="478" type="span" parent="479" relname="span"/>
		<group id="479" type="span" />
		<group id="482" type="span" parent="302" relname="contrast"/>
		<group id="483" type="span" parent="499" relname="span"/>
		<group id="489" type="multinuc" parent="490" relname="span"/>
		<group id="490" type="span" parent="491" relname="span"/>
		<group id="491" type="span" />
		<group id="497" type="span" parent="444" relname="contrast"/>
		<group id="498" type="span" parent="42" relname="cause"/>
		<group id="499" type="span" parent="100" relname="solutionhood"/>
		<group id="500" type="span" parent="325" relname="contrast"/>
		<group id="501" type="span" parent="489" relname="contrast"/>
		<group id="502" type="span" parent="447" relname="elaboration"/>
		<group id="503" type="span" parent="271" relname="sequence"/>
		<group id="504" type="span" parent="505" relname="span"/>
		<group id="505" type="span" parent="257" relname="cause"/>
		<group id="506" type="span" parent="507" relname="span"/>
		<group id="507" type="span" parent="508" relname="span"/>
		<group id="508" type="span" parent="509" relname="span"/>
		<group id="509" type="span" parent="433" relname="sequence"/>
	</body>
</rst>