<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://miumau.livejournal.com/3097347.html</segment>
		<segment id="2" >Если ваш ребенок целится туда, куда ему не попасть</segment>
		<segment id="3" ></segment>
		<segment id="4" ></segment>
		<segment id="5" >IMG</segment>
		<segment id="6" parent="111" relname="span">Некоторые дети в очень раннем возрасте впрягаются во что-то очень так по-серьезному.</segment>
		<segment id="7" parent="110" relname="contrast">Например в спорт, или еще во что-то, где можно либо заниматься как хобби,</segment>
		<segment id="8" parent="113" relname="span">либо впрягаешься сразу как профессионал, и там и расходы, и вложения, и амбиции.</segment>
		<segment id="9" parent="112" relname="span">И сразу целятся в какую-то высшую лигу.</segment>
		<segment id="10" parent="9" relname="elaboration">Это мо жет быть и приготовление еды, балет или какая-то наука, много чего.</segment>
		<segment id="11" parent="119" relname="preparation">Кстати, часто говорят, что на это родители детей толкают.</segment>
		<segment id="12" parent="205" relname="same-unit">Мол, сначала</segment>
		<segment id="13" parent="14" relname="attribution">какой-то тренер заметил,</segment>
		<segment id="14" parent="204" relname="span">что у ребенка потенциал.</segment>
		<segment id="15" parent="114" relname="sequence">Потом донес эту мысль до родителей.</segment>
		<segment id="16" parent="115" relname="joint">Потом они все вместе начали ребенка толкать,</segment>
		<segment id="17" parent="115" relname="joint">хвалить,</segment>
		<segment id="18" parent="115" relname="joint">водить.</segment>
		<segment id="19" parent="116" relname="joint">И вот он уже шесть раз в неделю бегает,</segment>
		<segment id="20" parent="116" relname="joint">катается,</segment>
		<segment id="21" parent="116" relname="joint">танцует,</segment>
		<segment id="22" parent="114" relname="sequence">вот уже выступает за местную сборную на региональном конкурсе.</segment>
		<segment id="23" parent="118" relname="span">Вот он уже целится в спецшколу,</segment>
		<segment id="24" parent="117" relname="contrast">где учебы по другим предметам будет самый минимум,</segment>
		<segment id="25" parent="117" relname="contrast">зато 4 часа тренировок в день (или репетиций, или специальных занятий).</segment>
		<segment id="26" parent="201" relname="preparation">Но бывает и так, что ребенок сам!</segment>
		<segment id="27" parent="121" relname="joint">Никто его не заставлял,</segment>
		<segment id="28" parent="121" relname="joint">не тянул,</segment>
		<segment id="29" parent="121" relname="joint">не подгонял.</segment>
		<segment id="30" parent="122" relname="sequence">Сам где-то попробовал,</segment>
		<segment id="31" parent="122" relname="sequence">начало хорошо получаться, лучше других.</segment>
		<segment id="32" parent="122" relname="sequence">Получил похвалу от тренера.</segment>
		<segment id="33" parent="122" relname="sequence">начал еще больше и дальше, и.т.д.</segment>
		<segment id="34" parent="128" relname="span">И вот представьте себе такую ситуацию, что он уже начал участвовать в каких-то соревнованиях местного масштаба.</segment>
		<segment id="35" parent="124" relname="joint">Вот уже все хобби побросал ради этого.</segment>
		<segment id="36" parent="124" relname="joint">Вот уже и школа начала прихрамывать.</segment>
		<segment id="37" parent="125" relname="contrast">Но в этом деле зато - расцвет.</segment>
		<segment id="38" parent="129" relname="span">И тут вам становится отчетливо ясно, что чемпионоим он не будет.</segment>
		<segment id="39" parent="127" relname="joint">Наверное даже профессионалом не будет.</segment>
		<segment id="40" parent="126" relname="contrast">Или будет</segment>
		<segment id="41" parent="126" relname="contrast">- но всегда в лиге самых слабых.</segment>
		<segment id="42" parent="135" relname="contrast">Т.е. он заметно сильнее всех других детей.</segment>
		<segment id="43" parent="135" relname="contrast">Но заметно слабее всех, с кем бьется в своих профессиональных кругах.</segment>
		<segment id="44" parent="136" relname="joint">И не надо ему в спецшколу!</segment>
		<segment id="45" parent="136" relname="joint">И тем более в спецвуз!</segment>
		<segment id="46" parent="47" relname="cause">И не надо ему надеяться на олимпиаду</segment>
		<segment id="47" parent="138" relname="span">- не попадет он туда</segment>
		<segment id="48" parent="137" relname="joint">(и тренеры это тоже видят</segment>
		<segment id="49" parent="137" relname="joint">и знают).</segment>
		<segment id="50" parent="140" relname="contrast">Надо бы, чтобы он это делал, как хобби, и не более.</segment>
		<segment id="51" parent="140" relname="contrast">Но ведь не остановишь?!</segment>
		<segment id="52" parent="196" relname="joint">А что делать?</segment>
		<segment id="53" parent="196" relname="joint">Верить в своего ребенка?</segment>
		<segment id="54" parent="147" relname="span">А вы не верите,</segment>
		<segment id="55" parent="146" relname="joint">вы реалист</segment>
		<segment id="56" parent="145" relname="span">и начали видеть очевидные факты</segment>
		<segment id="57" parent="144" relname="joint">- не тянет</segment>
		<segment id="58" parent="144" relname="joint">и не вытянет.</segment>
		<segment id="59" parent="149" relname="span">Данных каких-то не хватает.</segment>
		<segment id="60" parent="61" relname="condition">Причем настолько,</segment>
		<segment id="61" parent="148" relname="span">что энтузиазмом не компенсируются.</segment>
		<segment id="62" parent="158" relname="span">Можно бы подумать об альтернативной карьере.</segment>
		<segment id="63" parent="153" relname="condition">Ну скажем - если кому-то нет дороги станцевать соло на сцене Большого Театра</segment>
		<segment id="64" parent="153" relname="span">- можно еще где-то танцевать,</segment>
		<segment id="65" parent="64" relname="elaboration">где умение требуется, и немало - всякие там шоу и.т.д.</segment>
		<segment id="66" parent="206" relname="cause">Но ребенок ваш заражен снобизмом коллег,</segment>
		<segment id="67" parent="68" relname="attribution">и считает</segment>
		<segment id="68" parent="206" relname="span">всякие шоу - низшим развлечением для тех, кто на лучшее не способен,</segment>
		<segment id="69" parent="157" relname="contrast">а сам себя таки видит на той самойсуене.</segment>
		<segment id="70" parent="199" relname="preparation">И вот что?</segment>
		<segment id="71" parent="203" relname="attribution">Говорить ему:</segment>
		<segment id="72" parent="198" relname="joint">"ОК, ты все сможешь,</segment>
		<segment id="73" parent="198" relname="joint">ты справишься"?</segment>
		<segment id="74" parent="159" relname="joint">Или, пока маленький, просто сделать одолжение</segment>
		<segment id="75" parent="159" relname="joint">и забрать из секции,</segment>
		<segment id="76" parent="159" relname="joint">не разрешать больше столько заниматься.</segment>
		<segment id="77" parent="161" relname="joint">Заставить учиться в школе,</segment>
		<segment id="78" parent="161" relname="joint">урезать тренировки</segment>
		<segment id="79" parent="161" relname="joint">и на всем этом поставить точку?</segment>
		<segment id="80" parent="163" relname="joint">Так ведь можно сильно испортить отношения.</segment>
		<segment id="81" parent="163" relname="joint">И надо же как-то поддерживать ребенка своего.</segment>
		<segment id="82" parent="167" relname="contrast">Пытаться перенаправить внимание?</segment>
		<segment id="83" parent="166" relname="span">А как ты его перенаправишь,</segment>
		<segment id="84" parent="83" relname="condition">когда человек так увлечен каким-то делом?</segment>
		<segment id="85" parent="170" relname="restatement">Дать ребенку сделать свои ошибки самостоятельно.</segment>
		<segment id="86" parent="169" relname="span">В том смысле, что пусть бьется,</segment>
		<segment id="87" parent="86" relname="condition">сколько сможет.</segment>
		<segment id="88" parent="172" relname="span">Жизнь сама покажет,</segment>
		<segment id="89" parent="171" relname="joint">что он может</segment>
		<segment id="90" parent="171" relname="joint">или не может.</segment>
		<segment id="91" parent="177" relname="span">А вдруг потом будут рыдания на тему</segment>
		<segment id="92" parent="93" relname="cause">"Ой, я 18 лет потратил только на это,</segment>
		<segment id="93" parent="174" relname="span">я ничего другого не умею,</segment>
		<segment id="94" parent="174" relname="elaboration">теперь у меня даже нормального школьного образования нету"</segment>
		<segment id="95" parent="176" relname="span">ну и плюс вообще трагедия</segment>
		<segment id="96" parent="95" relname="cause">из-за неудачи?</segment>
		<segment id="97" parent="179" relname="joint">А может быть вообще все будет иначе,</segment>
		<segment id="98" parent="179" relname="joint">и он сам потом как-то решит сменить направление.</segment>
		<segment id="99" parent="180" relname="evaluation">И никаких трагедий не будет?</segment>
		<segment id="100" parent="183" relname="span">И вы будете радоваться,</segment>
		<segment id="101" parent="182" relname="joint">что не слезли</segment>
		<segment id="102" parent="182" relname="joint">и не вмешались?</segment>
		<segment id="103" parent="185" relname="condition">Или, пока ребенок делает, то что делает,</segment>
		<segment id="104" parent="184" relname="joint">просто пытаться "фоном" продвигать идею, что варианты бывают разные,</segment>
		<segment id="105" parent="184" relname="joint">на одном свет клином не сошелся,</segment>
		<segment id="106" parent="187" relname="span">можно на любом этапе передумать,</segment>
		<segment id="107" parent="188" relname="joint">начать другое.</segment>
		<segment id="108" parent="189" relname="evaluation">ничего страшного и.т.д.? :-)</segment>
		<segment id="109" >Что бы вы сделали? :-)</segment>
		<group id="110" type="multinuc" parent="6" relname="elaboration"/>
		<group id="111" type="span" />
		<group id="112" type="span" parent="8" relname="elaboration"/>
		<group id="113" type="span" parent="110" relname="contrast"/>
		<group id="114" type="multinuc" parent="119" relname="span"/>
		<group id="115" type="multinuc" parent="114" relname="sequence"/>
		<group id="116" type="multinuc" parent="114" relname="sequence"/>
		<group id="117" type="multinuc" parent="23" relname="elaboration"/>
		<group id="118" type="span" parent="114" relname="sequence"/>
		<group id="119" type="span" parent="120" relname="span"/>
		<group id="120" type="span" />
		<group id="121" type="multinuc" parent="123" relname="contrast"/>
		<group id="122" type="multinuc" parent="123" relname="contrast"/>
		<group id="123" type="multinuc" parent="131" relname="span"/>
		<group id="124" type="multinuc" parent="125" relname="contrast"/>
		<group id="125" type="multinuc" parent="34" relname="elaboration"/>
		<group id="126" type="multinuc" parent="127" relname="joint"/>
		<group id="127" type="multinuc" parent="38" relname="elaboration"/>
		<group id="128" type="span" parent="130" relname="contrast"/>
		<group id="129" type="span" parent="130" relname="contrast"/>
		<group id="130" type="multinuc" parent="200" relname="joint"/>
		<group id="131" type="span" parent="200" relname="joint"/>
		<group id="135" type="multinuc" parent="142" relname="cause"/>
		<group id="136" type="multinuc" parent="141" relname="contrast"/>
		<group id="137" type="multinuc" parent="138" relname="evaluation"/>
		<group id="138" type="span" parent="139" relname="span"/>
		<group id="139" type="span" parent="136" relname="joint"/>
		<group id="140" type="multinuc" parent="141" relname="contrast"/>
		<group id="141" type="multinuc" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="span"/>
		<group id="143" type="span" />
		<group id="144" type="multinuc" parent="151" relname="span"/>
		<group id="145" type="span" parent="146" relname="joint"/>
		<group id="146" type="multinuc" parent="54" relname="cause"/>
		<group id="147" type="span" parent="197" relname="span"/>
		<group id="148" type="span" parent="59" relname="elaboration"/>
		<group id="149" type="span" parent="151" relname="cause"/>
		<group id="150" type="span" parent="56" relname="elaboration"/>
		<group id="151" type="span" parent="150" relname="span"/>
		<group id="152" type="multinuc" />
		<group id="153" type="span" parent="154" relname="span"/>
		<group id="154" type="span" parent="155" relname="contrast"/>
		<group id="155" type="multinuc" parent="62" relname="elaboration"/>
		<group id="157" type="multinuc" parent="155" relname="contrast"/>
		<group id="158" type="span" parent="152" relname="comparison"/>
		<group id="159" type="multinuc" parent="160" relname="contrast"/>
		<group id="160" type="multinuc" parent="164" relname="solutionhood"/>
		<group id="161" type="multinuc" parent="160" relname="contrast"/>
		<group id="162" type="span" parent="168" relname="comparison"/>
		<group id="163" type="multinuc" parent="164" relname="span"/>
		<group id="164" type="span" parent="165" relname="span"/>
		<group id="165" type="span" parent="168" relname="comparison"/>
		<group id="166" type="span" parent="167" relname="contrast"/>
		<group id="167" type="multinuc" parent="168" relname="comparison"/>
		<group id="168" type="multinuc" parent="194" relname="solutionhood"/>
		<group id="169" type="span" parent="170" relname="restatement"/>
		<group id="170" type="multinuc" parent="172" relname="condition"/>
		<group id="171" type="multinuc" parent="88" relname="elaboration"/>
		<group id="172" type="span" parent="173" relname="span"/>
		<group id="173" type="span" parent="192" relname="contrast"/>
		<group id="174" type="span" parent="175" relname="span"/>
		<group id="175" type="span" parent="91" relname="elaboration"/>
		<group id="176" type="span" parent="178" relname="joint"/>
		<group id="177" type="span" parent="178" relname="joint"/>
		<group id="178" type="multinuc" parent="192" relname="contrast"/>
		<group id="179" type="multinuc" parent="180" relname="span"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="191" relname="span"/>
		<group id="182" type="multinuc" parent="100" relname="cause"/>
		<group id="183" type="span" parent="181" relname="evaluation"/>
		<group id="184" type="multinuc" parent="185" relname="span"/>
		<group id="185" type="span" parent="186" relname="span"/>
		<group id="186" type="span" parent="106" relname="cause"/>
		<group id="187" type="span" parent="188" relname="joint"/>
		<group id="188" type="multinuc" parent="189" relname="span"/>
		<group id="189" type="span" parent="190" relname="span"/>
		<group id="190" type="span" parent="193" relname="comparison"/>
		<group id="191" type="span" parent="193" relname="comparison"/>
		<group id="192" type="multinuc" parent="193" relname="comparison"/>
		<group id="193" type="multinuc" parent="194" relname="span"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" />
		<group id="196" type="multinuc" parent="147" relname="solutionhood"/>
		<group id="197" type="span" parent="152" relname="comparison"/>
		<group id="198" type="multinuc" parent="203" relname="span"/>
		<group id="199" type="span" parent="162" relname="span"/>
		<group id="200" type="multinuc" parent="201" relname="span"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" />
		<group id="203" type="span" parent="199" relname="span"/>
		<group id="204" type="span" parent="205" relname="same-unit"/>
		<group id="205" type="multinuc" parent="114" relname="sequence"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="157" relname="contrast"/>
	</body>
</rst>