<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://my-first-time.livejournal.com/574519.html</segment>
		<segment id="2" >Мой первый визит к стоматологу</segment>
		<segment id="3" parent="4" relname="evaluation">Может я и счастливый человек,</segment>
		<segment id="4" parent="125" relname="span">что до 33 лет не ведал проблем с зубами,</segment>
		<segment id="5" parent="124" relname="contrast">но всё когда-то бывает впервые.</segment>
		<segment id="6" parent="126" relname="contrast">Как ни гнал я от себя эту крамольную мысль,</segment>
		<segment id="7" parent="132" relname="span">но пришёл и мой черёд осознать что заветного кресла мне не избежать.</segment>
		<segment id="8" parent="131" relname="span">Осознание это пришло не сразу.</segment>
		<segment id="9" parent="127" relname="condition">Когда от нижней челюсти заболела верхняя и левое ухо,</segment>
		<segment id="10" parent="127" relname="span">тут ещё можно было как-то стерпеть,</segment>
		<segment id="11" parent="10" relname="elaboration">заткнуть дырку в зубе кусочком анальгина.</segment>
		<segment id="12" parent="13" relname="condition">Но когда боль перешла на ногу</segment>
		<segment id="13" parent="129" relname="span">— вот тут я реально испугался.</segment>
		<segment id="14" parent="138" relname="preparation">Дело в том, что я с детства боялся стоматологического кабинета.</segment>
		<segment id="15" parent="138" relname="span">То есть как боялся:</segment>
		<segment id="16" parent="135" relname="joint">я ни когда туда не ходил</segment>
		<segment id="17" parent="135" relname="joint">и ни чего об этом не знал,</segment>
		<segment id="18" parent="137" relname="span">но время от времени слушал страшные истории об ужасах, там происходящих</segment>
		<segment id="19" parent="18" relname="evaluation">и по-настоящему в это верил.</segment>
		<segment id="20" parent="21" relname="attribution">Даже сцена из фильма Иван Васильевич меняет профессию,</segment>
		<segment id="21" parent="139" relname="span">где Шпак отбойным молотком длбит в рот пациента (простите за каламбур)</segment>
		<segment id="22" parent="139" relname="evaluation">подсознательно казалась мне правдивой.</segment>
		<segment id="23" parent="143" relname="same-unit">И даже аналогичная сцена</segment>
		<segment id="24" parent="141" relname="span">из мультфильма "В поисках Немо",</segment>
		<segment id="25" parent="24" relname="background">вышедшего на экраны в начале нулевых,</segment>
		<segment id="26" parent="141" relname="background">когда я был уже во взрослом возрасте</segment>
		<segment id="27" parent="146" relname="span">— только укрепила во мне эту стоматофобию.</segment>
		<segment id="28" parent="27" relname="background">Ой:) сейчас же в моде такие словечки: Ксенофобия, пидорофобия и вот теперь ещё и стоматофобия.</segment>
		<segment id="29" parent="149" relname="evaluation">Ну таки вот. Настал самый счастливый день в моей жизни,</segment>
		<segment id="30" parent="148" relname="joint">когда я впервые увидел стоматологическое кресло</segment>
		<segment id="31" parent="148" relname="joint">и он мне сразу понравилось.</segment>
		<segment id="32" parent="152" relname="span">У меня возникла аналогия с американскими фильмами про психологов,</segment>
		<segment id="33" parent="151" relname="sequence">когда приходит человек к психологу,</segment>
		<segment id="34" parent="151" relname="sequence">ложится в такое же мягкое и удобное полукресло-полукровать</segment>
		<segment id="35" parent="151" relname="sequence">и рассказывает о своих гомофобиях.</segment>
		<segment id="36" parent="153" relname="sequence">Психолог делает приглушенный свет, (слегка даже интимный)</segment>
		<segment id="37" parent="153" relname="sequence">садится у изголовья пациента</segment>
		<segment id="38" parent="153" relname="sequence">и слушает.</segment>
		<segment id="39" parent="155" relname="sequence">А потом пациент встаёт,</segment>
		<segment id="40" parent="155" relname="sequence">платит деньги психологу за то что тот слушал</segment>
		<segment id="41" parent="155" relname="sequence">и счастливый уходит домой.</segment>
		<segment id="42" parent="158" relname="joint">Вот и у меня мелькнула шальная мысль что лягу я сейчас в это кресло</segment>
		<segment id="43" parent="157" relname="joint">и поговорю по душам с доктором,</segment>
		<segment id="44" parent="157" relname="joint">пожалуюсь на жизнь тяжёлую: клаустрофобию, агорафобию и дальше по списку;</segment>
		<segment id="45" parent="46" relname="evaluation">да на то как жена моя не верит</segment>
		<segment id="46" parent="159" relname="span">что у меня зубок болит,</segment>
		<segment id="47" parent="159" relname="evaluation">за последние дни я его ласково стал называть зубок.</segment>
		<segment id="48" parent="49" relname="cause">И потом меня эта зубная боль так измучила,</segment>
		<segment id="49" parent="161" relname="span">что я готов был в любое кресло сесть,</segment>
		<segment id="50" parent="161" relname="purpose">лишь бы только кто-нибудь мне помог.</segment>
		<segment id="51" parent="185" relname="preparation">Оказалось всё ни так уж и страшно.</segment>
		<segment id="52" parent="170" relname="span">Кресло действительно мягкое и удобное</segment>
		<segment id="53" parent="169" relname="span">— знаете, я бы у себя такое в саду поставил,</segment>
		<segment id="54" parent="168" relname="joint">чтобы сидеть,</segment>
		<segment id="55" parent="168" relname="joint">пить чай</segment>
		<segment id="56" parent="168" relname="joint">и созерцать "пышное природы увяданье"</segment>
		<segment id="57" parent="174" relname="span">— доктор, молодая и красивая женщина примерно моего возраста, с большими выразительными глазами,</segment>
		<segment id="58" parent="171" relname="joint">которые становятся ещё больше</segment>
		<segment id="59" parent="171" relname="joint">и выразительнее,</segment>
		<segment id="60" parent="172" relname="condition">когда она всё остальное лицо маской закрывает.</segment>
		<segment id="61" parent="175" relname="joint">Эти глаза её имеют колоссальное значение в её профессии,</segment>
		<segment id="62" parent="175" relname="joint">они действуют как кролик на удава — вот какие у неё глаза.</segment>
		<segment id="63" parent="183" relname="span">А в особенности голос у неё такой тихий и успокаивающий.</segment>
		<segment id="64" parent="179" relname="span">Как заговорит она своим вежливым и пронзительным голосом:</segment>
		<segment id="65" parent="177" relname="joint">"Откройте шире пожалуйста"</segment>
		<segment id="66" parent="177" relname="joint">"не бойтесь"</segment>
		<segment id="67" parent="177" relname="joint">"потерпите,</segment>
		<segment id="68" parent="177" relname="joint">сейчас будет немного больно"</segment>
		<segment id="69" parent="178" relname="span">"Тише, тише.</segment>
		<segment id="70" parent="69" relname="evaluation">Ну что ты так боишься".....</segment>
		<segment id="71" parent="181" relname="span">Ох, вы бы слышали какой милый у неё голос.</segment>
		<segment id="72" parent="180" relname="joint">Хочется отдаться ей полностью</segment>
		<segment id="73" parent="180" relname="joint">и пусть делает со мной всё что хочет — вот какой у неё голос.</segment>
		<segment id="74" parent="202" relname="preparation">А вот зубок мой спасти, похоже так и не удастся.</segment>
		<segment id="75" parent="76" relname="cause">Пока я столько лет упорно отказывался идти к стоматологу,</segment>
		<segment id="76" parent="187" relname="span">он у меня окончательно развалился.</segment>
		<segment id="77" parent="188" relname="joint">Доктор Татьяна мне просто его рассверлила</segment>
		<segment id="78" parent="188" relname="joint">и каналы прочистила такой иголочкой с зазубринками; типа натфеля, только очень маленького.</segment>
		<segment id="79" parent="189" relname="span">Вот эта процедура самая больная оказалась.</segment>
		<segment id="80" parent="79" relname="evaluation">Я даже чуть не обоссался от боли, честное слово.</segment>
		<segment id="81" parent="192" relname="span">Перфоратор же этот,</segment>
		<segment id="82" parent="193" relname="span">от одного только жужжания которого некоторые юзеры сознание теряют</segment>
		<segment id="83" parent="82" relname="evaluation">(правда-правда, есть и такие),</segment>
		<segment id="84" parent="194" relname="same-unit">оказался ни таким уж и страшным.</segment>
		<segment id="85" parent="196" relname="span">Была только ода единственная малюсенькая фобийка,</segment>
		<segment id="86" parent="195" relname="sequence">что у неё сейчас рука дрогнет</segment>
		<segment id="87" parent="195" relname="sequence">и она мне щёку просверлит насквозь.</segment>
		<segment id="88" parent="197" relname="span">Да вот ещё воняет очень палёными ногтями во рту,</segment>
		<segment id="89" parent="88" relname="condition">когда она остатки зубочка моего сверлила.</segment>
		<segment id="90" parent="204" relname="joint">После выполнения всех процедур назначила она мне полоскать рот содой</segment>
		<segment id="91" parent="204" relname="joint">и попить амоксициллин.</segment>
		<segment id="92" parent="206" relname="joint">А после того как стихнет боль</segment>
		<segment id="93" parent="206" relname="joint">и сойдёт восполение,</segment>
		<segment id="94" parent="207" relname="span">велела удалять.</segment>
		<segment id="95" parent="94" relname="evaluation">Вот и всё.</segment>
		<segment id="96" parent="209" relname="span">Поговорить мне с ней так и не удалось,</segment>
		<segment id="97" parent="208" relname="joint">потому что она мне всё время в рот железки какие-то засовывала,</segment>
		<segment id="98" parent="208" relname="joint">а в конце начала готовиться к следующему пациенту, который уже стоял в дверях.</segment>
		<segment id="99" parent="220" relname="preparation">Так благополучно закончился мой первый к стоматологу.</segment>
		<segment id="100" parent="211" relname="condition">Когда я пришёл домой,</segment>
		<segment id="101" parent="211" relname="span">первым делом развёл чайную ложку соды в стакане тёплой воды —</segment>
		<segment id="102" parent="101" relname="elaboration">всё как она велела —</segment>
		<segment id="103" parent="219" relname="span">и в этот момент совершил удивительное открытие:</segment>
		<segment id="104" parent="212" relname="span">Оказывается все эти минеральные воды в пластиковых бутылках,</segment>
		<segment id="105" parent="104" relname="background">которые продаются в нашем сельпо,</segment>
		<segment id="106" parent="213" relname="same-unit">имеют вкус идентичный моей ложке соды в стакане воды.</segment>
		<segment id="107" parent="214" relname="joint">Теперь я мечтаю съездить когда-нибудь в Ессентуки</segment>
		<segment id="108" parent="215" relname="span">и самому попробовать,</segment>
		<segment id="109" parent="216" relname="span">такой ли у тамошней минеральной воды вкус как в нашем сельпо.</segment>
		<segment id="110" parent="109" relname="evaluation">Вы же там в Москве думаете что у нас тут сельпо, ни так ли?</segment>
		<segment id="111" parent="227" relname="preparation">Ну вот пожалуй и всё.</segment>
		<segment id="112" parent="223" relname="span">Теперь мне предстоит ещё удаление.</segment>
		<segment id="113" parent="112" relname="evaluation">Вот где весело будет:)</segment>
		<segment id="114" parent="225" relname="solutionhood">А может не удалять?</segment>
		<segment id="115" parent="225" relname="span">Боль прошла, да и ладно.</segment>
		<segment id="116" parent="115" relname="background">Кстати боль уже прошла.</segment>
		<segment id="117" parent="118" relname="condition">Но пока я вам тут писал,</segment>
		<segment id="118" parent="228" relname="span">у нашей коровы телёночек родился!</segment>
		<segment id="119" parent="230" relname="span">Только рассказывать об этом я уже не буду.</segment>
		<segment id="120" parent="119" relname="cause">Потому что роды принимаю не в первый раз.</segment>
		<segment id="121" parent="231" relname="contrast">У меня есть интересные фотографии,</segment>
		<segment id="122" parent="232" relname="span">но и их я вам тут не покажу по той же причине</segment>
		<segment id="123" parent="122" relname="cause">— не в первый раз.</segment>
		<group id="124" type="multinuc" parent="133" relname="preparation"/>
		<group id="125" type="span" parent="124" relname="contrast"/>
		<group id="126" type="multinuc" parent="133" relname="span"/>
		<group id="127" type="span" parent="128" relname="span"/>
		<group id="128" type="span" parent="130" relname="contrast"/>
		<group id="129" type="span" parent="130" relname="contrast"/>
		<group id="130" type="multinuc" parent="8" relname="elaboration"/>
		<group id="131" type="span" parent="7" relname="elaboration"/>
		<group id="132" type="span" parent="126" relname="contrast"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" />
		<group id="135" type="multinuc" parent="136" relname="contrast"/>
		<group id="136" type="multinuc" parent="15" relname="elaboration"/>
		<group id="137" type="span" parent="145" relname="span"/>
		<group id="138" type="span" parent="147" relname="span"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="144" relname="joint"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="same-unit"/>
		<group id="143" type="multinuc" parent="144" relname="joint"/>
		<group id="144" type="multinuc" parent="137" relname="elaboration"/>
		<group id="145" type="span" parent="136" relname="contrast"/>
		<group id="146" type="span" parent="143" relname="same-unit"/>
		<group id="147" type="span" />
		<group id="148" type="multinuc" parent="149" relname="span"/>
		<group id="149" type="span" parent="150" relname="span"/>
		<group id="150" type="span" parent="166" relname="preparation"/>
		<group id="151" type="multinuc" parent="32" relname="elaboration"/>
		<group id="152" type="span" parent="154" relname="joint"/>
		<group id="153" type="multinuc" parent="154" relname="joint"/>
		<group id="154" type="multinuc" parent="156" relname="sequence"/>
		<group id="155" type="multinuc" parent="156" relname="sequence"/>
		<group id="156" type="multinuc" parent="165" relname="comparison"/>
		<group id="157" type="multinuc" parent="158" relname="joint"/>
		<group id="158" type="multinuc" parent="163" relname="span"/>
		<group id="159" type="span" parent="160" relname="span"/>
		<group id="160" type="span" parent="157" relname="joint"/>
		<group id="161" type="span" parent="162" relname="span"/>
		<group id="162" type="span" parent="163" relname="elaboration"/>
		<group id="163" type="span" parent="164" relname="span"/>
		<group id="164" type="span" parent="165" relname="comparison"/>
		<group id="165" type="multinuc" parent="166" relname="span"/>
		<group id="166" type="span" parent="167" relname="span"/>
		<group id="167" type="span" />
		<group id="168" type="multinuc" parent="53" relname="purpose"/>
		<group id="169" type="span" parent="52" relname="elaboration"/>
		<group id="170" type="span" parent="184" relname="joint"/>
		<group id="171" type="multinuc" parent="172" relname="span"/>
		<group id="172" type="span" parent="173" relname="span"/>
		<group id="173" type="span" parent="176" relname="span"/>
		<group id="174" type="span" parent="237" relname="span"/>
		<group id="175" type="multinuc" parent="173" relname="evaluation"/>
		<group id="176" type="span" parent="57" relname="elaboration"/>
		<group id="177" type="multinuc" parent="64" relname="elaboration"/>
		<group id="178" type="span" parent="177" relname="joint"/>
		<group id="179" type="span" parent="182" relname="span"/>
		<group id="180" type="multinuc" parent="71" relname="evaluation"/>
		<group id="181" type="span" parent="179" relname="evaluation"/>
		<group id="182" type="span" parent="63" relname="elaboration"/>
		<group id="183" type="span" parent="174" relname="elaboration"/>
		<group id="184" type="multinuc" parent="185" relname="span"/>
		<group id="185" type="span" parent="186" relname="span"/>
		<group id="186" type="span" />
		<group id="187" type="span" parent="201" relname="sequence"/>
		<group id="188" type="multinuc" parent="190" relname="span"/>
		<group id="189" type="span" parent="190" relname="evaluation"/>
		<group id="190" type="span" parent="191" relname="span"/>
		<group id="191" type="span" parent="201" relname="sequence"/>
		<group id="192" type="span" parent="194" relname="same-unit"/>
		<group id="193" type="span" parent="81" relname="evaluation"/>
		<group id="194" type="multinuc" parent="199" relname="contrast"/>
		<group id="195" type="multinuc" parent="85" relname="elaboration"/>
		<group id="196" type="span" parent="200" relname="span"/>
		<group id="197" type="span" parent="196" relname="elaboration"/>
		<group id="198" type="multinuc" parent="202" relname="span"/>
		<group id="199" type="multinuc" parent="198" relname="contrast"/>
		<group id="200" type="span" parent="199" relname="contrast"/>
		<group id="201" type="multinuc" parent="198" relname="contrast"/>
		<group id="202" type="span" parent="203" relname="span"/>
		<group id="203" type="span" />
		<group id="204" type="multinuc" parent="205" relname="sequence"/>
		<group id="205" type="multinuc" parent="210" relname="contrast"/>
		<group id="206" type="multinuc" parent="205" relname="sequence"/>
		<group id="207" type="span" parent="205" relname="sequence"/>
		<group id="208" type="multinuc" parent="96" relname="cause"/>
		<group id="209" type="span" parent="210" relname="contrast"/>
		<group id="210" type="multinuc" />
		<group id="211" type="span" parent="221" relname="span"/>
		<group id="212" type="span" parent="213" relname="same-unit"/>
		<group id="213" type="multinuc" parent="217" relname="span"/>
		<group id="214" type="multinuc" parent="217" relname="evaluation"/>
		<group id="215" type="span" parent="214" relname="joint"/>
		<group id="216" type="span" parent="108" relname="elaboration"/>
		<group id="217" type="span" parent="218" relname="span"/>
		<group id="218" type="span" parent="103" relname="elaboration"/>
		<group id="219" type="span" parent="221" relname="elaboration"/>
		<group id="220" type="span" parent="222" relname="span"/>
		<group id="221" type="span" parent="220" relname="span"/>
		<group id="222" type="span" />
		<group id="223" type="span" parent="224" relname="contrast"/>
		<group id="224" type="multinuc" parent="226" relname="span"/>
		<group id="225" type="span" parent="238" relname="span"/>
		<group id="226" type="span" parent="235" relname="contrast"/>
		<group id="227" type="span" parent="236" relname="span"/>
		<group id="228" type="span" parent="229" relname="contrast"/>
		<group id="229" type="multinuc" parent="233" relname="span"/>
		<group id="230" type="span" parent="229" relname="contrast"/>
		<group id="231" type="multinuc" parent="233" relname="elaboration"/>
		<group id="232" type="span" parent="231" relname="contrast"/>
		<group id="233" type="span" parent="234" relname="span"/>
		<group id="234" type="span" parent="235" relname="contrast"/>
		<group id="235" type="multinuc" parent="227" relname="span"/>
		<group id="236" type="span" />
		<group id="237" type="span" parent="184" relname="joint"/>
		<group id="238" type="span" parent="224" relname="contrast"/>
	</body>
</rst>