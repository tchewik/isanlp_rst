<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://alexandr-rogers.livejournal.com/1161320.html</segment>
		<segment id="2" >12:38 pm: Картина маслом</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" >От «Советского Информбюро».</segment>
		<segment id="5" parent="66" relname="span">Люблю такие расклады.</segment>
		<segment id="6" parent="65" relname="joint">Когда все новости из разных точек приходят почти одновременно,</segment>
		<segment id="7" parent="65" relname="joint">и все отображают реальную ситуацию в каждой из точек.</segment>
		<segment id="8" parent="69" relname="attribution">Из США вещают Wall Street Journal:</segment>
		<segment id="9" parent="117" relname="span">«По состоянию на конец прошлого года отношение корпоративной задолженности к валовому внутреннему продукту США,</segment>
		<segment id="10" parent="9" relname="attribution">согласно данным Федеральной резервной системы, достигло 73,1%,</segment>
		<segment id="11" parent="67" relname="comparison">что немного ниже максимального показателя в 73,7%, установленного в 2009 году.</segment>
		<segment id="12" parent="68" relname="comparison">Между тем сумма американского корпоративного долга с кредитным рейтингом BBB – то есть самой низкой категории кредитов инвестиционного уровня – более чем удвоилась с момента прошлого кризиса».</segment>
		<segment id="13" parent="73" relname="attribution">Одновременно глава ФРС Джером Пауэлл заявляет,</segment>
		<segment id="14" parent="71" relname="joint">что «Федеральный резерв готов отреагировать на торговые войны, которые ведёт Трамп,</segment>
		<segment id="15" parent="71" relname="joint">и готов снижать базовую учётную ставку».</segment>
		<segment id="16" parent="72" relname="cause">Причём текущая ставка находится в диапазоне 2,25-2,5%,</segment>
		<segment id="17" parent="72" relname="span">поэтому манёвр</segment>
		<segment id="18" parent="17" relname="purpose">для снижения и стимулирования</segment>
		<segment id="19" parent="105" relname="evaluation">таким образом роста экономики существенно ограничен.</segment>
		<segment id="20" parent="106" relname="evaluation">Фактически Пауэлл констатирует наличие рецессии в США.</segment>
		<segment id="21" parent="109" relname="span">При этом примерно четверть американцев берут кредиты</segment>
		<segment id="22" parent="21" relname="purpose">для покупки еды.</segment>
		<segment id="23" parent="75" relname="joint">Не покупки домов,</segment>
		<segment id="24" parent="75" relname="joint">не приобретения автомобиля,</segment>
		<segment id="25" parent="75" relname="joint">не оплаты образования –</segment>
		<segment id="26" parent="108" relname="contrast">еды.</segment>
		<segment id="27" parent="76" relname="span">Это к вопросу, «как хорошо там,</segment>
		<segment id="28" parent="27" relname="condition">где нас нет».</segment>
		<segment id="29" parent="78" relname="span">И в это же время,</segment>
		<segment id="30" parent="77" relname="joint">когда Трамп вводит пошлины</segment>
		<segment id="31" parent="77" relname="joint">и ведёт торговые войны против Китая, ЕС и даже Мексики,</segment>
		<segment id="32" parent="79" relname="same-unit">в Петербурге проходит очередной международный экономический форум.</segment>
		<segment id="33" parent="82" relname="span">Где крупнейшие мировые корпорации</segment>
		<segment id="34" parent="81" relname="span">(я не преувеличиваю,</segment>
		<segment id="35" parent="34" relname="evidence">можете сами посмотреть список участников)</segment>
		<segment id="36" parent="83" relname="same-unit">выстраиваются в очередь,</segment>
		<segment id="37" parent="84" relname="joint">чтобы иметь возможность торговать</segment>
		<segment id="38" parent="84" relname="joint">и сотрудничать с «порванной и изолированной» Россией.</segment>
		<segment id="39" parent="88" relname="span">И одновременно с этим в Москве проходит встреча президента России Владимира Путина и главы Китая Си Цзиньпина</segment>
		<segment id="40" parent="39" relname="elaboration">(в визите принимает участие китайское правительство почти в полном составе).</segment>
		<segment id="41" parent="88" relname="elaboration">Восьмой визит председателя Си в Россию с момента вступления в должность и тридцатая его встреча с Путиным.</segment>
		<segment id="42" parent="89" relname="elaboration">На которой на самом высоком уровне подписали целый ряд важных стратегических соглашений.</segment>
		<segment id="43" parent="93" relname="span">Из ключевого:</segment>
		<segment id="44" parent="91" relname="joint">- Россия теперь будет поставлять в Китай сою (вместо США);</segment>
		<segment id="45" parent="91" relname="joint">- Россия теперь будет поставлять в Китай пшеницу (вместо США);</segment>
		<segment id="46" parent="91" relname="joint">- Россия будет поставлять в Китай больше СПГ (вместо США);</segment>
		<segment id="47" parent="92" relname="joint">- Россия уже начала поставлять в Китай молоко (список аккредитованных компаний увеличили до 33),</segment>
		<segment id="48" parent="92" relname="joint">готовятся поставлять сухое молоко и сыворотку;</segment>
		<segment id="49" parent="112" relname="contrast">- «Хуавэй» подписал договор с «МТС»</segment>
		<segment id="50" parent="112" relname="contrast">(тот самый «Хуавэй», которого США изо всех сил пытаются задавить);</segment>
		<segment id="51" parent="91" relname="joint">- «Алибаба» подписал договор с «Мейл.ру»;</segment>
		<segment id="52" parent="91" relname="joint">- русские будут строить ещё два блока на китайской АЭС;</segment>
		<segment id="53" parent="91" relname="joint">- ещё несколько совместных проектов, как в России, так и в Китае.</segment>
		<segment id="54" parent="55" relname="cause">Председатель Си назвал Путина «самым близким иностранным коллегой и самым лучшим другом».</segment>
		<segment id="55" parent="95" relname="span">Путин не остался в долгу.</segment>
		<segment id="56" parent="95" relname="evaluation">Я не помню, они уже пили на брудершафт?</segment>
		<segment id="57" parent="97" relname="contrast">Раньше считалось, что самый страшный сон англосаксов – это союз России и Германии.</segment>
		<segment id="58" parent="97" relname="contrast">Оказалось, что это союз России и Китая.</segment>
		<segment id="59" parent="98" relname="evaluation">Картина маслом.</segment>
		<segment id="60" parent="100" relname="span">P.S. В Хасанском районе «Яблоко», остатки «Открытой России» и прочие грантоеды из последних сил пытаются помешать строительству СПГ-терминала</segment>
		<segment id="61" parent="60" relname="purpose">для торговли с Китаем.</segment>
		<segment id="62" parent="100" relname="evaluation">Кому это выгодно, думаю, объяснять не надо.</segment>
		<segment id="63" parent="113" relname="contrast">И, конечно, нужно срочно, кровь из носу, пролетарскую революцию в России (со специально обученными на деньги Ходорковского нигде не работающими «профессиональными пролетариями» во главе).</segment>
		<segment id="64" parent="113" relname="contrast">Иначе гегемон долго не продержится!</segment>
		<group id="65" type="multinuc" parent="5" relname="elaboration"/>
		<group id="66" type="span" parent="70" relname="preparation"/>
		<group id="67" type="multinuc" parent="68" relname="comparison"/>
		<group id="68" type="multinuc" parent="69" relname="span"/>
		<group id="69" type="span" parent="70" relname="span"/>
		<group id="70" type="span" parent="107" relname="span"/>
		<group id="71" type="multinuc" parent="73" relname="span"/>
		<group id="72" type="span" parent="105" relname="span"/>
		<group id="73" type="span" parent="74" relname="span"/>
		<group id="74" type="span" parent="111" relname="joint"/>
		<group id="75" type="multinuc" parent="108" relname="contrast"/>
		<group id="76" type="span" parent="116" relname="evaluation"/>
		<group id="77" type="multinuc" parent="29" relname="background"/>
		<group id="78" type="span" parent="79" relname="same-unit"/>
		<group id="79" type="multinuc" parent="80" relname="span"/>
		<group id="80" type="span" parent="87" relname="span"/>
		<group id="81" type="span" parent="33" relname="evaluation"/>
		<group id="82" type="span" parent="83" relname="same-unit"/>
		<group id="83" type="multinuc" parent="85" relname="span"/>
		<group id="84" type="multinuc" parent="85" relname="purpose"/>
		<group id="85" type="span" parent="86" relname="span"/>
		<group id="86" type="span" parent="80" relname="elaboration"/>
		<group id="87" type="span" />
		<group id="88" type="span" parent="89" relname="span"/>
		<group id="89" type="span" parent="90" relname="span"/>
		<group id="90" type="span" parent="94" relname="span"/>
		<group id="91" type="multinuc" parent="43" relname="elaboration"/>
		<group id="92" type="multinuc" parent="91" relname="joint"/>
		<group id="93" type="span" parent="90" relname="elaboration"/>
		<group id="94" type="span" />
		<group id="95" type="span" parent="96" relname="span"/>
		<group id="96" type="span" parent="99" relname="solutionhood"/>
		<group id="97" type="multinuc" parent="98" relname="span"/>
		<group id="98" type="span" parent="99" relname="span"/>
		<group id="99" type="span" parent="114" relname="span"/>
		<group id="100" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="104" relname="contrast"/>
		<group id="104" type="multinuc" />
		<group id="105" type="span" parent="106" relname="span"/>
		<group id="106" type="span" parent="110" relname="span"/>
		<group id="107" type="span" />
		<group id="108" type="multinuc" parent="109" relname="elaboration"/>
		<group id="109" type="span" parent="116" relname="span"/>
		<group id="110" type="span" parent="111" relname="joint"/>
		<group id="111" type="multinuc" />
		<group id="112" type="multinuc" parent="91" relname="joint"/>
		<group id="113" type="multinuc" parent="104" relname="contrast"/>
		<group id="114" type="span" />
		<group id="115" type="span" parent="111" relname="joint"/>
		<group id="116" type="span" parent="115" relname="span"/>
		<group id="117" type="span" parent="67" relname="comparison"/>
	</body>
</rst>