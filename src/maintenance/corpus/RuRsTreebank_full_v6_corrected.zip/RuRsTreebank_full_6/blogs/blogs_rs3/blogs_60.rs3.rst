<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://fritzmorgen.livejournal.com/1588453.html#cutid1</segment>
		<segment id="2" >Бесплатные квартиры, печь-зеркало и токсичное наследство СССР</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="65" relname="preparation">1. В фермерском хозяйстве в Новосибирской области работникам выдают бесплатные квартиры, уже прямо с мебелью и бытовой техникой.</segment>
		<segment id="5" parent="62" relname="joint">Желающие могут или выкупить их по себестоимости,</segment>
		<segment id="6" parent="62" relname="joint">или проработать на предприятии 20 лет,</segment>
		<segment id="7" parent="109" relname="span">чтобы получить квартиры в собственность</segment>
		<segment id="8" parent="7" relname="condition">без какой-либо оплаты:</segment>
		<segment id="9" parent="64" relname="attribution">https://news.ngs.ru/articles/66093778/</segment>
		<segment id="10" parent="75" relname="span">Квартиры раздают явно не от хорошей жизни.</segment>
		<segment id="11" parent="67" relname="joint">Специалистов мало,</segment>
		<segment id="12" parent="67" relname="joint">текучка большая.</segment>
		<segment id="13" parent="103" relname="joint">Кадров не хватает:</segment>
		<segment id="14" parent="103" relname="joint">работа нелёгкая.</segment>
		<segment id="15" parent="16" relname="cause">Нельзя, например, спокойно покурить в течение рабочего дня,</segment>
		<segment id="16" parent="68" relname="span">собьётся график.</segment>
		<segment id="17" parent="69" relname="span">С выпивкой тоже сложно:</segment>
		<segment id="18" parent="17" relname="elaboration">на проходной стоят алкотестеры.</segment>
		<segment id="19" parent="20" relname="cause">Четыре раза попался нетрезвым</segment>
		<segment id="20" parent="70" relname="span">— увольнение.</segment>
		<segment id="21" parent="71" relname="span">Бесплатных квартир и зарплаты в 30-70 тысяч рублей недостаточно,</segment>
		<segment id="22" parent="21" relname="purpose">чтобы компенсировать неудобства.</segment>
		<segment id="23" parent="77" relname="span">2. Всё как в фильмах.</segment>
		<segment id="24" parent="76" relname="contrast">СССР погиб,</segment>
		<segment id="25" parent="111" relname="same-unit">но,</segment>
		<segment id="26" parent="27" relname="condition">погибая,</segment>
		<segment id="27" parent="110" relname="span">успел нанести серьёзную рану напавшему на него врагу.</segment>
		<segment id="28" parent="78" relname="span">Беда пришла в США с неожиданной стороны</segment>
		<segment id="29" parent="28" relname="elaboration">— в стране всё громче и громче звучат голоса социалистов.</segment>
		<segment id="30" parent="80" relname="span">Шансы на успех коммунистической революции в Соединённых Штатах растут с каждым месяцем:</segment>
		<segment id="31" parent="30" relname="attribution">https://www.thenation.com/article/socialism-is-more-popular-than-donald-trump/</segment>
		<segment id="32" parent="33" relname="attribution">Уже 43% американцев полагают,</segment>
		<segment id="33" parent="114" relname="span">что «социализм будет хорошей штукой для страны».</segment>
		<segment id="34" parent="81" relname="span">Социалистические идеи особенно популярны среди женщин, среди «небелых» и среди молодых американцев.</segment>
		<segment id="35" parent="36" relname="attribution">Наивные, не знающие истории жители США полагают,</segment>
		<segment id="36" parent="116" relname="span">что после революции высший класс будет ограблен в пользу бедноты и среднего класса.</segment>
		<segment id="37" parent="84" relname="span">Опыт других стран показывает, что получится иначе:</segment>
		<segment id="38" parent="108" relname="span">высший класс останется «на коне»,</segment>
		<segment id="39" parent="38" relname="condition">просто поменяв свой состав,</segment>
		<segment id="40" parent="83" relname="joint">беднота станет ещё беднее,</segment>
		<segment id="41" parent="83" relname="joint">а средний класс, — традиционная жертва революций, — будет уничтожен почти под корень.</segment>
		<segment id="42" parent="88" relname="span">3. Железный век начался,</segment>
		<segment id="43" parent="86" relname="span">когда люди научились получать в печах достаточно высокую</segment>
		<segment id="44" parent="43" relname="purpose">для выплавки железа</segment>
		<segment id="45" parent="87" relname="same-unit">температуру.</segment>
		<segment id="46" parent="89" relname="comparison">Так-то бронза лучше железа,</segment>
		<segment id="47" parent="89" relname="comparison">однако железная руда встречается значительно чаще,</segment>
		<segment id="48" parent="107" relname="span">и потому железные орудия получались значительно дешевле.</segment>
		<segment id="49" parent="113" relname="evaluation">Интересно, что</segment>
		<segment id="50" parent="112" relname="span">очень высокую температуру</segment>
		<segment id="51" parent="50" relname="purpose">(достаточную даже для выплавки титана)</segment>
		<segment id="52" parent="93" relname="same-unit">человечество могло бы получить ещё в античности,</segment>
		<segment id="53" parent="95" relname="span">организовав так называемую солнечную печь</segment>
		<segment id="54" parent="94" relname="joint">— соорудив кучу зеркал</segment>
		<segment id="55" parent="94" relname="joint">и направив с их помочью лучи от Солнца в одну точку:</segment>
		<segment id="56" parent="97" relname="attribution">https://ru.wikipedia.org/wiki/Одейлийская_солнечная_печь</segment>
		<segment id="57" parent="99" relname="sequence">Солнечные лучи улавливаются первым набором из 9600 перенацеливаемых зеркал, расположенных на склоне,</segment>
		<segment id="58" parent="99" relname="sequence">а затем направляются на вторую серию зеркал («концентраторы»), которые расположены в параболе.</segment>
		<segment id="59" parent="100" relname="restatement">Они сходятся в направлении кольцевой мишени на вершине центральной башни, которая имеет всего 40 см в диаметре.</segment>
		<segment id="60" parent="100" relname="restatement">Это эквивалентно концентрации энергии «10 000 солнц».</segment>
		<segment id="61" parent="102" relname="span">Температура свыше 3500° C может быть получена в течение нескольких секунд…</segment>
		<group id="62" type="multinuc" parent="63" relname="span"/>
		<group id="63" type="span" parent="64" relname="span"/>
		<group id="64" type="span" parent="65" relname="span"/>
		<group id="65" type="span" parent="66" relname="span"/>
		<group id="66" type="span" />
		<group id="67" type="multinuc" parent="73" relname="span"/>
		<group id="68" type="span" parent="72" relname="joint"/>
		<group id="69" type="span" parent="72" relname="joint"/>
		<group id="70" type="span" parent="72" relname="joint"/>
		<group id="71" type="span" parent="72" relname="joint"/>
		<group id="72" type="multinuc" parent="104" relname="elaboration"/>
		<group id="73" type="span" parent="104" relname="span"/>
		<group id="74" type="span" parent="10" relname="elaboration"/>
		<group id="75" type="span" />
		<group id="76" type="multinuc" parent="23" relname="background"/>
		<group id="77" type="span" parent="79" relname="preparation"/>
		<group id="78" type="span" parent="79" relname="span"/>
		<group id="79" type="span" parent="105" relname="span"/>
		<group id="80" type="span" parent="78" relname="elaboration"/>
		<group id="81" type="span" parent="114" relname="evidence"/>
		<group id="83" type="multinuc" parent="106" relname="contrast"/>
		<group id="84" type="span" parent="85" relname="contrast"/>
		<group id="85" type="multinuc" />
		<group id="86" type="span" parent="87" relname="same-unit"/>
		<group id="87" type="multinuc" parent="42" relname="condition"/>
		<group id="88" type="span" parent="91" relname="span"/>
		<group id="89" type="multinuc" parent="90" relname="span"/>
		<group id="90" type="span" parent="48" relname="cause"/>
		<group id="91" type="span" />
		<group id="93" type="multinuc" parent="113" relname="span"/>
		<group id="94" type="multinuc" parent="53" relname="elaboration"/>
		<group id="95" type="span" parent="96" relname="condition"/>
		<group id="96" type="span" parent="97" relname="span"/>
		<group id="97" type="span" parent="98" relname="span"/>
		<group id="98" type="span" />
		<group id="99" type="multinuc" parent="101" relname="sequence"/>
		<group id="100" type="multinuc" parent="101" relname="sequence"/>
		<group id="101" type="multinuc" parent="61" relname="cause"/>
		<group id="102" type="span" />
		<group id="103" type="multinuc" parent="73" relname="elaboration"/>
		<group id="104" type="span" parent="74" relname="span"/>
		<group id="105" type="span" />
		<group id="106" type="multinuc" parent="37" relname="elaboration"/>
		<group id="107" type="span" parent="88" relname="elaboration"/>
		<group id="108" type="span" parent="106" relname="contrast"/>
		<group id="109" type="span" parent="63" relname="purpose"/>
		<group id="110" type="span" parent="111" relname="same-unit"/>
		<group id="111" type="multinuc" parent="76" relname="contrast"/>
		<group id="112" type="span" parent="93" relname="same-unit"/>
		<group id="113" type="span" parent="96" relname="span"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="85" relname="contrast"/>
		<group id="116" type="span" parent="34" relname="evaluation"/>
	</body>
</rst>