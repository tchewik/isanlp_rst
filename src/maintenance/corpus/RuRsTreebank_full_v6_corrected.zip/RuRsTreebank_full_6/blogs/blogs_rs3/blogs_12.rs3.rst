<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://modernafrodite.kosmetista.ru/blog/93853.html</segment>
		<segment id="2" >И снова о голландской косметике. Увлажнение лица с Bee Honest</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="175" relname="preparation">Привет всем!</segment>
		<segment id="5" parent="92" relname="joint">Продолжаю знакомиться</segment>
		<segment id="6" parent="92" relname="joint">и знакомить вас с голландской косметикой.</segment>
		<segment id="7" parent="95" relname="span">Сегодня в обзоре троица de Traay с маслом дикой розы</segment>
		<segment id="8" parent="93" relname="span">Я уже писала о муссе</segment>
		<segment id="9" parent="8" relname="purpose">для умывания</segment>
		<segment id="10" parent="94" relname="same-unit">и молочке,</segment>
		<segment id="11" parent="162" relname="sequence">теперь настал черёд скраба и кремов.</segment>
		<segment id="12" parent="97" relname="span">Упаковка у всех трёх стредств идентичная: пластиковые тюбики с откидывающейся крышкой.</segment>
		<segment id="13" parent="14" relname="cause">Пласик мягкий,</segment>
		<segment id="14" parent="98" relname="span">выдавливать средства очень легко.</segment>
		<segment id="15" parent="16" relname="cause">Моя кожа нормальная, беспроблемная,</segment>
		<segment id="16" parent="99" relname="span">поэтому от этих уходовых средств ждала обещаного производителем увлажнения.</segment>
		<segment id="17" parent="101" relname="joint">Дневной крем для лица Bee Honest de Traay Dag Creme Rozen voor een droge huid/Crème de Jour Rose pour une peau sèche призван увлажнить</segment>
		<segment id="18" parent="172" relname="span">и защитить сухую кожу</segment>
		<segment id="19" parent="18" relname="cause">благодаря входящим в состав пчелиному воску, маслу ши, маслу сладкого миндаля, ослинника и дикой розы.</segment>
		<segment id="20" parent="102" relname="elaboration">И снова о голландской косметике. Увлажнение лица с Bee Honest IMG</segment>
		<segment id="21" parent="22" relname="cause">Сам крем очень плотный по текстуре,</segment>
		<segment id="22" parent="105" relname="span">поэтому так просто размазать его по лицу не получится.</segment>
		<segment id="23" parent="106" relname="sequence">Поэтому я выдавливаю нужное количество крема,</segment>
		<segment id="24" parent="106" relname="sequence">наношу точечно на разные участки лица,</segment>
		<segment id="25" parent="106" relname="sequence">а потом вбиваю щёточкой Collistar массажной насадкой.</segment>
		<segment id="26" parent="107" relname="joint">Таким образом крем впитывается гораздо лучше,</segment>
		<segment id="27" parent="107" relname="joint">плюс происходит лёгкий массаж лица)</segment>
		<segment id="28" parent="110" relname="joint">Моя кожа получает от крема необходимое увлажнение,</segment>
		<segment id="29" parent="110" relname="joint">становится гладкой на ощупь.</segment>
		<segment id="30" parent="111" relname="span">Впитывается крем,</segment>
		<segment id="31" parent="30" relname="concession">несмотря на свою текстуру,</segment>
		<segment id="32" parent="112" relname="same-unit">довольно быстро:</segment>
		<segment id="33" parent="113" relname="elaboration">после двух минут массажа я уже могу наносить макияж.</segment>
		<segment id="34" parent="35" relname="cause">Тональный, пудра, тени, румяна ложаться на него отлично,</segment>
		<segment id="35" parent="115" relname="span">так что конфликта с декоративной косметикой нет.</segment>
		<segment id="36" parent="118" relname="elaboration">IMG</segment>
		<segment id="37" parent="119" relname="elaboration">Состав: aqua, prunus amygdalus dulcis oil, centaurea cyanus flower water*, alcohol*, glycerin, polyglyceryl-3 polyricinoleate, oenothera biennis oil*, rosa canina fruit oil*, cera alba, hydrogenated vegetable oil, butyrospermum parkii butter*, magnesium sulfate, tocopheryl acetate, polyglyceryl-3 ricinoleate, dehydroacetic acid, helianthus annuus seed oil, glycine soja oil, calendula officinalis flower extract*, rosmarinus officinalis leaf extract*, parfum**, citric acid, benzyl alcohol, citronellol, geraniol, linalool, benzyl salicylate, citral</segment>
		<segment id="38" parent="120" relname="span">Ночной крем для лица Bee Honest de Traay Nacht Creme Rozen voor een droge huid /Crème de Noit Rose pour une peau sèche</segment>
		<segment id="39" parent="38" relname="elaboration">IMG</segment>
		<segment id="40" parent="121" relname="span">Ночной крем, как и дневной, обязан делать то же самое с моей кожей, но только ночью.</segment>
		<segment id="41" parent="126" relname="span">По характеристикам он точно такой же, как и дневной.</segment>
		<segment id="42" parent="122" relname="joint">Такой же плотный,</segment>
		<segment id="43" parent="122" relname="joint">точно так же я его наношу</segment>
		<segment id="44" parent="122" relname="joint">и эффект от него аналогичный.</segment>
		<segment id="45" parent="123" relname="joint">Хорошо увлажняет</segment>
		<segment id="46" parent="123" relname="joint">и разглаживает кожу,</segment>
		<segment id="47" parent="123" relname="joint">питает немного.</segment>
		<segment id="48" parent="49" relname="cause">Честно говоря, я не увидела никакой разницы между дневным и ночным,</segment>
		<segment id="49" parent="177" relname="span">поэтому иногда меняю их местами.</segment>
		<segment id="50" parent="177" relname="elaboration">На ночной крем макияж ложится так же хорошо.</segment>
		<segment id="51" parent="129" relname="elaboration">IMG</segment>
		<segment id="52" parent="165" relname="elaboration">Состав: aqua, centaurea cyanus flower water*, prunus amygdalus dulcis oil, butyrospermum parkii butter*, alcohol*, glycerin, polyglyceryl-3 polyricinoleate, ceraalba, oenothera biennis oil*, rosa canina fruit oil, magnesium sulfate, tocopheryl acetate, calendula officinalis flower extract*, polyglyceryl-3 ricinoleate, dehydroacetic acid, helianthus annuus seed oil*, glycine soja oil, rosmarinus officinalis leaf extract*, citric aic, parfum**, benzyl alcohol, citronellol, geraniol, linalool, benzyl salicylate, citral, limonene.</segment>
		<segment id="53" parent="131" relname="preparation">Оба крема я использую и для кожи век.</segment>
		<segment id="54" parent="131" relname="span">Наношу как на верхние, так и на нижние.</segment>
		<segment id="55" parent="130" relname="contrast">В этой зоне уже массажером не пользуюсь,</segment>
		<segment id="56" parent="130" relname="contrast">а вбиваю легонько подушечками пальцев.</segment>
		<segment id="57" parent="58" relname="cause">Отёков и аллергических реакций крем не вызвал,</segment>
		<segment id="58" parent="133" relname="span">поэтому я продолжаю смело наносить кремы под глаза.</segment>
		<segment id="59" parent="134" relname="evaluation">Они отлично увлажняют кожу и в области вокруг глаз.</segment>
		<segment id="60" parent="136" relname="span">Скраб для лица Bee Honest de Traay Gezichts scrub Rozen voor alle huidtypes/Exfoliant visage Rose pour tous types de peau</segment>
		<segment id="61" parent="60" relname="elaboration">IMG</segment>
		<segment id="62" parent="137" relname="span">Механическими скрабами я редко пользуюсь:</segment>
		<segment id="63" parent="62" relname="elaboration">предпочитаю всё же энзимные пилинги.</segment>
		<segment id="64" parent="139" relname="contrast">Но этот взяла «за компанию», просто попробовать.</segment>
		<segment id="65" parent="66" relname="cause">Моя кожа не чувствительная</segment>
		<segment id="66" parent="140" relname="span">и даже знаменитую Чистую Линию с абрикосовыми косточками переносит легко.</segment>
		<segment id="67" parent="142" relname="contrast">В состав этого скраба входят также входят молотые абрикосовые косточки,</segment>
		<segment id="68" parent="69" relname="cause">но они очень мелкие,</segment>
		<segment id="69" parent="141" relname="span">поэтому кожу не травмируют.</segment>
		<segment id="70" parent="147" relname="joint">Скраб хорошо полирует кожу,</segment>
		<segment id="71" parent="147" relname="joint">выравнивает поверхность.</segment>
		<segment id="72" parent="148" relname="sequence">После того, как я его смываю,</segment>
		<segment id="73" parent="148" relname="sequence">кожа остаётся напитанной маслами</segment>
		<segment id="74" parent="149" relname="span">— никакой сухости или стянутости после использования нет.</segment>
		<segment id="75" parent="150" relname="joint">Использую скраб по настроению 1-2 раза в неделю.</segment>
		<segment id="76" parent="151" relname="elaboration">IMG</segment>
		<segment id="77" parent="152" relname="elaboration">Состав: aqua, centaurea cyanus flower water*, prunus amygdalus dulcis oil, prunus armeniaca seed powder*, glycerin, oenothera biennis oil*, rosa canina fruit oil, cera alba, cetearyl alcohol, cetearyl glucoside, glycerylstearate, palmitic acid, stearic acid, xanthan gum, dehydroacetic acid, helianthus annuus seed oil*, rosmarinus officinalis leaf extract*, parfum**, benzyl alcohol, citronellol, geraniol, linalool, benzyl salicylate. *органического происхождения **натурального происхождения</segment>
		<segment id="78" parent="155" relname="preparation">Общие впечатления:</segment>
		<segment id="79" parent="153" relname="joint">эти продукты не сделают чудес с вашей кожей,</segment>
		<segment id="80" parent="153" relname="joint">не омолодят на 10 лет,</segment>
		<segment id="81" parent="154" relname="contrast">но обеспечат хороший недорогой, но эффективный базовый уход.</segment>
		<segment id="82" parent="159" relname="joint">Мне нравится их упаковка, текстура, эффект.</segment>
		<segment id="83" parent="158" relname="span">Ещё один большой плюс — органические составы,</segment>
		<segment id="84" parent="157" relname="joint">нет синтетических отдушек и красителей,</segment>
		<segment id="85" parent="157" relname="joint">косметика не тестируется на животных</segment>
		<segment id="86" parent="157" relname="joint">и имеет сертификат BDIH.</segment>
		<segment id="87" parent="159" relname="joint">Ну и цена, конечно.</segment>
		<segment id="88" parent="161" relname="joint">Объём: 50 мл</segment>
		<segment id="89" parent="161" relname="joint">Цена: 8 евpо</segment>
		<segment id="90" parent="161" relname="joint">Срок тестирования: 3 месяца</segment>
		<segment id="91" parent="169" relname="evaluation">Оценка: 5</segment>
		<group id="92" type="multinuc" parent="175" relname="span"/>
		<group id="93" type="span" parent="94" relname="same-unit"/>
		<group id="94" type="multinuc" parent="162" relname="sequence"/>
		<group id="95" type="span" parent="96" relname="span"/>
		<group id="96" type="span" parent="100" relname="span"/>
		<group id="97" type="span" parent="96" relname="elaboration"/>
		<group id="98" type="span" parent="12" relname="elaboration"/>
		<group id="99" type="span" parent="103" relname="preparation"/>
		<group id="100" type="span" />
		<group id="101" type="multinuc" parent="102" relname="span"/>
		<group id="102" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" />
		<group id="105" type="span" parent="109" relname="cause"/>
		<group id="106" type="multinuc" parent="108" relname="cause"/>
		<group id="107" type="multinuc" parent="108" relname="span"/>
		<group id="108" type="span" parent="109" relname="span"/>
		<group id="109" type="span" parent="163" relname="span"/>
		<group id="110" type="multinuc" parent="117" relname="joint"/>
		<group id="111" type="span" parent="112" relname="same-unit"/>
		<group id="112" type="multinuc" parent="113" relname="span"/>
		<group id="113" type="span" parent="114" relname="span"/>
		<group id="114" type="span" parent="116" relname="span"/>
		<group id="115" type="span" parent="114" relname="elaboration"/>
		<group id="116" type="span" parent="117" relname="joint"/>
		<group id="117" type="multinuc" parent="118" relname="span"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" parent="167" relname="span"/>
		<group id="120" type="span" parent="40" relname="preparation"/>
		<group id="121" type="span" parent="125" relname="joint"/>
		<group id="122" type="multinuc" parent="124" relname="joint"/>
		<group id="123" type="multinuc" parent="124" relname="joint"/>
		<group id="124" type="multinuc" parent="41" relname="elaboration"/>
		<group id="125" type="multinuc" parent="128" relname="span"/>
		<group id="126" type="span" parent="125" relname="joint"/>
		<group id="128" type="span" parent="129" relname="span"/>
		<group id="129" type="span" parent="165" relname="span"/>
		<group id="130" type="multinuc" parent="54" relname="elaboration"/>
		<group id="131" type="span" parent="132" relname="span"/>
		<group id="132" type="span" parent="134" relname="span"/>
		<group id="133" type="span" parent="132" relname="elaboration"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" />
		<group id="136" type="span" parent="137" relname="preparation"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="139" relname="contrast"/>
		<group id="139" type="multinuc" parent="145" relname="span"/>
		<group id="140" type="span" parent="173" relname="joint"/>
		<group id="141" type="span" parent="142" relname="contrast"/>
		<group id="142" type="multinuc" parent="173" relname="joint"/>
		<group id="145" type="span" parent="146" relname="span"/>
		<group id="146" type="span" />
		<group id="147" type="multinuc" parent="150" relname="joint"/>
		<group id="148" type="multinuc" parent="74" relname="cause"/>
		<group id="149" type="span" parent="150" relname="joint"/>
		<group id="150" type="multinuc" parent="151" relname="span"/>
		<group id="151" type="span" parent="152" relname="span"/>
		<group id="152" type="span" parent="168" relname="span"/>
		<group id="153" type="multinuc" parent="154" relname="contrast"/>
		<group id="154" type="multinuc" parent="155" relname="span"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="160" relname="span"/>
		<group id="157" type="multinuc" parent="83" relname="elaboration"/>
		<group id="158" type="span" parent="159" relname="joint"/>
		<group id="159" type="multinuc" parent="156" relname="evaluation"/>
		<group id="160" type="span" parent="171" relname="span"/>
		<group id="161" type="multinuc" parent="169" relname="span"/>
		<group id="162" type="multinuc" parent="7" relname="elaboration"/>
		<group id="163" type="span" />
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" />
		<group id="167" type="span" />
		<group id="168" type="span" />
		<group id="169" type="span" parent="170" relname="span"/>
		<group id="170" type="span" parent="160" relname="elaboration"/>
		<group id="171" type="span" />
		<group id="172" type="span" parent="101" relname="joint"/>
		<group id="173" type="multinuc" parent="145" relname="elaboration"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" parent="95" relname="preparation"/>
		<group id="177" type="span" parent="178" relname="span"/>
		<group id="178" type="span" parent="128" relname="evaluation"/>
	</body>
</rst>