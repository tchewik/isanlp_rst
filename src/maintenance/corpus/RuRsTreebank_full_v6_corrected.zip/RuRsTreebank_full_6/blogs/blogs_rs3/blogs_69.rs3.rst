<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://dpmmax.livejournal.com/851297.html</segment>
		<segment id="2" >Хорошо забытое старое?</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="194" relname="comparison">Что касается лекарств, коими пользуют пациентов психиатрических клиник, в их разработке заметно некоторое затишье,</segment>
		<segment id="5" parent="194" relname="comparison">если сравнивать с второй половиной прошлого века.</segment>
		<segment id="6" parent="110" relname="sequence">Тогда, особенно после открытия аминазина, первого в череде нейролептиков, и ипрониазида, первого среди антидепрессантов,</segment>
		<segment id="7" parent="195" relname="span">события помчались галопом:</segment>
		<segment id="8" parent="111" relname="joint">делали всё новые и новые,</segment>
		<segment id="9" parent="111" relname="joint">применяли,</segment>
		<segment id="10" parent="111" relname="joint">копили опыт,</segment>
		<segment id="11" parent="111" relname="joint">боролись с появившимися побочными эффектами.</segment>
		<segment id="12" parent="112" relname="span">Но главное было сделано:</segment>
		<segment id="13" parent="12" relname="elaboration">психически больные пациенты перестали быть постоянными обитателями психиатрических клиник.</segment>
		<segment id="14" parent="114" relname="span">Дальше — больше:</segment>
		<segment id="15" parent="113" relname="span">стало много внимания уделяться тому,</segment>
		<segment id="16" parent="15" relname="purpose">чтобы лечение переносилось как можно легче и незаметнее.</segment>
		<segment id="17" parent="117" relname="span">Потому и на смену старым нейролептикам и антидепрессантам пришли их новые поколения.</segment>
		<segment id="18" parent="119" relname="contrast">А потом всё понемногу затихло.</segment>
		<segment id="19" parent="118" relname="joint">Нет, выпуск лекарств не прекратился,</segment>
		<segment id="20" parent="118" relname="joint">да и в разработке тоже кое-что имеется.</segment>
		<segment id="21" parent="120" relname="evaluation">Просто нет той ретивости.</segment>
		<segment id="22" parent="122" relname="span">Отчасти это объясняется тем, что фармкомпаниям не очень-то и выгодно разрабатывать препараты для тех, кто (в массе своей, конечно) не будет в состоянии за них платить</segment>
		<segment id="23" parent="122" relname="cause">— ведь психиатрия всегда была дотационной отраслью медицины.</segment>
		<segment id="24" parent="124" relname="joint">Ну ладно ещё антидепрессанты — их покупают охотнее,</segment>
		<segment id="25" parent="124" relname="joint">да и социальный срез побогаче в целом будет.</segment>
		<segment id="26" parent="125" relname="comparison">А вот с нейролептиками сложнее.</segment>
		<segment id="27" parent="127" relname="span">Другая причина — сейчас учёные, фармакологи и медики приблизились к порогу своих знаний о нейромедиаторах и того, как на них действуют эти группы лекарств.</segment>
		<segment id="28" parent="198" relname="span">Надо учить матчасть дальше,</segment>
		<segment id="29" parent="28" relname="purpose">а там и новые идеи появятся.</segment>
		<segment id="30" parent="130" relname="span">Одновременно, как маркер дефицита идей, начались опыты с применением преданных было анафеме грибочков, травок и марок.</segment>
		<segment id="31" parent="129" relname="contrast">Даже появился термин «микродозинг»,</segment>
		<segment id="32" parent="129" relname="contrast">но о нём как-нибудь в другой раз, при случае.</segment>
		<segment id="33" parent="131" relname="contrast">Сейчас же несколько слов об ещё одном незаслуженно забытом направлении в лечении психических болезней. О противовоспалительном.</segment>
		<segment id="34" parent="133" relname="preparation">Дело в том, что в механизме развития и шизофрении, и деменции, и даже депрессивного эпизода имеет место воспалительный процесс.</segment>
		<segment id="35" parent="36" relname="cause">Поскольку генетика генетикой,</segment>
		<segment id="36" parent="208" relname="span">сбой в основе — это само собой,</segment>
		<segment id="37" parent="132" relname="contrast">но что дальше?</segment>
		<segment id="38" parent="137" relname="span">А дальше — в нервной ткани, в тех её областях,</segment>
		<segment id="39" parent="38" relname="cause">где или генетически, или по внешним причинам возникает дефект,</segment>
		<segment id="40" parent="136" relname="restatement">развивается воспаление. По типу аутоиммунного</segment>
		<segment id="41" parent="135" relname="span">— то есть, когда мишенью для нашей сторожевой иммунной системы становятся собственные же ткани,</segment>
		<segment id="42" parent="41" relname="cause">из-за того, что как-то неправильно они для этой самой системы распознаются.</segment>
		<segment id="43" parent="139" relname="sequence">И, соответственно, определяются, как нечто чуждое и мастдай.</segment>
		<segment id="44" parent="141" relname="span">И вот это-то воспаление часто и даёт в итоге повреждение нервных клеток, со всеми вытекающими.</segment>
		<segment id="45" parent="46" relname="solutionhood">Почему хорошо забытое старое?</segment>
		<segment id="46" parent="200" relname="span">Помните, я писал про сульфозин и заражение малярией, как про экстремальные и ушедшие в историю методы лечения?</segment>
		<segment id="47" parent="143" relname="joint">А ведь при всей жести этих методик,</segment>
		<segment id="48" parent="142" relname="span">при всех незабываемых ощущениях</segment>
		<segment id="49" parent="48" relname="condition">в ходе их применения,</segment>
		<segment id="50" parent="144" relname="span">результат-то был — там, где они применялись по месту.</segment>
		<segment id="51" parent="150" relname="solutionhood">В чём же была фишка?</segment>
		<segment id="52" parent="150" relname="span">Да в том, что организму предлагали побороться с чем-то более серьёзным и всеобъемлющим, нежели какое то локальное и аутоиммунное воспаление.</segment>
		<segment id="53" parent="146" relname="comparison">Там — плазмодия малярийного надо давить.</segment>
		<segment id="54" parent="146" relname="comparison">Тут — с введённой в мышцу серой на персиковом масле что-то делать.</segment>
		<segment id="55" parent="147" relname="sequence">Вот и подстраивалась вся система под новое воспаление.</segment>
		<segment id="56" parent="147" relname="sequence">А потом с ним же успешно справлялась.</segment>
		<segment id="57" parent="202" relname="elaboration">А под шумок — давила те самые маленькие, но такие заметные для психики очажки.</segment>
		<segment id="58" parent="223" relname="attribution">А не так давно стали появляться работы,</segment>
		<segment id="59" parent="222" relname="joint">в которых всё чаще и чаще упоминается воспалительный процесс в нервной ткани,</segment>
		<segment id="60" parent="222" relname="joint">а также говорится о необходимости что-то с ним делать.</segment>
		<segment id="61" parent="217" relname="contrast">Но как?</segment>
		<segment id="62" parent="155" relname="contrast">Противовоспалительные средства гормонального ряда сами по себе дают немало осложнений,</segment>
		<segment id="63" parent="155" relname="contrast">а ведь применять планируется длительно.</segment>
		<segment id="64" parent="156" relname="evidence">Средства вроде аспирина и парацетамола тоже, знаете ли, не бесследно в организме исчезают.</segment>
		<segment id="65" parent="158" relname="span">В итоге внимание сейчас сосредоточено на двух направлениях.</segment>
		<segment id="66" parent="159" relname="contrast">На самом деле, ищут и дальше,</segment>
		<segment id="67" parent="159" relname="contrast">но по этим двум прохаживаются конкретно.</segment>
		<segment id="68" parent="163" relname="span">Первое — это вещества, тормозящие действие</segment>
		<segment id="69" parent="68" relname="elaboration">(чувствительным к биохимическим загибам заткнуть уши и закрыть глаза)</segment>
		<segment id="70" parent="164" relname="same-unit">циклооксигеназы-2.</segment>
		<segment id="71" parent="204" relname="restatement">Такие, к примеру, как целеоксиб</segment>
		<segment id="72" parent="204" relname="restatement">(мы его знаем больше, как целебрекс)</segment>
		<segment id="73" parent="165" relname="same-unit">и парекоксиб.</segment>
		<segment id="74" parent="168" relname="span">Оба не дают образовываться особым веществам, участвующим в процессе воспаления — таким, например, как простагландины.</segment>
		<segment id="75" parent="169" relname="span">И потому хорошо знакомы как тем, кто лечит свой ревматоидный артрит, так и людям, страдающим от острых болей.</segment>
		<segment id="76" parent="174" relname="span">Данные пока набираются противоречивые.</segment>
		<segment id="77" parent="218" relname="condition">При той же болезни Альцгеймера</segment>
		<segment id="78" parent="79" relname="attribution">одни исследователи утверждают,</segment>
		<segment id="79" parent="218" relname="span">будто никакого действия на глубину деменции целебрекс не оказывает,</segment>
		<segment id="80" parent="220" relname="attribution">а другие возражают:</segment>
		<segment id="81" parent="171" relname="same-unit">мол, зато</segment>
		<segment id="82" parent="83" relname="cause">после применения</segment>
		<segment id="83" parent="205" relname="span">замедляется дальнейший прогресс болезни,</segment>
		<segment id="84" parent="172" relname="joint">слабоумие перестаёт нарастать такими быстрыми темпами.</segment>
		<segment id="85" parent="175" relname="span">Работы с применением парекоксиба</segment>
		<segment id="86" parent="85" relname="condition">при шизофрении</segment>
		<segment id="87" parent="209" relname="span">пока ведутся</segment>
		<segment id="88" parent="87" relname="condition">в лабораторных условиях и на крысах</segment>
		<segment id="89" parent="177" relname="elaboration">(не спрашивайте меня про параллели и экстраполяцию),</segment>
		<segment id="90" parent="179" relname="cause">но результатами учёные впечатлились,</segment>
		<segment id="91" parent="179" relname="span">так что ждём,</segment>
		<segment id="92" parent="91" relname="condition">когда переключатся на людей.</segment>
		<segment id="93" parent="186" relname="preparation">Второе направление — это N-ацетилцистеин.</segment>
		<segment id="94" parent="185" relname="joint">Есть такая аминокислота,</segment>
		<segment id="95" parent="184" relname="span">и применяется она в основном для других целей</segment>
		<segment id="96" parent="183" relname="span">— для облегчения разжижения и отхождения мокроты</segment>
		<segment id="97" parent="96" relname="condition">при бронхитах,</segment>
		<segment id="98" parent="210" relname="same-unit">ну и как антиоксидант тоже.</segment>
		<segment id="99" parent="191" relname="span">Вот как раз это самое антиоксидантное действие и заинтересовало учёных.</segment>
		<segment id="100" parent="212" relname="same-unit">Дело в том, что так называемый окислительный стресс,</segment>
		<segment id="101" parent="102" relname="condition">наряду с воспалением,</segment>
		<segment id="102" parent="211" relname="span">замедляет выработку белков, стимулирующих рост нервной ткани (нейротрофинов),</segment>
		<segment id="103" parent="206" relname="restatement">тормозит выработку энергии в клеточных энергетических станциях</segment>
		<segment id="104" parent="206" relname="restatement">(их называют митохондриями),</segment>
		<segment id="105" parent="189" relname="joint">да и в процессе гибели нервных клеток тоже напрямую задействован.</segment>
		<segment id="106" parent="192" relname="span">А тут — вещество, которое повышает в организме уровень главного антиоксиданта — глутатиона.</segment>
		<segment id="107" parent="190" relname="joint">В общем, к его применению в психиатрии сейчас тоже внимательно приглядываются</segment>
		<segment id="108" parent="190" relname="joint">и примеряются.</segment>
		<segment id="109" parent="188" relname="evaluation">Так что не нейролептиками едиными и не только антидепрессантами...</segment>
		<group id="110" type="multinuc" parent="196" relname="span"/>
		<group id="111" type="multinuc" parent="7" relname="elaboration"/>
		<group id="112" type="span" parent="115" relname="sequence"/>
		<group id="113" type="span" parent="14" relname="elaboration"/>
		<group id="114" type="span" parent="115" relname="sequence"/>
		<group id="115" type="multinuc" parent="116" relname="span"/>
		<group id="116" type="span" parent="17" relname="cause"/>
		<group id="117" type="span" />
		<group id="118" type="multinuc" parent="119" relname="contrast"/>
		<group id="119" type="multinuc" parent="120" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="126" relname="span"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" parent="197" relname="span"/>
		<group id="124" type="multinuc" parent="125" relname="comparison"/>
		<group id="125" type="multinuc" parent="123" relname="elaboration"/>
		<group id="126" type="span" parent="128" relname="joint"/>
		<group id="127" type="span" parent="128" relname="joint"/>
		<group id="128" type="multinuc" />
		<group id="129" type="multinuc" parent="30" relname="elaboration"/>
		<group id="130" type="span" parent="131" relname="contrast"/>
		<group id="131" type="multinuc" />
		<group id="132" type="multinuc" parent="133" relname="span"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" parent="141" relname="solutionhood"/>
		<group id="135" type="span" parent="136" relname="restatement"/>
		<group id="136" type="multinuc" parent="138" relname="same-unit"/>
		<group id="137" type="span" parent="138" relname="same-unit"/>
		<group id="138" type="multinuc" parent="139" relname="sequence"/>
		<group id="139" type="multinuc" parent="140" relname="span"/>
		<group id="140" type="span" parent="44" relname="cause"/>
		<group id="141" type="span" parent="199" relname="span"/>
		<group id="142" type="span" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="50" relname="condition"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" parent="151" relname="span"/>
		<group id="146" type="multinuc" parent="148" relname="cause"/>
		<group id="147" type="multinuc" parent="202" relname="span"/>
		<group id="148" type="span" parent="149" relname="span"/>
		<group id="149" type="span" parent="52" relname="evidence"/>
		<group id="150" type="span" parent="201" relname="span"/>
		<group id="151" type="span" />
		<group id="155" type="multinuc" parent="156" relname="span"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="65" relname="cause"/>
		<group id="158" type="span" parent="160" relname="span"/>
		<group id="159" type="multinuc" parent="158" relname="elaboration"/>
		<group id="160" type="span" parent="203" relname="span"/>
		<group id="163" type="span" parent="164" relname="same-unit"/>
		<group id="164" type="multinuc" parent="166" relname="span"/>
		<group id="165" type="multinuc" parent="166" relname="evidence"/>
		<group id="166" type="span" parent="167" relname="span"/>
		<group id="167" type="span" parent="74" relname="preparation"/>
		<group id="168" type="span" parent="75" relname="cause"/>
		<group id="169" type="span" />
		<group id="171" type="multinuc" parent="172" relname="joint"/>
		<group id="172" type="multinuc" parent="220" relname="span"/>
		<group id="173" type="multinuc" parent="76" relname="elaboration"/>
		<group id="174" type="span" parent="182" relname="joint"/>
		<group id="175" type="span" parent="176" relname="same-unit"/>
		<group id="176" type="multinuc" parent="177" relname="span"/>
		<group id="177" type="span" parent="178" relname="span"/>
		<group id="178" type="span" parent="181" relname="contrast"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" parent="181" relname="contrast"/>
		<group id="181" type="multinuc" parent="182" relname="joint"/>
		<group id="182" type="multinuc" />
		<group id="183" type="span" parent="210" relname="same-unit"/>
		<group id="184" type="span" parent="185" relname="joint"/>
		<group id="185" type="multinuc" parent="186" relname="span"/>
		<group id="186" type="span" parent="187" relname="span"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" parent="193" relname="span"/>
		<group id="189" type="multinuc" parent="192" relname="background"/>
		<group id="190" type="multinuc" parent="106" relname="evaluation"/>
		<group id="191" type="span" parent="187" relname="elaboration"/>
		<group id="192" type="span" parent="207" relname="span"/>
		<group id="193" type="span" />
		<group id="194" type="multinuc" parent="196" relname="preparation"/>
		<group id="195" type="span" parent="110" relname="sequence"/>
		<group id="196" type="span" parent="213" relname="span"/>
		<group id="197" type="span" parent="121" relname="cause"/>
		<group id="198" type="span" parent="27" relname="elaboration"/>
		<group id="199" type="span" />
		<group id="200" type="span" parent="144" relname="background"/>
		<group id="201" type="span" parent="145" relname="elaboration"/>
		<group id="202" type="span" parent="148" relname="span"/>
		<group id="203" type="span" />
		<group id="204" type="multinuc" parent="165" relname="same-unit"/>
		<group id="205" type="span" parent="171" relname="same-unit"/>
		<group id="206" type="multinuc" parent="189" relname="joint"/>
		<group id="207" type="span" parent="99" relname="cause"/>
		<group id="208" type="span" parent="132" relname="contrast"/>
		<group id="209" type="span" parent="176" relname="same-unit"/>
		<group id="210" type="multinuc" parent="95" relname="purpose"/>
		<group id="211" type="span" parent="212" relname="same-unit"/>
		<group id="212" type="multinuc" parent="189" relname="joint"/>
		<group id="213" type="span" />
		<group id="217" type="multinuc" parent="160" relname="solutionhood"/>
		<group id="218" type="span" parent="219" relname="span"/>
		<group id="219" type="span" parent="173" relname="contrast"/>
		<group id="220" type="span" parent="221" relname="span"/>
		<group id="221" type="span" parent="173" relname="contrast"/>
		<group id="222" type="multinuc" parent="223" relname="span"/>
		<group id="223" type="span" parent="224" relname="span"/>
		<group id="224" type="span" parent="217" relname="contrast"/>
	</body>
</rst>