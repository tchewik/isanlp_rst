<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://kosmetista.ru/blog/pricheski/97137.html</segment>
		<segment id="2" >Из хенно-басменной леди в обесцвеченно-красную диву: сравнение ухода до и после, выводы и планы</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="669" relname="preparation">Всем привет.</segment>
		<segment id="5" parent="342" relname="joint">Меня зовут Дарья,</segment>
		<segment id="6" parent="342" relname="joint">и я новенький автор,</segment>
		<segment id="7" parent="343" relname="evaluation">банально, не находите?)</segment>
		<segment id="8" parent="345" relname="joint">и я люблю ухаживать за волосами.</segment>
		<segment id="9" parent="346" relname="joint">А так же красить их, будь-то травами(хна и басма) или же перманентным красителем\прямым пигментом.</segment>
		<segment id="10" parent="678" relname="joint">В этом вступительном посте хочу рассказать о своих волосах, об их изменениях за последние полгода, о методах окрашивания, об уходе за ними.</segment>
		<segment id="11" parent="678" relname="joint">А так же пройдусь по актуальному уходу.</segment>
		<segment id="12" parent="13" relname="preparation">Времена хны и басмы</segment>
		<segment id="13" parent="350" relname="span">Я обладательница негустых, средне-русых волос.</segment>
		<segment id="14" parent="15" relname="condition">Если выражаться парикмахерским языком,</segment>
		<segment id="15" parent="351" relname="span">то 6-7 угт.</segment>
		<segment id="16" parent="354" relname="span">То есть слишком темный оттенок,</segment>
		<segment id="17" parent="353" relname="joint">чтобы поиграть на них яркими цветами без осветления\обесцвечивания</segment>
		<segment id="18" parent="353" relname="joint">или же получить ярко-медный от хны без тех же манипуляций.</segment>
		<segment id="19" parent="668" relname="span">Около трех лет я красилась хной и басмой раздельным способом.</segment>
		<segment id="20" parent="357" relname="span">Такой метод,</segment>
		<segment id="21" parent="356" relname="sequence">где ты сначала красишь волосы хной,</segment>
		<segment id="22" parent="356" relname="sequence">потом смываешь,</segment>
		<segment id="23" parent="356" relname="sequence">подсушиваешь</segment>
		<segment id="24" parent="356" relname="sequence">и красишь поверх этого басмой,</segment>
		<segment id="25" parent="358" relname="same-unit">дает возможность со временем, а иногда и сразу получить красивый черный цвет волос.</segment>
		<segment id="26" parent="367" relname="solutionhood">Почему я пользовалась травяными красителями?</segment>
		<segment id="27" parent="361" relname="contrast">Мне нравился аромат хны</segment>
		<segment id="28" parent="361" relname="contrast">и совершенно не нравился запах басмы,</segment>
		<segment id="29" parent="362" relname="contrast">но я обожаю черный цвет.</segment>
		<segment id="30" parent="364" relname="span">Черный цвет на века,</segment>
		<segment id="31" parent="363" relname="joint">который будет с тобой до конца твоих дней</segment>
		<segment id="32" parent="363" relname="joint">или пока ты не срежешь его))</segment>
		<segment id="33" parent="366" relname="elaboration">IMG</segment>
		<segment id="34" parent="370" relname="span">Хну люблю ,</segment>
		<segment id="35" parent="369" relname="span">точнее любила,</segment>
		<segment id="36" parent="35" relname="cause">потому что сейчас я не на травяных красителях,</segment>
		<segment id="37" parent="371" relname="same-unit">качественную, с мельчайшим помолом и интенсивным выделением пигмента.</segment>
		<segment id="38" parent="372" relname="span">Как правило, это либо хна для мехенди,</segment>
		<segment id="39" parent="38" relname="elaboration">которая максимальна в вышеперечисленных свойствах,</segment>
		<segment id="40" parent="373" relname="span">либо хна,</segment>
		<segment id="41" parent="40" relname="elaboration">которую можно найти в аюрведических салонах и таких же интернет-магазинах.</segment>
		<segment id="42" parent="377" relname="comparison">Что до басмы, здесь те же критерии.</segment>
		<segment id="43" parent="616" relname="elaboration">На фото хна брендов: Lady Henna, INDI BIRD, Nupur, Aroma-Zone, Hathi, Prem Dulhan, Kokila, период использования 2017-2018 года, на данный момент у меня нет этих средств в обиходе. Басма брендов: Kajal, Khadi, INDI BIRD, период использования те же 2017-2018 года, сейчас не использую. IMG</segment>
		<segment id="44" parent="378" relname="joint">Многие думают, что хна, басма и прочие травы сушат волосы</segment>
		<segment id="45" parent="378" relname="joint">и превращают в веник.</segment>
		<segment id="46" parent="379" relname="joint">С таким же успехом можно говорить о том, что обесцвечивание портит волосы</segment>
		<segment id="47" parent="379" relname="joint">и превращает в тот же веник, только другого цвета))</segment>
		<segment id="48" parent="382" relname="condition">Да, конечно, если вы не ухаживаете за волосами,</segment>
		<segment id="49" parent="382" relname="span">то даже натуральные волосы превратятся в невообразимое нечто,</segment>
		<segment id="50" parent="381" relname="joint">которое можно только срезать</segment>
		<segment id="51" parent="381" relname="joint">или закератинить,</segment>
		<segment id="52" parent="381" relname="joint">а потом… тоже срезать.</segment>
		<segment id="53" parent="387" relname="span">За любыми волосами нужен уход.</segment>
		<segment id="54" parent="385" relname="comparison">Кому-то достаточно шампуня, кондиционера и одной несмывашки+масочка на длину 1 раз в неделю,</segment>
		<segment id="55" parent="386" relname="span">а у кого-то шампунь+маска+кондей после маски+трехступенчатый несмываемый уход и обязательная укладка феном,</segment>
		<segment id="56" parent="55" relname="cause">иначе волосы будут выглядеть совсем не должным образом.</segment>
		<segment id="57" parent="58" relname="preparation">Я, если можно так выразиться, адепт профессионального ухода за волосами.</segment>
		<segment id="58" parent="389" relname="span">В период окрашивания травами у меня был облегченный, но увлажняющий уход.</segment>
		<segment id="59" parent="390" relname="joint">Волосы натуральные,</segment>
		<segment id="60" parent="390" relname="joint">сверху покрыты травяными пигментами,</segment>
		<segment id="61" parent="390" relname="joint">не нуждаются в таких компонентах, которые как воздух необходимы волосам, подверженным химическому окрашиванию.</segment>
		<segment id="62" parent="393" relname="joint">Костяк моего тогдашнего ухода: шампунь, маска, масляная несмывашка.</segment>
		<segment id="63" parent="392" relname="span">Сушка феном,</segment>
		<segment id="64" parent="63" relname="cause">поскольку я не любитель влажных от волос маек и тяжелых тюрбанов из мокрого полотенца.</segment>
		<segment id="65" parent="394" relname="elaboration">На фото средства времен лета 2018г: питательная маска с маслом монои Kaaral Maraes, увлажняющая маска с алоэ-вера Kaaral Hydra, еще одна маска с алоэ Ollin Full Forse, масло Kerastase Elixir Ultime для окрашенных волос, восстанавливающий шампунь Kaaral Purify Reale. Сейчас у меня осталась только маска Kaaral Maraes, это литр просто нескончаем. IMG</segment>
		<segment id="66" parent="396" relname="preparation">В августе 2018 года я захотела перемен в длине волос и в цвете.</segment>
		<segment id="67" parent="395" relname="joint">Я отрезала волосы по плечи</segment>
		<segment id="68" parent="395" relname="joint">и убрала из окрашивания басму, оставив хну.</segment>
		<segment id="69" parent="397" relname="cause">Хотелось стать чуть посветлее, ярче, теплее, солнечнее.</segment>
		<segment id="70" parent="71" relname="concession">Но какой бы шикарной не была хна,</segment>
		<segment id="71" parent="620" relname="span">она не сделает имеющиеся волосы светлее.</segment>
		<segment id="72" parent="400" relname="joint">Она лишь придаст им медный оттенок</segment>
		<segment id="73" parent="400" relname="joint">и слегка затемнит.</segment>
		<segment id="74" parent="401" relname="elaboration">IMG</segment>
		<segment id="75" parent="404" relname="span">Теперь волосы требовали еще меньше ухода с моей стороны.</segment>
		<segment id="76" parent="403" relname="joint">Относительно небольшая длина,</segment>
		<segment id="77" parent="403" relname="joint">густой обновленный срез.</segment>
		<segment id="78" parent="406" relname="span">Красота.</segment>
		<segment id="79" parent="405" relname="joint">Отращивай</segment>
		<segment id="80" parent="405" relname="joint">и не мучайся!</segment>
		<segment id="81" parent="407" relname="evaluation">Однако меня уже понесло.</segment>
		<segment id="82" parent="83" relname="cause">Я три года проходила с длинными волосами в режиме бесперебойного отращивания,</segment>
		<segment id="83" parent="409" relname="span">поэтому мне это просто надоело.</segment>
		<segment id="84" parent="85" relname="cause">И да, я устала от длины,</segment>
		<segment id="85" parent="410" relname="span">захотелось перемен.</segment>
		<segment id="86" parent="411" relname="span">И с такими мыслями я решаюсь на стрижку боб-каре.</segment>
		<segment id="87" parent="86" relname="evaluation">Как люблю я говорить, подлецу все к лицу, даже такие изменения.</segment>
		<segment id="88" parent="412" relname="joint">Уход остается прежним.</segment>
		<segment id="89" parent="413" relname="elaboration">IMG</segment>
		<segment id="90" parent="91" relname="condition">Если меняться,</segment>
		<segment id="91" parent="418" relname="span">то по полной программе.</segment>
		<segment id="92" parent="419" relname="span">Что мы имеем: короткие волосы, 1см отросших родных корней, 7 см волос, окрашенных только хной и оставшаяся часть длины под хной и басмой, черной, непробиваемой, не смывающейся.</segment>
		<segment id="93" parent="420" relname="span">Помимо черного цвета я обожаю красно-малиновые оттенки волос.</segment>
		<segment id="94" parent="650" relname="span">Такой оттенок с огромным трудом можно добиться,</segment>
		<segment id="95" parent="94" relname="condition">окрашиваясь травами, и то, с сильным затемнением.</segment>
		<segment id="96" parent="622" relname="span">А мне захотелось яркости.</segment>
		<segment id="97" parent="422" relname="span">В моем случае без обесцвечивания не обойтись. Порошком и 3% оксигентом 2 раза и порошком и 1,8% оксигентом один раз.</segment>
		<segment id="98" parent="97" relname="elaboration">Все это по длине, там, где была хна с басмой.</segment>
		<segment id="99" parent="423" relname="contrast">Корни обесцвечивали на 1,8%,</segment>
		<segment id="100" parent="423" relname="contrast">но в сложившейся ситуации можно было бы обойтись и без чистки корней. Порошочек и оксиды фирм Bouticle и Tefia (оксид 1,8%).</segment>
		<segment id="101" parent="102" relname="condition">При смывании пудры</segment>
		<segment id="102" parent="425" relname="span">я поразилась тому, что мои волосы не были убитыми.</segment>
		<segment id="103" parent="425" relname="elaboration">Пальцы проходили сквозь волосы не застревая и не выдирая их.</segment>
		<segment id="104" parent="426" relname="evaluation">Фантастика да и только.</segment>
		<segment id="105" parent="428" relname="span">Что до цвета, то хна обесцветилась до желто-оранжевого цвета, а басма — сине-зеленое безобразие.</segment>
		<segment id="106" parent="105" relname="elaboration">IMG</segment>
		<segment id="107" parent="651" relname="span">Выход из хны и басмы путем обесцвечивания — весьма неоднозначная тема,</segment>
		<segment id="108" parent="107" relname="elaboration">вокруг которой ведутся жаркие дебаты как мастеров, так и простых обывателей.</segment>
		<segment id="109" parent="432" relname="joint">Многие из вас, наверно, слышали, что обесцвечивание хны дает зелень,</segment>
		<segment id="110" parent="432" relname="joint">после хны невозможно стать блондинкой\получить холодный блонд, и т.д.</segment>
		<segment id="111" parent="433" relname="evaluation">Отчасти, это правда, отчасти — бред больной души.</segment>
		<segment id="112" parent="113" relname="condition">Если будет время,</segment>
		<segment id="113" parent="435" relname="span">напишу об этом отдельный пост.</segment>
		<segment id="114" parent="652" relname="preparation">После всех очищающих цвет манипуляций покрасили волосы красителем Bouticle 8.55 по длине и 7.55 на корнях.</segment>
		<segment id="115" parent="116" relname="condition">Уже при смывании краски с волос</segment>
		<segment id="116" parent="652" relname="span">я ощутила колоссальную разницу между тем, какими были волосы после смывания пудры и какими сейчас.</segment>
		<segment id="117" parent="118" relname="cause">Пальцы с трудом проходили сквозь спутанные дебри волос,</segment>
		<segment id="118" parent="623" relname="span">а я все яснее и яснее понимала, что окрашивание перманентом было явно лишним.</segment>
		<segment id="119" parent="438" relname="span">Но дело сделано,</segment>
		<segment id="120" parent="655" relname="span">теперь моя задача ухаживать за поврежденными волосами,</segment>
		<segment id="121" parent="120" relname="condition">стараясь поддерживать цвет и качество волос на должном уровне.</segment>
		<segment id="122" parent="438" relname="elaboration">IMG</segment>
		<segment id="123" parent="442" relname="span">Я привыкла к блеску, упругости и мягкости волос,</segment>
		<segment id="124" parent="441" relname="joint">такими я хочу их видеть</segment>
		<segment id="125" parent="441" relname="joint">и ощущать даже после тройного обесцвечивания.</segment>
		<segment id="126" parent="127" relname="cause">Вы можете сказать мне что-то вроде: «Ты же обесцветилась,</segment>
		<segment id="127" parent="656" relname="span">испортила волосы,</segment>
		<segment id="128" parent="443" relname="joint">вот и терпи теперь,</segment>
		<segment id="129" parent="443" relname="joint">срезай</segment>
		<segment id="130" parent="443" relname="joint">и отращивай натуральный цвет»,-</segment>
		<segment id="131" parent="624" relname="span">и будете вкорне не правы)</segment>
		<segment id="132" parent="131" relname="cause">Поскольку даже такие волосы имеют возможность «восстать из пепла, подобно прекрасному фениксу».</segment>
		<segment id="133" parent="448" relname="span">Теперь мне нужен совсем иной уход для волос+ постоянное тонирование,</segment>
		<segment id="134" parent="133" relname="cause">поскольку ярко-красный такой же капризный и недолговечный, как пепельный блонд.</segment>
		<segment id="135" parent="449" relname="joint">Но из-за того, что мои волосы обесцвечены три раза подряд,</segment>
		<segment id="136" parent="449" relname="joint">и после последующего тонирования стали намного хуже себя чувствовать,</segment>
		<segment id="137" parent="451" relname="span">я решила перейти на прямые пигменты,</segment>
		<segment id="138" parent="450" relname="joint">это такие красители, которые продаются в готовом виде,</segment>
		<segment id="139" parent="450" relname="joint">их не нужно смешивать.</segment>
		<segment id="140" parent="453" relname="contrast">Они отлично ложатся на обесцвеченные волосы,</segment>
		<segment id="141" parent="453" relname="contrast">но на натуральные могут не лечь.</segment>
		<segment id="142" parent="625" relname="elaboration">На фото: слева пигмент прямого действия Kapous Professional Rain Bow (красный), оттеночный бальзам Kapous Professional Life Color (гранат), оттеночная маска Tefia (красный), эти три тюбика у меня закончились. Справа еще не открытые средства: оттеночная маска Ollin Matisse Color (гранат), пигмент прямого действия Estel X-tro (розовый) и пигмент прямого действия Ollin Matisse Color (красный), открою буквально на днях, поскольку подходит время для очередного обесцвечивания корней и тонирования. IMG</segment>
		<segment id="143" parent="456" relname="span">Эти красители можно смешивать с кондиционером или маской</segment>
		<segment id="144" parent="143" relname="purpose">для смягчения воздействия на волосы или разбавления цвета.</segment>
		<segment id="145" parent="146" relname="cause">Но я стремлюсь добиться максимальной яркости и насыщенности цвета,</segment>
		<segment id="146" parent="457" relname="span">использую пигменты в чистом виде.</segment>
		<segment id="147" parent="461" relname="span">В моем арсенале красные и розовые(фуксия) оттенки,</segment>
		<segment id="148" parent="460" relname="span">я их чередую,</segment>
		<segment id="149" parent="150" relname="cause">меняться прикольно, кстати,</segment>
		<segment id="150" parent="459" relname="span">никогда не соскучишься)</segment>
		<segment id="151" parent="461" relname="elaboration">IMG</segment>
		<segment id="152" parent="464" relname="sequence">А каждые месяц-полтора я прохожусь по корням обесцвечивающей пудрой, замешанной на 1,5% оксигенте,</segment>
		<segment id="153" parent="464" relname="sequence">и после тонирую каким-нибудь прямым пигментом. Чаще всего цветом «фуксия».</segment>
		<segment id="154" parent="465" relname="elaboration">IMG</segment>
		<segment id="155" parent="468" relname="preparation">Вернемся к уходу.</segment>
		<segment id="156" parent="157" relname="condition">Если ранее он состоял из легкого и не самого мягкого шампуня, средненькой маскочки и масляной несмывашки,</segment>
		<segment id="157" parent="468" relname="span">то теперь это мягенький шампунь с кучей смягчающих компонентов, обязательно мощная питательная маска, кондиционер(не всегда и только после маски), трехступенчатый несмываемый уход: увлажняющий спрей, кремовая термозащита и финишная масляная несмывашка.</segment>
		<segment id="158" parent="657" relname="span">Раньше, до моего увлечения уходом за волосами, все это мне казалось таким сложным и запутанным, а сейчас как дважды два.</segment>
		<segment id="159" parent="470" relname="joint">Я знаю, что за чем идет</segment>
		<segment id="160" parent="470" relname="joint">и знаю, какое средство какой эффект в сцепке с другим средством дает.</segment>
		<segment id="161" parent="471" relname="evaluation">И это прекрасно!</segment>
		<segment id="162" parent="473" relname="elaboration">IMG</segment>
		<segment id="163" parent="482" relname="preparation">Очень люблю смываемый уход от Angel Professional.</segment>
		<segment id="164" parent="476" relname="span">Раньше не любила его шампуни,</segment>
		<segment id="165" parent="475" relname="joint">т.к они мне утяжеляли волосы</segment>
		<segment id="166" parent="475" relname="joint">и плохо промывали кожу головы,</segment>
		<segment id="167" parent="480" relname="span">но сейчас я смогла найти себе по душе,</segment>
		<segment id="168" parent="479" relname="span">который в сложившихся реалиях и промывает хорошо,</segment>
		<segment id="169" parent="478" relname="joint">не способствуя загрязнению раньше времени,</segment>
		<segment id="170" parent="478" relname="joint">и в то же время бережно промывая;</segment>
		<segment id="171" parent="481" relname="joint">а ангельские маски что тогда, что сейчас для меня полнейший восторг)))</segment>
		<segment id="172" parent="484" relname="span">Так же впечатлил меня спрей из новой серии</segment>
		<segment id="173" parent="172" relname="purpose">для защиты цвета.</segment>
		<segment id="174" parent="485" relname="span">Что до кремовой термозащиты, то тут нескончаемый силиконистый,</segment>
		<segment id="175" parent="174" relname="evaluation">а другим он и не должен быть,</segment>
		<segment id="176" parent="486" relname="same-unit">Kaaral Pink Up.</segment>
		<segment id="177" parent="488" relname="span">Масляный финиш периодически меняется.</segment>
		<segment id="178" parent="177" relname="elaboration">Сейчас у меня в любимчиках кератиновое золотое масло Tahe Gold Keratin.</segment>
		<segment id="179" parent="487" relname="joint">Этот уход актуален на данный момент.</segment>
		<segment id="180" parent="487" relname="joint">Расскажу о нем подробнее.</segment>
		<segment id="181" parent="493" relname="span">Шампунь Angel Professional Color Protect Shampoo Защита цвета</segment>
		<segment id="182" parent="181" relname="elaboration">IMG на фото литровый формат и формат 250мл</segment>
		<segment id="183" parent="492" relname="joint">Шампунь предназначен для окрашенных волос</segment>
		<segment id="184" parent="492" relname="joint">и должен выполнять функцию защиты цвета.</segment>
		<segment id="185" parent="186" relname="cause">Он содержит в себе несколько мягких ПАВов, а так же SLES, но не на первом месте,</segment>
		<segment id="186" parent="496" relname="span">за счет всего этого шампунь очень бережно, но вместе с тем достаточно хорошо промывает как волосы, так и кожу головы.</segment>
		<segment id="187" parent="500" relname="joint">Никакого налета и преждевременного загрязнения не было выявлено, так же, как и перхоти, зуда, выпадения и прочих проблем.</segment>
		<segment id="188" parent="497" relname="comparison">Во время мытья им мои волосы не так сильно спутываются,</segment>
		<segment id="189" parent="497" relname="comparison">на более здоровых волосах, я думаю, этой проблемы не было бы вообще.</segment>
		<segment id="190" parent="498" relname="span">Шампунь мне идеально подошел</segment>
		<segment id="191" parent="190" relname="purpose">для постоянного использования,</segment>
		<segment id="192" parent="498" relname="elaboration">а я голову мою через день.</segment>
		<segment id="193" parent="503" relname="span">Что до защиты цвета окрашенных волос, то здесь, на мой взгляд, все стандартно:</segment>
		<segment id="194" parent="193" relname="elaboration">краситель вымывается в прежнем режиме.</segment>
		<segment id="195" parent="503" relname="elaboration">IMG</segment>
		<segment id="196" parent="506" relname="span">Консистенция шампуня очень интересная:</segment>
		<segment id="197" parent="196" relname="elaboration">этакий крем-гель нежно-розового цвета без посторонних вкраплений и добавок, тягучий и ароматный.</segment>
		<segment id="198" parent="199" relname="cause">Кстати, аромат очень насыщенный,</segment>
		<segment id="199" parent="507" relname="span">первое время может надоедать своей резкостью.</segment>
		<segment id="200" parent="666" relname="contrast">К сожалению, у меня плохо получается детально описывать ароматы,</segment>
		<segment id="201" parent="666" relname="contrast">но на мой взгляд, он представляет собой адскую смесь дедушкиного одеколона и цветочного букета.</segment>
		<segment id="202" parent="513" relname="span">И только от пользователя шампуня зависит, чем будут пахнуть его волосы:</segment>
		<segment id="203" parent="204" relname="condition">нанесешь немного и смоешь хорошо,</segment>
		<segment id="204" parent="510" relname="span">будет приятный аромат цветов,</segment>
		<segment id="205" parent="511" relname="joint">если переборщишь</segment>
		<segment id="206" parent="511" relname="joint">и плохо смоешь-привет, дедуля.</segment>
		<segment id="207" parent="515" relname="elaboration">IMG</segment>
		<segment id="208" parent="517" relname="span">Кому подойдет этот шампунь:</segment>
		<segment id="209" parent="208" relname="elaboration">волосам окрашенным, прошедшим через обесцвечивание, а так же часто подвергающимся укладкам термоприборами.</segment>
		<segment id="210" parent="659" relname="joint">Натуральным и волосам, окрашенными травами может не подойти</segment>
		<segment id="211" parent="212" relname="cause">из-за слишком насыщенного состава и мягкости мытья</segment>
		<segment id="212" parent="658" relname="span">будет перегружать волосы.</segment>
		<segment id="213" parent="519" relname="joint">Цена: 370р, 974р</segment>
		<segment id="214" parent="519" relname="joint">Объем: 250мл, 1000мл</segment>
		<segment id="215" parent="628" relname="evaluation">Оценка: 5</segment>
		<segment id="216" parent="630" relname="joint">Срок тестирования: 2 месяца.</segment>
		<segment id="217" parent="520" relname="span">Расход шампуня зависит от формата упаковки:</segment>
		<segment id="218" parent="217" relname="elaboration">у маленькой бутылочке 250мл мне требовалось на 1 намыливание 3-5 нажатий дозатора, а у литровой бутылки — 1-2 нажатия.</segment>
		<segment id="219" parent="521" relname="span">Маска для волос Angel Professional Color Protect Hair Mask Защита цвета</segment>
		<segment id="220" parent="219" relname="elaboration">IMG</segment>
		<segment id="221" parent="522" relname="span">Маска предназначена для окрашенных волос,</segment>
		<segment id="222" parent="221" relname="purpose">для защиты цвета,</segment>
		<segment id="223" parent="523" relname="contrast">однако она ценна лично для меня не этим.</segment>
		<segment id="224" parent="526" relname="span">Содержит в себе жирные спирты, глицерин</segment>
		<segment id="225" parent="224" relname="evaluation">(шикарный увлажняющий компонент, не знаю, почему вокруг него столько шумихи),</segment>
		<segment id="226" parent="527" relname="same-unit">масла виноградных косточек, арганы, макадамии, экстракты бурых водорослей и лепестков дикой сакуры, амодиметикон(силикон), кератин, гидролизованные протеины пшеницы.</segment>
		<segment id="227" parent="528" relname="elaboration">IMG</segment>
		<segment id="228" parent="531" relname="joint">Консистенция у маски похожа на нежнейший пудинг или густой йогурт розового цвета.</segment>
		<segment id="229" parent="533" relname="contrast">Аромат такой же яркий, как у шампуня.</segment>
		<segment id="230" parent="532" relname="joint">Но к нему я привыкла</segment>
		<segment id="231" parent="532" relname="joint">и почти не замечаю.</segment>
		<segment id="232" parent="534" relname="elaboration">IMG</segment>
		<segment id="233" parent="537" relname="preparation">Маска дарит моим волосам все то, чего им не хватает: блеск, увлажнение, питание.</segment>
		<segment id="234" parent="536" relname="joint">Трогаешь их</segment>
		<segment id="235" parent="536" relname="joint">и ощущаешь приятную прохладу и нетипичную для обесцвеченного полотна волос мягкость.</segment>
		<segment id="236" parent="539" relname="joint">Они не спутываются,</segment>
		<segment id="237" parent="539" relname="joint">и в целом, выглядят очень даже ухоженными.</segment>
		<segment id="238" parent="540" relname="joint">В ней нет ничего лишнего,</segment>
		<segment id="239" parent="540" relname="joint">она не перегружает волосы</segment>
		<segment id="240" parent="541" relname="span">и не способствует их преждевременному загрязнению</segment>
		<segment id="241" parent="240" relname="concession">несмотря на то, что я ее наношу близко к корням.</segment>
		<segment id="242" parent="543" relname="elaboration">IMG</segment>
		<segment id="243" parent="545" relname="span">Расход в моем случае относительно большой,</segment>
		<segment id="244" parent="243" relname="evidence">поллитровая банка за пару месяцев регулярного (после каждого мытья) использования опустела наполовину.</segment>
		<segment id="245" parent="546" relname="comparison">Для более здоровых волос расход будет ощутимо меньше.</segment>
		<segment id="246" parent="547" relname="span">Кому подойдет эта маска:</segment>
		<segment id="247" parent="246" relname="elaboration">окрашенным и обесцвеченным волосам — однозначно.</segment>
		<segment id="248" parent="548" relname="span">Неокрашенным и волосам, окрашенными травами — с осторожностью,</segment>
		<segment id="249" parent="248" relname="cause">поскольку лишний кератин в составе маски с такими волосами может сыграть злую шутку.</segment>
		<segment id="250" parent="551" relname="joint">Цена: 857р</segment>
		<segment id="251" parent="551" relname="joint">Объем: 500мл</segment>
		<segment id="252" parent="634" relname="evaluation">Оценка: 5</segment>
		<segment id="253" parent="635" relname="elaboration">Срок тестирования: 2 месяца.</segment>
		<segment id="254" parent="552" relname="span">Спрей-кондиционер Angel Professional Color Protect Защита цвета</segment>
		<segment id="255" parent="254" relname="elaboration">IMG</segment>
		<segment id="256" parent="554" relname="span">Спрей-кондиционер предназначен</segment>
		<segment id="257" parent="553" relname="span">для сохранения цвета окрашенных волос и защиты от солнечных лучей и перегрева</segment>
		<segment id="258" parent="257" relname="condition">при укладке.</segment>
		<segment id="259" parent="637" relname="contrast">Но я человек упертый, который не верит в термозащитные свойства и силы спреев,</segment>
		<segment id="260" parent="637" relname="contrast">мне подавай более плотные текстуры или в особо запущенных случаях — трехступенчатую несмываемую систему.</segment>
		<segment id="261" parent="262" relname="cause">Консистенция спрея двухфазная,</segment>
		<segment id="262" parent="556" relname="span">поэтому перед применением нужно взболтать бутылку.</segment>
		<segment id="263" parent="558" relname="joint">Распыление широким мелкодисперсным облаком</segment>
		<segment id="264" parent="559" relname="elaboration">IMG</segment>
		<segment id="265" parent="567" relname="span">Этот спрей очень хорош для моих волос.</segment>
		<segment id="266" parent="563" relname="span">Мало того, что он облегчает расчесывание,</segment>
		<segment id="267" parent="562" relname="joint">его много не надо,</segment>
		<segment id="268" parent="661" relname="comparison">а так же нет необходимости обновлять каждые два часа,</segment>
		<segment id="269" parent="660" relname="span">как всеми хваленый голубой спрей Kapous Professional,</segment>
		<segment id="270" parent="269" relname="evaluation">который я считаю одним из самых отвратительных спреев.</segment>
		<segment id="271" parent="564" relname="joint">Спрей Angel не сушит волосы</segment>
		<segment id="272" parent="564" relname="joint">и не перегружает,</segment>
		<segment id="273" parent="565" relname="restatement">т.е никаких слипшихся прядей или тусклое полотно волос я не наблюдаю, только легкость и блеск.</segment>
		<segment id="274" parent="569" relname="span">Кому подойдет этот спрей:</segment>
		<segment id="275" parent="568" relname="span">здесь точно так же:</segment>
		<segment id="276" parent="275" relname="elaboration">поврежденным, окрашенным волосам подойдет идеально, а более здоровым волосам — постолько, поскольку.</segment>
		<segment id="277" parent="570" relname="joint">Цена: 920р</segment>
		<segment id="278" parent="570" relname="joint">Объем: 250мл</segment>
		<segment id="279" parent="638" relname="evaluation">Оценка: 5</segment>
		<segment id="280" parent="639" relname="elaboration">Срок тестирования: 2 месяца.</segment>
		<segment id="281" parent="571" relname="span">Термозащитный крем</segment>
		<segment id="282" parent="281" relname="purpose">для выпрямления Kaaral Pink Up</segment>
		<segment id="283" parent="571" relname="elaboration">IMG</segment>
		<segment id="284" parent="662" relname="span">Предназначен для защиты от высоких температур</segment>
		<segment id="285" parent="284" relname="condition">при выпрямлении волос и сушки феном.</segment>
		<segment id="286" parent="574" relname="contrast">Я не выпрямляю волосы,</segment>
		<segment id="287" parent="574" relname="contrast">но сушка феном обязательный для меня ритуал.</segment>
		<segment id="288" parent="575" relname="joint">Крем обладает плотной силиконистой текстурой,</segment>
		<segment id="289" parent="575" relname="joint">и пахнет карамельками.</segment>
		<segment id="290" parent="576" relname="elaboration">IMG</segment>
		<segment id="291" parent="579" relname="span">На влажные чистые волосы я наношу немного крема, распределяя от прикорневой зоны до самых кончиков.</segment>
		<segment id="292" parent="291" relname="evidence">На мои короткие волосы достаточно трех таких дозировок, как на фото выше.</segment>
		<segment id="293" parent="580" relname="sequence">Средство равномерно распределяется</segment>
		<segment id="294" parent="665" relname="span">и быстро впитывается,</segment>
		<segment id="295" parent="294" relname="condition">не оставляя после себя никакого налета.</segment>
		<segment id="296" parent="581" relname="sequence">Волосы гораздо легче расчесать.</segment>
		<segment id="297" parent="581" relname="sequence">Можно приступать к сушке волос и укладке.</segment>
		<segment id="298" parent="585" relname="span">Кому подойдет этот крем:</segment>
		<segment id="299" parent="584" relname="joint">всем тем, кто так или иначе пользуется термоприборами</segment>
		<segment id="300" parent="583" relname="span">и не гнушается силиконами,</segment>
		<segment id="301" parent="300" relname="evidence">а в средстве их много.</segment>
		<segment id="302" parent="641" relname="joint">Цена: 600р+ (средство снято с производства)</segment>
		<segment id="303" parent="641" relname="joint">Объем: 250мл</segment>
		<segment id="304" parent="642" relname="evaluation">Оценка: 5</segment>
		<segment id="305" parent="643" relname="elaboration">Срок тестирования: 13 месяцев больше года</segment>
		<segment id="306" parent="586" relname="span">Аргановое масло для волос с частицами золота Tahe Keratin gold</segment>
		<segment id="307" parent="306" relname="elaboration">IMG</segment>
		<segment id="308" parent="587" relname="joint">Это масло разглаживает</segment>
		<segment id="309" parent="587" relname="joint">и защищает мои волосы от прикорневой зоны и до самых кончиков покруче Kerastase для окрашенных волос,</segment>
		<segment id="310" parent="588" relname="contrast">а вот с классическим золотым эликсиром еще не сравнивала конкретно на окрашенных волосах.</segment>
		<segment id="311" parent="591" relname="joint">Масло содержит в себе силиконы, масло арганы и кератин,</segment>
		<segment id="312" parent="591" relname="joint">пахнет пьянящими ананасами.</segment>
		<segment id="313" parent="593" relname="contrast">На официальном сайте есть информация о том, что средство содержит в себе микрочастицы золота,</segment>
		<segment id="314" parent="592" relname="span">однако мне в это верится с трудом,</segment>
		<segment id="315" parent="314" relname="cause">поскольку масло абсолютно прозрачное, по консистенции средней густоты.</segment>
		<segment id="316" parent="594" relname="elaboration">IMG</segment>
		<segment id="317" parent="599" relname="span">Кому подойдет это масло:</segment>
		<segment id="318" parent="598" relname="joint">всем тем, кто любит ухаживать за волосами</segment>
		<segment id="319" parent="598" relname="joint">и не боится силиконов.</segment>
		<segment id="320" parent="599" relname="evaluation">Мне кажется, оно подойдет любому типу волос.</segment>
		<segment id="321" parent="601" relname="joint">Цена: 1000р</segment>
		<segment id="322" parent="601" relname="joint">Объем: 30мл</segment>
		<segment id="323" parent="645" relname="evaluation">Оценка: 5</segment>
		<segment id="324" parent="646" relname="elaboration">Срок тестирования: полгода</segment>
		<segment id="325" parent="648" relname="solutionhood">Жалею ли я о содеянном?</segment>
		<segment id="326" parent="648" relname="span">Ни капли.</segment>
		<segment id="327" parent="602" relname="span">Меня наконец-то отпустил страх испортить волосы обесцвечиванием,</segment>
		<segment id="328" parent="327" relname="cause">потому что уход способен творить чудеса.</segment>
		<segment id="329" parent="603" relname="span">А так же есть полная уверенность в том, что я смогу отрастить длинные и ухоженные волосы,</segment>
		<segment id="330" parent="329" relname="condition">не отказываясь от ярких оттенков волос.</segment>
		<segment id="331" parent="603" relname="concession">Хоть и рано об этом говорить.</segment>
		<segment id="332" parent="607" relname="joint">В мои планы входит сращивание и постепенное срезание остатков тройного обесцвечивания, которому подвергся тот промежуток волос, на котором остались хна и басма.</segment>
		<segment id="333" parent="606" relname="contrast">Мне часто говорят о красоте перехода из темного в яркий на моих волосах,</segment>
		<segment id="334" parent="606" relname="contrast">однако пятнистость невыводимой с волос басмы смотрится не очень красиво.</segment>
		<segment id="335" parent="611" relname="contrast">В голубых мечтах сидит пунктик об окрашивании в разные цвета, пастельные и насыщенные,</segment>
		<segment id="336" parent="610" relname="span">однако, чувствую, что перегорю,</segment>
		<segment id="337" parent="609" relname="span">хотя, кто знает…</segment>
		<segment id="338" parent="339" relname="cause">когда я начала краситься басмой,</segment>
		<segment id="339" parent="608" relname="span">тоже уверяла себя, что с черным навсегда. Не навсегда.</segment>
		<segment id="340" parent="612" relname="evaluation">Все временно.</segment>
		<segment id="341" >Всем спасибо за внимание)</segment>
		<group id="342" type="multinuc" parent="669" relname="span"/>
		<group id="343" type="span" parent="344" relname="span"/>
		<group id="344" type="span" parent="345" relname="joint"/>
		<group id="345" type="multinuc" parent="346" relname="joint"/>
		<group id="346" type="multinuc" parent="679" relname="preparation"/>
		<group id="350" type="span" parent="355" relname="span"/>
		<group id="351" type="span" parent="352" relname="restatement"/>
		<group id="352" type="multinuc" parent="350" relname="elaboration"/>
		<group id="353" type="multinuc" parent="16" relname="purpose"/>
		<group id="354" type="span" parent="352" relname="restatement"/>
		<group id="355" type="span" parent="667" relname="joint"/>
		<group id="356" type="multinuc" parent="20" relname="elaboration"/>
		<group id="357" type="span" parent="358" relname="same-unit"/>
		<group id="358" type="multinuc" parent="19" relname="elaboration"/>
		<group id="361" type="multinuc" parent="362" relname="contrast"/>
		<group id="362" type="multinuc" parent="365" relname="span"/>
		<group id="363" type="multinuc" parent="30" relname="elaboration"/>
		<group id="364" type="span" parent="365" relname="evaluation"/>
		<group id="365" type="span" parent="366" relname="span"/>
		<group id="366" type="span" parent="367" relname="span"/>
		<group id="367" type="span" parent="615" relname="span"/>
		<group id="368" type="multinuc" />
		<group id="369" type="span" parent="34" relname="elaboration"/>
		<group id="370" type="span" parent="371" relname="same-unit"/>
		<group id="371" type="multinuc" parent="375" relname="span"/>
		<group id="372" type="span" parent="374" relname="same-unit"/>
		<group id="373" type="span" parent="374" relname="same-unit"/>
		<group id="374" type="multinuc" parent="375" relname="elaboration"/>
		<group id="375" type="span" parent="376" relname="span"/>
		<group id="376" type="span" parent="377" relname="comparison"/>
		<group id="377" type="multinuc" parent="616" relname="span"/>
		<group id="378" type="multinuc" parent="618" relname="comparison"/>
		<group id="379" type="multinuc" parent="618" relname="comparison"/>
		<group id="380" type="span" parent="384" relname="span"/>
		<group id="381" type="multinuc" parent="49" relname="elaboration"/>
		<group id="382" type="span" parent="383" relname="span"/>
		<group id="383" type="span" parent="380" relname="elaboration"/>
		<group id="384" type="span" parent="388" relname="span"/>
		<group id="385" type="multinuc" parent="53" relname="elaboration"/>
		<group id="386" type="span" parent="385" relname="comparison"/>
		<group id="387" type="span" parent="384" relname="evaluation"/>
		<group id="388" type="span" />
		<group id="389" type="span" parent="391" relname="span"/>
		<group id="390" type="multinuc" parent="389" relname="elaboration"/>
		<group id="391" type="span" parent="394" relname="span"/>
		<group id="392" type="span" parent="393" relname="joint"/>
		<group id="393" type="multinuc" parent="391" relname="elaboration"/>
		<group id="394" type="span" parent="619" relname="span"/>
		<group id="395" type="multinuc" parent="396" relname="span"/>
		<group id="396" type="span" parent="397" relname="span"/>
		<group id="397" type="span" parent="398" relname="span"/>
		<group id="398" type="span" parent="401" relname="span"/>
		<group id="399" type="multinuc" parent="398" relname="elaboration"/>
		<group id="400" type="multinuc" parent="399" relname="contrast"/>
		<group id="401" type="span" parent="402" relname="span"/>
		<group id="402" type="span" />
		<group id="403" type="multinuc" parent="75" relname="elaboration"/>
		<group id="404" type="span" parent="407" relname="span"/>
		<group id="405" type="multinuc" parent="78" relname="elaboration"/>
		<group id="406" type="span" parent="404" relname="evaluation"/>
		<group id="407" type="span" parent="408" relname="span"/>
		<group id="408" type="span" parent="417" relname="span"/>
		<group id="409" type="span" parent="415" relname="joint"/>
		<group id="410" type="span" parent="415" relname="joint"/>
		<group id="411" type="span" parent="412" relname="joint"/>
		<group id="412" type="multinuc" parent="413" relname="span"/>
		<group id="413" type="span" parent="414" relname="span"/>
		<group id="414" type="span" parent="416" relname="span"/>
		<group id="415" type="multinuc" parent="414" relname="cause"/>
		<group id="416" type="span" parent="408" relname="elaboration"/>
		<group id="417" type="span" />
		<group id="418" type="span" parent="92" relname="preparation"/>
		<group id="419" type="span" parent="421" relname="background"/>
		<group id="420" type="span" parent="621" relname="contrast"/>
		<group id="421" type="span" parent="431" relname="span"/>
		<group id="422" type="span" parent="424" relname="joint"/>
		<group id="423" type="multinuc" parent="424" relname="joint"/>
		<group id="424" type="multinuc" parent="430" relname="sequence"/>
		<group id="425" type="span" parent="426" relname="span"/>
		<group id="426" type="span" parent="427" relname="span"/>
		<group id="427" type="span" parent="429" relname="joint"/>
		<group id="428" type="span" parent="429" relname="joint"/>
		<group id="429" type="multinuc" parent="430" relname="sequence"/>
		<group id="430" type="multinuc" parent="96" relname="elaboration"/>
		<group id="431" type="span" />
		<group id="432" type="multinuc" parent="433" relname="span"/>
		<group id="433" type="span" parent="434" relname="span"/>
		<group id="434" type="span" parent="436" relname="span"/>
		<group id="435" type="span" parent="434" relname="elaboration"/>
		<group id="436" type="span" parent="651" relname="elaboration"/>
		<group id="437" type="span" />
		<group id="438" type="span" parent="439" relname="span"/>
		<group id="439" type="span" parent="440" relname="contrast"/>
		<group id="440" type="multinuc" parent="653" relname="elaboration"/>
		<group id="441" type="multinuc" parent="123" relname="elaboration"/>
		<group id="442" type="span" parent="447" relname="span"/>
		<group id="443" type="multinuc" parent="444" relname="span"/>
		<group id="444" type="span" parent="677" relname="span"/>
		<group id="445" type="span" parent="446" relname="span"/>
		<group id="446" type="span" parent="442" relname="elaboration"/>
		<group id="447" type="span" />
		<group id="448" type="span" parent="455" relname="contrast"/>
		<group id="449" type="multinuc" parent="451" relname="cause"/>
		<group id="450" type="multinuc" parent="137" relname="elaboration"/>
		<group id="451" type="span" parent="452" relname="span"/>
		<group id="452" type="span" parent="454" relname="span"/>
		<group id="453" type="multinuc" parent="452" relname="elaboration"/>
		<group id="454" type="span" parent="455" relname="contrast"/>
		<group id="455" type="multinuc" parent="625" relname="span"/>
		<group id="456" type="span" parent="458" relname="contrast"/>
		<group id="457" type="span" parent="463" relname="span"/>
		<group id="458" type="multinuc" parent="467" relname="joint"/>
		<group id="459" type="span" parent="148" relname="evaluation"/>
		<group id="460" type="span" parent="147" relname="elaboration"/>
		<group id="461" type="span" parent="462" relname="span"/>
		<group id="462" type="span" parent="457" relname="elaboration"/>
		<group id="463" type="span" parent="458" relname="contrast"/>
		<group id="464" type="multinuc" parent="465" relname="span"/>
		<group id="465" type="span" parent="466" relname="span"/>
		<group id="466" type="span" parent="467" relname="joint"/>
		<group id="467" type="multinuc" />
		<group id="468" type="span" parent="469" relname="span"/>
		<group id="469" type="span" parent="473" relname="span"/>
		<group id="470" type="multinuc" parent="471" relname="span"/>
		<group id="471" type="span" parent="472" relname="span"/>
		<group id="472" type="span" parent="158" relname="elaboration"/>
		<group id="473" type="span" parent="474" relname="span"/>
		<group id="474" type="span" />
		<group id="475" type="multinuc" parent="164" relname="cause"/>
		<group id="476" type="span" parent="477" relname="contrast"/>
		<group id="477" type="multinuc" parent="481" relname="joint"/>
		<group id="478" type="multinuc" parent="168" relname="cause"/>
		<group id="479" type="span" parent="167" relname="elaboration"/>
		<group id="480" type="span" parent="477" relname="contrast"/>
		<group id="481" type="multinuc" parent="482" relname="span"/>
		<group id="482" type="span" parent="483" relname="span"/>
		<group id="483" type="span" parent="489" relname="joint"/>
		<group id="484" type="span" parent="489" relname="joint"/>
		<group id="485" type="span" parent="486" relname="same-unit"/>
		<group id="486" type="multinuc" parent="489" relname="joint"/>
		<group id="487" type="multinuc" parent="490" relname="evaluation"/>
		<group id="488" type="span" parent="489" relname="joint"/>
		<group id="489" type="multinuc" parent="490" relname="span"/>
		<group id="490" type="span" parent="491" relname="span"/>
		<group id="491" type="span" />
		<group id="492" type="multinuc" parent="494" relname="span"/>
		<group id="493" type="span" parent="494" relname="preparation"/>
		<group id="494" type="span" parent="495" relname="span"/>
		<group id="495" type="span" parent="501" relname="span"/>
		<group id="496" type="span" parent="500" relname="joint"/>
		<group id="497" type="multinuc" parent="500" relname="joint"/>
		<group id="498" type="span" parent="499" relname="span"/>
		<group id="499" type="span" parent="505" relname="joint"/>
		<group id="500" type="multinuc" parent="495" relname="elaboration"/>
		<group id="501" type="span" parent="502" relname="span"/>
		<group id="502" type="span" />
		<group id="503" type="span" parent="504" relname="span"/>
		<group id="504" type="span" parent="505" relname="joint"/>
		<group id="505" type="multinuc" parent="501" relname="evaluation"/>
		<group id="506" type="span" parent="515" relname="span"/>
		<group id="507" type="span" parent="509" relname="span"/>
		<group id="509" type="span" parent="514" relname="span"/>
		<group id="510" type="span" parent="512" relname="comparison"/>
		<group id="511" type="multinuc" parent="512" relname="comparison"/>
		<group id="512" type="multinuc" parent="202" relname="elaboration"/>
		<group id="513" type="span" parent="509" relname="elaboration"/>
		<group id="514" type="span" parent="506" relname="elaboration"/>
		<group id="515" type="span" parent="516" relname="span"/>
		<group id="516" type="span" />
		<group id="517" type="span" parent="518" relname="contrast"/>
		<group id="518" type="multinuc" parent="627" relname="span"/>
		<group id="519" type="multinuc" parent="627" relname="elaboration"/>
		<group id="520" type="span" parent="630" relname="joint"/>
		<group id="521" type="span" parent="524" relname="purpose"/>
		<group id="522" type="span" parent="523" relname="contrast"/>
		<group id="523" type="multinuc" parent="524" relname="span"/>
		<group id="524" type="span" parent="525" relname="span"/>
		<group id="525" type="span" parent="529" relname="preparation"/>
		<group id="526" type="span" parent="527" relname="same-unit"/>
		<group id="527" type="multinuc" parent="528" relname="span"/>
		<group id="528" type="span" parent="529" relname="span"/>
		<group id="529" type="span" parent="530" relname="span"/>
		<group id="530" type="span" parent="632" relname="span"/>
		<group id="531" type="multinuc" parent="534" relname="span"/>
		<group id="532" type="multinuc" parent="533" relname="contrast"/>
		<group id="533" type="multinuc" parent="531" relname="joint"/>
		<group id="534" type="span" parent="535" relname="span"/>
		<group id="535" type="span" parent="530" relname="elaboration"/>
		<group id="536" type="multinuc" parent="537" relname="span"/>
		<group id="537" type="span" parent="538" relname="span"/>
		<group id="538" type="span" parent="543" relname="span"/>
		<group id="539" type="multinuc" parent="542" relname="joint"/>
		<group id="540" type="multinuc" parent="542" relname="joint"/>
		<group id="541" type="span" parent="540" relname="joint"/>
		<group id="542" type="multinuc" parent="538" relname="elaboration"/>
		<group id="543" type="span" parent="544" relname="span"/>
		<group id="544" type="span" parent="550" relname="joint"/>
		<group id="545" type="span" parent="546" relname="comparison"/>
		<group id="546" type="multinuc" parent="550" relname="joint"/>
		<group id="547" type="span" parent="549" relname="comparison"/>
		<group id="548" type="span" parent="549" relname="comparison"/>
		<group id="549" type="multinuc" parent="633" relname="span"/>
		<group id="550" type="multinuc" />
		<group id="551" type="multinuc" parent="633" relname="elaboration"/>
		<group id="552" type="span" parent="554" relname="preparation"/>
		<group id="553" type="span" parent="256" relname="purpose"/>
		<group id="554" type="span" parent="555" relname="span"/>
		<group id="555" type="span" parent="557" relname="contrast"/>
		<group id="556" type="span" parent="558" relname="joint"/>
		<group id="557" type="multinuc" parent="561" relname="joint"/>
		<group id="558" type="multinuc" parent="559" relname="span"/>
		<group id="559" type="span" parent="560" relname="span"/>
		<group id="560" type="span" parent="561" relname="joint"/>
		<group id="561" type="multinuc" />
		<group id="562" type="multinuc" parent="266" relname="elaboration"/>
		<group id="563" type="span" parent="566" relname="joint"/>
		<group id="564" type="multinuc" parent="565" relname="restatement"/>
		<group id="565" type="multinuc" parent="566" relname="joint"/>
		<group id="566" type="multinuc" parent="265" relname="evidence"/>
		<group id="567" type="span" />
		<group id="568" type="span" parent="274" relname="elaboration"/>
		<group id="569" type="span" parent="638" relname="span"/>
		<group id="570" type="multinuc" parent="569" relname="elaboration"/>
		<group id="571" type="span" parent="572" relname="span"/>
		<group id="572" type="span" parent="663" relname="span"/>
		<group id="573" type="span" parent="572" relname="purpose"/>
		<group id="574" type="multinuc" parent="663" relname="elaboration"/>
		<group id="575" type="multinuc" parent="576" relname="span"/>
		<group id="576" type="span" parent="577" relname="span"/>
		<group id="577" type="span" parent="578" relname="joint"/>
		<group id="578" type="multinuc" />
		<group id="579" type="span" parent="582" relname="span"/>
		<group id="580" type="multinuc" parent="581" relname="sequence"/>
		<group id="581" type="multinuc" parent="579" relname="elaboration"/>
		<group id="582" type="span" />
		<group id="583" type="span" parent="584" relname="joint"/>
		<group id="584" type="multinuc" parent="298" relname="elaboration"/>
		<group id="585" type="span" parent="642" relname="span"/>
		<group id="586" type="span" parent="589" relname="preparation"/>
		<group id="587" type="multinuc" parent="588" relname="contrast"/>
		<group id="588" type="multinuc" parent="589" relname="span"/>
		<group id="589" type="span" parent="590" relname="span"/>
		<group id="590" type="span" parent="597" relname="span"/>
		<group id="591" type="multinuc" parent="596" relname="joint"/>
		<group id="592" type="span" parent="593" relname="contrast"/>
		<group id="593" type="multinuc" parent="594" relname="span"/>
		<group id="594" type="span" parent="595" relname="span"/>
		<group id="595" type="span" parent="596" relname="joint"/>
		<group id="596" type="multinuc" parent="590" relname="elaboration"/>
		<group id="597" type="span" />
		<group id="598" type="multinuc" parent="317" relname="elaboration"/>
		<group id="599" type="span" parent="600" relname="span"/>
		<group id="600" type="span" parent="645" relname="span"/>
		<group id="601" type="multinuc" parent="600" relname="elaboration"/>
		<group id="602" type="span" parent="605" relname="joint"/>
		<group id="603" type="span" parent="604" relname="span"/>
		<group id="604" type="span" parent="605" relname="joint"/>
		<group id="605" type="multinuc" parent="326" relname="evidence"/>
		<group id="606" type="multinuc" parent="607" relname="joint"/>
		<group id="607" type="multinuc" parent="614" relname="joint"/>
		<group id="608" type="span" parent="337" relname="evidence"/>
		<group id="609" type="span" parent="336" relname="concession"/>
		<group id="610" type="span" parent="611" relname="contrast"/>
		<group id="611" type="multinuc" parent="612" relname="span"/>
		<group id="612" type="span" parent="613" relname="span"/>
		<group id="613" type="span" parent="614" relname="joint"/>
		<group id="614" type="multinuc" />
		<group id="615" type="span" parent="368" relname="joint"/>
		<group id="616" type="span" parent="617" relname="span"/>
		<group id="617" type="span" />
		<group id="618" type="multinuc" parent="380" relname="span"/>
		<group id="619" type="span" />
		<group id="620" type="span" parent="399" relname="contrast"/>
		<group id="621" type="multinuc" parent="421" relname="span"/>
		<group id="622" type="span" parent="621" relname="contrast"/>
		<group id="623" type="span" parent="440" relname="contrast"/>
		<group id="624" type="span" parent="445" relname="evaluation"/>
		<group id="625" type="span" parent="626" relname="span"/>
		<group id="626" type="span" />
		<group id="627" type="span" parent="628" relname="span"/>
		<group id="628" type="span" parent="629" relname="span"/>
		<group id="629" type="span" parent="631" relname="span"/>
		<group id="630" type="multinuc" parent="629" relname="elaboration"/>
		<group id="631" type="span" />
		<group id="632" type="span" />
		<group id="633" type="span" parent="634" relname="span"/>
		<group id="634" type="span" parent="635" relname="span"/>
		<group id="635" type="span" parent="636" relname="span"/>
		<group id="636" type="span" />
		<group id="637" type="multinuc" parent="557" relname="contrast"/>
		<group id="638" type="span" parent="639" relname="span"/>
		<group id="639" type="span" parent="640" relname="span"/>
		<group id="640" type="span" />
		<group id="641" type="multinuc" parent="585" relname="elaboration"/>
		<group id="642" type="span" parent="643" relname="span"/>
		<group id="643" type="span" parent="644" relname="span"/>
		<group id="644" type="span" />
		<group id="645" type="span" parent="646" relname="span"/>
		<group id="646" type="span" parent="647" relname="span"/>
		<group id="647" type="span" />
		<group id="648" type="span" parent="649" relname="span"/>
		<group id="649" type="span" parent="614" relname="joint"/>
		<group id="650" type="span" parent="93" relname="elaboration"/>
		<group id="651" type="span" parent="437" relname="span"/>
		<group id="652" type="span" parent="653" relname="span"/>
		<group id="653" type="span" parent="654" relname="span"/>
		<group id="654" type="span" />
		<group id="655" type="span" parent="119" relname="elaboration"/>
		<group id="656" type="span" parent="444" relname="cause"/>
		<group id="657" type="span" parent="469" relname="elaboration"/>
		<group id="658" type="span" parent="659" relname="joint"/>
		<group id="659" type="multinuc" parent="518" relname="contrast"/>
		<group id="660" type="span" parent="661" relname="comparison"/>
		<group id="661" type="multinuc" parent="562" relname="joint"/>
		<group id="662" type="span" parent="573" relname="span"/>
		<group id="663" type="span" parent="664" relname="span"/>
		<group id="664" type="span" parent="578" relname="joint"/>
		<group id="665" type="span" parent="580" relname="sequence"/>
		<group id="666" type="multinuc" parent="507" relname="evaluation"/>
		<group id="667" type="multinuc" parent="368" relname="joint"/>
		<group id="668" type="span" parent="667" relname="joint"/>
		<group id="669" type="span" parent="343" relname="span"/>
		<group id="677" type="span" parent="445" relname="span"/>
		<group id="678" type="multinuc" parent="679" relname="span"/>
		<group id="679" type="span" parent="680" relname="span"/>
		<group id="680" type="span" />
	</body>
</rst>