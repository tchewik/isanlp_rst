<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://ru-travel.livejournal.com/33778768.html</segment>
		<segment id="2" >Покупка отзывов на Букинге</segment>
		<segment id="3" parent="100" relname="span">Букинг позволяет написать отзыв об отеле</segment>
		<segment id="4" parent="3" relname="condition">только после подтвержденного проживания в нем.</segment>
		<segment id="5" parent="101" relname="joint">Это должно уберечь</segment>
		<segment id="6" parent="101" relname="joint">и уберегает от сверхположительных нахваливаний владельцев и поливания грязью конкурентов.</segment>
		<segment id="7" parent="161" relname="contrast">Но, как выяснилось, купить можно всё, в том числе и эти отзывы.</segment>
		<segment id="8" parent="103" relname="elaboration">IMG</segment>
		<segment id="9" parent="104" relname="sequence">Жилье в Лиссабоне мы выбирали в диапазоне до 55 евро/ночь для 2х человек,</segment>
		<segment id="10" parent="104" relname="sequence">сперва смотрели отдельные квартиры на Эйрбнб.</segment>
		<segment id="11" parent="105" relname="contrast">Но в центре были только варианты со входом с улицы, на первом или полуподвальном этаже, или совсем грустные по обстановке.</segment>
		<segment id="12" parent="163" relname="span">Поэтому когда я на Букинге увидел Гестхауз практически на Маркиз Помбал с балконом, кухонным уголком и своими удобствами, чуть дороже 40 евро при невозвратной брони –</segment>
		<segment id="13" parent="106" relname="span">выбор был сделан в его пользу.</segment>
		<segment id="14" parent="110" relname="span">Тем более, что у нас был удачный опыт бронирования таких квартир в Варшаве (отдельная квартира в хостеле) и в Люблине (просто отдельная квартира в доме).</segment>
		<segment id="15" parent="109" relname="sequence">Что-то похожее мы рассматривали и в Берлине,</segment>
		<segment id="16" parent="109" relname="sequence">но потом нашли квартиру.</segment>
		<segment id="17" parent="111" relname="evaluation">В общем, ничего не предвещало неожиданности.</segment>
		<segment id="18" parent="116" relname="joint">За первую ночь (из восьми) деньги были сняты на следующий день после бронирования,</segment>
		<segment id="19" parent="115" relname="span">с сотрудниками была нормальная переписка по техническим вопросам:</segment>
		<segment id="20" parent="114" relname="joint">первая карта не прошла,</segment>
		<segment id="21" parent="205" relname="attribution">мы уточняли,</segment>
		<segment id="22" parent="202" relname="joint">как нас встретят</segment>
		<segment id="23" parent="202" relname="joint">и как найти отель.</segment>
		<segment id="24" parent="118" relname="sequence">В отель мы добрались около полуночи.</segment>
		<segment id="25" parent="117" relname="sequence">С нас сразу сняли деньги за оставшиеся ночи,</segment>
		<segment id="26" parent="164" relname="span">а потом показали номер.</segment>
		<segment id="27" parent="121" relname="joint">В нем из обещанного был только балкон…</segment>
		<segment id="28" parent="120" relname="joint">Удобства общие,</segment>
		<segment id="29" parent="120" relname="joint">кухня одна на всех.</segment>
		<segment id="30" parent="122" relname="span">Скорей всего, мы не первые,</segment>
		<segment id="31" parent="30" relname="elaboration">кто офигевал от увиденного,</segment>
		<segment id="32" parent="122" relname="cause">т.к. на ресепшне была распечатка страницы букинга с подчёркнутыми общими удобствами.</segment>
		<segment id="33" parent="188" relname="span">На утро я поговорил с владельцем,</segment>
		<segment id="34" parent="33" relname="elaboration">который экспрессивно объяснил,</segment>
		<segment id="35" parent="126" relname="joint">что рядом Риц, Шератон и прочие отели с удобствами в номере и ценой от 100 евро,</segment>
		<segment id="36" parent="125" relname="span">и это Лиссабон,</segment>
		<segment id="37" parent="124" relname="joint">в котором не бывает цен по 40 евро за номер с удобствами в номере в таком месте,</segment>
		<segment id="38" parent="123" relname="span">и это должно было быть понятно</segment>
		<segment id="39" parent="38" relname="condition">при бронировании.</segment>
		<segment id="40" parent="208" relname="attribution">Я объяснял,</segment>
		<segment id="41" parent="42" relname="attribution">что на Букинге написано</segment>
		<segment id="42" parent="191" relname="span">наличие кухни и туалета в описании номера,</segment>
		<segment id="43" parent="127" relname="span">и поэтому я на них рассчитываю.</segment>
		<segment id="44" parent="193" relname="attribution">Владелец сказал,</segment>
		<segment id="45" parent="128" relname="restatement">что у него вообще нет номеров с удобствами,</segment>
		<segment id="46" parent="128" relname="restatement">т.е. переселить нас даже за доплату некуда.</segment>
		<segment id="47" parent="177" relname="same-unit">Ему</segment>
		<segment id="48" parent="49" relname="condition">во время нашего разговора</segment>
		<segment id="49" parent="176" relname="span">дозвониться до букинга не удалось.</segment>
		<segment id="50" parent="130" relname="joint">По итогам я написал жалобу в букинг</segment>
		<segment id="51" parent="129" relname="span">и начал смотреть варианты Эйрбнб,</segment>
		<segment id="52" parent="51" relname="evaluation">которых было очень мало.</segment>
		<segment id="53" parent="204" relname="joint">В середине дня я дозвонился до букинга</segment>
		<segment id="54" parent="204" relname="joint">и объяснил ситуацию,</segment>
		<segment id="55" parent="133" relname="attribution">на что мне ответили,</segment>
		<segment id="56" parent="132" relname="joint">что свяжутся с отелем</segment>
		<segment id="57" parent="132" relname="joint">и предложат решение.</segment>
		<segment id="58" parent="138" relname="span">После первого шока мы посмотрели на отель –</segment>
		<segment id="59" parent="137" relname="span">он был не просто чистый,</segment>
		<segment id="60" parent="59" relname="evaluation">а можно сказать вылизанный.</segment>
		<segment id="61" parent="139" relname="joint">На кухне все было чисто,</segment>
		<segment id="62" parent="139" relname="joint">было много утвари,</segment>
		<segment id="63" parent="140" relname="span">можно было готовить,</segment>
		<segment id="64" parent="63" relname="elaboration">как мы и планировали.</segment>
		<segment id="65" parent="195" relname="preparation">Вечером мне перезвонил Букинг</segment>
		<segment id="66" parent="194" relname="attribution">и сказал,</segment>
		<segment id="67" parent="194" relname="span">что они не могут ничего компенсировать через владельца,</segment>
		<segment id="68" parent="67" relname="cause">т.к. в описании номера присутствуют общие удобства.</segment>
		<segment id="69" parent="142" relname="span">А потом сам хозяин предложил мне скидку от себя лично</segment>
		<segment id="70" parent="69" relname="condition">с условием, что я напишу хороший отзыв про отель.</segment>
		<segment id="71" parent="72" relname="attribution">Я сказал,</segment>
		<segment id="72" parent="209" relname="span">что подумаю до завтрашнего утра.</segment>
		<segment id="73" parent="144" relname="comparison">В итоге, посчитав, что скидка больше чем в 40 евро лучше</segment>
		<segment id="74" parent="180" relname="span">чем съезжать</segment>
		<segment id="75" parent="74" relname="condition">без компенсации</segment>
		<segment id="76" parent="143" relname="joint">и платить 250-300 за неизвестно что не в таком центровом месте,</segment>
		<segment id="77" parent="145" relname="span">мы решили принять предложение.</segment>
		<segment id="78" parent="182" relname="same-unit">На следующий день,</segment>
		<segment id="79" parent="80" relname="condition">при передаче денег,</segment>
		<segment id="80" parent="181" relname="span">мне было эмоционально сказано,</segment>
		<segment id="81" parent="147" relname="joint">что он мне доверяет</segment>
		<segment id="82" parent="147" relname="joint">и не берет расписки,</segment>
		<segment id="83" parent="148" relname="joint">но я должен сдержать свое обещание</segment>
		<segment id="84" parent="148" relname="joint">и написать хороший отзыв.</segment>
		<segment id="85" parent="174" relname="span">Дальнейшие дни мы прожили без приключений.</segment>
		<segment id="86" parent="85" relname="elaboration">На фото – вид с балкона номера, бокалы из общей зоны.</segment>
		<segment id="87" parent="157" relname="span">Вот так покупаются отзывы на Букинге.</segment>
		<segment id="88" parent="87" relname="evaluation">Никогда не думал, что это возможно.</segment>
		<segment id="89" parent="155" relname="span">По понятным причинам, название отеля указывать не буду.</segment>
		<segment id="90" parent="150" relname="joint">Отзыв я написал, корректный,</segment>
		<segment id="91" parent="150" relname="joint">и в нем указал о моих ожиданиях.</segment>
		<segment id="92" parent="156" relname="span">В Букинг про некорректное описание больше не обращался.</segment>
		<segment id="93" parent="151" relname="span">Предпримут ли они что—то по первому обращению,</segment>
		<segment id="94" parent="93" relname="evaluation">не знаю.</segment>
		<segment id="95" parent="152" relname="span">Сейчас в описании номера я вижу только общие удобства,</segment>
		<segment id="96" parent="95" relname="evaluation">как и должно быть.</segment>
		<segment id="97" parent="154" relname="contrast">Но общие кухонные принадлежности из описания номера не удалены.</segment>
		<segment id="98" parent="153" relname="joint">А какой системе отзывов больше доверяете вы?</segment>
		<segment id="99" parent="153" relname="joint">Что вас не устраивает в отзывах Букинга?</segment>
		<group id="100" type="span" parent="102" relname="cause"/>
		<group id="101" type="multinuc" parent="161" relname="contrast"/>
		<group id="102" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="162" relname="span"/>
		<group id="104" type="multinuc" parent="105" relname="contrast"/>
		<group id="105" type="multinuc" parent="107" relname="span"/>
		<group id="106" type="span" parent="108" relname="span"/>
		<group id="107" type="span" parent="12" relname="cause"/>
		<group id="108" type="span" parent="111" relname="span"/>
		<group id="109" type="multinuc" parent="14" relname="evidence"/>
		<group id="110" type="span" parent="108" relname="evidence"/>
		<group id="111" type="span" parent="112" relname="span"/>
		<group id="112" type="span" />
		<group id="114" type="multinuc" parent="19" relname="evidence"/>
		<group id="115" type="span" parent="116" relname="joint"/>
		<group id="116" type="multinuc" />
		<group id="117" type="multinuc" parent="118" relname="sequence"/>
		<group id="118" type="multinuc" parent="119" relname="span"/>
		<group id="119" type="span" parent="166" relname="span"/>
		<group id="120" type="multinuc" parent="121" relname="joint"/>
		<group id="121" type="multinuc" parent="26" relname="elaboration"/>
		<group id="122" type="span" parent="165" relname="span"/>
		<group id="123" type="span" parent="124" relname="joint"/>
		<group id="124" type="multinuc" parent="36" relname="elaboration"/>
		<group id="125" type="span" parent="126" relname="joint"/>
		<group id="126" type="multinuc" parent="189" relname="span"/>
		<group id="127" type="span" parent="208" relname="span"/>
		<group id="128" type="multinuc" parent="193" relname="span"/>
		<group id="129" type="span" parent="130" relname="joint"/>
		<group id="130" type="multinuc" parent="136" relname="sequence"/>
		<group id="132" type="multinuc" parent="133" relname="span"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" parent="135" relname="sequence"/>
		<group id="135" type="multinuc" parent="136" relname="sequence"/>
		<group id="136" type="multinuc" />
		<group id="137" type="span" parent="58" relname="elaboration"/>
		<group id="138" type="span" parent="141" relname="span"/>
		<group id="139" type="multinuc" parent="138" relname="evidence"/>
		<group id="140" type="span" parent="139" relname="joint"/>
		<group id="141" type="span" parent="136" relname="sequence"/>
		<group id="142" type="span" parent="146" relname="sequence"/>
		<group id="143" type="multinuc" parent="144" relname="comparison"/>
		<group id="144" type="multinuc" parent="77" relname="cause"/>
		<group id="145" type="span" parent="171" relname="span"/>
		<group id="146" type="multinuc" parent="171" relname="solutionhood"/>
		<group id="147" type="multinuc" parent="149" relname="contrast"/>
		<group id="148" type="multinuc" parent="149" relname="contrast"/>
		<group id="149" type="multinuc" parent="210" relname="span"/>
		<group id="150" type="multinuc" parent="89" relname="elaboration"/>
		<group id="151" type="span" parent="92" relname="elaboration"/>
		<group id="152" type="span" parent="154" relname="contrast"/>
		<group id="153" type="multinuc" />
		<group id="154" type="multinuc" parent="156" relname="evidence"/>
		<group id="155" type="span" parent="159" relname="joint"/>
		<group id="156" type="span" parent="158" relname="span"/>
		<group id="157" type="span" parent="160" relname="span"/>
		<group id="158" type="span" parent="159" relname="joint"/>
		<group id="159" type="multinuc" parent="157" relname="elaboration"/>
		<group id="160" type="span" parent="175" relname="span"/>
		<group id="161" type="multinuc" parent="102" relname="span"/>
		<group id="162" type="span" />
		<group id="163" type="span" parent="13" relname="cause"/>
		<group id="164" type="span" parent="117" relname="sequence"/>
		<group id="165" type="span" parent="119" relname="evaluation"/>
		<group id="166" type="span" />
		<group id="167" type="multinuc" parent="168" relname="span"/>
		<group id="168" type="span" parent="169" relname="span"/>
		<group id="169" type="span" />
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" parent="173" relname="span"/>
		<group id="173" type="span" />
		<group id="174" type="span" parent="160" relname="preparation"/>
		<group id="175" type="span" />
		<group id="176" type="span" parent="177" relname="same-unit"/>
		<group id="177" type="multinuc" parent="184" relname="elaboration"/>
		<group id="180" type="span" parent="143" relname="joint"/>
		<group id="181" type="span" parent="182" relname="same-unit"/>
		<group id="182" type="multinuc" parent="210" relname="attribution"/>
		<group id="184" type="span" parent="185" relname="span"/>
		<group id="185" type="span" parent="167" relname="contrast"/>
		<group id="188" type="span" parent="189" relname="attribution"/>
		<group id="189" type="span" parent="190" relname="span"/>
		<group id="190" type="span" parent="168" relname="preparation"/>
		<group id="191" type="span" parent="43" relname="cause"/>
		<group id="193" type="span" parent="184" relname="span"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" parent="196" relname="span"/>
		<group id="196" type="span" parent="146" relname="sequence"/>
		<group id="202" type="multinuc" parent="205" relname="span"/>
		<group id="204" type="multinuc" parent="135" relname="sequence"/>
		<group id="205" type="span" parent="206" relname="span"/>
		<group id="206" type="span" parent="114" relname="joint"/>
		<group id="207" type="span" parent="167" relname="contrast"/>
		<group id="208" type="span" parent="207" relname="span"/>
		<group id="209" type="span" parent="146" relname="sequence"/>
		<group id="210" type="span" parent="211" relname="span"/>
		<group id="211" type="span" parent="172" relname="evaluation"/>
	</body>
</rst>