<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://putnik1.livejournal.com/7594285.html#cutid1</segment>
		<segment id="2" >КВАНТУНСКАЯ ВОЛОСТЬ</segment>
		<segment id="3" parent="101" relname="elaboration">IMG-TXT</segment>
		<segment id="4" parent="100" relname="preparation">Для начала констатируем очевидное:</segment>
		<segment id="5" parent="6" relname="condition">если даже в самые хорошие, самые скрепные времена Россия экспортировала в развитые страны только сырье, лес и сельхозпродукты,</segment>
		<segment id="6" parent="49" relname="span">то сейчас, как видим, целых 5.9% российского экспорта составляют продукты отечественного производства,</segment>
		<segment id="7" parent="49" relname="evaluation">- и это бесспорное свидетельство прорыва в дестилетие ярких побед.</segment>
		<segment id="8" parent="50" relname="elaboration">Из чего и будем исходить...</segment>
		<segment id="9" parent="54" relname="span">IMG-TXT</segment>
		<segment id="10" parent="9" relname="evaluation">На мой взгляд, точка зрения уважаемого Владимира Федорова и тональность развернувшейся вокруг неё дискуссии выдержаны в излишне скептических тонах.</segment>
		<segment id="11" parent="85" relname="same-unit">На самом же деле,</segment>
		<segment id="12" parent="13" relname="condition">даже если все так,</segment>
		<segment id="13" parent="86" relname="span">повода ни для скепсиса, ни для негатива нет.</segment>
		<segment id="14" parent="56" relname="joint">Договор об аренде заключен в законном порядке законной властью,</segment>
		<segment id="15" parent="55" relname="joint">а право законного владельца продавать,</segment>
		<segment id="16" parent="55" relname="joint">дарить,</segment>
		<segment id="17" parent="55" relname="joint">отчуждать</segment>
		<segment id="18" parent="55" relname="joint">или сдавать в аренду свою собственность несомненно.</segment>
		<segment id="19" parent="58" relname="same-unit">Особым же придирам, которые заявят, что владелец сибирских гектаров со всеми их угодьям все-таки не власть,</segment>
		<segment id="20" parent="97" relname="restatement">а население Российской Федерации,</segment>
		<segment id="21" parent="97" relname="restatement">именуемое также народом,</segment>
		<segment id="22" parent="58" relname="same-unit">следует принять во внимание тот факт,</segment>
		<segment id="23" parent="24" relname="cause">что упомянутое население (народ) на всех последних выборах подтвердил полномочия именно данной власти,</segment>
		<segment id="24" parent="60" relname="span">тем самым выписав ей генеральную доверенность на решение всех вопросов,</segment>
		<segment id="25" parent="61" relname="span">а следовательно, заранее одобрил все ее решения, в том числе, и это.</segment>
		<segment id="26" parent="67" relname="span">Таким образом, юридически все тип-топ, и в политическом ракурсе тоже.</segment>
		<segment id="27" parent="65" relname="span">В конце концов, абсолютно идентичный договор имел место в хорошие, скрепные времена,</segment>
		<segment id="28" parent="64" relname="joint">когда Китай обижали злые соседи,</segment>
		<segment id="29" parent="64" relname="joint">и он рассчитывал на помощь России.</segment>
		<segment id="30" parent="66" relname="comparison">Сейчас то же самое, только функции сторон изменились.</segment>
		<segment id="31" parent="90" relname="span">И наконец, о "стеклянных бусах".</segment>
		<segment id="32" parent="87" relname="span">Уважаемый Владимир Федоров,</segment>
		<segment id="33" parent="32" relname="evaluation">- это ясно,</segment>
		<segment id="34" parent="35" relname="attribution">- намекает</segment>
		<segment id="35" parent="89" relname="span">на  продажу индейцами голландцам целого Манхеттена за кучу ширпотреба,</segment>
		<segment id="36" parent="79" relname="restatement">подразумевая, что "российские дикари" отдают ценнейшие угодья в обмен на двух красивых, но бессмысленных животных,</segment>
		<segment id="37" parent="80" relname="contrast">- и он не прав:</segment>
		<segment id="38" parent="71" relname="span">во-первых, ценность любого товара относительна.</segment>
		<segment id="39" parent="68" relname="span">Для индейцев островок никакой ценности не представлял</segment>
		<segment id="40" parent="39" relname="cause">(земли у них было немеряно),</segment>
		<segment id="41" parent="69" relname="comparison">"бусы" же, кроме как у голландцев, взять было неоткуда,</segment>
		<segment id="42" parent="91" relname="comparison">- и точно так же у Москвы "сибирских гектаров" хоть жопой ешь,</segment>
		<segment id="43" parent="91" relname="comparison">тогда как панды в глухом дефиците,</segment>
		<segment id="44" parent="72" relname="contrast">а во-вторых, - и это главное, - Манхэттен индейцы продали навсегда,</segment>
		<segment id="45" parent="72" relname="contrast">а тут речь об аренде.</segment>
		<segment id="46" parent="92" relname="sequence">Через 15 лет зверушки (или то, что от них останется) вернутся в Пекин,</segment>
		<segment id="47" parent="92" relname="sequence">а через 40 лет китайцы  вернут "сибирские гектары" (с тем, что там останется) Российской Федерации или ее законному правопреемнику...</segment>
		<group id="49" type="span" parent="50" relname="span"/>
		<group id="50" type="span" parent="100" relname="span"/>
		<group id="54" type="span" parent="76" relname="contrast"/>
		<group id="55" type="multinuc" parent="56" relname="joint"/>
		<group id="56" type="multinuc" parent="63" relname="contrast"/>
		<group id="58" type="multinuc" parent="59" relname="span"/>
		<group id="59" type="span" parent="62" relname="span"/>
		<group id="60" type="span" parent="25" relname="cause"/>
		<group id="61" type="span" parent="59" relname="elaboration"/>
		<group id="62" type="span" parent="63" relname="contrast"/>
		<group id="63" type="multinuc" parent="83" relname="span"/>
		<group id="64" type="multinuc" parent="27" relname="elaboration"/>
		<group id="65" type="span" parent="66" relname="comparison"/>
		<group id="66" type="multinuc" parent="26" relname="evidence"/>
		<group id="67" type="span" parent="83" relname="evaluation"/>
		<group id="68" type="span" parent="69" relname="comparison"/>
		<group id="69" type="multinuc" parent="70" relname="comparison"/>
		<group id="70" type="multinuc" parent="38" relname="elaboration"/>
		<group id="71" type="span" parent="75" relname="joint"/>
		<group id="72" type="multinuc" parent="73" relname="span"/>
		<group id="73" type="span" parent="74" relname="span"/>
		<group id="74" type="span" parent="75" relname="joint"/>
		<group id="75" type="multinuc" parent="81" relname="cause"/>
		<group id="76" type="multinuc" parent="77" relname="span"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" />
		<group id="79" type="multinuc" parent="31" relname="elaboration"/>
		<group id="80" type="multinuc" parent="81" relname="span"/>
		<group id="81" type="span" parent="82" relname="span"/>
		<group id="82" type="span" />
		<group id="83" type="span" parent="84" relname="span"/>
		<group id="84" type="span" parent="77" relname="elaboration"/>
		<group id="85" type="multinuc" parent="76" relname="contrast"/>
		<group id="86" type="span" parent="85" relname="same-unit"/>
		<group id="87" type="span" parent="88" relname="same-unit"/>
		<group id="88" type="multinuc" parent="79" relname="restatement"/>
		<group id="89" type="span" parent="88" relname="same-unit"/>
		<group id="90" type="span" parent="80" relname="contrast"/>
		<group id="91" type="multinuc" parent="70" relname="comparison"/>
		<group id="92" type="multinuc" parent="73" relname="elaboration"/>
		<group id="97" type="multinuc" parent="58" relname="same-unit"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" parent="102" relname="span"/>
		<group id="102" type="span" />
	</body>
</rst>