<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://spoon.com.ua/2018/07/milk/</segment>
		<segment id="2" >Молочные продукты IMG</segment>
		<segment id="3" parent="70" relname="span">Становиться орторексиком,</segment>
		<segment id="4" parent="3" relname="elaboration">исключая целые группы продуктов,</segment>
		<segment id="5" parent="73" relname="span">чтобы сделать свое питание “чистым” на всякий случай</segment>
		<segment id="6" parent="7" relname="cause">(“все исключают сахар и молоко,</segment>
		<segment id="7" parent="72" relname="span">я тоже исключу!”)</segment>
		<segment id="8" parent="71" relname="evaluation">– плохо.</segment>
		<segment id="9" parent="75" relname="joint">Молоко незаслуженно попадает под раздачу</segment>
		<segment id="10" parent="75" relname="joint">и становится героем сотен статей с негативным подтекстом.</segment>
		<segment id="11" parent="76" relname="span">Исследований на тему “пить или не пить животное молоко” сейчас масса</segment>
		<segment id="12" parent="11" relname="evaluation">и впечатляющие резюме есть как у сторонников, так и у противников молока.</segment>
		<segment id="13" parent="14" relname="attribution">У современной диетологии пока ответ простой:</segment>
		<segment id="14" parent="80" relname="span">все зависит от состояния вашего здоровья.</segment>
		<segment id="15" parent="82" relname="contrast">Плюсы: легкий белок, кальций, витамин D.</segment>
		<segment id="16" parent="84" relname="span">Минусы: крайне распространенная</segment>
		<segment id="17" parent="83" relname="restatement">(у 40-50% людей взрослых среднего возраста,</segment>
		<segment id="18" parent="83" relname="restatement">то есть у каждого второго)</segment>
		<segment id="19" parent="85" relname="sequence">нетолерантность к лактозе и усугубление заболеваний ЖКТ (воспалений слизистых оболочек, язв).</segment>
		<segment id="20" parent="86" relname="contrast">Но давайте по порядку.</segment>
		<segment id="21" parent="88" relname="joint">Молочные продукты хороши</segment>
		<segment id="22" parent="89" relname="span">и могут присутствовать в рационе здорового человека в размере 1-2 порций в день</segment>
		<segment id="23" parent="22" relname="elaboration">(порция – это 150 г творога, или 250 мл йогурта, или кефира без добавок, или 250 мл молока – до одной порции, или 75 г творожного сыра или выдержанный сыр, кусочек размером с указательный палец).</segment>
		<segment id="24" parent="90" relname="span">У отказа от молока может быть несколько весомых причин,</segment>
		<segment id="25" parent="24" relname="condition">даже при крепком здоровье в целом.</segment>
		<segment id="26" parent="90" relname="cause">Это аллергия на молоко, пищевая чувствительность или непереносимость молока и соблюдение особых систем питания, например, веганского рациона по внутренним убеждениям. IMG</segment>
		<segment id="27" parent="94" relname="cause">Молоко – вовсе не напиток, а полноценная еда.</segment>
		<segment id="28" parent="93" relname="joint">Об этом стоит помнить тем, кто его употребляет</segment>
		<segment id="29" parent="93" relname="joint">и не заливать капучино сверху на плотный прием еды.</segment>
		<segment id="30" parent="96" relname="joint">Молоко не отличается хорошей сочетаемостью с другими продуктами</segment>
		<segment id="31" parent="96" relname="joint">и достаточно калорийно.</segment>
		<segment id="32" parent="98" relname="joint">Однако ценим молоко за легкоусваиваемый белок и кальций. За вкус и многообразие продуктов из молока коров, коз, буйволиц и прочих.</segment>
		<segment id="33" parent="98" relname="joint">Уважаем молоко за содержание насыщенных жиров</segment>
		<segment id="34" parent="99" relname="span">и корректно пересматриваем порцию жирных молочных продуктов в своей тарелке.</segment>
		<segment id="35" parent="102" relname="joint">Но есть ситуации, когда мы вынуждены</segment>
		<segment id="36" parent="102" relname="joint">или хотим заменить его.</segment>
		<segment id="37" parent="120" relname="preparation">Аллергия на молоко – это чаще всего непереносимость казеина, молочного белка.</segment>
		<segment id="38" parent="119" relname="joint">Люди с аллергией не могут употреблять ни цельное молоко, ни кисломолочные продукты.</segment>
		<segment id="39" parent="40" relname="cause">Более того, казеин молочного белка структурно похож на глютен, белок в зерновых.</segment>
		<segment id="40" parent="106" relname="span">Поэтому люди с чувствительностью к клейковине могут иметь проблемы с казеином и молочными продуктами.</segment>
		<segment id="41" parent="42" relname="condition">Если глютен проблема для вас,</segment>
		<segment id="42" parent="107" relname="span">вероятно, у вас также будет чрезмерное воспаление в ответ на казеин.</segment>
		<segment id="43" parent="114" relname="span">А непереносимость молока – это неспособность организма усваивать лактозу, молочный сахар.</segment>
		<segment id="44" parent="108" relname="contrast">Недостаточность фермента лактаза с возрастом наступает у всех,</segment>
		<segment id="45" parent="110" relname="contrast">но кто-то спокойно пьет молоко до 60-70 лет,</segment>
		<segment id="46" parent="47" relname="evaluation">а кому-то не везет</segment>
		<segment id="47" parent="113" relname="span">и едва за 30 он начинает ту самую недостаточность чувствовать: вздутием, тяжестью в кишечнике, повышенным газообразованием и болевыми ощущениями.</segment>
		<segment id="48" parent="112" relname="contrast">Так как вместо того, чтобы корректно перевариваться в тонком кишечнике,</segment>
		<segment id="49" parent="111" relname="span">без ферментов молоко “пролетает” в сторону толстого,</segment>
		<segment id="50" parent="49" relname="background">а именно там живут газообразующие бактерии.</segment>
		<segment id="51" parent="109" relname="elaboration">Эту нетолерантность к лактозе люди будут ощущать только употребляя цельное молоко – как самостоятельный напиток или как часть кофе, десертов.</segment>
		<segment id="52" parent="118" relname="joint">Кисломолочное брожение (йогурты, творог) снижает уровень лактозы в продуктах.</segment>
		<segment id="53" parent="117" relname="span">Допустимая дневная порция молочных и кисломолочных продуктов для взрослого здорового человека – это на выбор: 250 мл йогурта или кефира, 150 г творога, 200-250 мл молока, несколько кусочков сыра (размером 1-2 указательных пальца и в два раза больше – творожного сыра).</segment>
		<segment id="54" parent="116" relname="joint">Но о сырах мы еще поговорим отдельно.</segment>
		<segment id="55" parent="116" relname="joint">И том, почему у козьих – приоритет перед коровьими.</segment>
		<segment id="56" parent="118" relname="joint">А сегодня – много “альтернативного” молока. IMG</segment>
		<segment id="57" parent="126" relname="joint">Для тех, кто хочет облегчить рацион.</segment>
		<segment id="58" parent="124" relname="contrast">И тех, кто был бы и рад,</segment>
		<segment id="59" parent="125" relname="joint">но по каким-то причинам не может</segment>
		<segment id="60" parent="125" relname="joint">или не хочет употреблять животное молоко.</segment>
		<segment id="61" parent="134" relname="span">Растительные источники – это целый новый мир.</segment>
		<segment id="62" parent="127" relname="span">Миндальное с тонким вкусом</segment>
		<segment id="63" parent="62" relname="evaluation">и, пожалуй, сейчас самое популярное.</segment>
		<segment id="64" parent="128" relname="joint">Густое маковое молоко, настоящий суперфуд!</segment>
		<segment id="65" parent="128" relname="joint">Молоко из грецкого ореха, крем из кешью, ароматное кедровое, конопляное, рисовое, овсяное.</segment>
		<segment id="66" parent="129" relname="span">Всех их можно приготовить самостоятельно.</segment>
		<segment id="67" parent="66" relname="evaluation">Это просто.</segment>
		<segment id="68" parent="130" relname="span">И ингредиентов обычно два: орех или цельная крупа и вода, все!</segment>
		<segment id="69" parent="68" relname="evaluation">Немного времени и терпения.</segment>
		<group id="70" type="span" parent="71" relname="span"/>
		<group id="71" type="span" parent="74" relname="span"/>
		<group id="72" type="span" parent="5" relname="elaboration"/>
		<group id="73" type="span" parent="70" relname="purpose"/>
		<group id="74" type="span" parent="77" relname="cause"/>
		<group id="75" type="multinuc" parent="77" relname="span"/>
		<group id="76" type="span" parent="79" relname="comparison"/>
		<group id="77" type="span" parent="78" relname="span"/>
		<group id="78" type="span" parent="79" relname="comparison"/>
		<group id="79" type="multinuc" parent="81" relname="solutionhood"/>
		<group id="80" type="span" parent="81" relname="span"/>
		<group id="81" type="span" parent="87" relname="span"/>
		<group id="82" type="multinuc" parent="86" relname="contrast"/>
		<group id="83" type="multinuc" parent="16" relname="elaboration"/>
		<group id="84" type="span" parent="85" relname="sequence"/>
		<group id="85" type="multinuc" parent="82" relname="contrast"/>
		<group id="86" type="multinuc" parent="100" relname="preparation"/>
		<group id="87" type="span" />
		<group id="88" type="multinuc" parent="91" relname="contrast"/>
		<group id="89" type="span" parent="88" relname="joint"/>
		<group id="90" type="span" parent="92" relname="span"/>
		<group id="91" type="multinuc" parent="100" relname="span"/>
		<group id="92" type="span" parent="91" relname="contrast"/>
		<group id="93" type="multinuc" parent="94" relname="span"/>
		<group id="94" type="span" parent="95" relname="span"/>
		<group id="95" type="span" parent="104" relname="preparation"/>
		<group id="96" type="multinuc" parent="97" relname="contrast"/>
		<group id="97" type="multinuc" parent="103" relname="contrast"/>
		<group id="98" type="multinuc" parent="34" relname="cause"/>
		<group id="99" type="span" parent="97" relname="contrast"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" />
		<group id="102" type="multinuc" parent="103" relname="contrast"/>
		<group id="103" type="multinuc" parent="104" relname="span"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" />
		<group id="106" type="span" parent="119" relname="joint"/>
		<group id="107" type="span" parent="119" relname="joint"/>
		<group id="108" type="multinuc" parent="43" relname="elaboration"/>
		<group id="109" type="span" parent="115" relname="span"/>
		<group id="110" type="multinuc" parent="108" relname="contrast"/>
		<group id="111" type="span" parent="112" relname="contrast"/>
		<group id="112" type="multinuc" parent="113" relname="cause"/>
		<group id="113" type="span" parent="109" relname="span"/>
		<group id="114" type="span" parent="119" relname="joint"/>
		<group id="115" type="span" parent="110" relname="contrast"/>
		<group id="116" type="multinuc" parent="53" relname="elaboration"/>
		<group id="117" type="span" parent="118" relname="joint"/>
		<group id="118" type="multinuc" parent="122" relname="span"/>
		<group id="119" type="multinuc" parent="120" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="solutionhood"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" />
		<group id="124" type="multinuc" parent="126" relname="joint"/>
		<group id="125" type="multinuc" parent="124" relname="contrast"/>
		<group id="126" type="multinuc" parent="134" relname="solutionhood"/>
		<group id="127" type="span" parent="128" relname="joint"/>
		<group id="128" type="multinuc" parent="132" relname="span"/>
		<group id="129" type="span" parent="131" relname="span"/>
		<group id="130" type="span" parent="129" relname="elaboration"/>
		<group id="131" type="span" parent="132" relname="elaboration"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" parent="61" relname="elaboration"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" />
	</body>
</rst>