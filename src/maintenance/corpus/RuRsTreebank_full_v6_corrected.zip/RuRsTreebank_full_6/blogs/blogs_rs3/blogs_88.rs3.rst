<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://maxkatz.livejournal.com/752036.html</segment>
		<segment id="2" >Преображение Петербурга — 5 примеров</segment>
		<segment id="3" parent="153" relname="preparation">Сейчас идёт сбор средств на вторую стадию Штаба Преображения Петербурга.</segment>
		<segment id="4" parent="153" relname="span">Мы собираем 500к рублей,</segment>
		<segment id="5" parent="6" relname="condition">если этот сбор будет успешным</segment>
		<segment id="6" parent="151" relname="span">— крупный жертвователь Городских Проектов добавит ещё 500к,</segment>
		<segment id="7" parent="152" relname="span">и с общим бюджетом в миллион мы сможем запустить много новых интересных проектов.</segment>
		<segment id="8" parent="156" relname="span">На данный момент собрано 186,000</segment>
		<segment id="9" parent="155" relname="contrast">— это неплохо,</segment>
		<segment id="10" parent="155" relname="contrast">но пока недостаточно.</segment>
		<segment id="11" parent="158" relname="span">Сегодня хочу вам показать проекты, которые мы уже сделали.</segment>
		<segment id="12" parent="11" relname="elaboration">Все их можно посмотреть на сайте штаба.</segment>
		<segment id="13" parent="162" relname="span">Мы стараемся делать так,</segment>
		<segment id="14" parent="160" relname="joint">чтобы каждый проект не только показывал принципы улучшения конкретного места,</segment>
		<segment id="15" parent="161" relname="span">но и мог стать примером</segment>
		<segment id="16" parent="15" relname="purpose">для работы с другими похожими пространствами.</segment>
		<segment id="17" parent="165" relname="contrast">Ясное дело, что с бюджетом в 80к рублей можно сделать лишь концепцию и красивые картиночки.</segment>
		<segment id="18" parent="252" relname="cause">Но проблемы в Петербурге настолько простые и настолько на поверхности,</segment>
		<segment id="19" parent="164" relname="joint">что совершенно очевидно, как их решать,</segment>
		<segment id="20" parent="163" relname="span">и глубоких исследований не требуется</segment>
		<segment id="21" parent="20" relname="purpose">для такой демонстрации.</segment>
		<segment id="22" parent="291" relname="preparation">Начнём с Казанского сада.</segment>
		<segment id="23" parent="290" relname="span">Это просто какой-то провал и позорище,</segment>
		<segment id="24" parent="167" relname="span">как умудрились такой красивейший собор,</segment>
		<segment id="25" parent="24" relname="background">находящийся в таком месте у всех на виду,</segment>
		<segment id="26" parent="168" relname="same-unit">превратить в тупо склад хаотично припаркованных машин</segment>
		<segment id="27" parent="290" relname="elaboration">IMG</segment>
		<segment id="28" parent="173" relname="preparation">Обратите внимание сверху справа на кнопку «показать сноски с комментариями».</segment>
		<segment id="29" parent="173" relname="span">Там можно увидеть комментарии Петербуржских архитекторов, которые делали проект.</segment>
		<segment id="30" parent="171" relname="restatement">Все проекты делают только Петербуржские архитектурные бюро,</segment>
		<segment id="31" parent="169" relname="span">то есть город,</segment>
		<segment id="32" parent="31" relname="condition">если захочет,</segment>
		<segment id="33" parent="170" relname="same-unit">прямо завтра может у них же заказать детальную проработку проекта</segment>
		<segment id="34" parent="172" relname="sequence">и уже летом существенно улучшить это пространство,</segment>
		<segment id="35" parent="293" relname="span">а на следующий год высадить и предлагаемый яблоневый сад,</segment>
		<segment id="36" parent="35" relname="condition">привезя крупномеры, например, из этого или любого другого питомника.</segment>
		<segment id="37" parent="293" relname="evidence">Вот в каталоге можно посмотреть яблони.</segment>
		<segment id="38" parent="39" relname="purpose">Это я к тому пишу,</segment>
		<segment id="39" parent="176" relname="span">что не верьте, будто это всё сложно и т.д.,</segment>
		<segment id="40" parent="41" relname="condition">если захотеть,</segment>
		<segment id="41" parent="175" relname="span">то всё можно сделать очень быстро и недорого.</segment>
		<segment id="42" parent="178" relname="joint">Пример Москвы это показывает (про быстро),</segment>
		<segment id="43" parent="178" relname="joint">а пример Нью-Йорка про недорого.</segment>
		<segment id="44" parent="45" relname="purpose">Чтобы город становился таким, как на этих картинках,</segment>
		<segment id="45" parent="179" relname="span">нужна только политическая воля,</segment>
		<segment id="46" parent="180" relname="contrast">всё остальное есть.</segment>
		<segment id="47" parent="48" relname="preparation">Но продолжим.</segment>
		<segment id="48" parent="182" relname="span">Выходы к воде это отдельная проблема в городе.</segment>
		<segment id="49" parent="185" relname="span">К своим прекрасным рекам Петербург относится как к сточным канавам в дачных кооперативах</segment>
		<segment id="50" parent="49" relname="evidence">— огораживает их будто там труба с помоями.</segment>
		<segment id="51" parent="183" relname="span">А нужно делать деревянные понтонные набережные и выходы к воде,</segment>
		<segment id="52" parent="51" relname="cause">люди это любят</segment>
		<segment id="53" parent="183" relname="elaboration">IMG</segment>
		<segment id="54" parent="188" relname="joint">Вот это реально стоит три копейки</segment>
		<segment id="55" parent="188" relname="joint">и можно сделать прямо завтра, штуку такую деревянную.</segment>
		<segment id="56" parent="189" relname="contrast">Только кому она там нужна?</segment>
		<segment id="57" parent="190" relname="span">Городские власти лопатой размахивают под камеры только перед выборами, а не перед улучшением города,</segment>
		<segment id="58" parent="57" relname="cause">поэтому около Казанского не деревянная понтонная набережная, а говно десятилетиями.</segment>
		<segment id="59" parent="60" relname="preparation">Но продолжим,</segment>
		<segment id="60" parent="193" relname="span">вот ещё пример работы с реками — канал Грибоедова.</segment>
		<segment id="61" parent="294" relname="span">Самый центр Петербурга, крутейшие исторические здания вокруг, красивейший канал.</segment>
		<segment id="62" parent="258" relname="joint">Жемчужина города,</segment>
		<segment id="63" parent="258" relname="joint">можно вешать на открытки почти каждую фотографию с этого канала.</segment>
		<segment id="64" parent="194" relname="joint">Уютные пешеходные мостики, прогуливающиеся граждане.</segment>
		<segment id="65" parent="259" relname="solutionhood">Что мы делаем с зелёной территорией, прилегающей к каналу?</segment>
		<segment id="66" parent="259" relname="span">Устраиваем там помойку!</segment>
		<segment id="67" parent="196" relname="purpose">И чтобы точно туда никто не ходил</segment>
		<segment id="68" parent="195" relname="joint">— не делаем к ней пешеходных переходов</segment>
		<segment id="69" parent="195" relname="joint">и ещё в довершении спиливаем огромные деревья, которые там стояли.</segment>
		<segment id="70" parent="197" relname="span">А надо совсем не так</segment>
		<segment id="71" parent="70" relname="elaboration">IMG</segment>
		<segment id="72" parent="266" relname="attribution">Мне периодически возмущённые великодержавные петербуржцы (ну или боты, я не знаю, но не суть) пишут в твиттере что-то такое:</segment>
		<segment id="73" parent="74" relname="solutionhood">"Коц, может о Москве подумаете?</segment>
		<segment id="74" parent="265" relname="span">Как-то без москвичей разберёмся у себя в Питере".</segment>
		<segment id="75" parent="265" relname="attribution">⚓️Игорь Морской⚓️🇷🇺 (@812Hockey) April 18, 2019</segment>
		<segment id="76" parent="210" relname="span">Что-то не очень-то разобрались!</segment>
		<segment id="77" parent="208" relname="span">Город в полном запустении находится.</segment>
		<segment id="78" parent="199" relname="joint">Каналы и реки в парковках,</segment>
		<segment id="79" parent="199" relname="joint">трамваи в пробках стоят,</segment>
		<segment id="80" parent="199" relname="joint">поля стихийных паркингов, пылища и грязища.</segment>
		<segment id="81" parent="200" relname="contrast">Это ползучее уничтожение города,</segment>
		<segment id="82" parent="200" relname="contrast">люди даже не понимают, что что-то идёт не так.</segment>
		<segment id="83" parent="201" relname="joint">Одно дерево спилили,</segment>
		<segment id="84" parent="201" relname="joint">другое кронировали,</segment>
		<segment id="85" parent="201" relname="joint">на третьей площади сделали паркинг, вокруг четвёртой забор,</segment>
		<segment id="86" parent="201" relname="joint">пятую реку забросили</segment>
		<segment id="87" parent="202" relname="span">и вот уже вместо культурной Северной Столицы</segment>
		<segment id="88" parent="87" relname="background">куда полстраны приезжает на белые ночи,</segment>
		<segment id="89" parent="203" relname="same-unit">у нас фиг знает что.</segment>
		<segment id="90" parent="91" relname="preparation">Вот ещё наш проект, Конюшенная площадь.</segment>
		<segment id="91" parent="275" relname="span">Ну что это такое?</segment>
		<segment id="92" parent="272" relname="span">Стихийный паркинг в самом центре города, с видом на Спас-на-Крови.</segment>
		<segment id="93" parent="211" relname="contrast">Это даже не парковка,</segment>
		<segment id="94" parent="212" relname="span">это просто пустырь грязный,</segment>
		<segment id="95" parent="94" relname="elaboration">откуда грязища и пылища разлетается по сторонам с машинами, которые там хаотично стоят.</segment>
		<segment id="96" parent="213" relname="span">Мы, конечно, предлагаем общественное пространство с катком, детскими площадками, лавочками и прочим</segment>
		<segment id="97" parent="96" relname="elaboration">IMG</segment>
		<segment id="98" parent="215" relname="span">Про лавочки отдельная история.</segment>
		<segment id="99" parent="214" relname="contrast">Про это проект ещё не сделали,</segment>
		<segment id="100" parent="214" relname="contrast">но скоро будет</segment>
		<segment id="101" parent="216" relname="span">— в городе их вообще нет! Ни одной лавочки, только в скверах и парках.</segment>
		<segment id="102" parent="218" relname="span">Пожилой человек не может присесть на пути в булочную,</segment>
		<segment id="103" parent="217" relname="span">нет лавочек</segment>
		<segment id="104" parent="103" relname="evaluation">хоть ты тресни.</segment>
		<segment id="105" parent="221" relname="span">Это при том, что в Петербурге есть узнаваемый городской Ленинградский диван,</segment>
		<segment id="106" parent="220" relname="joint">которых можно просто купить хоть завтра 1000 штук</segment>
		<segment id="107" parent="220" relname="joint">и расставить по городу,</segment>
		<segment id="108" parent="222" relname="span">пожилым людям стало бы намного лучше жить.</segment>
		<segment id="109" parent="223" relname="span">Но кому это интересно кроме нас с вами?</segment>
		<segment id="110" parent="109" relname="elaboration">IMG</segment>
		<segment id="111" parent="226" relname="preparation">Ладно продолжим по проектам.</segment>
		<segment id="112" parent="226" relname="span">Вот одно архитектурное бюро делает большой проект по малым рекам Петербурга,</segment>
		<segment id="113" parent="277" relname="span">которые в основном все в заброшенном состоянии находятся,</segment>
		<segment id="114" parent="113" relname="elaboration">там на берегах помойки и паркинги вместо общественных пространств.</segment>
		<segment id="115" parent="295" relname="span">Мы для примера проиллюстрировали, как могло бы быть всё на Смоленке</segment>
		<segment id="116" parent="115" relname="elaboration">IMG</segment>
		<segment id="117" parent="233" relname="span">Тут бомбануло уже у представителя Справедливой России на Васильевском Острове.</segment>
		<segment id="118" parent="282" relname="attribution">Муниципальный депутат от СР Нэлли Вавилина</segment>
		<segment id="119" parent="227" relname="joint">вместо того, чтобы порадоваться</segment>
		<segment id="120" parent="227" relname="joint">и начать требовать реализовать этот или похожий проект,</segment>
		<segment id="121" parent="228" relname="contrast">написала огромный текст на тему того, что мы совершенно неправы.</segment>
		<segment id="122" parent="230" relname="attribution">На следующий день она продолжила объяснять,</segment>
		<segment id="123" parent="229" relname="joint">какой негодяй Кац</segment>
		<segment id="124" parent="229" relname="joint">и как он плох</segment>
		<segment id="125" parent="229" relname="joint">и неправилен.</segment>
		<segment id="126" parent="234" relname="span">Ещё один проект — типичный небольшой сквер в историческом центре Петербурга,</segment>
		<segment id="127" parent="126" relname="elaboration">мы назвали его Сквер Земцова.</segment>
		<segment id="128" parent="235" relname="span">Опять заброшенное и запаркованное общественное пространство в очень крутом месте,</segment>
		<segment id="129" parent="128" relname="evidence">больно смотреть на это всё</segment>
		<segment id="130" parent="236" relname="elaboration">IMG</segment>
		<segment id="131" parent="241" relname="span">Скоро выйдут другие, уже сделанные проекты, в том числе большой по трамваю.</segment>
		<segment id="132" parent="240" relname="span">Пожалуйста, расшаривайте эти истории,</segment>
		<segment id="133" parent="239" relname="span">это важно,</segment>
		<segment id="134" parent="238" relname="joint">чтобы люди понимали, что город может выглядеть иначе</segment>
		<segment id="135" parent="238" relname="joint">и что это совсем не сложно.</segment>
		<segment id="136" parent="286" relname="span">Городская среда это такая штука, про которую люди думают, что она неизменна.</segment>
		<segment id="137" parent="242" relname="joint">Как гора у дома — вызывает неудобства</segment>
		<segment id="138" parent="242" relname="joint">и надо карабкаться,</segment>
		<segment id="139" parent="243" relname="contrast">но никто не думает о том, что эту проблему можно как-то решить.</segment>
		<segment id="140" parent="285" relname="comparison">Проблемы городской среды, паркингов и заброшенных общественных пространств воспринимаются так же — как часть неизменной среды вокруг нас.</segment>
		<segment id="141" parent="246" relname="span">Но, в отличие от горы, эту проблему решить можно и совсем несложно.</segment>
		<segment id="142" parent="143" relname="cause">Почитав про эти проблемы,</segment>
		<segment id="143" parent="244" relname="span">более 1000 человек подали заявки на выдвижение в муниципальные депутаты,</segment>
		<segment id="144" parent="287" relname="sequence">наш яблочный штаб, которым я руковожу, будет помогать им избираться.</segment>
		<segment id="145" parent="245" relname="joint">Выдвигайтесь и вы.</segment>
		<segment id="146" parent="249" relname="span">Чтобы продолжать нам делать эти проекты,</segment>
		<segment id="147" parent="146" relname="elaboration">как я писал выше,</segment>
		<segment id="148" parent="250" relname="span">нам нужно собрать 500к.</segment>
		<segment id="149" parent="251" relname="joint">Пока собрали 37% от этой суммы,</segment>
		<segment id="150" parent="251" relname="joint">поучаствовать можно тут: https://donate.city4people.ru/#</segment>
		<group id="151" type="span" parent="7" relname="cause"/>
		<group id="152" type="span" parent="4" relname="purpose"/>
		<group id="153" type="span" parent="154" relname="span"/>
		<group id="154" type="span" parent="157" relname="span"/>
		<group id="155" type="multinuc" parent="8" relname="evaluation"/>
		<group id="156" type="span" parent="154" relname="elaboration"/>
		<group id="157" type="span" parent="159" relname="joint"/>
		<group id="158" type="span" parent="159" relname="joint"/>
		<group id="159" type="multinuc" />
		<group id="160" type="multinuc" parent="13" relname="purpose"/>
		<group id="161" type="span" parent="160" relname="joint"/>
		<group id="162" type="span" parent="166" relname="span"/>
		<group id="163" type="span" parent="164" relname="joint"/>
		<group id="164" type="multinuc" parent="252" relname="span"/>
		<group id="165" type="multinuc" parent="162" relname="evaluation"/>
		<group id="166" type="span" />
		<group id="167" type="span" parent="168" relname="same-unit"/>
		<group id="168" type="multinuc" parent="23" relname="evaluation"/>
		<group id="169" type="span" parent="170" relname="same-unit"/>
		<group id="170" type="multinuc" parent="172" relname="sequence"/>
		<group id="171" type="multinuc" parent="29" relname="elaboration"/>
		<group id="172" type="multinuc" parent="171" relname="restatement"/>
		<group id="173" type="span" parent="174" relname="span"/>
		<group id="174" type="span" />
		<group id="175" type="span" parent="256" relname="span"/>
		<group id="176" type="span" parent="255" relname="contrast"/>
		<group id="177" type="span" parent="181" relname="span"/>
		<group id="178" type="multinuc" parent="175" relname="evidence"/>
		<group id="179" type="span" parent="180" relname="contrast"/>
		<group id="180" type="multinuc" parent="177" relname="elaboration"/>
		<group id="181" type="span" />
		<group id="182" type="span" parent="187" relname="span"/>
		<group id="183" type="span" parent="184" relname="span"/>
		<group id="184" type="span" parent="257" relname="span"/>
		<group id="185" type="span" parent="186" relname="contrast"/>
		<group id="186" type="multinuc" parent="182" relname="elaboration"/>
		<group id="187" type="span" />
		<group id="188" type="multinuc" parent="189" relname="contrast"/>
		<group id="189" type="multinuc" parent="191" relname="span"/>
		<group id="190" type="span" parent="191" relname="elaboration"/>
		<group id="191" type="span" parent="192" relname="span"/>
		<group id="192" type="span" parent="184" relname="evaluation"/>
		<group id="193" type="span" parent="297" relname="preparation"/>
		<group id="194" type="multinuc" parent="296" relname="span"/>
		<group id="195" type="multinuc" parent="196" relname="span"/>
		<group id="196" type="span" parent="260" relname="span"/>
		<group id="197" type="span" parent="198" relname="contrast"/>
		<group id="198" type="multinuc" parent="296" relname="elaboration"/>
		<group id="199" type="multinuc" parent="268" relname="span"/>
		<group id="200" type="multinuc" parent="206" relname="span"/>
		<group id="201" type="multinuc" parent="204" relname="cause"/>
		<group id="202" type="span" parent="203" relname="same-unit"/>
		<group id="203" type="multinuc" parent="204" relname="span"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="206" relname="elaboration"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="268" relname="evaluation"/>
		<group id="208" type="span" parent="209" relname="joint"/>
		<group id="209" type="multinuc" parent="76" relname="evidence"/>
		<group id="210" type="span" parent="270" relname="contrast"/>
		<group id="211" type="multinuc" parent="92" relname="elaboration"/>
		<group id="212" type="span" parent="211" relname="contrast"/>
		<group id="213" type="span" parent="273" relname="contrast"/>
		<group id="214" type="multinuc" parent="98" relname="elaboration"/>
		<group id="215" type="span" parent="101" relname="preparation"/>
		<group id="216" type="span" parent="219" relname="span"/>
		<group id="217" type="span" parent="102" relname="cause"/>
		<group id="218" type="span" parent="216" relname="evidence"/>
		<group id="219" type="span" parent="225" relname="span"/>
		<group id="220" type="multinuc" parent="105" relname="elaboration"/>
		<group id="221" type="span" parent="108" relname="cause"/>
		<group id="222" type="span" parent="224" relname="contrast"/>
		<group id="223" type="span" parent="224" relname="contrast"/>
		<group id="224" type="multinuc" parent="219" relname="elaboration"/>
		<group id="225" type="span" />
		<group id="226" type="span" parent="278" relname="span"/>
		<group id="227" type="multinuc" parent="228" relname="contrast"/>
		<group id="228" type="multinuc" parent="282" relname="span"/>
		<group id="229" type="multinuc" parent="230" relname="span"/>
		<group id="230" type="span" parent="231" relname="span"/>
		<group id="231" type="span" parent="232" relname="sequence"/>
		<group id="232" type="multinuc" parent="117" relname="evidence"/>
		<group id="233" type="span" parent="280" relname="span"/>
		<group id="234" type="span" parent="235" relname="preparation"/>
		<group id="235" type="span" parent="236" relname="span"/>
		<group id="236" type="span" parent="237" relname="span"/>
		<group id="237" type="span" parent="284" relname="joint"/>
		<group id="238" type="multinuc" parent="133" relname="purpose"/>
		<group id="239" type="span" parent="132" relname="evaluation"/>
		<group id="240" type="span" parent="131" relname="elaboration"/>
		<group id="241" type="span" parent="248" relname="span"/>
		<group id="242" type="multinuc" parent="243" relname="contrast"/>
		<group id="243" type="multinuc" parent="285" relname="comparison"/>
		<group id="244" type="span" parent="287" relname="sequence"/>
		<group id="245" type="multinuc" parent="141" relname="evidence"/>
		<group id="246" type="span" parent="247" relname="contrast"/>
		<group id="247" type="multinuc" parent="241" relname="elaboration"/>
		<group id="248" type="span" parent="289" relname="span"/>
		<group id="249" type="span" parent="148" relname="purpose"/>
		<group id="250" type="span" parent="288" relname="comparison"/>
		<group id="251" type="multinuc" parent="288" relname="comparison"/>
		<group id="252" type="span" parent="253" relname="span"/>
		<group id="253" type="span" parent="165" relname="contrast"/>
		<group id="254" type="span" parent="172" relname="sequence"/>
		<group id="255" type="multinuc" parent="177" relname="span"/>
		<group id="256" type="span" parent="255" relname="contrast"/>
		<group id="257" type="span" parent="186" relname="contrast"/>
		<group id="258" type="multinuc" parent="61" relname="evaluation"/>
		<group id="259" type="span" parent="261" relname="span"/>
		<group id="260" type="span" parent="66" relname="elaboration"/>
		<group id="261" type="span" parent="198" relname="contrast"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" parent="267" relname="span"/>
		<group id="267" type="span" parent="270" relname="contrast"/>
		<group id="268" type="span" parent="269" relname="span"/>
		<group id="269" type="span" parent="77" relname="elaboration"/>
		<group id="270" type="multinuc" parent="271" relname="span"/>
		<group id="271" type="span" />
		<group id="272" type="span" parent="273" relname="contrast"/>
		<group id="273" type="multinuc" parent="274" relname="span"/>
		<group id="274" type="span" parent="276" relname="span"/>
		<group id="275" type="span" parent="274" relname="solutionhood"/>
		<group id="276" type="span" />
		<group id="277" type="span" parent="112" relname="background"/>
		<group id="278" type="span" parent="279" relname="comparison"/>
		<group id="279" type="multinuc" parent="280" relname="cause"/>
		<group id="280" type="span" parent="281" relname="span"/>
		<group id="281" type="span" parent="284" relname="joint"/>
		<group id="282" type="span" parent="283" relname="span"/>
		<group id="283" type="span" parent="232" relname="sequence"/>
		<group id="284" type="multinuc" />
		<group id="285" type="multinuc" parent="136" relname="evidence"/>
		<group id="286" type="span" parent="247" relname="contrast"/>
		<group id="287" type="multinuc" parent="245" relname="joint"/>
		<group id="288" type="multinuc" parent="248" relname="elaboration"/>
		<group id="289" type="span" />
		<group id="290" type="span" parent="291" relname="span"/>
		<group id="291" type="span" parent="292" relname="span"/>
		<group id="292" type="span" />
		<group id="293" type="span" parent="254" relname="span"/>
		<group id="294" type="span" parent="194" relname="joint"/>
		<group id="295" type="span" parent="279" relname="comparison"/>
		<group id="296" type="span" parent="297" relname="span"/>
		<group id="297" type="span" parent="298" relname="span"/>
		<group id="298" type="span" />
	</body>
</rst>