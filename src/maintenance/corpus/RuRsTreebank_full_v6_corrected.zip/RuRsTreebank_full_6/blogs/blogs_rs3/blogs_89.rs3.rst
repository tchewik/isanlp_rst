<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://maxkatz.livejournal.com/727306.html</segment>
		<segment id="2" >Почему я так привязался к электробусам и почему они так важны</segment>
		<segment id="3" parent="87" relname="joint">Многие стали спрашивать почему я заспамил весь твиттер электробусами,</segment>
		<segment id="4" parent="87" relname="joint">предлагают с этим прекратить.</segment>
		<segment id="5" parent="88" relname="span">Сегодня от нескольких знакомых читателей получил такую жалобу:</segment>
		<segment id="6" parent="5" relname="elaboration">TXT-IMG</segment>
		<segment id="7" parent="92" relname="span">Электробусы и троллейбусы — профильная для меня штука,</segment>
		<segment id="8" parent="91" relname="joint">я интересуюсь транспортом</segment>
		<segment id="9" parent="91" relname="joint">и вообще урбанистический магистр.</segment>
		<segment id="10" parent="96" relname="joint">Но глупостей в городе делается много,</segment>
		<segment id="11" parent="95" relname="span">бредятина с электробусами важна</segment>
		<segment id="12" parent="94" relname="span">ещё потому, что это прям хрестоматийный пример,</segment>
		<segment id="13" parent="12" relname="elaboration">показывающий, из-за чего в нашей стране все проблемы получаются.</segment>
		<segment id="14" parent="123" relname="span">Тут в этой теме всё:</segment>
		<segment id="15" parent="16" relname="preparation">Самодурство и глупость одного начальника.</segment>
		<segment id="16" parent="98" relname="span">Вся тема с уничтожением троллейбусов и введением футуристичных электробусов это полностью на 100% инициатива только Собянина.</segment>
		<segment id="17" parent="103" relname="joint">Даже Ликсутов был против,</segment>
		<segment id="18" parent="103" relname="joint">не говоря о профильных руководителях,</segment>
		<segment id="19" parent="101" relname="span">работники Дептранса,</segment>
		<segment id="20" parent="99" relname="span">многие из которых пришли туда работать,</segment>
		<segment id="21" parent="20" relname="purpose">чтобы улучшать город,</segment>
		<segment id="22" parent="100" relname="span">стыдливо опускают глаза</segment>
		<segment id="23" parent="22" relname="condition">при разговоре о троллейбусах,</segment>
		<segment id="24" parent="105" relname="span">В результате уничтожается ценная и важная инфраструктура,</segment>
		<segment id="25" parent="104" relname="comparison">которую такие города, как Берлин, сейчас только думают строить,</segment>
		<segment id="26" parent="104" relname="comparison">а такие, как Лондон, — о ней мечтают,</segment>
		<segment id="27" parent="106" relname="contrast">Всё это стоит уже сейчас 12 миллиардов рублей</segment>
		<segment id="28" parent="106" relname="contrast">и не имеет никакого смысла.</segment>
		<segment id="29" parent="107" relname="contrast">Это целый год работы десяти тысяч человек с зарплатой 100,000 рублей просто выброшен в унитаз.</segment>
		<segment id="30" parent="107" relname="contrast">Это ~12,5 лет работы персонала института Склифосовского, например.</segment>
		<segment id="31" parent="109" relname="evaluation">Просто вот так раз и на ветер,</segment>
		<segment id="32" parent="112" relname="span">Всё это будет стоить намного дороже,</segment>
		<segment id="33" parent="111" relname="contrast">если уничтожить троллейбус</segment>
		<segment id="34" parent="111" relname="contrast">и накупить этих хреномутей,</segment>
		<segment id="35" parent="114" relname="span">и нам же это потом разгребать,</segment>
		<segment id="36" parent="35" relname="cause">когда власть станет адекватной,</segment>
		<segment id="37" parent="115" relname="joint">Всё медийное пространство зачищено,</segment>
		<segment id="38" parent="115" relname="joint">рациональный подход к совершенно обычному хозяйственному вопросу отстаиваю один я,</segment>
		<segment id="39" parent="116" relname="joint">Дептранс скупает блогеров,</segment>
		<segment id="40" parent="116" relname="joint">крутит репортажи по ТВ,</segment>
		<segment id="41" parent="117" relname="span">закупает крупнейшую дизайн-студию</segment>
		<segment id="42" parent="41" relname="purpose">для дизайна</segment>
		<segment id="43" parent="44" relname="purpose">— на пиар глупости и замыливание темы</segment>
		<segment id="44" parent="160" relname="span">тратится куча времени и сил,</segment>
		<segment id="45" parent="121" relname="span">Но сейчас все находят миллион причин, почему это неважно.</segment>
		<segment id="46" parent="120" relname="joint">Вопрос мелкий,</segment>
		<segment id="47" parent="120" relname="joint">портить отношения с мэрией не хочется,</segment>
		<segment id="48" parent="120" relname="joint">не хочется напрямую критиковать,</segment>
		<segment id="49" parent="120" relname="joint">не хочется задавать такие вопросы.</segment>
		<segment id="50" parent="51" relname="condition">Если и я на это забью,</segment>
		<segment id="51" parent="124" relname="span">то все будут молчать.</segment>
		<segment id="52" parent="125" relname="contrast">На одной чаше куча бабла на пиар-бюджет никому не нужной хреномути,</segment>
		<segment id="53" parent="125" relname="contrast">на другой какой-то общественный интерес с непонятными троллейбусами и экономикой.</segment>
		<segment id="54" parent="127" relname="span">И ведь в стране всё так. Никакой экспертной дискуссии, рациональной политики, никаких решений, основанных на фактах и на цифрах.</segment>
		<segment id="55" parent="54" relname="elaboration">Ничего из того, чему учат урбанистического магистра в университете Глазго.</segment>
		<segment id="56" parent="161" relname="span">Сплошное самодурство, враньё, продажность и пустой пиар.</segment>
		<segment id="57" parent="56" relname="evaluation">Поэтому жизнь с каждым годом становится всё хуже и страшнее.</segment>
		<segment id="58" parent="128" relname="joint">Электробус хорош</segment>
		<segment id="59" parent="60" relname="cause">ещё тем, что бред этой истории очевиден,</segment>
		<segment id="60" parent="162" relname="span">лежит на поверхности, среди экспертов консенсус.</segment>
		<segment id="61" parent="130" relname="joint">Он просто не едет,</segment>
		<segment id="62" parent="63" relname="condition">а когда едет,</segment>
		<segment id="63" parent="129" relname="span">то дороже во много раз.</segment>
		<segment id="64" parent="131" relname="joint">Но все куплены</segment>
		<segment id="65" parent="131" relname="joint">и никто не хочет вписываться.</segment>
		<segment id="66" parent="139" relname="preparation">А я вот буду.</segment>
		<segment id="67" parent="68" relname="condition">Отобьём троллейбус</segment>
		<segment id="68" parent="153" relname="span">— хорошо.</segment>
		<segment id="69" parent="136" relname="joint">Это будет хорошее и важное дело,</segment>
		<segment id="70" parent="136" relname="joint">город станет лучше с более чистым воздухом и более экономичным транспортом.</segment>
		<segment id="71" parent="156" relname="condition">Не отобьём</segment>
		<segment id="72" parent="137" relname="joint">— покажем, как дела такие делаются,</segment>
		<segment id="73" parent="137" relname="joint">и объясним, как их надо делать</segment>
		<segment id="74" parent="137" relname="joint">и почему действующая власть это не может.</segment>
		<segment id="75" parent="159" relname="contrast">Вы зря думаете, что все знают всё про нынешнюю власть.</segment>
		<segment id="76" parent="140" relname="joint">На самом деле у многих иллюзия, что мэрия Москвы, например, городом управляет хорошо</segment>
		<segment id="77" parent="140" relname="joint">и становится всё в городе лучше.</segment>
		<segment id="78" parent="141" relname="joint">Людям это всё нужно будет объяснять,</segment>
		<segment id="79" parent="141" relname="joint">убеждать</segment>
		<segment id="80" parent="141" relname="joint">и доказывать.</segment>
		<segment id="81" parent="143" relname="span">Все такие истории станут аргументом в ситуации,</segment>
		<segment id="82" parent="163" relname="condition">когда избиратель будет решать</segment>
		<segment id="83" parent="142" relname="joint">— отдать власть нам</segment>
		<segment id="84" parent="142" relname="joint">или оставить им.</segment>
		<segment id="85" parent="143" relname="elaboration">А момент такой наступит в Москве при нашей жизни и, я думаю, довольно скоро</segment>
		<segment id="86" >IMG</segment>
		<group id="87" type="multinuc" parent="89" relname="span"/>
		<group id="88" type="span" parent="89" relname="evidence"/>
		<group id="89" type="span" parent="90" relname="span"/>
		<group id="90" type="span" parent="92" relname="preparation"/>
		<group id="91" type="multinuc" parent="7" relname="elaboration"/>
		<group id="92" type="span" parent="93" relname="span"/>
		<group id="93" type="span" parent="97" relname="contrast"/>
		<group id="94" type="span" parent="11" relname="evidence"/>
		<group id="95" type="span" parent="96" relname="joint"/>
		<group id="96" type="multinuc" parent="97" relname="contrast"/>
		<group id="97" type="multinuc" />
		<group id="98" type="span" parent="149" relname="contrast"/>
		<group id="99" type="span" parent="19" relname="elaboration"/>
		<group id="100" type="span" parent="102" relname="same-unit"/>
		<group id="101" type="span" parent="102" relname="same-unit"/>
		<group id="102" type="multinuc" parent="103" relname="joint"/>
		<group id="103" type="multinuc" parent="149" relname="contrast"/>
		<group id="104" type="multinuc" parent="24" relname="elaboration"/>
		<group id="105" type="span" parent="122" relname="joint"/>
		<group id="106" type="multinuc" parent="108" relname="span"/>
		<group id="107" type="multinuc" parent="108" relname="evidence"/>
		<group id="108" type="span" parent="109" relname="span"/>
		<group id="109" type="span" parent="110" relname="span"/>
		<group id="110" type="span" parent="122" relname="joint"/>
		<group id="111" type="multinuc" parent="32" relname="condition"/>
		<group id="112" type="span" parent="113" relname="sequence"/>
		<group id="113" type="multinuc" parent="122" relname="joint"/>
		<group id="114" type="span" parent="113" relname="sequence"/>
		<group id="115" type="multinuc" parent="122" relname="joint"/>
		<group id="116" type="multinuc" parent="118" relname="span"/>
		<group id="117" type="span" parent="116" relname="joint"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" parent="122" relname="joint"/>
		<group id="120" type="multinuc" parent="45" relname="elaboration"/>
		<group id="121" type="span" parent="122" relname="joint"/>
		<group id="122" type="multinuc" parent="14" relname="elaboration"/>
		<group id="123" type="span" />
		<group id="124" type="span" parent="126" relname="span"/>
		<group id="125" type="multinuc" parent="151" relname="span"/>
		<group id="126" type="span" parent="135" relname="joint"/>
		<group id="127" type="span" parent="150" relname="contrast"/>
		<group id="128" type="multinuc" parent="132" relname="span"/>
		<group id="129" type="span" parent="130" relname="joint"/>
		<group id="130" type="multinuc" parent="132" relname="evidence"/>
		<group id="131" type="multinuc" parent="134" relname="contrast"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" parent="134" relname="contrast"/>
		<group id="134" type="multinuc" parent="135" relname="joint"/>
		<group id="135" type="multinuc" />
		<group id="136" type="multinuc" parent="153" relname="evaluation"/>
		<group id="137" type="multinuc" parent="155" relname="span"/>
		<group id="138" type="multinuc" parent="139" relname="span"/>
		<group id="139" type="span" parent="158" relname="span"/>
		<group id="140" type="multinuc" parent="159" relname="contrast"/>
		<group id="141" type="multinuc" parent="145" relname="elaboration"/>
		<group id="142" type="multinuc" parent="163" relname="span"/>
		<group id="143" type="span" parent="144" relname="span"/>
		<group id="144" type="span" parent="146" relname="elaboration"/>
		<group id="145" type="span" parent="146" relname="span"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" parent="148" relname="joint"/>
		<group id="148" type="multinuc" />
		<group id="149" type="multinuc" parent="122" relname="joint"/>
		<group id="150" type="multinuc" parent="151" relname="evaluation"/>
		<group id="151" type="span" parent="152" relname="span"/>
		<group id="152" type="span" parent="124" relname="evaluation"/>
		<group id="153" type="span" parent="154" relname="span"/>
		<group id="154" type="span" parent="138" relname="joint"/>
		<group id="155" type="span" parent="156" relname="span"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="138" relname="joint"/>
		<group id="158" type="span" parent="148" relname="joint"/>
		<group id="159" type="multinuc" parent="145" relname="span"/>
		<group id="160" type="span" parent="118" relname="elaboration"/>
		<group id="161" type="span" parent="150" relname="contrast"/>
		<group id="162" type="span" parent="128" relname="joint"/>
		<group id="163" type="span" parent="164" relname="span"/>
		<group id="164" type="span" parent="81" relname="elaboration"/>
	</body>
</rst>