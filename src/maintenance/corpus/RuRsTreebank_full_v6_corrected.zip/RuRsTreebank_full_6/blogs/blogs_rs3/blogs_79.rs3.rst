<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://t.me/TeplitsaPRO/205</segment>
		<segment id="2" parent="3" relname="preparation">Поговорим о призывах к действию. CTA (ситиэй – колтуэкшн – call to action).</segment>
		<segment id="3" parent="85" relname="span">Они повсюду.</segment>
		<segment id="4" parent="86" relname="joint">Атакуют наши сенсорные системы.</segment>
		<segment id="5" parent="86" relname="joint">Спешат нам продать,</segment>
		<segment id="6" parent="86" relname="joint">заставить зарегистрироваться,</segment>
		<segment id="7" parent="86" relname="joint">убедить стать чьим-то сторонником.</segment>
		<segment id="8" parent="148" relname="joint">"Поддержите нас".</segment>
		<segment id="9" parent="148" relname="joint">"Начните помогать прямо сейчас".</segment>
		<segment id="10" parent="148" relname="joint">"Подпишитесь на наш канал".</segment>
		<segment id="11" parent="89" relname="span">Самый бесполезный призыв к действию увидел вчера в троллейбусе.</segment>
		<segment id="12" parent="13" relname="attribution">Экран рекламы с логотипом московской мэрии мелкими красными буквами на зеленом фоне деревьев пишет:</segment>
		<segment id="13" parent="88" relname="span">"Берегите лес от пожара".</segment>
		<segment id="14" parent="15" relname="cause">В отсутствие коммерческих заказов</segment>
		<segment id="15" parent="90" relname="span">маркетинговый отдел Мостранса решил, видимо, заняться "социалочкой".</segment>
		<segment id="16" parent="17" relname="cause">Лето жаркое,</segment>
		<segment id="17" parent="149" relname="span">поэтому почему бы не спасти планету.</segment>
		<segment id="18" parent="150" relname="solutionhood">Почему это плохо?</segment>
		<segment id="19" parent="93" relname="span">Во-первых, контекст.</segment>
		<segment id="20" parent="19" relname="evidence">Возвращающаяся с работы Надежда Ивановна явно не планирует даже посещать лес в ближайшее несколько месяцев.</segment>
		<segment id="21" parent="99" relname="span">Во-вторых, отсутствие инструментов и условий к осуществлению этого призыва.</segment>
		<segment id="22" parent="96" relname="span">Продавщица Аня,</segment>
		<segment id="23" parent="95" relname="joint">которая отпахала смену</segment>
		<segment id="24" parent="94" relname="span">и старается занять последнее место</segment>
		<segment id="25" parent="24" relname="purpose">для сидения,</segment>
		<segment id="26" parent="97" relname="same-unit">даже если бы и хотела,</segment>
		<segment id="27" parent="98" relname="span">все равно не смогла бы защитить лес от пожара находясь в троллейбусе.</segment>
		<segment id="28" parent="101" relname="joint">В троллейбусе адекватный призыв к действию – это вести себя прилично и уважительно к окружающим</segment>
		<segment id="29" parent="101" relname="joint">и следить за кошельком,</segment>
		<segment id="30" parent="102" relname="contrast">а не беречь лес от пожара.</segment>
		<segment id="31" parent="153" relname="solutionhood">Какие проблемы с призывами к действию у НКО?</segment>
		<segment id="32" parent="103" relname="comparison">В отличие от коммерческих компаний, которым понятно, что призыв к действию ведет к продажам,</segment>
		<segment id="33" parent="103" relname="comparison">у НКО есть серьезные сомнения по поводу того, в какую воронку "сливать" нашедших их людей.</segment>
		<segment id="34" parent="104" relname="span">1. Призыв к действию отсутствует. На сайте, в литературе, в видео, в письмах, в соц.сетях.</segment>
		<segment id="35" parent="34" relname="evidence">"Мы просто существуем".</segment>
		<segment id="36" parent="156" relname="solutionhood">Зачем тогда, собственно, существует НКО?</segment>
		<segment id="37" parent="105" relname="span">Призыв к действию должен либо "давать"</segment>
		<segment id="38" parent="37" relname="elaboration">(Позвоните на горячую линию психологической помощи),</segment>
		<segment id="39" parent="106" relname="span">либо "брать"</segment>
		<segment id="40" parent="39" relname="elaboration">(Станьте сторонником).</segment>
		<segment id="41" parent="108" relname="joint">Если организация не оказывает помощи</segment>
		<segment id="42" parent="108" relname="joint">и не пытается перераспределить ресурсы,</segment>
		<segment id="43" parent="162" relname="span">то она может хотя бы стремиться к увеличению своего влияния</segment>
		<segment id="44" parent="43" relname="cause">за счет увеличения числа подписчиков.</segment>
		<segment id="45" parent="110" relname="span">Или "И так же все понятно".</segment>
		<segment id="46" parent="112" relname="span">Непонятно.</segment>
		<segment id="47" parent="113" relname="joint">Изменение "в головах" проходит</segment>
		<segment id="48" parent="113" relname="joint">и забывается.</segment>
		<segment id="49" parent="114" relname="evaluation">Всегда выводите на действие в физическом пространстве.</segment>
		<segment id="50" parent="123" relname="span">2. Призыв к действию не там.</segment>
		<segment id="51" parent="116" relname="span">Например, есть организация с текстовыми памятками для определенного вида пациентов.</segment>
		<segment id="52" parent="117" relname="joint">Записи на консультации нет,</segment>
		<segment id="53" parent="117" relname="joint">онлайн-рассылки тоже нет.</segment>
		<segment id="54" parent="55" relname="attribution">Говорю:</segment>
		<segment id="55" parent="164" relname="span">ну хотя бы ведите всех к себе в сообщество в социальной сети.</segment>
		<segment id="56" parent="119" relname="span">Ставят иконку соц.сети в "подвале" (нижняя часть сайта, как правило, содержащая техническую информацию о сайте, партнерах и правилах использования).</segment>
		<segment id="57" parent="121" relname="span">Это неправильно.</segment>
		<segment id="58" parent="120" relname="joint">Призыв к действию – идет после текста</segment>
		<segment id="59" parent="120" relname="joint">и выделен как кнопка, а не иконка.</segment>
		<segment id="60" parent="124" relname="joint">3. Призывов несколько,</segment>
		<segment id="61" parent="124" relname="joint">но сначала идет "берущий".</segment>
		<segment id="62" parent="160" relname="span">Пример: несобирающая организация</segment>
		<segment id="63" parent="62" relname="purpose">(т.е. основная цель не перераспределение средств для соц.миссии)</segment>
		<segment id="64" parent="125" relname="same-unit">везде лепит в правом верхнем углу "Поддержите нас".</segment>
		<segment id="65" parent="128" relname="contrast">Хотя основная функция сайта – консультации.</segment>
		<segment id="66" parent="127" relname="contrast">Так вы поставьте везде призыв к действию "Получить консультацию",</segment>
		<segment id="67" parent="163" relname="span">а собирайте</segment>
		<segment id="68" parent="67" relname="condition">только тогда, когда вы оказали помощь</segment>
		<segment id="69" parent="126" relname="span">и люди вам благодарны.</segment>
		<segment id="70" parent="131" relname="preparation">4. Призыв к действию в видео.</segment>
		<segment id="71" parent="131" relname="span">Посмотрите osocio.org</segment>
		<segment id="72" parent="71" relname="elaboration">– как весь мир делает социальные видео.</segment>
		<segment id="73" parent="139" relname="span">Призыв к действию выделяется черным экраном с конкретным указанием, что нужно делать, сразу после пуэнты (кульминационный момент истории).</segment>
		<segment id="74" parent="137" relname="span">А то недавно увидел</segment>
		<segment id="75" parent="136" relname="contrast">– отличная анимация, история рассказана на важную тему,</segment>
		<segment id="76" parent="135" relname="span">но повествование такое:</segment>
		<segment id="77" parent="78" relname="cause">"мультик" - "информация об авторах"</segment>
		<segment id="78" parent="133" relname="span">(люди уже переключились)</segment>
		<segment id="79" parent="134" relname="sequence">– на полсекунды призыв к действию.</segment>
		<segment id="80" parent="137" relname="evaluation">Так не надо.</segment>
		<segment id="81" parent="143" relname="span">Мой призыв к действию на сегодня:</segment>
		<segment id="82" parent="83" relname="condition">если у вас есть примеры хорошего или плохого использования призывов к действию</segment>
		<segment id="83" parent="141" relname="span">– присылайте в Теплицу – https://pd.te-st.ru/forms/contacts/</segment>
		<segment id="84" parent="142" relname="span">– самые лучшие примеры я прокомментирую здесь. Спасибо.</segment>
		<group id="85" type="span" parent="87" relname="span"/>
		<group id="86" type="multinuc" parent="146" relname="span"/>
		<group id="87" type="span" />
		<group id="88" type="span" parent="11" relname="elaboration"/>
		<group id="89" type="span" parent="92" relname="span"/>
		<group id="90" type="span" parent="91" relname="span"/>
		<group id="91" type="span" parent="89" relname="evaluation"/>
		<group id="92" type="span" />
		<group id="93" type="span" parent="100" relname="joint"/>
		<group id="94" type="span" parent="95" relname="joint"/>
		<group id="95" type="multinuc" parent="22" relname="elaboration"/>
		<group id="96" type="span" parent="97" relname="same-unit"/>
		<group id="97" type="multinuc" parent="27" relname="condition"/>
		<group id="98" type="span" parent="152" relname="contrast"/>
		<group id="99" type="span" parent="100" relname="joint"/>
		<group id="100" type="multinuc" parent="150" relname="span"/>
		<group id="101" type="multinuc" parent="102" relname="contrast"/>
		<group id="102" type="multinuc" parent="152" relname="contrast"/>
		<group id="103" type="multinuc" parent="153" relname="span"/>
		<group id="104" type="span" parent="155" relname="span"/>
		<group id="105" type="span" parent="107" relname="joint"/>
		<group id="106" type="span" parent="107" relname="joint"/>
		<group id="107" type="multinuc" parent="156" relname="span"/>
		<group id="108" type="multinuc" parent="162" relname="condition"/>
		<group id="109" type="span" parent="111" relname="joint"/>
		<group id="110" type="span" parent="111" relname="joint"/>
		<group id="111" type="multinuc" parent="158" relname="elaboration"/>
		<group id="112" type="span" parent="45" relname="evaluation"/>
		<group id="113" type="multinuc" parent="114" relname="span"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="46" relname="elaboration"/>
		<group id="116" type="span" parent="118" relname="span"/>
		<group id="117" type="multinuc" parent="51" relname="elaboration"/>
		<group id="118" type="span" parent="50" relname="evidence"/>
		<group id="119" type="span" parent="122" relname="span"/>
		<group id="120" type="multinuc" parent="57" relname="evidence"/>
		<group id="121" type="span" parent="119" relname="evaluation"/>
		<group id="122" type="span" parent="116" relname="concession"/>
		<group id="123" type="span" />
		<group id="124" type="multinuc" parent="129" relname="span"/>
		<group id="125" type="multinuc" parent="128" relname="contrast"/>
		<group id="126" type="span" parent="127" relname="contrast"/>
		<group id="127" type="multinuc" parent="144" relname="evaluation"/>
		<group id="128" type="multinuc" parent="144" relname="span"/>
		<group id="129" type="span" parent="130" relname="span"/>
		<group id="130" type="span" />
		<group id="131" type="span" parent="132" relname="span"/>
		<group id="132" type="span" parent="140" relname="span"/>
		<group id="133" type="span" parent="134" relname="sequence"/>
		<group id="134" type="multinuc" parent="76" relname="elaboration"/>
		<group id="135" type="span" parent="136" relname="contrast"/>
		<group id="136" type="multinuc" parent="74" relname="elaboration"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="73" relname="evidence"/>
		<group id="139" type="span" parent="132" relname="elaboration"/>
		<group id="140" type="span" parent="143" relname="solutionhood"/>
		<group id="141" type="span" parent="84" relname="cause"/>
		<group id="142" type="span" parent="81" relname="elaboration"/>
		<group id="143" type="span" parent="161" relname="span"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" parent="129" relname="evidence"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" parent="85" relname="evidence"/>
		<group id="148" type="multinuc" parent="146" relname="elaboration"/>
		<group id="149" type="span" parent="90" relname="evidence"/>
		<group id="150" type="span" parent="151" relname="span"/>
		<group id="151" type="span" />
		<group id="152" type="multinuc" parent="21" relname="evidence"/>
		<group id="153" type="span" parent="154" relname="span"/>
		<group id="154" type="span" parent="104" relname="preparation"/>
		<group id="155" type="span" parent="157" relname="preparation"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="158" relname="span"/>
		<group id="158" type="span" parent="159" relname="span"/>
		<group id="159" type="span" />
		<group id="160" type="span" parent="125" relname="same-unit"/>
		<group id="161" type="span" />
		<group id="162" type="span" parent="109" relname="span"/>
		<group id="163" type="span" parent="69" relname="cause"/>
		<group id="164" type="span" parent="56" relname="cause"/>
	</body>
</rst>