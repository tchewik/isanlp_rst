<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://alexandr-rogers.livejournal.com/1162207.html</segment>
		<segment id="2" >05:55 pm: Сводка с информационных фронтов</segment>
		<segment id="3" parent="201" relname="preparation">Для начала дисклеймер:</segment>
		<segment id="4" parent="193" relname="span">Нижеследующий текст написан не для того,</segment>
		<segment id="5" parent="191" relname="joint">чтобы жаловаться,</segment>
		<segment id="6" parent="191" relname="joint">выбивать финансирование</segment>
		<segment id="7" parent="191" relname="joint">или бороться «за лучшее место под солнцем».</segment>
		<segment id="8" parent="194" relname="span">У меня есть свой бизнес,</segment>
		<segment id="9" parent="8" relname="elaboration">который приносит мне стабильный доход,</segment>
		<segment id="10" parent="11" relname="cause">в связи с прошедшим ПМЭФ</segment>
		<segment id="11" parent="195" relname="span">я познакомился с несколькими людьми, которые предлагают мне перспективные проекты,</segment>
		<segment id="12" parent="197" relname="span">так что лично меня с точки зрения личного благополучия всё устраивает.</segment>
		<segment id="13" parent="198" relname="joint">И на госфинансирование я не претендую.</segment>
		<segment id="14" parent="198" relname="joint">Более того, всё написанное никак не изменит моих антимайданных и антизападных убеждений.</segment>
		<segment id="15" parent="200" relname="span">Текст призван ознакомить широкие массы с реальной ситуацией</segment>
		<segment id="16" parent="15" relname="evaluation">(или, если точнее, то с моей точкой зрения на то, как эта реальность выглядит). IMG</segment>
		<segment id="17" parent="204" relname="same-unit">Теперь,</segment>
		<segment id="18" parent="19" relname="condition">когда мы это оговорили,</segment>
		<segment id="19" parent="203" relname="span">приступим.</segment>
		<segment id="20" parent="205" relname="span">В ширнармассах существует странное убеждение</segment>
		<segment id="21" parent="20" relname="background">(активно поддерживаемое оппозицией),</segment>
		<segment id="22" parent="206" relname="span">что Кремль закидывает патриотических блогеров деньгами и прочими ништяками.</segment>
		<segment id="23" parent="208" relname="span">Это не так.</segment>
		<segment id="24" parent="23" relname="evaluation">Вообще не так.</segment>
		<segment id="25" parent="226" relname="span">Всё ровным счётом наоборот.</segment>
		<segment id="26" parent="210" relname="contrast">У руководства России есть телевидение.</segment>
		<segment id="27" parent="210" relname="contrast">И ничего больше его не интересует.</segment>
		<segment id="28" parent="211" relname="contrast">Всё финансирование идёт всяким «Первым каналам», «Россиям-1/24» и так далее.</segment>
		<segment id="29" parent="212" relname="span">На блогеров или интернет-вещание никто не тратится.</segment>
		<segment id="30" parent="213" relname="span">Это для них «слишком мелко».</segment>
		<segment id="31" parent="225" relname="span">Они привыкли «бить по площадям», ковровыми бомбардировками.</segment>
		<segment id="32" parent="216" relname="attribution">Среди чиновников доминирует мнение,</segment>
		<segment id="33" parent="214" relname="condition">что если ТВ охватывает 50-70 миллионов человек,</segment>
		<segment id="34" parent="214" relname="span">то заниматься блогерами или интернет-СМИ,</segment>
		<segment id="35" parent="34" relname="background">аудитория которых исчисляется даже сотнями тысяч</segment>
		<segment id="36" parent="215" relname="evaluation">– не интересно.</segment>
		<segment id="37" parent="219" relname="comparison">Руководство России совершает в информационной политике ту же ошибку,</segment>
		<segment id="38" parent="218" relname="joint">что и Советский Союз когда-то – сосредоточено на официальной пропаганде</segment>
		<segment id="39" parent="218" relname="joint">и игнорирует блогосферу и «сарафанное радио».</segment>
		<segment id="40" parent="220" relname="cause">А ведь когда-то именно подпольное вещание «Радио Свобода», «Дойче Велле» и «Голос Америки» внесло существенный вклад в развал СССР.</segment>
		<segment id="41" parent="229" relname="contrast">Кстати, никаких «ольгинских ботов» тоже не существует. Вообще.</segment>
		<segment id="42" parent="230" relname="span">А вот оппоботов, укроботов и американских (или, более широко, западные) ботов – десятки тысяч.</segment>
		<segment id="43" parent="42" relname="elaboration">Мне известно про восемь разных «ферм».</segment>
		<segment id="44" parent="231" relname="span">Плюс, например, у КПРФ есть своя фабрика ботов, вполне легальная</segment>
		<segment id="45" parent="44" relname="background">(я даже выкладывал фото Зюганова с этими деятелями)</segment>
		<segment id="46" parent="232" relname="joint">и вполне себе оппозиционно-майданная.</segment>
		<segment id="47" parent="372" relname="joint">Правда, она очень топорная</segment>
		<segment id="48" parent="235" relname="evaluation">и пропаганду ведёт предельно тупую,</segment>
		<segment id="49" parent="234" relname="contrast">в стиле «Я на выборы никогда не ходил»</segment>
		<segment id="50" parent="234" relname="contrast">и/или «В топ! Грудинина/Платошкина/Лукошкина в президенты!».</segment>
		<segment id="51" parent="237" relname="joint">Накручивают просмотры, лайки и репосты,</segment>
		<segment id="52" parent="237" relname="joint">устраивают массовые набеги в комменты с бессвязными оскорблениями и матами,</segment>
		<segment id="53" parent="237" relname="joint">распространяют фейки про неугодных им персонажей и так далее.</segment>
		<segment id="54" parent="241" relname="span">На всё это выделяются и осваиваются нехилые бюджеты.</segment>
		<segment id="55" parent="239" relname="span">Ниточки финансирования идут через таких персонажей, как Навальный, Гудков, Рашкин, Пономарёв к западным спецслужбам,</segment>
		<segment id="56" parent="238" relname="span">которые используют деньги от наркоторговли (а иногда, как оказывается, и наркотики напрямую)</segment>
		<segment id="57" parent="56" relname="purpose">для финансирования своих нелегальных операций.</segment>
		<segment id="58" parent="255" relname="span">В любом случае, масштабы финансирования несопоставимы.</segment>
		<segment id="59" parent="244" relname="comparison">Если на финансирование «RT» государство российское тратит порядка 80 миллионов долларов в год,</segment>
		<segment id="60" parent="244" relname="comparison">то американцы тратят на свою русофобскую пропаганду около 30 миллиардов.</segment>
		<segment id="61" parent="245" relname="evaluation">На три порядка больше.</segment>
		<segment id="62" parent="247" relname="cause">Если даже «Раша Тудэй» получает минимальное финансирование</segment>
		<segment id="63" parent="64" relname="attribution">(и, как мне рассказали изнутри,</segment>
		<segment id="64" parent="247" relname="span">поэтому активно использует волонтёрский труд),</segment>
		<segment id="65" parent="249" relname="span">то что уже говорить о блогосфере?</segment>
		<segment id="66" parent="256" relname="span">Ей попросту никто не занимается. Вообще.</segment>
		<segment id="67" parent="250" relname="span">Все так называемые «охранители» в интернете – это исключительно добровольцы.</segment>
		<segment id="68" parent="67" relname="elaboration">И существуют исключительно на самофинансировании.</segment>
		<segment id="69" parent="251" relname="span">Именно поэтому на таких сайтах, как «Ньюз-фронт» или «Журналистская правда» всегда много рекламы с дурацких «партнёрских обменок».</segment>
		<segment id="70" parent="253" relname="joint">Потому что бюджетов на рекламу попросту НЕТ.</segment>
		<segment id="71" parent="252" relname="joint">А «партнёрки» бесплатны,</segment>
		<segment id="72" parent="252" relname="joint">и дают хоть какие-то дополнительные просмотры.</segment>
		<segment id="73" parent="283" relname="preparation">Факты. Всегда смотрите на факты.</segment>
		<segment id="74" parent="259" relname="span">У «оппозиции» всегда полно денег.</segment>
		<segment id="75" parent="74" relname="evaluation">Их попросту заливают деньгами.</segment>
		<segment id="76" parent="259" relname="elaboration">И это всегда видно.</segment>
		<segment id="77" parent="264" relname="joint">У них всегда есть дорогие качественные камеры, монтажные станции, студийный свет и дополнительный персонал – осветители, звукорежиссёры, операторы и так далее.</segment>
		<segment id="78" parent="263" relname="same-unit">У каждого рукопожатного борцуна свой канал «Дно-ТВ», помещение для студии, рекламные бюджеты и</segment>
		<segment id="79" parent="262" relname="span">обслуживающий персонал,</segment>
		<segment id="80" parent="261" relname="contrast">которого не видно в кадре,</segment>
		<segment id="81" parent="261" relname="contrast">но работа которого ощущается в качестве света, картинки, звука и монтажа. А также в СММ.</segment>
		<segment id="82" parent="265" relname="contrast">Каждый Вдудь – это не просто мальчик-мажор в кадре,</segment>
		<segment id="83" parent="266" relname="span">но и работа примерно десятка человек в команде</segment>
		<segment id="84" parent="267" relname="joint">(начиная с подготовки к съёмке</segment>
		<segment id="85" parent="267" relname="joint">и заканчивая СММ-продвижением).</segment>
		<segment id="86" parent="268" relname="joint">И, конечно, бот-поддержка в виде накрутки просмотров, лайков, репостов и комментов.</segment>
		<segment id="87" parent="269" relname="span">Это вам не Роджерс, который снимает за один дубль, на одном дыхании на домашнюю вебку за 1500 рублей.</segment>
		<segment id="88" parent="87" relname="elaboration">Причём делает это «когда получается урвать полчасика между работой и семьёй».</segment>
		<segment id="89" parent="271" relname="joint">Их видео продвигает ютуб,</segment>
		<segment id="90" parent="271" relname="joint">они всегда в «трендах»,</segment>
		<segment id="91" parent="272" relname="span">они никогда не заморачиваются на</segment>
		<segment id="92" parent="273" relname="span">«где взять ещё пару халтур,</segment>
		<segment id="93" parent="92" relname="purpose">чтобы прожить»</segment>
		<segment id="94" parent="275" relname="span">– большинство из них попросту нигде не работает,</segment>
		<segment id="95" parent="94" relname="cause">«борьба кормит».</segment>
		<segment id="96" parent="278" relname="condition">Как только человек становится «борцуном с рижымом»,</segment>
		<segment id="97" parent="276" relname="joint">то у него внезапно решаются все финансовые проблемы,</segment>
		<segment id="98" parent="276" relname="joint">он начинает мотаться по всей стране с лекциями и концертами,</segment>
		<segment id="99" parent="276" relname="joint">он отдыхает в Таиланде, в Каталонии или на Бали,</segment>
		<segment id="100" parent="277" relname="span">а также у него образовывается куча, просто куча свободного времени</segment>
		<segment id="101" parent="100" relname="purpose">для ведения этой самой оппозиционной борьбы etc.</segment>
		<segment id="102" parent="103" relname="purpose">И чтобы это увидеть,</segment>
		<segment id="103" parent="280" relname="span">не нужно быть офицером ФСБ,</segment>
		<segment id="104" parent="282" relname="joint">достаточно просто внимательно смотреть</segment>
		<segment id="105" parent="282" relname="joint">и анализировать.</segment>
		<segment id="106" parent="296" relname="condition">На оппозицию тратится столько денег,</segment>
		<segment id="107" parent="292" relname="span">что Максим Шевченко,</segment>
		<segment id="108" parent="290" relname="contrast">принявший ислам,</segment>
		<segment id="109" parent="290" relname="contrast">внезапно снова становится «православным человеком» и</segment>
		<segment id="110" parent="291" relname="contrast">при всём своём антисоветизме</segment>
		<segment id="111" parent="291" relname="contrast">начинает петь «Интернационал».</segment>
		<segment id="112" parent="294" relname="contrast">А Захар Прилепин по щелчку бросает свой батальон</segment>
		<segment id="113" parent="114" relname="attribution">и летит в Москву рассказывать</segment>
		<segment id="114" parent="377" relname="span">избирателям о «драйве революционной борьбы» и «национал-большевистской молодости».</segment>
		<segment id="115" parent="295" relname="joint">Или там кладовщик на складе Егор «Тубус» Иванов из Владивостока летает на бизнесджетах в Москву пару раз в месяц.</segment>
		<segment id="116" parent="298" relname="evaluation">Я вам честно скажу:</segment>
		<segment id="117" parent="118" relname="condition">если вы хотите заработать,</segment>
		<segment id="118" parent="298" relname="span">то в «охранителях» вам делать нечего.</segment>
		<segment id="119" parent="299" relname="elaboration">Единственное, что вы можете заработать – это язву желудка от нервов.</segment>
		<segment id="120" parent="301" relname="span">Зато оппозиционер,</segment>
		<segment id="121" parent="120" relname="evaluation">гадящий на Россию под тем или иным углом,</segment>
		<segment id="122" parent="304" relname="span">всегда может рассчитывать на гранты, бюджеты, эфиры (в том числе и на телевидении), продвижение, просмотры и известность.</segment>
		<segment id="123" parent="124" relname="attribution">Как говорил Индиана Джонс</segment>
		<segment id="124" parent="303" relname="span">«Богатство и славу».</segment>
		<segment id="125" parent="311" relname="span">Охранителей не берут работать на телевидение.</segment>
		<segment id="126" parent="305" relname="contrast">Баронову берут,</segment>
		<segment id="127" parent="305" relname="contrast">Носикова или Мараховского не берут.</segment>
		<segment id="128" parent="129" relname="cause">Мы – идейные и принципиальные.</segment>
		<segment id="129" parent="306" relname="span">С нами поэтому сложно.</segment>
		<segment id="130" parent="310" relname="span">Проще купить того, кто изначально продажный.</segment>
		<segment id="131" parent="130" relname="elaboration">Баронову, Собчак, Потупчик и так далее.</segment>
		<segment id="132" parent="318" relname="span">Все известные мне охранители – бессеребреники.</segment>
		<segment id="133" parent="134" relname="evaluation">Многие из нас уже вкусили «молекулы свободы» на Украине,</segment>
		<segment id="134" parent="312" relname="span">нам угрожали пытками и убийствами, и/или последствия «мирных революций» на Донбассе.</segment>
		<segment id="135" parent="313" relname="span">И не хотим,</segment>
		<segment id="136" parent="135" relname="evaluation">отчаянно не хотим повторения такого же в России.</segment>
		<segment id="137" parent="313" relname="cause">Потому что при масштабах России это будет на порядки более жестоким и кровавым.</segment>
		<segment id="138" parent="314" relname="joint">Не хочу,</segment>
		<segment id="139" parent="314" relname="joint">не дам,</segment>
		<segment id="140" parent="314" relname="joint">идите накуй!</segment>
		<segment id="141" parent="320" relname="contrast">Против нас миллиардные бюджеты, армии ботов и кибервойска США (шестой флот на море и далее по тексту).</segment>
		<segment id="142" parent="321" relname="span">А мы – партизаны инфовойны.</segment>
		<segment id="143" parent="319" relname="contrast">Одиночки,</segment>
		<segment id="144" parent="319" relname="contrast">иногда сбившиеся в кучки.</segment>
		<segment id="145" parent="326" relname="span">Каждый из нас, по масштабам противостояния – один против дивизии.</segment>
		<segment id="146" parent="323" relname="span">Вот тут смастерить из гуано и палок РПГ,</segment>
		<segment id="147" parent="146" relname="purpose">чтобы бахнуть по вражескому «Абрамсу».</segment>
		<segment id="148" parent="324" relname="joint">Там сапёрной лопаткой метнуть в F-35.</segment>
		<segment id="149" parent="325" relname="contrast">Да я зубами гусеницы их танков грызть буду,</segment>
		<segment id="150" parent="325" relname="contrast">но они не пройдут!</segment>
		<segment id="151" parent="328" relname="evaluation">Не удивительно,</segment>
		<segment id="152" parent="327" relname="joint">что некоторые периодически не выдерживают</segment>
		<segment id="153" parent="327" relname="joint">и сдаются.</segment>
		<segment id="154" parent="331" relname="span">Сходят с дистанции,</segment>
		<segment id="155" parent="330" relname="joint">едут крышей от перенапряжения (как «Иван Победа»)</segment>
		<segment id="156" parent="330" relname="joint">или ловят инфаркты (Григорий Витальевич Кваснюк, Игорь «Зелёный Чай» и так далее).</segment>
		<segment id="157" parent="334" relname="evaluation">Да, мы тоже несём потери.</segment>
		<segment id="158" parent="340" relname="attribution">Некоторые, которым мы мешаем майданить, регулярно пишут нам</segment>
		<segment id="159" parent="339" relname="joint">«Едь в окопы Донбасса!».</segment>
		<segment id="160" parent="376" relname="span">Или даже «Нужно тебя выслать на Украину</segment>
		<segment id="161" parent="160" relname="purpose">(чтобы тебя там убили)».</segment>
		<segment id="162" parent="342" relname="span">Что угодно,</segment>
		<segment id="163" parent="343" relname="cause">лишь бы им не мешали разлагать умы русских пропагандой «перестройки-2»,</segment>
		<segment id="164" parent="343" relname="span">после которой Россия будет окончательно уничтожена,</segment>
		<segment id="165" parent="164" relname="evaluation">на этот раз уже без шансов на восстановление.</segment>
		<segment id="166" parent="346" relname="contrast">Мне пишут «Да ты опух от бухла».</segment>
		<segment id="167" parent="346" relname="contrast">А я осунулся от систематического недосыпания.</segment>
		<segment id="168" parent="347" relname="span">Холёным мажорам,</segment>
		<segment id="169" parent="168" relname="evaluation">изображающим из себя нынче «пролетарских революционеров»</segment>
		<segment id="170" parent="348" relname="same-unit">не понять, что такое работать на двух работах (плюс халтуры)</segment>
		<segment id="171" parent="349" relname="joint">и ещё и успевать вносить свой вклад в информационную защиту Родины.</segment>
		<segment id="172" parent="350" relname="span">А потому годами спать по четыре часа в сутки.</segment>
		<segment id="173" parent="351" relname="span">И их «Сдохни!»</segment>
		<segment id="174" parent="173" relname="evaluation">я воспринимаю как признание моих заслуг в защите Родины.</segment>
		<segment id="175" parent="352" relname="joint">И их убогие фейки (про «Ляшко» или «торговал землёй Сахалина») и попытки облить меня грязью я воспринимаю как признание своей правоты.</segment>
		<segment id="176" parent="353" relname="cause">Ибо опровергнуть меня фактами они не в состоянии.</segment>
		<segment id="177" parent="357" relname="contrast">Нас мало,</segment>
		<segment id="178" parent="357" relname="contrast">но мы в тельняшках.</segment>
		<segment id="179" parent="367" relname="joint">И за нами Правда.</segment>
		<segment id="180" parent="358" relname="contrast">У нас нет бюджетов,</segment>
		<segment id="181" parent="359" relname="restatement">но каждый из нас – это автономная боевая единица информационного сопротивления.</segment>
		<segment id="182" parent="359" relname="restatement">We are Resistance!</segment>
		<segment id="183" parent="359" relname="restatement">Партизаны инфовойны.</segment>
		<segment id="184" parent="185" relname="condition">Если ты за деньгами</segment>
		<segment id="185" parent="360" relname="span">– то можешь сразу идти в «оппозицию».</segment>
		<segment id="186" parent="360" relname="cause">Там тебе радостно дадут и банку варенья, и корзину печенья, и учёбу в Стэнфорде, и продвижение на ютубе.</segment>
		<segment id="187" parent="188" relname="condition">А если ты наш,</segment>
		<segment id="188" parent="362" relname="span">то вот тебе граната репоста,</segment>
		<segment id="189" parent="363" relname="joint">иди подбей вон тот бронефейк про «неуинаватого наркодельца-журналиста» на службе у Ходорковского.</segment>
		<segment id="190" parent="364" relname="evaluation">Радио «Советское Информбюро» ставит всем песню группы «Молот Родины» под названием «Нам зачтётся».</segment>
		<group id="191" type="multinuc" parent="192" relname="span"/>
		<group id="192" type="span" parent="4" relname="purpose"/>
		<group id="193" type="span" parent="199" relname="contrast"/>
		<group id="194" type="span" parent="196" relname="joint"/>
		<group id="195" type="span" parent="196" relname="joint"/>
		<group id="196" type="multinuc" parent="12" relname="cause"/>
		<group id="197" type="span" parent="198" relname="joint"/>
		<group id="198" type="multinuc" parent="199" relname="contrast"/>
		<group id="199" type="multinuc" parent="200" relname="solutionhood"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" />
		<group id="203" type="span" parent="204" relname="same-unit"/>
		<group id="204" type="multinuc" parent="227" relname="preparation"/>
		<group id="205" type="span" parent="22" relname="evaluation"/>
		<group id="206" type="span" parent="207" relname="contrast"/>
		<group id="207" type="multinuc" parent="227" relname="span"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" parent="207" relname="contrast"/>
		<group id="210" type="multinuc" parent="223" relname="span"/>
		<group id="211" type="multinuc" parent="223" relname="elaboration"/>
		<group id="212" type="span" parent="211" relname="contrast"/>
		<group id="213" type="span" parent="29" relname="cause"/>
		<group id="214" type="span" parent="215" relname="span"/>
		<group id="215" type="span" parent="216" relname="span"/>
		<group id="216" type="span" parent="217" relname="span"/>
		<group id="217" type="span" parent="222" relname="span"/>
		<group id="218" type="multinuc" parent="219" relname="comparison"/>
		<group id="219" type="multinuc" parent="220" relname="span"/>
		<group id="220" type="span" parent="221" relname="span"/>
		<group id="221" type="span" parent="217" relname="evaluation"/>
		<group id="222" type="span" parent="31" relname="elaboration"/>
		<group id="223" type="span" parent="224" relname="span"/>
		<group id="224" type="span" parent="25" relname="elaboration"/>
		<group id="225" type="span" parent="30" relname="cause"/>
		<group id="226" type="span" parent="208" relname="evaluation"/>
		<group id="227" type="span" parent="228" relname="span"/>
		<group id="228" type="span" />
		<group id="229" type="multinuc" />
		<group id="230" type="span" parent="240" relname="joint"/>
		<group id="231" type="span" parent="232" relname="joint"/>
		<group id="232" type="multinuc" parent="233" relname="contrast"/>
		<group id="233" type="multinuc" parent="240" relname="joint"/>
		<group id="234" type="multinuc" parent="235" relname="span"/>
		<group id="235" type="span" parent="236" relname="span"/>
		<group id="236" type="span" parent="372" relname="joint"/>
		<group id="237" type="multinuc" parent="373" relname="elaboration"/>
		<group id="238" type="span" parent="55" relname="background"/>
		<group id="239" type="span" parent="54" relname="elaboration"/>
		<group id="240" type="multinuc" parent="243" relname="span"/>
		<group id="241" type="span" parent="243" relname="elaboration"/>
		<group id="242" type="span" parent="229" relname="contrast"/>
		<group id="243" type="span" parent="242" relname="span"/>
		<group id="244" type="multinuc" parent="245" relname="span"/>
		<group id="245" type="span" parent="246" relname="span"/>
		<group id="246" type="span" parent="58" relname="evidence"/>
		<group id="247" type="span" parent="248" relname="span"/>
		<group id="248" type="span" parent="65" relname="condition"/>
		<group id="249" type="span" parent="256" relname="solutionhood"/>
		<group id="250" type="span" parent="69" relname="cause"/>
		<group id="251" type="span" parent="254" relname="span"/>
		<group id="252" type="multinuc" parent="253" relname="joint"/>
		<group id="253" type="multinuc" parent="251" relname="cause"/>
		<group id="254" type="span" parent="66" relname="evidence"/>
		<group id="255" type="span" parent="258" relname="contrast"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" parent="258" relname="contrast"/>
		<group id="258" type="multinuc" />
		<group id="259" type="span" parent="260" relname="span"/>
		<group id="260" type="span" parent="283" relname="span"/>
		<group id="261" type="multinuc" parent="79" relname="elaboration"/>
		<group id="262" type="span" parent="263" relname="same-unit"/>
		<group id="263" type="multinuc" parent="264" relname="joint"/>
		<group id="264" type="multinuc" parent="286" relname="span"/>
		<group id="265" type="multinuc" parent="270" relname="contrast"/>
		<group id="266" type="span" parent="268" relname="joint"/>
		<group id="267" type="multinuc" parent="83" relname="elaboration"/>
		<group id="268" type="multinuc" parent="265" relname="contrast"/>
		<group id="269" type="span" parent="284" relname="contrast"/>
		<group id="270" type="multinuc" parent="286" relname="elaboration"/>
		<group id="271" type="multinuc" parent="284" relname="contrast"/>
		<group id="272" type="span" parent="271" relname="joint"/>
		<group id="273" type="span" parent="274" relname="contrast"/>
		<group id="274" type="multinuc" parent="91" relname="elaboration"/>
		<group id="275" type="span" parent="274" relname="contrast"/>
		<group id="276" type="multinuc" parent="278" relname="span"/>
		<group id="277" type="span" parent="276" relname="joint"/>
		<group id="278" type="span" parent="279" relname="span"/>
		<group id="279" type="span" parent="287" relname="span"/>
		<group id="280" type="span" parent="281" relname="contrast"/>
		<group id="281" type="multinuc" parent="279" relname="evidence"/>
		<group id="282" type="multinuc" parent="281" relname="contrast"/>
		<group id="283" type="span" parent="285" relname="span"/>
		<group id="284" type="multinuc" parent="270" relname="contrast"/>
		<group id="285" type="span" parent="287" relname="solutionhood"/>
		<group id="286" type="span" parent="288" relname="span"/>
		<group id="287" type="span" parent="289" relname="span"/>
		<group id="288" type="span" parent="260" relname="elaboration"/>
		<group id="289" type="span" />
		<group id="290" type="multinuc" parent="107" relname="background"/>
		<group id="291" type="multinuc" parent="293" relname="same-unit"/>
		<group id="292" type="span" parent="293" relname="same-unit"/>
		<group id="293" type="multinuc" parent="295" relname="joint"/>
		<group id="294" type="multinuc" parent="295" relname="joint"/>
		<group id="295" type="multinuc" parent="296" relname="span"/>
		<group id="296" type="span" parent="297" relname="span"/>
		<group id="297" type="span" parent="307" relname="evidence"/>
		<group id="298" type="span" parent="299" relname="span"/>
		<group id="299" type="span" parent="375" relname="span"/>
		<group id="300" type="multinuc" parent="307" relname="span"/>
		<group id="301" type="span" parent="302" relname="same-unit"/>
		<group id="302" type="multinuc" parent="300" relname="contrast"/>
		<group id="303" type="span" parent="122" relname="evaluation"/>
		<group id="304" type="span" parent="302" relname="same-unit"/>
		<group id="305" type="multinuc" parent="125" relname="elaboration"/>
		<group id="306" type="span" parent="309" relname="contrast"/>
		<group id="307" type="span" parent="308" relname="span"/>
		<group id="308" type="span" />
		<group id="309" type="multinuc" parent="335" relname="span"/>
		<group id="310" type="span" parent="309" relname="contrast"/>
		<group id="311" type="span" parent="335" relname="cause"/>
		<group id="312" type="span" parent="316" relname="cause"/>
		<group id="313" type="span" parent="315" relname="span"/>
		<group id="314" type="multinuc" parent="315" relname="evaluation"/>
		<group id="315" type="span" parent="316" relname="span"/>
		<group id="316" type="span" parent="317" relname="span"/>
		<group id="317" type="span" parent="132" relname="elaboration"/>
		<group id="318" type="span" parent="337" relname="span"/>
		<group id="319" type="multinuc" parent="142" relname="elaboration"/>
		<group id="320" type="multinuc" parent="332" relname="evidence"/>
		<group id="321" type="span" parent="322" relname="span"/>
		<group id="322" type="span" parent="320" relname="contrast"/>
		<group id="323" type="span" parent="324" relname="joint"/>
		<group id="324" type="multinuc" parent="145" relname="elaboration"/>
		<group id="325" type="multinuc" parent="324" relname="joint"/>
		<group id="326" type="span" parent="321" relname="evaluation"/>
		<group id="327" type="multinuc" parent="328" relname="span"/>
		<group id="328" type="span" parent="329" relname="span"/>
		<group id="329" type="span" parent="332" relname="span"/>
		<group id="330" type="multinuc" parent="334" relname="span"/>
		<group id="331" type="span" parent="329" relname="elaboration"/>
		<group id="332" type="span" parent="338" relname="span"/>
		<group id="333" type="span" parent="154" relname="elaboration"/>
		<group id="334" type="span" parent="333" relname="span"/>
		<group id="335" type="span" parent="336" relname="span"/>
		<group id="336" type="span" parent="318" relname="cause"/>
		<group id="337" type="span" />
		<group id="338" type="span" />
		<group id="339" type="multinuc" parent="340" relname="span"/>
		<group id="340" type="span" parent="341" relname="span"/>
		<group id="341" type="span" parent="345" relname="span"/>
		<group id="342" type="span" parent="356" relname="span"/>
		<group id="343" type="span" parent="344" relname="span"/>
		<group id="344" type="span" parent="162" relname="purpose"/>
		<group id="345" type="span" parent="355" relname="solutionhood"/>
		<group id="346" type="multinuc" parent="342" relname="elaboration"/>
		<group id="347" type="span" parent="348" relname="same-unit"/>
		<group id="348" type="multinuc" parent="349" relname="joint"/>
		<group id="349" type="multinuc" parent="172" relname="cause"/>
		<group id="350" type="span" parent="354" relname="background"/>
		<group id="351" type="span" parent="352" relname="joint"/>
		<group id="352" type="multinuc" parent="353" relname="span"/>
		<group id="353" type="span" parent="354" relname="span"/>
		<group id="354" type="span" parent="355" relname="span"/>
		<group id="355" type="span" parent="371" relname="span"/>
		<group id="356" type="span" parent="341" relname="evaluation"/>
		<group id="357" type="multinuc" parent="367" relname="joint"/>
		<group id="358" type="multinuc" parent="369" relname="contrast"/>
		<group id="359" type="multinuc" parent="358" relname="contrast"/>
		<group id="360" type="span" parent="361" relname="span"/>
		<group id="361" type="span" parent="366" relname="contrast"/>
		<group id="362" type="span" parent="363" relname="joint"/>
		<group id="363" type="multinuc" parent="364" relname="span"/>
		<group id="364" type="span" parent="365" relname="span"/>
		<group id="365" type="span" parent="366" relname="contrast"/>
		<group id="366" type="multinuc" parent="369" relname="contrast"/>
		<group id="367" type="multinuc" parent="368" relname="span"/>
		<group id="368" type="span" parent="370" relname="span"/>
		<group id="369" type="multinuc" parent="368" relname="elaboration"/>
		<group id="370" type="span" />
		<group id="371" type="span" />
		<group id="372" type="multinuc" parent="373" relname="span"/>
		<group id="373" type="span" parent="374" relname="span"/>
		<group id="374" type="span" parent="233" relname="contrast"/>
		<group id="375" type="span" parent="300" relname="contrast"/>
		<group id="376" type="span" parent="339" relname="joint"/>
		<group id="377" type="span" parent="294" relname="contrast"/>
	</body>
</rst>