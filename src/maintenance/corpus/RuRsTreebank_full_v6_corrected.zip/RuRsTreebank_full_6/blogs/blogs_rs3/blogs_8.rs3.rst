<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://kosmetista.ru/blog/uhodovaya-kosmetika/99379.html</segment>
		<segment id="2" >Мой лучший крем A'PIEU c мадекассосидом</segment>
		<segment id="3" parent="4" relname="condition">Если перечитать мои посты в сообществе «Уходовая косметика»,</segment>
		<segment id="4" parent="214" relname="span">то можно заметить, что найти крем для лица, который устраивал бы меня «от и до», мне не всегда удавалось.</segment>
		<segment id="5" parent="109" relname="joint">Всё время казалось, что дальше будет лучше</segment>
		<segment id="6" parent="109" relname="joint">и я обязательно найду свой «Святой Грааль» в мире кремов.</segment>
		<segment id="7" parent="110" relname="span">Что ж, кажется, это наконец-то произошло! IMG</segment>
		<segment id="8" parent="118" relname="preparation">С корейским брендом A'Pieu я уже была знакома.</segment>
		<segment id="9" parent="113" relname="joint">Несколько раз покупала их тканевые маски для лица (без восторга),</segment>
		<segment id="10" parent="112" relname="span">первое гидрофильное масло в моей жизни тоже было их бренда</segment>
		<segment id="11" parent="111" relname="span">(ужасно!</segment>
		<segment id="12" parent="11" relname="cause">вызвало аллергию),</segment>
		<segment id="13" parent="115" relname="same-unit">поэтому,</segment>
		<segment id="14" parent="15" relname="condition">когда я шла на кассу с этим кремом,</segment>
		<segment id="15" parent="114" relname="span">мое сердечко предательски ёкало.</segment>
		<segment id="16" parent="117" relname="contrast">Теперь то я знаю, что это оно от восторга 😉</segment>
		<segment id="17" parent="136" relname="span">A'PIEU Madecassoside Cream Крем для лица A'pieu с мадекассосидом, 50 ml. IMG</segment>
		<segment id="18" parent="17" relname="elaboration">Сначала пробежимся немного по внешним характеристикам.</segment>
		<segment id="19" parent="120" relname="span">Крем в пластиковой тубе,</segment>
		<segment id="20" parent="19" relname="elaboration">которая в свою очередь находится в картонной коробке, как на заглавном фото.</segment>
		<segment id="21" parent="121" relname="span">На ней указан состав и вся необходимая информация на русском, английском и корейском языках.</segment>
		<segment id="22" parent="21" relname="evaluation">Все максимально просто и лаконично.</segment>
		<segment id="23" parent="122" relname="comparison">Упаковка напоминает чем-то аптечную косметику.</segment>
		<segment id="24" parent="123" relname="joint">Крышка отвинчивается,</segment>
		<segment id="25" parent="123" relname="joint">носик широкий.</segment>
		<segment id="26" parent="129" relname="span">Проблем с извлечением крема не возникает.</segment>
		<segment id="27" parent="28" relname="condition">Пока его достаточно</segment>
		<segment id="28" parent="126" relname="span">— храню тубу горизонтально,</segment>
		<segment id="29" parent="128" relname="sequence">но к окончанию средства, ставлю вертикально</segment>
		<segment id="30" parent="128" relname="sequence">и потом крем легко выдавливается. IMG</segment>
		<segment id="31" parent="132" relname="span">Отдушка приятная.</segment>
		<segment id="32" parent="31" relname="elaboration">Пахнет чем-то кисленьким.</segment>
		<segment id="33" parent="132" relname="elaboration">Быстро выветривается.</segment>
		<segment id="34" parent="133" relname="evaluation">Не раздражает.</segment>
		<segment id="35" parent="141" relname="span">Текстура у A'pieu Madecassoside гелевая, а не классическая кремовая.</segment>
		<segment id="36" parent="140" relname="contrast">Далее по фото это можно будет увидеть.</segment>
		<segment id="37" parent="38" relname="evaluation">Но пока сохраню небольшую интригу</segment>
		<segment id="38" parent="139" relname="span">и перейду сразу же к описанию эффекта.</segment>
		<segment id="39" parent="142" relname="span">Моя кожа проблемная.</segment>
		<segment id="40" parent="39" relname="evaluation">Это слово, как мне кажется, в полной мере характеризует её.</segment>
		<segment id="41" parent="143" relname="joint">Постакне, периодически акне,</segment>
		<segment id="42" parent="143" relname="joint">она то сухая, то жирная.</segment>
		<segment id="43" parent="144" relname="joint">Еще и реагирует буквально на все: вода, день цикла, еда.</segment>
		<segment id="44" parent="145" relname="evaluation">Все факторы перечислять можно долго.</segment>
		<segment id="45" parent="149" relname="span">В этом году, я наконец-то нашла свой работающий уход.</segment>
		<segment id="46" parent="147" relname="span">Не так давно я писала пост на the Ordinary,</segment>
		<segment id="47" parent="46" relname="elaboration">где упоминала крем с мадекассосидом.</segment>
		<segment id="48" parent="147" relname="background">Почитать можно тут.</segment>
		<segment id="49" parent="165" relname="span">Так вот, именно сыворотки от the Ordinary я закрываю этим кремом от A'Pieu.</segment>
		<segment id="50" parent="164" relname="joint">Мне хватает пары горошин крема на всё лицо.</segment>
		<segment id="51" parent="164" relname="joint">Использую его исключительно на ночь.</segment>
		<segment id="52" parent="152" relname="evaluation">Так как, и вам нужно это знать ❗</segment>
		<segment id="53" parent="151" relname="joint">крем липкий,</segment>
		<segment id="54" parent="151" relname="joint">впитывается долго.</segment>
		<segment id="55" parent="155" relname="same-unit">И как мне кажется,</segment>
		<segment id="56" parent="57" relname="purpose">для использования под макияж</segment>
		<segment id="57" parent="154" relname="span">не очень подходит.</segment>
		<segment id="58" parent="160" relname="span">Но я делаю так:</segment>
		<segment id="59" parent="158" relname="sequence">умываюсь,</segment>
		<segment id="60" parent="158" relname="sequence">наношу сыворотки the Ordinary,</segment>
		<segment id="61" parent="158" relname="sequence">наношу крем.</segment>
		<segment id="62" parent="159" relname="sequence">Утром только умываюсь</segment>
		<segment id="63" parent="159" relname="sequence">и сразу наношу макияж.</segment>
		<segment id="64" parent="167" relname="evaluation">Неужели? Спросите вы.</segment>
		<segment id="65" parent="212" relname="span">О, да!</segment>
		<segment id="66" parent="169" relname="contrast">Эффекта от крема мне хватает и на утро.</segment>
		<segment id="67" parent="169" relname="contrast">Но всё, конечно, индивидуально.</segment>
		<segment id="68" parent="170" relname="span">Моя кожа очень хорошо на него реагирует,</segment>
		<segment id="69" parent="68" relname="elaboration">и конечно же не только с сыворотками, но и соло.</segment>
		<segment id="70" parent="171" relname="joint">Все шелушения за зимний период прошли,</segment>
		<segment id="71" parent="171" relname="joint">кожа мягкая, упругая и напитанная.</segment>
		<segment id="72" parent="172" relname="span">А ведь именно вот этот (странный для русского слуха) мадекассосид,</segment>
		<segment id="73" parent="72" relname="background">добываемый из центеллы азиатской</segment>
		<segment id="74" parent="173" relname="same-unit">помогает защитить кожу,</segment>
		<segment id="75" parent="174" relname="joint">восстановить ее,</segment>
		<segment id="76" parent="175" relname="span">поэтому крем можно применять даже</segment>
		<segment id="77" parent="76" relname="purpose">для заживления ранок.</segment>
		<segment id="78" parent="177" relname="concession">И, хотя я очень боюсь всяких силиконов в составе кремов,</segment>
		<segment id="79" parent="177" relname="span">с ним мои опасения оказались напрасны,</segment>
		<segment id="80" parent="79" relname="elaboration">и повторюсь, он отлично работает в тандеме с ниацинамидом, к примеру.</segment>
		<segment id="81" parent="189" relname="span">Смотрим в действии?</segment>
		<segment id="82" parent="81" relname="evaluation">Внимание, далее не самые эстетичные фото!</segment>
		<segment id="83" parent="188" relname="span">Зимой, у меня страдает кожа не только лица, но и рук.</segment>
		<segment id="84" parent="187" relname="span">В этом году как-то сильно всё обострилось,</segment>
		<segment id="85" parent="186" relname="contrast">и что я только не перепробовала,</segment>
		<segment id="86" parent="186" relname="contrast">ничего не помогало убрать красноту и шелушения.</segment>
		<segment id="87" parent="88" relname="condition">Пока, в отчаянии, я не решила нанести героя данного поста на руки.</segment>
		<segment id="88" parent="191" relname="span">Буквально за два дня каждодневного использования крема ушли шелушения, зуд, краснота.</segment>
		<segment id="89" parent="190" relname="contrast">А ведь ни один крем для рук ни в одной ценовой категории не помогал мне.</segment>
		<segment id="90" parent="193" relname="evaluation">Такие дела.</segment>
		<segment id="91" parent="192" relname="span">Собственно говоря фото-доказательства.</segment>
		<segment id="92" parent="91" relname="elaboration">А заодно и консистенция крема.</segment>
		<segment id="93" parent="192" relname="elaboration">IMG до IMG через минуту после нанесения крема A'pieu с мадекассосидом</segment>
		<segment id="94" parent="197" relname="contrast">Эффект, как говорится, на руки 😄</segment>
		<segment id="95" parent="96" relname="evaluation">Ну а если серьезно,</segment>
		<segment id="96" parent="196" relname="span">то я очень довольна кремом.</segment>
		<segment id="97" parent="198" relname="joint">Я точно буду его повторять,</segment>
		<segment id="98" parent="199" relname="span">и скорее всего перестану искать для своей кожи «что-то лучше»,</segment>
		<segment id="99" parent="98" relname="condition">по крайней мере, до тех пор, пока свойства и результат от данного крема меня будет устраивать. IMG</segment>
		<segment id="100" parent="205" relname="elaboration">750₽цена</segment>
		<segment id="101" parent="204" relname="evaluation">10/10оценка</segment>
		<segment id="102" parent="206" relname="elaboration">3 месяца, 5р/в неделюиспользование</segment>
		<segment id="103" >​Девушки, спасибо за внимание,</segment>
		<segment id="104" >меня зовут Кристина,</segment>
		<segment id="105" >и ко мне на «ты».</segment>
		<segment id="106" >Расскажите, вы уже нашли свой идеальный крем для лица?</segment>
		<segment id="107" >Пробовали ли что-то у бренда A'PIEU?</segment>
		<group id="109" type="multinuc" parent="215" relname="contrast"/>
		<group id="110" type="span" />
		<group id="111" type="span" parent="10" relname="evaluation"/>
		<group id="112" type="span" parent="113" relname="joint"/>
		<group id="113" type="multinuc" parent="116" relname="span"/>
		<group id="114" type="span" parent="115" relname="same-unit"/>
		<group id="115" type="multinuc" parent="210" relname="span"/>
		<group id="116" type="span" parent="210" relname="cause"/>
		<group id="117" type="multinuc" parent="118" relname="span"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" />
		<group id="120" type="span" parent="131" relname="span"/>
		<group id="121" type="span" parent="122" relname="comparison"/>
		<group id="122" type="multinuc" parent="124" relname="span"/>
		<group id="123" type="multinuc" parent="124" relname="elaboration"/>
		<group id="124" type="span" parent="125" relname="span"/>
		<group id="125" type="span" parent="130" relname="span"/>
		<group id="126" type="span" parent="127" relname="contrast"/>
		<group id="127" type="multinuc" parent="26" relname="elaboration"/>
		<group id="128" type="multinuc" parent="127" relname="contrast"/>
		<group id="129" type="span" parent="125" relname="elaboration"/>
		<group id="130" type="span" parent="120" relname="elaboration"/>
		<group id="131" type="span" parent="135" relname="joint"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" parent="135" relname="joint"/>
		<group id="135" type="multinuc" parent="137" relname="span"/>
		<group id="136" type="span" parent="137" relname="preparation"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" />
		<group id="139" type="span" parent="140" relname="contrast"/>
		<group id="140" type="multinuc" parent="35" relname="elaboration"/>
		<group id="141" type="span" parent="135" relname="joint"/>
		<group id="142" type="span" parent="150" relname="span"/>
		<group id="143" type="multinuc" parent="144" relname="joint"/>
		<group id="144" type="multinuc" parent="145" relname="span"/>
		<group id="145" type="span" parent="146" relname="span"/>
		<group id="146" type="span" parent="142" relname="elaboration"/>
		<group id="147" type="span" parent="148" relname="span"/>
		<group id="148" type="span" parent="45" relname="background"/>
		<group id="149" type="span" parent="163" relname="span"/>
		<group id="150" type="span" parent="149" relname="solutionhood"/>
		<group id="151" type="multinuc" parent="152" relname="span"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" parent="156" relname="cause"/>
		<group id="154" type="span" parent="155" relname="same-unit"/>
		<group id="155" type="multinuc" parent="156" relname="span"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="166" relname="contrast"/>
		<group id="158" type="multinuc" parent="162" relname="span"/>
		<group id="159" type="multinuc" parent="162" relname="elaboration"/>
		<group id="160" type="span" parent="166" relname="contrast"/>
		<group id="161" type="span" parent="58" relname="elaboration"/>
		<group id="162" type="span" parent="161" relname="span"/>
		<group id="163" type="span" />
		<group id="164" type="multinuc" parent="49" relname="elaboration"/>
		<group id="165" type="span" parent="185" relname="preparation"/>
		<group id="166" type="multinuc" parent="185" relname="span"/>
		<group id="167" type="span" parent="168" relname="span"/>
		<group id="168" type="span" parent="212" relname="solutionhood"/>
		<group id="169" type="multinuc" parent="179" relname="span"/>
		<group id="170" type="span" parent="181" relname="span"/>
		<group id="171" type="multinuc" parent="184" relname="span"/>
		<group id="172" type="span" parent="173" relname="same-unit"/>
		<group id="173" type="multinuc" parent="174" relname="joint"/>
		<group id="174" type="multinuc" parent="175" relname="cause"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" parent="182" relname="span"/>
		<group id="177" type="span" parent="178" relname="span"/>
		<group id="178" type="span" parent="176" relname="evaluation"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" parent="65" relname="evidence"/>
		<group id="181" type="span" parent="179" relname="elaboration"/>
		<group id="182" type="span" parent="184" relname="elaboration"/>
		<group id="183" type="span" parent="170" relname="elaboration"/>
		<group id="184" type="span" parent="183" relname="span"/>
		<group id="185" type="span" parent="167" relname="span"/>
		<group id="186" type="multinuc" parent="84" relname="elaboration"/>
		<group id="187" type="span" parent="83" relname="evaluation"/>
		<group id="188" type="span" parent="201" relname="span"/>
		<group id="189" type="span" parent="188" relname="preparation"/>
		<group id="190" type="multinuc" parent="193" relname="span"/>
		<group id="191" type="span" parent="190" relname="contrast"/>
		<group id="192" type="span" parent="195" relname="span"/>
		<group id="193" type="span" parent="194" relname="span"/>
		<group id="194" type="span" parent="202" relname="span"/>
		<group id="195" type="span" parent="200" relname="span"/>
		<group id="196" type="span" parent="197" relname="contrast"/>
		<group id="197" type="multinuc" parent="195" relname="evaluation"/>
		<group id="198" type="multinuc" parent="205" relname="span"/>
		<group id="199" type="span" parent="198" relname="joint"/>
		<group id="200" type="span" parent="194" relname="evidence"/>
		<group id="201" type="span" parent="208" relname="solutionhood"/>
		<group id="202" type="span" parent="203" relname="joint"/>
		<group id="203" type="multinuc" parent="208" relname="span"/>
		<group id="204" type="span" parent="206" relname="span"/>
		<group id="205" type="span" parent="204" relname="span"/>
		<group id="206" type="span" parent="207" relname="span"/>
		<group id="207" type="span" parent="203" relname="joint"/>
		<group id="208" type="span" parent="209" relname="span"/>
		<group id="209" type="span" />
		<group id="210" type="span" parent="211" relname="span"/>
		<group id="211" type="span" parent="117" relname="contrast"/>
		<group id="212" type="span" parent="213" relname="span"/>
		<group id="213" type="span" />
		<group id="214" type="span" parent="215" relname="contrast"/>
		<group id="215" type="multinuc" parent="7" relname="solutionhood"/>
	</body>
</rst>