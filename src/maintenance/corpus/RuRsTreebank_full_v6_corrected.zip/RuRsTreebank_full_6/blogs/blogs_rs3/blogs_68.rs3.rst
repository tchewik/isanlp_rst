<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://gelena-s.livejournal.com/296755.html</segment>
		<segment id="2" >Про имидж</segment>
		<segment id="3" parent="211" relname="same-unit">«Доктор,</segment>
		<segment id="4" parent="5" relname="condition">когда я встаю на четвереньки,</segment>
		<segment id="5" parent="210" relname="span">у меня отвисают нижние веки!»</segment>
		<segment id="6" parent="212" relname="elaboration">Из реальных запросов к пластическому хирургу.</segment>
		<segment id="7" parent="111" relname="span">Вот по такому запросу и понятно, почему раньше в любой уважающей себя клинике пластической хирургии обязательно работал психиатр.</segment>
		<segment id="8" parent="7" relname="elaboration">Это я по теме поста у Яны miumau про маму, которая так и не увидела, что дочь нуждается в пластике.</segment>
		<segment id="9" parent="113" relname="span">Потому решила сама немного про это написать.</segment>
		<segment id="10" parent="118" relname="preparation">Когда-то в старших классах я сама уговорила подругу на пластику носа.</segment>
		<segment id="11" parent="114" relname="joint">Она была внешне очень хорошо сложена,</segment>
		<segment id="12" parent="117" relname="span">все в лице пропорционально, кроме кончика носа.</segment>
		<segment id="13" parent="116" relname="comparison">Который всегда оставлял странное впечатление:</segment>
		<segment id="14" parent="15" relname="cause">как будто кто-то небрежно надрезал нос посередине</segment>
		<segment id="15" parent="115" relname="span">и все вот так заросло. Как бы почти два носа.</segment>
		<segment id="16" parent="120" relname="contrast">Пустяк вроде,</segment>
		<segment id="17" parent="120" relname="contrast">но на школьных танцах ее практически не приглашали.</segment>
		<segment id="18" parent="121" relname="joint">И меня тогда больше всего зацепило, что ребята, старались взглядом как бы избегать ее лица.</segment>
		<segment id="19" parent="124" relname="contrast">Кстати, ни травли, ни каких-то дразнилок в ее адрес тоже никогда не было.</segment>
		<segment id="20" parent="123" relname="joint">Но я тогда очень хотела ей помочь,</segment>
		<segment id="21" parent="123" relname="joint">мне было неуютно, что мимо нее проходят вся эта подростковая круговерть с влюбленностями и первыми поцелуями.</segment>
		<segment id="22" parent="125" relname="span">Вот и посеяла ей идею сделать пластику.</segment>
		<segment id="23" parent="215" relname="joint">Ее мама ругалась на нас обоих,</segment>
		<segment id="24" parent="215" relname="joint">говорила,</segment>
		<segment id="25" parent="129" relname="joint">что ее дочь и так полюбят,</segment>
		<segment id="26" parent="129" relname="joint">что «судьба и на печке найдет»,</segment>
		<segment id="27" parent="129" relname="joint">что недостаток у нее пустяшный.</segment>
		<segment id="28" parent="131" relname="contrast">Но маму уломали доехать с дочкой к врачу.</segment>
		<segment id="29" parent="134" relname="sequence">Вошли они в кабинет</segment>
		<segment id="30" parent="133" relname="joint">и врач,</segment>
		<segment id="31" parent="32" relname="cause">глядя на взвинченную маму,</segment>
		<segment id="32" parent="132" relname="span">сразу решил успокоить: «А чего вы волнуетесь?</segment>
		<segment id="33" parent="135" relname="joint">Операция простая,</segment>
		<segment id="34" parent="135" relname="joint">кость трогать не надо,</segment>
		<segment id="35" parent="135" relname="joint">через месяц будет красавицей!»</segment>
		<segment id="36" parent="138" relname="joint">Действительно, после операции она стала и лучше выглядеть</segment>
		<segment id="37" parent="138" relname="joint">и самое главное, увереннее себя чувствовать.</segment>
		<segment id="38" parent="137" relname="span">Это выразилось даже в том, что на следующий год она сама, без блата, поступила в Плехановский,</segment>
		<segment id="39" parent="38" relname="evaluation">тогда такое было сродни чуду.</segment>
		<segment id="40" parent="218" relname="attribution">Она говорила,</segment>
		<segment id="41" parent="218" relname="span">что как раз вот радость от того, что она теперь всегда чувствует себя в порядке и дала ей силы</segment>
		<segment id="42" parent="41" relname="purpose">для поступления.</segment>
		<segment id="43" parent="146" relname="preparation">Кстати, еще один интересный факт.</segment>
		<segment id="44" parent="145" relname="span">Когда ее готовили к операции,</segment>
		<segment id="45" parent="44" relname="background">а это в «институте красоты» делали почему-то для всех сразу,</segment>
		<segment id="46" parent="146" relname="span">то среди тех, кто с оперировался одновременно с моей подругой, была девушка, вызывавшая недоуменные взгляды.</segment>
		<segment id="47" parent="148" relname="span">Она была просто красавица, с распущенными пышными волосами,</segment>
		<segment id="48" parent="47" relname="evaluation">на первый взгляд, совершенно нечего оперировать.</segment>
		<segment id="49" parent="150" relname="contrast">Остальные были со всяко-разно заметными носами, пара девушек с Кавказа, у которых нос «на двоих рос», девушка после аварии с вмятиной на лице,</segment>
		<segment id="50" parent="150" relname="contrast">а тут такая красотка…</segment>
		<segment id="51" parent="154" relname="evaluation">Зачем?</segment>
		<segment id="52" parent="153" relname="span">Все выяснилось,</segment>
		<segment id="53" parent="152" relname="joint">когда все переоделись</segment>
		<segment id="54" parent="152" relname="joint">и убрали волосы под шапочку.</segment>
		<segment id="55" parent="156" relname="attribution">Подруга рассказывала,</segment>
		<segment id="56" parent="57" relname="concession">что несмотря на мандраж перед операцией,</segment>
		<segment id="57" parent="156" relname="span">все невольно расползлись в улыбке.</segment>
		<segment id="58" parent="158" relname="joint">У этой красавицы одно ухо торчало строго перпендикулярно к голове,</segment>
		<segment id="59" parent="158" relname="joint">и вид у нее получался умилительно-забавный.</segment>
		<segment id="60" parent="159" relname="comparison">Как будто она одним ухом прислушивается, как щенок.</segment>
		<segment id="61" parent="62" relname="attribution">Девушка на улыбки и ответила:</segment>
		<segment id="62" parent="220" relname="span">«Знаете, как надоело работать клоуном?</segment>
		<segment id="63" parent="160" relname="span">Вот потому и делаю пластику,</segment>
		<segment id="64" parent="63" relname="cause">что устала от таких улыбок.»</segment>
		<segment id="65" parent="164" relname="span">По этой причине уже много позже, взрослой, я предложила соседке, которая все умилялась на дочкины оттопыренные «лопушки», все же сделать операцию,</segment>
		<segment id="66" parent="65" relname="condition">пока ребенок особо ничего не понимает.</segment>
		<segment id="67" parent="164" relname="purpose">Что бы роль клоуна не приросла.</segment>
		<segment id="68" parent="166" relname="contrast">Но тогда она даже слушать не стала.</segment>
		<segment id="69" parent="167" relname="joint">И я уже была сильно взрослее</segment>
		<segment id="70" parent="167" relname="joint">и настаивать, конечно не стала.</segment>
		<segment id="71" parent="168" relname="span">А через какое-то время получила упрек от мамы, что вот «ты же психолог</segment>
		<segment id="72" parent="71" relname="concession">(хотя тогда я психологом еще не была),</segment>
		<segment id="73" parent="169" relname="span">чего же не настояла?»</segment>
		<segment id="74" parent="170" relname="joint">У девочки случилась нехорошая история с мальчиком, который ей нравился,</segment>
		<segment id="75" parent="170" relname="joint">а он прилюдно и довольно зло проехался по ее ушам.</segment>
		<segment id="76" parent="209" relname="span">Ну и была попытка суицида, к счастью неудачная.</segment>
		<segment id="77" parent="175" relname="joint">Потом было много разных случаев с клиентами,</segment>
		<segment id="78" parent="175" relname="joint">я даже где-то писала.</segment>
		<segment id="79" parent="176" relname="span">Так вот, клиентам иногда даже советовала к врачу косметологу сходить.</segment>
		<segment id="80" parent="81" relname="condition">При хорошем контакте с клиентом</segment>
		<segment id="81" parent="179" relname="span">сказать можно многое.</segment>
		<segment id="82" parent="178" relname="span">Например, тот же ботокс может быть серьезным вспомогательным средством</segment>
		<segment id="83" parent="82" relname="condition">при психотерапии.</segment>
		<segment id="84" parent="185" relname="span">Великолепно блокирует автоматический вход во многие привычные состояния.</segment>
		<segment id="85" parent="183" relname="contrast">Лоб уже не хмурится,</segment>
		<segment id="86" parent="182" relname="span">а с гладким лбом накрутить себя в разы труднее</segment>
		<segment id="87" parent="181" relname="same-unit">(попробуйте,</segment>
		<segment id="88" parent="89" relname="condition">сохраняя гладкое лицо,</segment>
		<segment id="89" parent="180" relname="span">воспроизвести в себе какое-либо состояние из списка «все люди – гады!»),</segment>
		<segment id="90" parent="184" relname="span">соответственно уходит привычный автоматизм реакций.</segment>
		<segment id="91" parent="226" relname="preparation">Но вот об одной вещи хочу обязательно рассказать.</segment>
		<segment id="92" parent="224" relname="span">Есть такое фактически расстройство психики, как дисморфофобия.</segment>
		<segment id="93" parent="225" relname="span">И тут я хочу описать один грубый, но заметный признак, по которому становится понятно, что лучше работать уже не с психологом, а с психиатром.</segment>
		<segment id="94" parent="192" relname="same-unit">Это когда клиент,</segment>
		<segment id="95" parent="190" relname="span">имея во внешности действительно заметный дефект</segment>
		<segment id="96" parent="95" relname="evidence">(нос там кривой или очень плохую кожу)</segment>
		<segment id="97" parent="191" relname="span">зафиксирован совсем на другом.</segment>
		<segment id="98" parent="213" relname="same-unit">Например,</segment>
		<segment id="99" parent="100" relname="condition">при явно выраженной кривизне носа</segment>
		<segment id="100" parent="214" relname="span">человек сосредоточен на форме груди или повышенной волосатости на руках.</segment>
		<segment id="101" parent="193" relname="joint">И если при этом были какие-то дико радикальные попытки самому себе что-то исправить.</segment>
		<segment id="102" parent="103" relname="condition">Так вот, учтите, если это ваш близкий,</segment>
		<segment id="103" parent="197" relname="span">то ищите психиатра.</segment>
		<segment id="104" parent="197" relname="evaluation">Очень может пригодится.</segment>
		<segment id="105" parent="202" relname="span">А вам я сейчас задам один вопрос на эту тему.</segment>
		<segment id="106" parent="201" relname="joint">Когда, на ваш взгляд, полезны операции по увеличению груди?</segment>
		<segment id="107" parent="201" relname="joint">Когда полезны операции по уменьшению груди?</segment>
		<segment id="108" parent="201" relname="joint">Какие факторы тут работают?</segment>
		<segment id="109" parent="200" relname="contrast">Когда это блажь,</segment>
		<segment id="110" parent="200" relname="contrast">а когда необходимость?</segment>
		<group id="111" type="span" parent="112" relname="span"/>
		<group id="112" type="span" parent="9" relname="cause"/>
		<group id="113" type="span" parent="128" relname="span"/>
		<group id="114" type="multinuc" parent="127" relname="span"/>
		<group id="115" type="span" parent="116" relname="comparison"/>
		<group id="116" type="multinuc" parent="12" relname="elaboration"/>
		<group id="117" type="span" parent="114" relname="joint"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" parent="113" relname="evidence"/>
		<group id="120" type="multinuc" parent="121" relname="joint"/>
		<group id="121" type="multinuc" parent="122" relname="span"/>
		<group id="122" type="span" parent="126" relname="span"/>
		<group id="123" type="multinuc" parent="124" relname="contrast"/>
		<group id="124" type="multinuc" parent="22" relname="cause"/>
		<group id="125" type="span" parent="122" relname="elaboration"/>
		<group id="126" type="span" parent="127" relname="elaboration"/>
		<group id="127" type="span" parent="118" relname="span"/>
		<group id="128" type="span" />
		<group id="129" type="multinuc" parent="216" relname="span"/>
		<group id="131" type="multinuc" parent="136" relname="sequence"/>
		<group id="132" type="span" parent="204" relname="solutionhood"/>
		<group id="133" type="multinuc" parent="134" relname="sequence"/>
		<group id="134" type="multinuc" parent="136" relname="sequence"/>
		<group id="135" type="multinuc" parent="204" relname="span"/>
		<group id="136" type="multinuc" parent="143" relname="span"/>
		<group id="137" type="span" parent="142" relname="span"/>
		<group id="138" type="multinuc" parent="139" relname="span"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="143" relname="evaluation"/>
		<group id="142" type="span" parent="139" relname="evidence"/>
		<group id="143" type="span" parent="144" relname="span"/>
		<group id="144" type="span" />
		<group id="145" type="span" parent="46" relname="condition"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" parent="149" relname="span"/>
		<group id="148" type="span" parent="147" relname="elaboration"/>
		<group id="149" type="span" parent="151" relname="comparison"/>
		<group id="150" type="multinuc" parent="151" relname="comparison"/>
		<group id="151" type="multinuc" parent="154" relname="span"/>
		<group id="152" type="multinuc" parent="52" relname="cause"/>
		<group id="153" type="span" parent="163" relname="span"/>
		<group id="154" type="span" parent="155" relname="span"/>
		<group id="155" type="span" parent="163" relname="solutionhood"/>
		<group id="156" type="span" parent="221" relname="span"/>
		<group id="158" type="multinuc" parent="159" relname="comparison"/>
		<group id="159" type="multinuc" parent="221" relname="cause"/>
		<group id="160" type="span" parent="207" relname="span"/>
		<group id="163" type="span" parent="206" relname="span"/>
		<group id="164" type="span" parent="165" relname="span"/>
		<group id="165" type="span" parent="166" relname="contrast"/>
		<group id="166" type="multinuc" parent="173" relname="span"/>
		<group id="167" type="multinuc" parent="172" relname="contrast"/>
		<group id="168" type="span" parent="73" relname="cause"/>
		<group id="169" type="span" parent="171" relname="span"/>
		<group id="170" type="multinuc" parent="76" relname="cause"/>
		<group id="171" type="span" parent="172" relname="contrast"/>
		<group id="172" type="multinuc" parent="173" relname="evaluation"/>
		<group id="173" type="span" parent="174" relname="span"/>
		<group id="174" type="span" />
		<group id="175" type="multinuc" parent="79" relname="preparation"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" parent="187" relname="span"/>
		<group id="178" type="span" parent="186" relname="span"/>
		<group id="179" type="span" parent="176" relname="elaboration"/>
		<group id="180" type="span" parent="181" relname="same-unit"/>
		<group id="181" type="multinuc" parent="86" relname="evidence"/>
		<group id="182" type="span" parent="183" relname="contrast"/>
		<group id="183" type="multinuc" parent="90" relname="cause"/>
		<group id="184" type="span" parent="84" relname="elaboration"/>
		<group id="185" type="span" parent="178" relname="elaboration"/>
		<group id="186" type="span" parent="177" relname="evidence"/>
		<group id="187" type="span" />
		<group id="190" type="span" parent="97" relname="condition"/>
		<group id="191" type="span" parent="192" relname="same-unit"/>
		<group id="192" type="multinuc" parent="194" relname="span"/>
		<group id="193" type="multinuc" parent="194" relname="evidence"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" parent="93" relname="elaboration"/>
		<group id="197" type="span" parent="198" relname="span"/>
		<group id="198" type="span" parent="224" relname="evaluation"/>
		<group id="200" type="multinuc" parent="201" relname="joint"/>
		<group id="201" type="multinuc" parent="105" relname="elaboration"/>
		<group id="202" type="span" />
		<group id="203" type="span" parent="111" relname="preparation"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="133" relname="joint"/>
		<group id="206" type="span" />
		<group id="207" type="span" parent="222" relname="evaluation"/>
		<group id="209" type="span" parent="169" relname="background"/>
		<group id="210" type="span" parent="211" relname="same-unit"/>
		<group id="211" type="multinuc" parent="212" relname="span"/>
		<group id="212" type="span" parent="203" relname="span"/>
		<group id="213" type="multinuc" parent="193" relname="joint"/>
		<group id="214" type="span" parent="213" relname="same-unit"/>
		<group id="215" type="multinuc" parent="216" relname="attribution"/>
		<group id="216" type="span" parent="217" relname="span"/>
		<group id="217" type="span" parent="131" relname="contrast"/>
		<group id="218" type="span" parent="219" relname="span"/>
		<group id="219" type="span" parent="137" relname="elaboration"/>
		<group id="220" type="span" parent="160" relname="cause"/>
		<group id="221" type="span" parent="222" relname="span"/>
		<group id="222" type="span" parent="223" relname="span"/>
		<group id="223" type="span" parent="153" relname="elaboration"/>
		<group id="224" type="span" parent="226" relname="span"/>
		<group id="225" type="span" parent="92" relname="elaboration"/>
		<group id="226" type="span" parent="227" relname="span"/>
		<group id="227" type="span" />
	</body>
</rst>