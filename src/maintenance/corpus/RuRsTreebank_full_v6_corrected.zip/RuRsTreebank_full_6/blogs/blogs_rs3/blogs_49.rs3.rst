<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://tonsky.livejournal.com/320566.html</segment>
		<segment id="2" >Пациент умер, выносите IMG</segment>
		<segment id="3" parent="142" relname="preparation">Я занимаюсь веб программированием 15 лет.</segment>
		<segment id="4" parent="139" relname="span">Когда я начинал работать за деньги</segment>
		<segment id="5" parent="4" relname="background">(компьютер у меня был и раньше, конечно),</segment>
		<segment id="6" parent="140" relname="joint">IE 6 был самым передовым и инновационным браузером,</segment>
		<segment id="7" parent="140" relname="joint">Firefox должен был вот-вот появиться,</segment>
		<segment id="8" parent="140" relname="joint">разработчики верили, что будущее за XHTML,</segment>
		<segment id="9" parent="140" relname="joint">до первого драфта HTML 5 и запуска StackOverflow оставалось 4 года,</segment>
		<segment id="10" parent="140" relname="joint">а до первого Chrome – пять лет.</segment>
		<segment id="11" parent="146" relname="span">С вебом было связяно много неоправданных надежд, хайпа, завышенных ожиданий.</segment>
		<segment id="12" parent="144" relname="joint">Мы все ждали, когда же он вот все вообще поглотит,</segment>
		<segment id="13" parent="144" relname="joint">заменит,</segment>
		<segment id="14" parent="144" relname="joint">научится всему</segment>
		<segment id="15" parent="145" relname="span">и вообще останется чуть ли не единственным инструментом,</segment>
		<segment id="16" parent="15" relname="elaboration">с которым будут работать вообще все.</segment>
		<segment id="17" parent="18" relname="cause">Сейчас ажиотаж спал</segment>
		<segment id="18" parent="150" relname="span">и можно взглянуть трезво,</segment>
		<segment id="19" parent="147" relname="contrast">что он такое есть</segment>
		<segment id="20" parent="147" relname="contrast">и что он такое нет.</segment>
		<segment id="21" parent="163" relname="preparation">Получается вот как.</segment>
		<segment id="22" parent="152" relname="span">Веб хорош</segment>
		<segment id="23" parent="22" relname="purpose">для быстрого прототипирования, простого delivery,</segment>
		<segment id="24" parent="153" relname="contrast">но масштаб его роста сильно ограничен.</segment>
		<segment id="25" parent="156" relname="evaluation">Грубо говоря, он подходит только для прототипов и игрушечных задач.</segment>
		<segment id="26" parent="155" relname="span">Что-то вроде языка Basic,</segment>
		<segment id="27" parent="154" relname="contrast">вроде и программы писать на нем можно,</segment>
		<segment id="28" parent="154" relname="contrast">но всерьез его никто не берет.</segment>
		<segment id="29" parent="159" relname="contrast">Веб, конечно, не пропадет,</segment>
		<segment id="30" parent="161" relname="span">но в конечном счете займет место какого-нибудь там питона,</segment>
		<segment id="31" parent="160" relname="joint">на котором будут детей в MIT учить</segment>
		<segment id="32" parent="160" relname="joint">и ученые не слишком требовательные графики рисовать.</segment>
		<segment id="33" parent="179" relname="solutionhood">Почему?</segment>
		<segment id="34" parent="179" relname="span">Качество.</segment>
		<segment id="35" parent="178" relname="span">Все, сделанное на вебе, просто не доводится до какого-то сносного качества.</segment>
		<segment id="36" parent="165" relname="span">Да, на вебе можно начать,</segment>
		<segment id="37" parent="36" relname="evaluation">и это будет быстрый старт.</segment>
		<segment id="38" parent="166" relname="span">Но веб нельзя дожать до приемлимого состояния.</segment>
		<segment id="39" parent="38" relname="evaluation">От слова никак.</segment>
		<segment id="40" parent="167" relname="contrast">Обязательно будет смешно, плохо и стыдно,</segment>
		<segment id="41" parent="167" relname="contrast">а хорошо и быстро — никогда.</segment>
		<segment id="42" parent="170" relname="contrast">Все веб-программисты на самом деле верят, что это они недостаточно стараются,</segment>
		<segment id="43" parent="44" relname="condition">но если было бы время,</segment>
		<segment id="44" parent="171" relname="span">можно было бы сделать нормально.</segment>
		<segment id="45" parent="172" relname="evaluation">На этом самообмане вообще вся веб-индустрия держится.</segment>
		<segment id="46" parent="175" relname="span">Но нет. Нельзя.</segment>
		<segment id="47" parent="46" relname="condition">Ни за какие деньги.</segment>
		<segment id="48" parent="175" relname="condition">Просто физически невозможно.</segment>
		<segment id="49" parent="181" relname="joint">Ладно, простые статические страницы с текстом — ок, может быть.</segment>
		<segment id="50" parent="181" relname="joint">С адблоком и reader mode жить можно.</segment>
		<segment id="51" parent="182" relname="evaluation">Хотя и тут есть умельцы,</segment>
		<segment id="52" parent="182" relname="span">которые умудряются сто слов отрендерить в страницу в 20 мегабайт,</segment>
		<segment id="53" parent="52" relname="cause">потому что технологии, инновации и disruption.</segment>
		<segment id="54" parent="187" relname="span">Что-то чуть сложнее — все,</segment>
		<segment id="55" parent="54" relname="evaluation">говно лезет из всех щелей.</segment>
		<segment id="56" parent="188" relname="joint">Веб-приложения?</segment>
		<segment id="57" parent="188" relname="joint">Интерфейсы?</segment>
		<segment id="58" parent="196" relname="span">Сразу вешайтесь.</segment>
		<segment id="59" parent="189" relname="span">Веб не создан</segment>
		<segment id="60" parent="59" relname="purpose">для приложений</segment>
		<segment id="61" parent="190" relname="joint">и не развивается в эту сторону даже.</segment>
		<segment id="62" parent="191" relname="joint">Нет ни одного человека, который бы искренне любил веб-версию чего-либо</segment>
		<segment id="63" parent="191" relname="joint">и предпочитал ее нативной.</segment>
		<segment id="64" parent="65" relname="condition">Как только появляется альтернатива, даже иллюзия альтернативы, даже электрон-приложение,</segment>
		<segment id="65" parent="192" relname="span">— всё, команда с крысами покинула корабль.</segment>
		<segment id="66" parent="203" relname="span">Сказать, что веб-приложение работает «нормально»</segment>
		<segment id="67" parent="200" relname="span">можно только если очень, очень сильно смотреть на какой-то очень и очень частный случай сквозь пальцы,</segment>
		<segment id="68" parent="199" relname="span">стиснутые настолько сильно,</segment>
		<segment id="69" parent="68" relname="evaluation">что они превращаются в фейспалм,</segment>
		<segment id="70" parent="201" relname="joint">и только если очень, очень верить в идею веба</segment>
		<segment id="71" parent="201" relname="joint">и хотеть это «нормально» увидеть.</segment>
		<segment id="72" parent="73" relname="condition">В определенных условиях на определенной мощности машине</segment>
		<segment id="73" parent="204" relname="span">страничка может проскроллиться относительно плавно.</segment>
		<segment id="74" parent="205" relname="joint">В определенном месте экватора сайт может открыться условно быстро,</segment>
		<segment id="75" parent="205" relname="joint">а в определенное время конкретного дня в веб-консоли даже не будет ни одной ошибки.</segment>
		<segment id="76" parent="207" relname="condition">Но если взять платформу в целом,</segment>
		<segment id="77" parent="78" relname="condition">без сверхподвигов и свехржертв,</segment>
		<segment id="78" parent="207" relname="span">иллюзия пропадает.</segment>
		<segment id="79" parent="209" relname="span">Если дать на нее посмотреть человеку,</segment>
		<segment id="80" parent="79" relname="condition">не укушенному веб-пропагандой,</segment>
		<segment id="81" parent="210" relname="span">иллюзия пропадает.</segment>
		<segment id="82" parent="83" relname="condition">Как только приложение открывает кто-то, отличный от его собственного разработчика на гигабитном интернете и двенадцатиядерном аймаке про,</segment>
		<segment id="83" parent="211" relname="span">иллюзия пропадает.</segment>
		<segment id="84" parent="213" relname="span">Начинается бесконечный поток убогостей, шероховатостей, заусенцев, тормозов, проблем, ошибок,</segment>
		<segment id="85" parent="220" relname="span">которые в принципе не устранить никаким образом.</segment>
		<segment id="86" parent="214" relname="joint">Даже если у разработчика есть внимание и желание возиться с такими глупостями,</segment>
		<segment id="87" parent="214" relname="joint">даже если приложить бесконенчые усилия</segment>
		<segment id="88" parent="215" relname="span">— нет, оно не исправляется в принципе.</segment>
		<segment id="89" parent="216" relname="joint">Я знаю, я сам такой разработчик,</segment>
		<segment id="90" parent="216" relname="joint">и я пробовал много раз,</segment>
		<segment id="91" parent="216" relname="joint">и много раз обжигался.</segment>
		<segment id="92" parent="93" relname="condition">Хотя когда смотришь издалека,</segment>
		<segment id="93" parent="218" relname="span">на бумаге, вроде все хорошо.</segment>
		<segment id="94" parent="228" relname="solutionhood">Что может пойти не так?</segment>
		<segment id="95" parent="223" relname="span">Да все что угодно.</segment>
		<segment id="96" parent="222" relname="joint">И не только может,</segment>
		<segment id="97" parent="222" relname="joint">но и пойдет, причем в самом неожиданном месте.</segment>
		<segment id="98" parent="225" relname="span">Веб это такой аналог российского автопрома</segment>
		<segment id="99" parent="224" relname="joint">— издалека вроде тоже машина,</segment>
		<segment id="100" parent="224" relname="joint">вроде тоже ездит,</segment>
		<segment id="101" parent="224" relname="joint">че еще надо-то?</segment>
		<segment id="102" parent="227" relname="contrast">Но, как мы все прекрасно знаем, есть нюанс.</segment>
		<segment id="103" parent="231" relname="span">Существует ли версия этой реальности,</segment>
		<segment id="104" parent="103" relname="condition">где веб вырастает во что-то более значимое?</segment>
		<segment id="105" parent="232" relname="joint">А как же WebAssembly?</segment>
		<segment id="106" parent="233" relname="span">А что WebAssebly?</segment>
		<segment id="107" parent="106" relname="evaluation">Эта чехарда имеет смысл только только для людей, которые думают, что компьютеров нигде кроме браузера не существует.</segment>
		<segment id="108" parent="247" relname="span">Очнитесь, ребята, это еще один никому ненужный слой абстракции.</segment>
		<segment id="109" parent="235" relname="joint">Мы с радостью себя отбросили на N лет назад</segment>
		<segment id="110" parent="235" relname="joint">и теперь с радостью это преодолеваем.</segment>
		<segment id="111" parent="267" relname="span">WebAssembly — это попытка запихнуть в веб то, что без веба прекрасно работало уже несколько десятков лет как — С++ приложения.</segment>
		<segment id="112" parent="245" relname="solutionhood">Чтобы что?</segment>
		<segment id="113" parent="236" relname="contrast">Я не знаю чтобы что.</segment>
		<segment id="114" parent="238" relname="span">Чтобы условный Вася все равно качал себе Слак,</segment>
		<segment id="115" parent="237" relname="contrast">завернутый в Электрон,</segment>
		<segment id="116" parent="237" relname="contrast">зато теперь написаный на WebAssembly.</segment>
		<segment id="117" parent="239" relname="span">Смотри, мам, он почти как нативный,</segment>
		<segment id="118" parent="117" relname="elaboration">даже иконочка есть!</segment>
		<segment id="119" parent="241" relname="joint">И почти не тормозит. Почти-почти.</segment>
		<segment id="120" parent="242" relname="joint">Еще раз — попробуйте выкинуть говно веб-пропаганды из головы</segment>
		<segment id="121" parent="242" relname="joint">и взглянуть на это трезво.</segment>
		<segment id="122" parent="243" relname="evaluation">В чем тут достижение-то?</segment>
		<segment id="123" parent="251" relname="contrast">Не то чтобы я НЕ хотел чтобы веб во что-то превратился.</segment>
		<segment id="124" parent="251" relname="contrast">Я хотел, может, даже больше других.</segment>
		<segment id="125" parent="252" relname="joint">И был момент лет десять назад когда многие в это верили</segment>
		<segment id="126" parent="252" relname="joint">и был еще шанс.</segment>
		<segment id="127" parent="253" relname="contrast">Просто пора зафиксировать (давно пора,</segment>
		<segment id="128" parent="253" relname="contrast">я просто немножко тормоз, конечно)</segment>
		<segment id="129" parent="254" relname="span">что веб это веб, не больше и не меньше.</segment>
		<segment id="130" parent="256" relname="span">Все эти глюки, неровности, тормоза, неудобства, несовместимости, интервенции — это не временные мелкие неприятности,</segment>
		<segment id="131" parent="130" relname="elaboration">которые вот-вот разрешатся со следующим апдейтом Хрома.</segment>
		<segment id="132" parent="258" relname="span">Это неотъемлемые свойства платформы,</segment>
		<segment id="133" parent="257" relname="sequence">она такая сейчас</segment>
		<segment id="134" parent="257" relname="sequence">и примерно такой же будет всегда.</segment>
		<segment id="135" parent="263" relname="span">Надеяться уже в принципе не на что.</segment>
		<segment id="136" parent="259" relname="joint">И не то чтобы у меня было для вас что-то получше,</segment>
		<segment id="137" parent="259" relname="joint">или что я могу сказать, где будущее.</segment>
		<segment id="138" parent="262" relname="contrast">Все что я могу сказать что оно точно не здесь.</segment>
		<group id="139" type="span" parent="141" relname="condition"/>
		<group id="140" type="multinuc" parent="141" relname="span"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="span"/>
		<group id="143" type="span" />
		<group id="144" type="multinuc" parent="11" relname="elaboration"/>
		<group id="145" type="span" parent="144" relname="joint"/>
		<group id="146" type="span" parent="151" relname="sequence"/>
		<group id="147" type="multinuc" parent="148" relname="span"/>
		<group id="148" type="span" parent="149" relname="span"/>
		<group id="149" type="span" parent="151" relname="sequence"/>
		<group id="150" type="span" parent="148" relname="evaluation"/>
		<group id="151" type="multinuc" />
		<group id="152" type="span" parent="153" relname="contrast"/>
		<group id="153" type="multinuc" parent="156" relname="span"/>
		<group id="154" type="multinuc" parent="26" relname="elaboration"/>
		<group id="155" type="span" parent="158" relname="comparison"/>
		<group id="156" type="span" parent="157" relname="span"/>
		<group id="157" type="span" parent="158" relname="comparison"/>
		<group id="158" type="multinuc" parent="162" relname="span"/>
		<group id="159" type="multinuc" parent="162" relname="evaluation"/>
		<group id="160" type="multinuc" parent="30" relname="elaboration"/>
		<group id="161" type="span" parent="159" relname="contrast"/>
		<group id="162" type="span" parent="163" relname="span"/>
		<group id="163" type="span" parent="164" relname="span"/>
		<group id="164" type="span" />
		<group id="165" type="span" parent="169" relname="contrast"/>
		<group id="166" type="span" parent="168" relname="span"/>
		<group id="167" type="multinuc" parent="166" relname="cause"/>
		<group id="168" type="span" parent="177" relname="span"/>
		<group id="169" type="multinuc" parent="35" relname="elaboration"/>
		<group id="170" type="multinuc" parent="172" relname="span"/>
		<group id="171" type="span" parent="170" relname="contrast"/>
		<group id="172" type="span" parent="173" relname="span"/>
		<group id="173" type="span" parent="174" relname="contrast"/>
		<group id="174" type="multinuc" parent="168" relname="elaboration"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" parent="174" relname="contrast"/>
		<group id="177" type="span" parent="169" relname="contrast"/>
		<group id="178" type="span" parent="34" relname="elaboration"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" />
		<group id="181" type="multinuc" parent="184" relname="span"/>
		<group id="182" type="span" parent="183" relname="span"/>
		<group id="183" type="span" parent="184" relname="concession"/>
		<group id="184" type="span" parent="185" relname="span"/>
		<group id="185" type="span" parent="186" relname="contrast"/>
		<group id="186" type="multinuc" />
		<group id="187" type="span" parent="197" relname="span"/>
		<group id="188" type="multinuc" parent="187" relname="elaboration"/>
		<group id="189" type="span" parent="190" relname="joint"/>
		<group id="190" type="multinuc" parent="194" relname="background"/>
		<group id="191" type="multinuc" parent="193" relname="span"/>
		<group id="192" type="span" parent="193" relname="cause"/>
		<group id="193" type="span" parent="194" relname="span"/>
		<group id="194" type="span" parent="195" relname="span"/>
		<group id="195" type="span" parent="58" relname="cause"/>
		<group id="196" type="span" parent="198" relname="span"/>
		<group id="197" type="span" parent="196" relname="solutionhood"/>
		<group id="198" type="span" parent="186" relname="contrast"/>
		<group id="199" type="span" parent="67" relname="elaboration"/>
		<group id="200" type="span" parent="202" relname="joint"/>
		<group id="201" type="multinuc" parent="202" relname="joint"/>
		<group id="202" type="multinuc" parent="66" relname="condition"/>
		<group id="203" type="span" parent="206" relname="span"/>
		<group id="204" type="span" parent="205" relname="joint"/>
		<group id="205" type="multinuc" parent="203" relname="elaboration"/>
		<group id="206" type="span" />
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="212" relname="joint"/>
		<group id="209" type="span" parent="81" relname="condition"/>
		<group id="210" type="span" parent="212" relname="joint"/>
		<group id="211" type="span" parent="212" relname="joint"/>
		<group id="212" type="multinuc" parent="213" relname="cause"/>
		<group id="213" type="span" parent="219" relname="span"/>
		<group id="214" type="multinuc" parent="88" relname="condition"/>
		<group id="215" type="span" parent="217" relname="span"/>
		<group id="216" type="multinuc" parent="215" relname="evidence"/>
		<group id="217" type="span" parent="221" relname="span"/>
		<group id="218" type="span" parent="230" relname="span"/>
		<group id="219" type="span" />
		<group id="220" type="span" parent="84" relname="elaboration"/>
		<group id="221" type="span" parent="85" relname="elaboration"/>
		<group id="222" type="multinuc" parent="95" relname="elaboration"/>
		<group id="223" type="span" parent="226" relname="comparison"/>
		<group id="224" type="multinuc" parent="98" relname="elaboration"/>
		<group id="225" type="span" parent="227" relname="contrast"/>
		<group id="226" type="multinuc" parent="228" relname="span"/>
		<group id="227" type="multinuc" parent="226" relname="comparison"/>
		<group id="228" type="span" parent="229" relname="span"/>
		<group id="229" type="span" parent="218" relname="elaboration"/>
		<group id="230" type="span" parent="217" relname="concession"/>
		<group id="231" type="span" parent="232" relname="joint"/>
		<group id="232" type="multinuc" parent="249" relname="preparation"/>
		<group id="233" type="span" parent="234" relname="contrast"/>
		<group id="234" type="multinuc" parent="248" relname="span"/>
		<group id="235" type="multinuc" parent="108" relname="elaboration"/>
		<group id="236" type="multinuc" parent="245" relname="span"/>
		<group id="237" type="multinuc" parent="114" relname="elaboration"/>
		<group id="238" type="span" parent="240" relname="span"/>
		<group id="239" type="span" parent="241" relname="joint"/>
		<group id="240" type="span" parent="236" relname="contrast"/>
		<group id="241" type="multinuc" parent="238" relname="elaboration"/>
		<group id="242" type="multinuc" parent="243" relname="span"/>
		<group id="243" type="span" parent="244" relname="span"/>
		<group id="244" type="span" parent="267" relname="evaluation"/>
		<group id="245" type="span" parent="246" relname="span"/>
		<group id="246" type="span" parent="111" relname="purpose"/>
		<group id="247" type="span" parent="234" relname="contrast"/>
		<group id="248" type="span" parent="249" relname="span"/>
		<group id="249" type="span" parent="250" relname="span"/>
		<group id="250" type="span" />
		<group id="251" type="multinuc" parent="265" relname="preparation"/>
		<group id="252" type="multinuc" parent="255" relname="sequence"/>
		<group id="253" type="multinuc" parent="129" relname="evaluation"/>
		<group id="254" type="span" parent="264" relname="span"/>
		<group id="255" type="multinuc" parent="265" relname="span"/>
		<group id="256" type="span" parent="260" relname="span"/>
		<group id="257" type="multinuc" parent="132" relname="evidence"/>
		<group id="258" type="span" parent="261" relname="joint"/>
		<group id="259" type="multinuc" parent="262" relname="contrast"/>
		<group id="260" type="span" parent="254" relname="elaboration"/>
		<group id="261" type="multinuc" parent="256" relname="evaluation"/>
		<group id="262" type="multinuc" parent="135" relname="elaboration"/>
		<group id="263" type="span" parent="261" relname="joint"/>
		<group id="264" type="span" parent="255" relname="sequence"/>
		<group id="265" type="span" parent="266" relname="span"/>
		<group id="266" type="span" />
		<group id="267" type="span" parent="268" relname="span"/>
		<group id="268" type="span" parent="248" relname="elaboration"/>
	</body>
</rst>