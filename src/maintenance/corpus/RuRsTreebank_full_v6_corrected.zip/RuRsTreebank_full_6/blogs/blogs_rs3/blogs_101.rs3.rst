<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://ru-travel.livejournal.com/33778415.html</segment>
		<segment id="2" >Монастырь в Раифе</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="112" relname="same-unit">По дороге к Раифскому Богородицкому мужскому монастырю,</segment>
		<segment id="5" parent="6" relname="condition">свернув с трассы Казань-Зеленодольск,</segment>
		<segment id="6" parent="111" relname="span">попадаешь сначала в заповедный лес, затем в Местечко Раифа на берегу живописного Раифского озера.</segment>
		<segment id="7" parent="8" relname="cause">Дорога закончится автостоянкой,</segment>
		<segment id="8" parent="61" relname="span">дальше не проедешь.</segment>
		<segment id="9" parent="62" relname="joint">Ну, а пеший путь легко определяется по группам туристов и паломников.</segment>
		<segment id="10" parent="92" relname="span">Прекрасным ориентиром будет также и IMG колокольня над Святыми Вратами, сооружение самое высокое на территории монастыря.</segment>
		<segment id="11" parent="10" relname="elaboration">Двигаясь по улочке с едальнями и сувенирными лавками взгляд упирается именно в нее.</segment>
		<segment id="12" parent="63" relname="span">Основателем монастыря является отшельник Филарет,</segment>
		<segment id="13" parent="12" relname="elaboration">избравший путь странника после смерти родителей.</segment>
		<segment id="14" parent="65" relname="sequence">Раздав имущество</segment>
		<segment id="15" parent="65" relname="sequence">он пустился в путь по Поволжью</segment>
		<segment id="16" parent="64" relname="span">и, в итоге, в 1613 году выбрал место для своей кельи на берегу Раифского озера</segment>
		<segment id="17" parent="16" relname="evaluation">(скорее всего озеро имело другое название на тот момент).</segment>
		<segment id="18" parent="113" relname="span">Первыми соседями по территории с Филаретом оказались мари-язычники,</segment>
		<segment id="19" parent="18" relname="elaboration">также совершающие свои обряды в этих местах.</segment>
		<segment id="20" parent="113" relname="evidence">Как известно, часть марийцев избрала христианскую веру.</segment>
		<segment id="21" parent="66" relname="evaluation">Возможно именно с этого момента, но точных сведений у меня нет.</segment>
		<segment id="22" parent="23" relname="cause">Тем не менее слухи о монахе разошлись быстро</segment>
		<segment id="23" parent="70" relname="span">и вскоре на этом месте строится первая часовня.</segment>
		<segment id="24" parent="71" relname="sequence">Датой же основания монастыря принято считать 1661 год,</segment>
		<segment id="25" parent="71" relname="sequence">за два года до этого Филарет умер.</segment>
		<segment id="26" parent="72" relname="span">В монастырь привезли точную копию Грузинской иконы Божьей Матери,</segment>
		<segment id="27" parent="26" relname="elaboration">которая и по сей день является главной святыней монастыря.</segment>
		<segment id="28" parent="29" relname="cause">Деревянные постройки разрушил пожар.</segment>
		<segment id="29" parent="99" relname="span">Каменные здания стали появляться в начале 18-го века.</segment>
		<segment id="30" parent="75" relname="sequence">Чуть ранее началось строительство стены вокруг монастыря.</segment>
		<segment id="31" parent="114" relname="elaboration">IMG</segment>
		<segment id="32" parent="77" relname="span">В самом центре территории - Троицкий собор. Нео русский стиль. Относительно свежее сооружение, 1910 год окончания строительства. IMG</segment>
		<segment id="33" parent="78" relname="span">Церковь в честь Святых Отцов в Синае и Раифе избиенных. Год возведения 1708-й, таким образом это самое старое здание храма на территории монастыря.</segment>
		<segment id="34" parent="116" relname="span">В названии церкви кроется и идея посвящения монастыря в честь монахов в синайской обители Раифа,</segment>
		<segment id="35" parent="117" relname="span">погибших</segment>
		<segment id="36" parent="35" relname="cause">в результате разбойного нападения африканских язычников. IMG</segment>
		<segment id="37" parent="81" relname="joint">Небольшая Софийская церковь построена чуть позже над братскими кельями.</segment>
		<segment id="38" parent="80" relname="span">Котика видите?</segment>
		<segment id="39" parent="79" relname="span">Их здесь много,</segment>
		<segment id="40" parent="39" relname="elaboration">показывал их отдельно вот здесь. IMG</segment>
		<segment id="41" parent="100" relname="elaboration">Фрагмент забора и башня. Периметр монастыря более полукилометра. IMG</segment>
		<segment id="42" parent="43" relname="cause">После октябрьской революции</segment>
		<segment id="43" parent="118" relname="span">монастырь официально был закрыт,</segment>
		<segment id="44" parent="82" relname="contrast">однако до 1930 года службы не прекращались.</segment>
		<segment id="45" parent="83" relname="joint">В 30-м году были арестованы</segment>
		<segment id="46" parent="83" relname="joint">и расстреляны 6 человек, иеромонахов и послушников,</segment>
		<segment id="47" parent="84" relname="joint">а бывшая обитель стала выполнять функции тюрьмы с мастерскими, основанными в храмах.</segment>
		<segment id="48" parent="86" relname="span">Русский и татарин братья навек.</segment>
		<segment id="49" parent="48" relname="elaboration">Глубоко осознать это можно только в Казани.</segment>
		<segment id="50" parent="87" relname="joint">После возвращения монастыря РПЦ в 1991 году первую помощь в восстановлении монахи получили от мусульман,</segment>
		<segment id="51" parent="87" relname="joint">а президент Шаймиев пожертвовал деньги на новые кресты для Троицкого собора.</segment>
		<segment id="52" parent="88" relname="joint">На сегодняшний день в братии около 60 человек.</segment>
		<segment id="53" parent="89" relname="joint">IMG Территория ухоженная,</segment>
		<segment id="54" parent="89" relname="joint">есть даже такой симпатичный прудик. IMG</segment>
		<segment id="55" parent="94" relname="joint">Часовня. Перед ней на площади солнечные часы весьма интересной конструкции. IMG</segment>
		<segment id="56" parent="119" relname="span">Ну и напоследок вид на то самое живописное Раифское озеро.</segment>
		<segment id="57" parent="56" relname="evaluation">В солнечный день, наверное, и вода играет другими красками.</segment>
		<segment id="58" parent="90" relname="contrast">Ну а наше нынешнее лето было такое, какое было.</segment>
		<segment id="59" parent="108" relname="contrast">Главное, что это не повод сидеть дома,</segment>
		<segment id="60" parent="108" relname="contrast">надо успевать поездить посмотреть. Интересных мест еще много!</segment>
		<group id="61" type="span" parent="93" relname="elaboration"/>
		<group id="62" type="multinuc" parent="96" relname="joint"/>
		<group id="63" type="span" parent="68" relname="span"/>
		<group id="64" type="span" parent="65" relname="sequence"/>
		<group id="65" type="multinuc" parent="63" relname="elaboration"/>
		<group id="66" type="span" parent="67" relname="span"/>
		<group id="67" type="span" parent="69" relname="joint"/>
		<group id="68" type="span" parent="69" relname="joint"/>
		<group id="69" type="multinuc" />
		<group id="70" type="span" parent="97" relname="span"/>
		<group id="71" type="multinuc" parent="70" relname="background"/>
		<group id="72" type="span" parent="73" relname="joint"/>
		<group id="73" type="multinuc" parent="98" relname="joint"/>
		<group id="74" type="span" parent="76" relname="joint"/>
		<group id="75" type="multinuc" parent="76" relname="joint"/>
		<group id="76" type="multinuc" parent="114" relname="span"/>
		<group id="77" type="span" parent="91" relname="joint"/>
		<group id="78" type="span" parent="91" relname="joint"/>
		<group id="79" type="span" parent="38" relname="solutionhood"/>
		<group id="80" type="span" parent="81" relname="joint"/>
		<group id="81" type="multinuc" parent="100" relname="span"/>
		<group id="82" type="multinuc" parent="85" relname="sequence"/>
		<group id="83" type="multinuc" parent="84" relname="joint"/>
		<group id="84" type="multinuc" parent="85" relname="sequence"/>
		<group id="85" type="multinuc" />
		<group id="86" type="span" parent="103" relname="preparation"/>
		<group id="87" type="multinuc" parent="103" relname="span"/>
		<group id="88" type="multinuc" parent="105" relname="span"/>
		<group id="89" type="multinuc" parent="94" relname="joint"/>
		<group id="90" type="multinuc" parent="107" relname="span"/>
		<group id="91" type="multinuc" parent="102" relname="joint"/>
		<group id="92" type="span" parent="62" relname="joint"/>
		<group id="93" type="span" parent="95" relname="span"/>
		<group id="94" type="multinuc" parent="105" relname="elaboration"/>
		<group id="95" type="span" parent="96" relname="joint"/>
		<group id="96" type="multinuc" />
		<group id="97" type="span" parent="98" relname="joint"/>
		<group id="98" type="multinuc" parent="74" relname="span"/>
		<group id="99" type="span" parent="75" relname="sequence"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" parent="102" relname="joint"/>
		<group id="102" type="multinuc" />
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" parent="88" relname="joint"/>
		<group id="105" type="span" parent="106" relname="span"/>
		<group id="106" type="span" />
		<group id="107" type="span" parent="109" relname="solutionhood"/>
		<group id="108" type="multinuc" parent="109" relname="span"/>
		<group id="109" type="span" parent="110" relname="span"/>
		<group id="110" type="span" />
		<group id="111" type="span" parent="112" relname="same-unit"/>
		<group id="112" type="multinuc" parent="93" relname="span"/>
		<group id="113" type="span" parent="66" relname="span"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" />
		<group id="116" type="span" parent="33" relname="elaboration"/>
		<group id="117" type="span" parent="34" relname="elaboration"/>
		<group id="118" type="span" parent="82" relname="contrast"/>
		<group id="119" type="span" parent="90" relname="contrast"/>
	</body>
</rst>