<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://aelita544.ru/post455819547</segment>
		<segment id="2" >Упражнения, которые сделают точеными ваши руки и спину</segment>
		<segment id="3" parent="4" relname="purpose">Чтобы упражнения приносили заметный эффект,</segment>
		<segment id="4" parent="167" relname="span">важно сочетать их с правильным питанием.</segment>
		<segment id="5" parent="168" relname="span">Кроме того нельзя забывать об активном образе жизни:</segment>
		<segment id="6" parent="5" relname="elaboration">нужно стараться больше ходить пешком.</segment>
		<segment id="7" parent="171" relname="same-unit">Также эффективным</segment>
		<segment id="8" parent="9" relname="purpose">для проработки спины и рук</segment>
		<segment id="9" parent="170" relname="span">является плавание в бассейне.</segment>
		<segment id="10" parent="173" relname="cause">Благодаря плаванию</segment>
		<segment id="11" parent="172" relname="joint">укрепляется спина, повышается эластичность кожи,</segment>
		<segment id="12" parent="172" relname="joint">сжигается лишний вес</segment>
		<segment id="13" parent="172" relname="joint">и поднимается настроение! IMG</segment>
		<segment id="14" parent="15" relname="condition">Начиная заниматься фитнесом,</segment>
		<segment id="15" parent="178" relname="span">следует помнить, что не только талия, ноги и ягодицы нуждаются в совершенствовании, но и руки, и спина.</segment>
		<segment id="16" parent="179" relname="condition">Даже если эти области не имеют лишних жировых отложений,</segment>
		<segment id="17" parent="179" relname="span">они все равно требуют проработки</segment>
		<segment id="18" parent="17" relname="purpose">для укрепления мышц.</segment>
		<segment id="19" parent="180" relname="purpose">Для этого существуют специальные упражнения, которые можно выполнять как в спортивном центре, так и в домашних условиях.</segment>
		<segment id="20" parent="200" relname="preparation">Проведение занятий фитнесом дома</segment>
		<segment id="21" parent="22" relname="cause">Посещение фитнес-центров требует больше времени и средств,</segment>
		<segment id="22" parent="183" relname="span">а потому этот вариант по душе не всем.</segment>
		<segment id="23" parent="184" relname="span">В этом случае можно отдать предпочтение занятиям дома.</segment>
		<segment id="24" parent="187" relname="evaluation">Недостатком этого варианта является то,</segment>
		<segment id="25" parent="186" relname="joint">что настроиться на занятия сложнее, чем в организованных группах,</segment>
		<segment id="26" parent="186" relname="joint">и нередко лень может взять свое.</segment>
		<segment id="27" parent="197" relname="joint">Выбирая домашние тренировки нужно подготовить следующее снаряжение: гимнастический коврик; гантели или бутылки с песком; небольшой резиновый мяч; эластичная лента (эспандер); хула-хуп (обруч).</segment>
		<segment id="28" parent="197" relname="joint">Заниматься фитнесом нужно хотя бы трижды в неделю по 45-60 минут.</segment>
		<segment id="29" parent="190" relname="span">Перед занятием обязательно надо разогреть все мышцы,</segment>
		<segment id="30" parent="29" relname="elaboration">например, потанцевав несколько минут.</segment>
		<segment id="31" parent="191" relname="contrast">Лучше уделять внимание всем группам мышц на каждой тренировке,</segment>
		<segment id="32" parent="192" relname="span">но выделяя разные дни для более детальной проработки определенной</segment>
		<segment id="33" parent="32" relname="elaboration">области.Например, в понедельник — ноги и ягодицы, в среду — пресс, в пятницу — спина и руки.</segment>
		<segment id="34" parent="195" relname="purpose">Чтобы занятия были эффективны,</segment>
		<segment id="35" parent="195" relname="span">нужно постоянно прогрессировать,</segment>
		<segment id="36" parent="194" relname="joint">увеличивая количество подходов, повторений,</segment>
		<segment id="37" parent="194" relname="joint">добавляя новые и более сложные упражнения. IMG</segment>
		<segment id="38" parent="202" relname="preparation">Комплекс упражнений для спины</segment>
		<segment id="39" parent="201" relname="joint">Упражнения для спины способствуют укреплению ее мышц</segment>
		<segment id="40" parent="201" relname="joint">и, вместе с тем, сжиганию жировых отложений.</segment>
		<segment id="41" parent="304" relname="span">А потому их нужно выполнять независимо от того,</segment>
		<segment id="42" parent="41" relname="condition">имеются лишние килограммы или нет.</segment>
		<segment id="43" parent="235" relname="span">Новичкам рекомендуется следующий комплекс упражнений:</segment>
		<segment id="44" parent="203" relname="sequence">Встать ровно,</segment>
		<segment id="45" parent="203" relname="sequence">в руки взять эластичную ленту</segment>
		<segment id="46" parent="203" relname="sequence">и растянуть ее за спиной.</segment>
		<segment id="47" parent="203" relname="sequence">Перешагивать через нее то вперед, то назад.</segment>
		<segment id="48" parent="204" relname="span">Ленту не расслаблять,</segment>
		<segment id="49" parent="48" relname="elaboration">она должна быть максимально натянута.</segment>
		<segment id="50" parent="205" relname="span">При этом после каждого перешагивания надо выравниваться,</segment>
		<segment id="51" parent="50" relname="condition">держа ленту то на уровне груди, то за спиной.</segment>
		<segment id="52" parent="206" relname="joint">Продолжительность выполнения элемента — 3-5 минут.</segment>
		<segment id="53" parent="210" relname="span">Лечь на пол животом вниз,</segment>
		<segment id="54" parent="209" relname="span">руки согнуты в локтях</segment>
		<segment id="55" parent="54" relname="elaboration">и лежат на полу.</segment>
		<segment id="56" parent="211" relname="sequence">Сделать упор на кисти</segment>
		<segment id="57" parent="212" relname="span">и поднять верхнюю часть туловища,</segment>
		<segment id="58" parent="213" relname="joint">выравнивая руки</segment>
		<segment id="59" parent="213" relname="joint">и прогибая спину.</segment>
		<segment id="60" parent="211" relname="sequence">Задержаться так на некоторое время</segment>
		<segment id="61" parent="211" relname="sequence">и вернуться в изначальную позицию.</segment>
		<segment id="62" parent="216" relname="joint">Выполнить не менее 10 раз.</segment>
		<segment id="63" parent="215" relname="span">Со временем это упражнение можно усложнить,</segment>
		<segment id="64" parent="214" relname="joint">соединив кисти на затылке</segment>
		<segment id="65" parent="214" relname="joint">и прогибаясь без помощи рук.</segment>
		<segment id="66" parent="219" relname="joint">Сесть,</segment>
		<segment id="67" parent="219" relname="joint">прямые ноги слегка раздвинуты в стороны,</segment>
		<segment id="68" parent="219" relname="joint">спина выпрямлена.</segment>
		<segment id="69" parent="220" relname="sequence">Потянуться верхней частью корпуса сначала к одной ступне, затем ко второй,</segment>
		<segment id="70" parent="221" relname="span">потом максимально наклониться к центру</segment>
		<segment id="71" parent="70" relname="elaboration">(стремясь лечь на пол),</segment>
		<segment id="72" parent="220" relname="sequence">задержавшись в такой позе на несколько секунд.</segment>
		<segment id="73" parent="222" relname="elaboration">Выполнить по 15 наклонов в каждое положение.</segment>
		<segment id="74" parent="224" relname="sequence">Встать,</segment>
		<segment id="75" parent="224" relname="sequence">левую руку поднять вверх,</segment>
		<segment id="76" parent="224" relname="sequence">правую опустить вниз.</segment>
		<segment id="77" parent="226" relname="sequence">После этого согнуть их в локтях</segment>
		<segment id="78" parent="227" relname="span">и соединить за спиной в замок таким образом,</segment>
		<segment id="79" parent="78" relname="elaboration">чтобы один локоть смотрел вверх, а второй — вниз.</segment>
		<segment id="80" parent="228" relname="span">В таком положении надо тянуть руки в разные направления,</segment>
		<segment id="81" parent="80" relname="condition">не размыкая.</segment>
		<segment id="82" parent="229" relname="sequence">Поменять руки местами</segment>
		<segment id="83" parent="229" relname="sequence">и повторить упражнение.</segment>
		<segment id="84" parent="237" relname="span">Также эффективными упражнениями для спины являются наклоны.</segment>
		<segment id="85" parent="84" relname="elaboration">Это могут быть поочередные сгибания тела сначала к одной ноге, затем к другой, наклоны в стороны и т.д. IMG</segment>
		<segment id="86" parent="238" relname="joint">С возрастом,</segment>
		<segment id="87" parent="238" relname="joint">а также после резкого сброса веса,</segment>
		<segment id="88" parent="239" relname="joint">кожа на руках становится дряблой</segment>
		<segment id="89" parent="239" relname="joint">и обвисает.</segment>
		<segment id="90" parent="242" relname="span">От этой проблемы очень сложно избавиться</segment>
		<segment id="91" parent="90" relname="condition">без специальных упражнений с гантелями или другими подручными средствами:</segment>
		<segment id="92" parent="244" relname="sequence">Встать ровно,</segment>
		<segment id="93" parent="244" relname="sequence">взять в руки гантели,</segment>
		<segment id="94" parent="244" relname="sequence">руки повернуть локтями вниз,</segment>
		<segment id="95" parent="244" relname="sequence">согнуть</segment>
		<segment id="96" parent="244" relname="sequence">и прижать к поясу.</segment>
		<segment id="97" parent="245" relname="span">Делать сгибания и разгибания сначала одной рукой, затем — другой.</segment>
		<segment id="98" parent="249" relname="span">При этом рука полностью не разгибается.</segment>
		<segment id="99" parent="100" relname="condition">При подъеме вверх</segment>
		<segment id="100" parent="246" relname="span">гантель доводится до плеча,</segment>
		<segment id="101" parent="102" relname="condition">при опускании</segment>
		<segment id="102" parent="247" relname="span">— находится параллельно полу.</segment>
		<segment id="103" parent="250" relname="elaboration">Выполнить 10-15 повторений в 2 подхода.</segment>
		<segment id="104" parent="252" relname="contrast">Следующее упражнение с гантелями немного похожее на предыдущее,</segment>
		<segment id="105" parent="252" relname="contrast">но выполняется оно сидя на стуле.</segment>
		<segment id="106" parent="253" relname="sequence">Спина не прогибается,</segment>
		<segment id="107" parent="253" relname="sequence">ноги слегка расставлены,</segment>
		<segment id="108" parent="253" relname="sequence">стопы на полу.</segment>
		<segment id="109" parent="254" relname="sequence">Наклонить корпус вперед,</segment>
		<segment id="110" parent="254" relname="sequence">упереться локтем в колено.</segment>
		<segment id="111" parent="254" relname="sequence">Во вторую руку взять гантель.</segment>
		<segment id="112" parent="255" relname="sequence">Поднимать</segment>
		<segment id="113" parent="255" relname="sequence">и опускать руку со снарядом не менее 10 раз,</segment>
		<segment id="114" parent="255" relname="sequence">после чего сменить сторону.</segment>
		<segment id="115" parent="258" relname="sequence">Взять эластичную ленту за концы руками.</segment>
		<segment id="116" parent="258" relname="sequence">В получившуюся петлю встать ногами.</segment>
		<segment id="117" parent="259" relname="span">Делать подъемы прямых рук в стороны,</segment>
		<segment id="118" parent="260" relname="joint">натягивая ленту,</segment>
		<segment id="119" parent="260" relname="joint">и задерживаясь в верхней точке на некоторое время.</segment>
		<segment id="120" parent="262" relname="joint">Исходное положение как в предыдущем упражнении.</segment>
		<segment id="121" parent="261" relname="span">Надо натягивать ленту,</segment>
		<segment id="122" parent="121" relname="condition">вытягивая руки сначала вперед, а затем назад (по 10 раз).</segment>
		<segment id="123" parent="265" relname="sequence">Сесть на стул,</segment>
		<segment id="124" parent="265" relname="sequence">руками обхватить его по краям.</segment>
		<segment id="125" parent="266" relname="span">Поднять таз над стулом,</segment>
		<segment id="126" parent="267" relname="joint">выпрямив руки</segment>
		<segment id="127" parent="267" relname="joint">и сделав на них основной упор.</segment>
		<segment id="128" parent="266" relname="condition">Ноги от пола не отрываются.</segment>
		<segment id="129" parent="265" relname="sequence">Повторить 10 раз.</segment>
		<segment id="130" parent="269" relname="sequence">Взять в руки небольшой надувной мяч,</segment>
		<segment id="131" parent="269" relname="sequence">обхватить его ладонями с двух сторон перед собой.</segment>
		<segment id="132" parent="269" relname="sequence">Давить двумя руками на мяч в течение 10 секунд.</segment>
		<segment id="133" parent="269" relname="sequence">Выполнить несколько подходов.</segment>
		<segment id="134" parent="135" relname="condition">Выполняя упражнения с гантелями,</segment>
		<segment id="135" parent="273" relname="span">следует помнить, что их вес не должен быть слишком большим.</segment>
		<segment id="136" parent="273" relname="elaboration">Для домашнего фитнеса подойдут снаряды по 1-1,5 кг. IMG</segment>
		<segment id="137" parent="278" relname="preparation">Упражнения для боков</segment>
		<segment id="138" parent="277" relname="contrast">Упражнения для спины помогут придать фигуре стройности,</segment>
		<segment id="139" parent="277" relname="contrast">но не стоит забывать, что бока и талия также требуют проработки.</segment>
		<segment id="140" parent="280" relname="span">Новичкам достаточно применять следующий комплекс упражнений:</segment>
		<segment id="141" parent="289" relname="span">Кручение обруча.</segment>
		<segment id="142" parent="141" relname="elaboration">Он бывает нескольких видов — пластмассовый, алюминиевый, с песком, с выпуклостями.</segment>
		<segment id="143" parent="281" relname="span">Если регулярно крутить обруч,</segment>
		<segment id="144" parent="282" relname="joint">увеличивая продолжительность занятия</segment>
		<segment id="145" parent="282" relname="joint">и используя все более сложные его виды,</segment>
		<segment id="146" parent="283" relname="span">жир на боках никогда не будет вашей проблемой.</segment>
		<segment id="147" parent="284" relname="sequence">Встать ровно,</segment>
		<segment id="148" parent="284" relname="sequence">руки на поясе или за головой.</segment>
		<segment id="149" parent="285" relname="span">Делать повороты в стороны,</segment>
		<segment id="150" parent="149" relname="condition">не двигая при этом бедрами.</segment>
		<segment id="151" parent="286" relname="joint">Спина ровная,</segment>
		<segment id="152" parent="286" relname="joint">прямые руки — по швам.</segment>
		<segment id="153" parent="288" relname="span">Выполнять наклоны в стороны, дотягиваясь кистью до колена.</segment>
		<segment id="154" parent="153" relname="elaboration">Можно выполнять подобные упражнения с гантелями.</segment>
		<segment id="155" parent="156" relname="purpose">Чтобы фитнес приносил заметный эффект,</segment>
		<segment id="156" parent="293" relname="span">важно сочетать его с правильным питанием.</segment>
		<segment id="157" parent="295" relname="span">Кроме того нельзя забывать об активном образе жизни:</segment>
		<segment id="158" parent="157" relname="elaboration">нужно стараться больше ходить пешком.</segment>
		<segment id="159" parent="297" relname="same-unit">Также эффективным</segment>
		<segment id="160" parent="161" relname="purpose">для проработки спины и рук</segment>
		<segment id="161" parent="296" relname="span">является плавание в бассейне.</segment>
		<segment id="162" parent="299" relname="cause">Благодаря плаванию</segment>
		<segment id="163" parent="298" relname="joint">укрепляется спина,</segment>
		<segment id="164" parent="298" relname="joint">повышается эластичность кожи,</segment>
		<segment id="165" parent="298" relname="joint">сжигается лишний вес</segment>
		<segment id="166" parent="298" relname="joint">и поднимается настроение.</segment>
		<group id="167" type="span" parent="169" relname="joint"/>
		<group id="168" type="span" parent="169" relname="joint"/>
		<group id="169" type="multinuc" parent="177" relname="preparation"/>
		<group id="170" type="span" parent="171" relname="same-unit"/>
		<group id="171" type="multinuc" parent="175" relname="span"/>
		<group id="172" type="multinuc" parent="173" relname="span"/>
		<group id="173" type="span" parent="174" relname="span"/>
		<group id="174" type="span" parent="175" relname="elaboration"/>
		<group id="175" type="span" parent="176" relname="span"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" parent="189" relname="span"/>
		<group id="178" type="span" parent="181" relname="preparation"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" parent="181" relname="span"/>
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" parent="176" relname="elaboration"/>
		<group id="183" type="span" parent="23" relname="cause"/>
		<group id="184" type="span" parent="185" relname="contrast"/>
		<group id="185" type="multinuc" parent="193" relname="span"/>
		<group id="186" type="multinuc" parent="187" relname="span"/>
		<group id="187" type="span" parent="188" relname="span"/>
		<group id="188" type="span" parent="185" relname="contrast"/>
		<group id="189" type="span" />
		<group id="190" type="span" parent="197" relname="joint"/>
		<group id="191" type="multinuc" parent="197" relname="joint"/>
		<group id="192" type="span" parent="191" relname="contrast"/>
		<group id="193" type="span" parent="200" relname="span"/>
		<group id="194" type="multinuc" parent="35" relname="elaboration"/>
		<group id="195" type="span" parent="196" relname="span"/>
		<group id="196" type="span" parent="198" relname="elaboration"/>
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" parent="193" relname="elaboration"/>
		<group id="200" type="span" parent="303" relname="span"/>
		<group id="201" type="multinuc" parent="304" relname="cause"/>
		<group id="202" type="span" parent="236" relname="span"/>
		<group id="203" type="multinuc" parent="207" relname="span"/>
		<group id="204" type="span" parent="206" relname="joint"/>
		<group id="205" type="span" parent="206" relname="joint"/>
		<group id="206" type="multinuc" parent="207" relname="elaboration"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="232" relname="joint"/>
		<group id="209" type="span" parent="53" relname="elaboration"/>
		<group id="210" type="span" parent="211" relname="sequence"/>
		<group id="211" type="multinuc" parent="217" relname="span"/>
		<group id="212" type="span" parent="211" relname="sequence"/>
		<group id="213" type="multinuc" parent="57" relname="condition"/>
		<group id="214" type="multinuc" parent="63" relname="elaboration"/>
		<group id="215" type="span" parent="216" relname="joint"/>
		<group id="216" type="multinuc" parent="217" relname="elaboration"/>
		<group id="217" type="span" parent="218" relname="span"/>
		<group id="218" type="span" parent="232" relname="joint"/>
		<group id="219" type="multinuc" parent="220" relname="sequence"/>
		<group id="220" type="multinuc" parent="222" relname="span"/>
		<group id="221" type="span" parent="220" relname="sequence"/>
		<group id="222" type="span" parent="223" relname="span"/>
		<group id="223" type="span" parent="232" relname="joint"/>
		<group id="224" type="multinuc" parent="225" relname="sequence"/>
		<group id="225" type="multinuc" parent="232" relname="joint"/>
		<group id="226" type="multinuc" parent="231" relname="span"/>
		<group id="227" type="span" parent="226" relname="sequence"/>
		<group id="228" type="span" parent="231" relname="elaboration"/>
		<group id="229" type="multinuc" parent="225" relname="sequence"/>
		<group id="230" type="span" parent="225" relname="sequence"/>
		<group id="231" type="span" parent="230" relname="span"/>
		<group id="232" type="multinuc" parent="233" relname="span"/>
		<group id="233" type="span" parent="234" relname="span"/>
		<group id="234" type="span" />
		<group id="235" type="span" parent="233" relname="preparation"/>
		<group id="236" type="span" parent="43" relname="preparation"/>
		<group id="237" type="span" parent="232" relname="joint"/>
		<group id="238" type="multinuc" parent="240" relname="cause"/>
		<group id="239" type="multinuc" parent="240" relname="span"/>
		<group id="240" type="span" parent="241" relname="span"/>
		<group id="241" type="span" parent="243" relname="span"/>
		<group id="242" type="span" parent="241" relname="evaluation"/>
		<group id="243" type="span" parent="271" relname="preparation"/>
		<group id="244" type="multinuc" parent="250" relname="span"/>
		<group id="245" type="span" parent="244" relname="sequence"/>
		<group id="246" type="span" parent="248" relname="joint"/>
		<group id="247" type="span" parent="248" relname="joint"/>
		<group id="248" type="multinuc" parent="98" relname="elaboration"/>
		<group id="249" type="span" parent="97" relname="elaboration"/>
		<group id="250" type="span" parent="251" relname="span"/>
		<group id="251" type="span" parent="270" relname="joint"/>
		<group id="252" type="multinuc" parent="256" relname="preparation"/>
		<group id="253" type="multinuc" parent="256" relname="span"/>
		<group id="254" type="multinuc" parent="253" relname="sequence"/>
		<group id="255" type="multinuc" parent="254" relname="sequence"/>
		<group id="256" type="span" parent="257" relname="span"/>
		<group id="257" type="span" parent="270" relname="joint"/>
		<group id="258" type="multinuc" parent="263" relname="span"/>
		<group id="259" type="span" parent="258" relname="sequence"/>
		<group id="260" type="multinuc" parent="117" relname="condition"/>
		<group id="261" type="span" parent="262" relname="joint"/>
		<group id="262" type="multinuc" parent="263" relname="elaboration"/>
		<group id="263" type="span" parent="264" relname="span"/>
		<group id="264" type="span" parent="270" relname="joint"/>
		<group id="265" type="multinuc" parent="270" relname="joint"/>
		<group id="266" type="span" parent="268" relname="span"/>
		<group id="267" type="multinuc" parent="125" relname="condition"/>
		<group id="268" type="span" parent="265" relname="sequence"/>
		<group id="269" type="multinuc" parent="276" relname="span"/>
		<group id="270" type="multinuc" parent="271" relname="span"/>
		<group id="271" type="span" parent="272" relname="span"/>
		<group id="272" type="span" />
		<group id="273" type="span" parent="274" relname="span"/>
		<group id="274" type="span" parent="276" relname="elaboration"/>
		<group id="275" type="span" parent="270" relname="joint"/>
		<group id="276" type="span" parent="275" relname="span"/>
		<group id="277" type="multinuc" parent="278" relname="span"/>
		<group id="278" type="span" parent="279" relname="span"/>
		<group id="279" type="span" parent="140" relname="preparation"/>
		<group id="280" type="span" parent="291" relname="preparation"/>
		<group id="281" type="span" parent="146" relname="condition"/>
		<group id="282" type="multinuc" parent="143" relname="condition"/>
		<group id="283" type="span" parent="289" relname="elaboration"/>
		<group id="284" type="multinuc" parent="290" relname="elaboration"/>
		<group id="285" type="span" parent="287" relname="span"/>
		<group id="286" type="multinuc" parent="285" relname="elaboration"/>
		<group id="287" type="span" parent="284" relname="sequence"/>
		<group id="288" type="span" parent="284" relname="sequence"/>
		<group id="289" type="span" parent="290" relname="span"/>
		<group id="290" type="span" parent="291" relname="span"/>
		<group id="291" type="span" parent="292" relname="span"/>
		<group id="292" type="span" />
		<group id="293" type="span" parent="294" relname="joint"/>
		<group id="294" type="multinuc" />
		<group id="295" type="span" parent="294" relname="joint"/>
		<group id="296" type="span" parent="297" relname="same-unit"/>
		<group id="297" type="multinuc" parent="302" relname="span"/>
		<group id="298" type="multinuc" parent="299" relname="span"/>
		<group id="299" type="span" parent="300" relname="span"/>
		<group id="300" type="span" parent="302" relname="elaboration"/>
		<group id="301" type="span" parent="294" relname="joint"/>
		<group id="302" type="span" parent="301" relname="span"/>
		<group id="303" type="span" />
		<group id="304" type="span" parent="202" relname="span"/>
	</body>
</rst>