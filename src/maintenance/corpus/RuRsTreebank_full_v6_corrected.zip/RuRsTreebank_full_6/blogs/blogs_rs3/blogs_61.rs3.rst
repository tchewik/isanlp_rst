<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://seva-riga.livejournal.com/907963.html#cutid1</segment>
		<segment id="2" >Новейшая история России внушает оптимизм</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="72" relname="span">Наверно это профессиональная деформация</segment>
		<segment id="5" parent="114" relname="contrast">– искать что-то положительное там,</segment>
		<segment id="6" parent="114" relname="contrast">где окружающие видят только «щастье» из  известных 4х букв.</segment>
		<segment id="7" parent="73" relname="contrast">Однако, по крайней мере тактически, так легче адаптироваться к внешней, весьма агрессивной среде.</segment>
		<segment id="8" parent="74" relname="span">Ну и приятный бонус в долговременной перспективе</segment>
		<segment id="9" parent="8" relname="elaboration">– приятно осознавать, насколько был прав…</segment>
		<segment id="10" parent="77" relname="span">Всёпропальщиков тоже можно понять.</segment>
		<segment id="11" parent="120" relname="span">Их  такое публичное и громогласное «всё пропало» - это не декларация незыблемой позиции, а призыв к окружающим приступать к убеждению,</segment>
		<segment id="12" parent="76" relname="joint">что не всё так плохо,</segment>
		<segment id="13" parent="76" relname="joint">могло быть и хуже</segment>
		<segment id="14" parent="76" relname="joint">и вообще  - радуйся что живой…</segment>
		<segment id="15" parent="78" relname="span">Геополитическая катастрофа социалистического блока и развал СССР,</segment>
		<segment id="16" parent="15" relname="concession">несмотря на личные трагедии миллионов ни в чём не повинных людей,</segment>
		<segment id="17" parent="79" relname="same-unit">развеяла иллюзии как по поводу «наших западных партнёров» так и многочисленных «небратьев» ,</segment>
		<segment id="18" parent="121" relname="span">избавила от многочисленных «союзников»-захребетников,</segment>
		<segment id="19" parent="18" relname="background">весьма комфортно устроившихся на российской шее и небрежно поплёвывающих оттуда в руку дающую.</segment>
		<segment id="20" parent="81" relname="span">Теперь  стадо профессиональных попрошаек, с песнями и плясками, радостно откочевало в англосаксонские загоны</segment>
		<segment id="21" parent="20" relname="elaboration">где их уже ничего не спасёт от судьбы коренных жителей США.</segment>
		<segment id="22" parent="81" relname="evidence">Это ежедневно подтверждается демографическими отчётами, больше похожими на сводки боевых потерь во время военных действий.</segment>
		<segment id="23" parent="84" relname="span">Четверть века назад,</segment>
		<segment id="24" parent="23" relname="background">когда началось наступление на русский язык на всех окраинах бывшего СССР,</segment>
		<segment id="25" parent="85" relname="same-unit">я предлагал всячески приветствовать этот процесс,</segment>
		<segment id="26" parent="86" relname="elaboration">который принудительно загоняет молодёжь гонористых титульных наций в монолингвальное состояние.</segment>
		<segment id="27" parent="88" relname="joint">25 лет прошло</segment>
		<segment id="28" parent="122" relname="span">и можно уже констатировать, что окраинные националисты честно сделали своих детей неконкурентоспособными на российском рынке,</segment>
		<segment id="29" parent="123" relname="span">так и не потерявшем привлекательность,</segment>
		<segment id="30" parent="29" relname="condition">не получив у «наших западных партнёров» и сотой доли  тех преференций, которые они имели в России.</segment>
		<segment id="31" parent="89" relname="span">И уж куда им вход точно заказан – так это в правящую элиту.</segment>
		<segment id="32" parent="31" relname="evaluation">На Западе, оказывается, своих элит хватает…</segment>
		<segment id="33" parent="133" relname="span">Про собственную национальную идентичность,</segment>
		<segment id="34" parent="33" relname="elaboration">за которую так боролись «небратья» с Россией,</segment>
		<segment id="35" parent="134" relname="same-unit">у «наших западных партнёров» они вообще  не вспоминают.</segment>
		<segment id="36" parent="116" relname="contrast">Англосаксонский проект  никакой другой идентичности, кроме собственной, не предусматривает.</segment>
		<segment id="37" parent="130" relname="same-unit">Без всякой помощи «коварной России»,</segment>
		<segment id="38" parent="39" relname="condition">исключительно усилиями собственных националистических элит,</segment>
		<segment id="39" parent="129" relname="span">подмандатное титульное население в рамках англосаксонской цивилизации уверенно совершает переход  государствообразующих наций в прикольную этнографическую редкость.</segment>
		<segment id="40" parent="131" relname="evaluation">С чем небратьев можно поздравить.</segment>
		<segment id="41" parent="124" relname="span">Сама Россия, впервые за последнее столетие,</segment>
		<segment id="42" parent="41" relname="condition">жалуясь на отсутствие государственной идеологии, впервые строит свою геополитику</segment>
		<segment id="43" parent="124" relname="condition">опираясь не на умозрительные идеалистические конструкции, а на самые базовые потребности, которые правильно было бы называть инстинктами.</segment>
		<segment id="44" parent="125" relname="span">В результате в начале ХХI века активность российского государства демонстрирует образец прагматичности.</segment>
		<segment id="45" parent="93" relname="contrast">Не на отвоевании Константинополя, которого домогались Романовы, ни на построении социализма в Африке,</segment>
		<segment id="46" parent="93" relname="contrast">а на контроле над месторождениями углеводородов и логистикой  сосредоточены усилия современной российской элиты.</segment>
		<segment id="47" parent="95" relname="joint">Никакой идеи.</segment>
		<segment id="48" parent="94" relname="joint">Мотив полностью приземлённый</segment>
		<segment id="49" parent="94" relname="joint">и циничный. Строго в соответствии с марксистской теорией капитализма.</segment>
		<segment id="50" parent="96" relname="joint">Но посмотрите, как корёжит при этом “колыбель буржуазии” – цивилизацию англосаксов.</segment>
		<segment id="51" parent="96" relname="joint">Как им не нравится эти в доску капиталистические поползновения России в Сирии, Венесуэле, Германии, Китае!</segment>
		<segment id="52" parent="98" relname="attribution">А как  писал классик</segment>
		<segment id="53" parent="54" relname="condition">– если твой враг тебя проклинает,</segment>
		<segment id="54" parent="98" relname="span">скорее всего ты всё делаешь правильно…</segment>
		<segment id="55" parent="102" relname="preparation">Капитализм, он ведь тоже имеет свою логику развития, которую вполне квалифицированно описал Маркс.</segment>
		<segment id="56" parent="102" relname="span">В полном соответствии с этой логикой компрадорская буржуазия Росси 90х  сегодня вытесняется другой, более зубастой,</segment>
		<segment id="57" parent="127" relname="span">которая  уже смотрит на Запад еще снизу вверх, но уже без былого почитания, а скорее как хищник,</segment>
		<segment id="58" parent="57" relname="elaboration">почуявший, что гегемон слабеет и скоро сам вполне может стать кормом.</segment>
		<segment id="59" parent="104" relname="contrast">Сам капитализм, как общественно-экономическая формация, тоже находится при смерти,</segment>
		<segment id="60" parent="104" relname="contrast">но эту уже другая тема.</segment>
		<segment id="61" parent="106" relname="contrast">К социальной справедливости внутри самой России всё вышесказанное не имеет никакого отношения,</segment>
		<segment id="62" parent="107" relname="comparison">однако  это не должно мешать гордиться победами местных олигархов над иностранными,</segment>
		<segment id="63" parent="107" relname="comparison">как не мешает гордиться Суворовым его крайне сложные отношения с народными восстаниями (Пугачёв) и национально освободительными движениями (Польша)</segment>
		<segment id="64" parent="109" relname="span">Кстати, насчёт Суворова в частности и истории вообще.</segment>
		<segment id="65" parent="128" relname="span">Наконец то в России нет вычеркнутых времён, про которые не принято вспоминать.</segment>
		<segment id="66" parent="108" relname="joint">И это хорошо!</segment>
		<segment id="67" parent="108" relname="joint">Это правильно.</segment>
		<segment id="68" parent="109" relname="evidence">Взаимосвязь событий и непрерывность исторических процессов – необходимое условие их адекватного восприятия.</segment>
		<segment id="69" parent="112" relname="span">Осталось только научиться  спокойно анализировать былое,</segment>
		<segment id="70" parent="111" relname="span">дабы вовремя  вносить правки в скорость и направление движения,</segment>
		<segment id="71" parent="70" relname="purpose">чтобы не наступать повторно на детские грабли.</segment>
		<group id="72" type="span" parent="73" relname="contrast"/>
		<group id="73" type="multinuc" parent="75" relname="joint"/>
		<group id="74" type="span" parent="75" relname="joint"/>
		<group id="75" type="multinuc" />
		<group id="76" type="multinuc" parent="11" relname="elaboration"/>
		<group id="77" type="span" parent="83" relname="joint"/>
		<group id="78" type="span" parent="79" relname="same-unit"/>
		<group id="79" type="multinuc" parent="80" relname="joint"/>
		<group id="80" type="multinuc" parent="83" relname="joint"/>
		<group id="81" type="span" parent="82" relname="span"/>
		<group id="82" type="span" parent="115" relname="span"/>
		<group id="83" type="multinuc" parent="82" relname="cause"/>
		<group id="84" type="span" parent="85" relname="same-unit"/>
		<group id="85" type="multinuc" parent="86" relname="span"/>
		<group id="86" type="span" parent="87" relname="span"/>
		<group id="87" type="span" parent="117" relname="background"/>
		<group id="88" type="multinuc" parent="90" relname="joint"/>
		<group id="89" type="span" parent="90" relname="joint"/>
		<group id="90" type="multinuc" parent="91" relname="joint"/>
		<group id="91" type="multinuc" parent="117" relname="span"/>
		<group id="92" type="span" parent="125" relname="cause"/>
		<group id="93" type="multinuc" parent="44" relname="elaboration"/>
		<group id="94" type="multinuc" parent="95" relname="joint"/>
		<group id="95" type="multinuc" parent="101" relname="contrast"/>
		<group id="96" type="multinuc" parent="97" relname="span"/>
		<group id="97" type="span" parent="100" relname="span"/>
		<group id="98" type="span" parent="99" relname="span"/>
		<group id="99" type="span" parent="97" relname="evidence"/>
		<group id="100" type="span" parent="101" relname="contrast"/>
		<group id="101" type="multinuc" />
		<group id="102" type="span" parent="103" relname="span"/>
		<group id="103" type="span" parent="105" relname="joint"/>
		<group id="104" type="multinuc" parent="105" relname="joint"/>
		<group id="105" type="multinuc" />
		<group id="106" type="multinuc" parent="113" relname="joint"/>
		<group id="107" type="multinuc" parent="106" relname="contrast"/>
		<group id="108" type="multinuc" parent="65" relname="evaluation"/>
		<group id="109" type="span" parent="110" relname="span"/>
		<group id="110" type="span" parent="113" relname="joint"/>
		<group id="111" type="span" parent="69" relname="purpose"/>
		<group id="112" type="span" parent="119" relname="contrast"/>
		<group id="113" type="multinuc" parent="119" relname="contrast"/>
		<group id="114" type="multinuc" parent="4" relname="elaboration"/>
		<group id="115" type="span" />
		<group id="116" type="multinuc" parent="91" relname="joint"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" />
		<group id="119" type="multinuc" />
		<group id="120" type="span" parent="10" relname="elaboration"/>
		<group id="121" type="span" parent="80" relname="joint"/>
		<group id="122" type="span" parent="88" relname="joint"/>
		<group id="123" type="span" parent="28" relname="elaboration"/>
		<group id="124" type="span" parent="92" relname="span"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" />
		<group id="127" type="span" parent="56" relname="elaboration"/>
		<group id="128" type="span" parent="64" relname="elaboration"/>
		<group id="129" type="span" parent="130" relname="same-unit"/>
		<group id="130" type="multinuc" parent="131" relname="span"/>
		<group id="131" type="span" parent="132" relname="span"/>
		<group id="132" type="span" />
		<group id="133" type="span" parent="134" relname="same-unit"/>
		<group id="134" type="multinuc" parent="116" relname="contrast"/>
	</body>
</rst>