<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://tumbalele.livejournal.com/123424.html</segment>
		<segment id="2" >КАК ПРОЖИВАЕТСЯ ОТВЕРЖЕНИЕ (Ч.1)</segment>
		<segment id="3" >IMG</segment>
		<segment id="4" parent="118" relname="span">Отвержение кажется</segment>
		<segment id="5" parent="4" relname="evaluation">(или даже является)</segment>
		<segment id="6" parent="119" relname="same-unit">непереносимым тогда,</segment>
		<segment id="7" parent="120" relname="cause">когда произошло слияние.</segment>
		<segment id="8" parent="9" relname="condition">Если вы - младенец,</segment>
		<segment id="9" parent="122" relname="span">то отвержение со стороны мамы это катастрофа.</segment>
		<segment id="10" parent="124" relname="span">У младенца еще нет никаких ресурсов,</segment>
		<segment id="11" parent="10" relname="purpose">чтобы выжить одному.</segment>
		<segment id="12" parent="129" relname="span">Его единственный шанс - это привязанность к нему мамы.</segment>
		<segment id="13" parent="128" relname="contrast">Залог выживания - сохранение этого "мы",</segment>
		<segment id="14" parent="127" relname="span">и в нём нет отдельных меня и мамы,</segment>
		<segment id="15" parent="126" relname="span">у которой есть жизнь, никак не связанная с моей</segment>
		<segment id="16" parent="17" relname="cause">(ведь осознание того, что у мамы есть другая жизнь и люди, к которым она тоже может быть привязана,</segment>
		<segment id="17" parent="217" relname="span">порождает тревогу.</segment>
		<segment id="18" parent="125" relname="joint">Мама может думать больше о них, чем обо мне.</segment>
		<segment id="19" parent="125" relname="joint">Она может меня бросить и оставить).</segment>
		<segment id="20" parent="139" relname="span">"Мы" - единый организм.</segment>
		<segment id="21" parent="137" relname="span">В нем хорошо, тихо, спокойно.</segment>
		<segment id="22" parent="132" relname="contrast">Энергии не очень много,</segment>
		<segment id="23" parent="218" relname="span">но зачем она,</segment>
		<segment id="24" parent="23" relname="condition">когда так тепло и сытно...</segment>
		<segment id="25" parent="133" relname="joint">Свернутся калачиком,</segment>
		<segment id="26" parent="133" relname="joint">прижаться к мягкому и теплому телу,</segment>
		<segment id="27" parent="133" relname="joint">слышать биение сердца матери,</segment>
		<segment id="28" parent="133" relname="joint">ощущать молоко в желудке и на губах...</segment>
		<segment id="29" parent="134" relname="joint">Я - это ты,</segment>
		<segment id="30" parent="134" relname="joint">и ты - это я.</segment>
		<segment id="31" parent="207" relname="contrast">Нет больше ничего.</segment>
		<segment id="32" parent="142" relname="contrast">Мы можем телесно вырасти,</segment>
		<segment id="33" parent="142" relname="contrast">но какая-то часть нашей души (по разным причинам) может остаться младенческой, отчаянно ищущей восстановления "мы".</segment>
		<segment id="34" parent="219" relname="joint">И этот младенец может вцепиться в того, кто по какой-то причине напоминает человека, способного избавить от тревоги брошенности.</segment>
		<segment id="35" parent="219" relname="joint">Того, кто полностью, целиком будет удовлетворять все наши потребности в тепле, любви, нежности.</segment>
		<segment id="36" parent="219" relname="joint">И еще - всегда будет рядом...</segment>
		<segment id="37" parent="221" relname="restatement">"Я боюсь быть отвергнутым" значит</segment>
		<segment id="38" parent="221" relname="restatement">" я не научился еще жить автономно.</segment>
		<segment id="39" parent="222" relname="elaboration">Я по-прежнему ищу того или ту, кто вернет мне то блаженное и полубессознательное состояние любви и постоянного присутствия рядом".</segment>
		<segment id="40" parent="148" relname="span">Таким человеком может быть кто угодно.</segment>
		<segment id="41" parent="146" relname="span">Родители могут вцепиться в своих детей,</segment>
		<segment id="42" parent="41" relname="cause">требуя от них всепоглощающей любви и отречения от своей жизни.</segment>
		<segment id="43" parent="147" relname="joint">Любой парень или девушка, появившиеся у выросших детей - смертельная угроза.</segment>
		<segment id="44" parent="208" relname="comparison">Ревнивые супруги в этом мало чем отличаются от таких родителей.</segment>
		<segment id="45" parent="209" relname="span">"Ты, и только ты единственный/единственная, кто может дать мне всё, что мне нужно" - это общее ощущение людей, стремящихся к психологическому слиянию с теми, кто, как кажется, может заменить утраченную связь с тем, кто всегда рядом и удовлетворяет все желания.</segment>
		<segment id="46" parent="150" relname="joint">Да, в обмен на эту связь и ощущение безопасности теряешь свободу</segment>
		<segment id="47" parent="150" relname="joint">и лишаешь ее другого</segment>
		<segment id="48" parent="151" relname="contrast">- но зато как хорошо...</segment>
		<segment id="49" parent="50" relname="condition">Чем больше напуган этот младенец</segment>
		<segment id="50" parent="210" relname="span">- тем менее терпим он будет к любым намекам на то, что другой человек не в состоянии удовлетворить это всепоглощающую младенческую тоску по утраченной матери.</segment>
		<segment id="51" parent="223" relname="span">А эти "намеки" неизбежно появятся</segment>
		<segment id="52" parent="51" relname="elaboration">- любые различия, любой взгляд на сторону - уже угроза.</segment>
		<segment id="53" parent="152" relname="contrast">Любой намек на то, что у него или у нее есть мысли, не связанные с тобой, есть своя жизнь - уже угроза.</segment>
		<segment id="54" parent="152" relname="contrast">А обнаружение того, что другой человек в принципе не в состоянии полностью удовлетворить младенческий эмоциональный голод - и вовсе может породить состояние, близкое к панике.</segment>
		<segment id="55" parent="156" relname="preparation">И тогда "младенец" начинает действовать.</segment>
		<segment id="56" parent="156" relname="span">На одном полюсе его переживаний - ярость и ненависть к тому, кто осмелился предать это блаженное "единство"</segment>
		<segment id="57" parent="155" relname="joint">(и неважно, было ли оно в реальности</segment>
		<segment id="58" parent="155" relname="joint">или только воображалось).</segment>
		<segment id="59" parent="60" relname="condition">Когда мы переживаем отвержение</segment>
		<segment id="60" parent="224" relname="span">- в этой боли много гнева и страха.</segment>
		<segment id="61" parent="158" relname="span">Отвергнутый пытается любой ценой вернуть того, кто уходит. Или через тотальный контроль</segment>
		<segment id="62" parent="157" relname="joint">("ты где?!",</segment>
		<segment id="63" parent="157" relname="joint">"почему ты не отвечал на мои звонки целый час?!",</segment>
		<segment id="64" parent="157" relname="joint">просмотр чужих почт,</segment>
		<segment id="65" parent="157" relname="joint">взлом/ежечасный мониторинг аккаунтов в соцсетях и так далее)</segment>
		<segment id="66" parent="159" relname="same-unit">или через отчаянные попытки стать еще лучше,</segment>
		<segment id="67" parent="211" relname="span">стать настолько хорошим и замечательным,</segment>
		<segment id="68" parent="67" relname="purpose">чтобы уж точно не бросили.</segment>
		<segment id="69" parent="162" relname="contrast">Ведь бросают только плохих,</segment>
		<segment id="70" parent="162" relname="contrast">хороших бросить не могут!</segment>
		<segment id="71" parent="163" relname="span">"Что мне еще сделать,</segment>
		<segment id="72" parent="71" relname="purpose">чтобы ты не бросал?!"</segment>
		<segment id="73" parent="164" relname="span">Не зря психоаналитики называют такое состояние параноидным</segment>
		<segment id="74" parent="75" relname="cause">- бьющийся в душе ужас бросает из крайности в крайность,</segment>
		<segment id="75" parent="215" relname="span">делая человека крайне подозрительным и враждебным.</segment>
		<segment id="76" parent="179" relname="span">Чего только там нет...</segment>
		<segment id="77" parent="165" relname="span">Например, фантазии о том, что отвергший меня человек сейчас радостно смеётся надо мной в компании друзей,</segment>
		<segment id="78" parent="77" relname="condition">пока я тут в одиночестве плачу.</segment>
		<segment id="79" parent="165" relname="evaluation">Ему/ей вообще нет до меня дела.</segment>
		<segment id="80" parent="166" relname="contrast">Отвергли</segment>
		<segment id="81" parent="166" relname="contrast">- и пошли дальше, похихикивая.</segment>
		<segment id="82" parent="175" relname="contrast">Он/она рисуются в душе бессердечными, надменными гадами.</segment>
		<segment id="83" parent="167" relname="joint">Но ничего! Я сейчас займусь собой как следует,</segment>
		<segment id="84" parent="167" relname="joint">сброшу вес,</segment>
		<segment id="85" parent="167" relname="joint">пойду в спортзал</segment>
		<segment id="86" parent="87" relname="condition">- и когда ты в следующий раз увидишь меня,</segment>
		<segment id="87" parent="168" relname="span">то поразишься тому, как я изменился,</segment>
		<segment id="88" parent="169" relname="contrast">но будет уже поздно!!</segment>
		<segment id="89" parent="90" relname="cause">Или убью себя,</segment>
		<segment id="90" parent="172" relname="span">и ты осознаешь, как я был тебе дорог</segment>
		<segment id="91" parent="92" relname="cause">- но будет уже поздно,</segment>
		<segment id="92" parent="216" relname="span">ты познаешь боль, на которую меня обрекла!</segment>
		<segment id="93" parent="183" relname="span">В этом воспаленном сознании полностью исчезает какая-либо эмпатия к тому, кто тебя отверг</segment>
		<segment id="94" parent="93" relname="evaluation">(реально или мнимо - неважно).</segment>
		<segment id="95" parent="184" relname="span">Отвергающий по определению - бессердечный негодяй/гадина,</segment>
		<segment id="96" parent="95" relname="cause">потому что отказал/а нуждающемся в том, без чего он не проживет.</segment>
		<segment id="97" parent="186" relname="comparison">Отказался жертвовать собой,</segment>
		<segment id="98" parent="185" relname="span">как жертвует своим временем и здоровьем мать</segment>
		<segment id="99" parent="98" relname="purpose">для того, чтобы выходить младенца.</segment>
		<segment id="100" parent="187" relname="span">Отверженный не осознает другого как живого, чувствующего, думающего, переживающего</segment>
		<segment id="101" parent="100" relname="elaboration">- для него это просто объект, не дающий того, что требуется.</segment>
		<segment id="102" parent="187" relname="evaluation">В общем-то, с позиции младенческой психики так оно и есть.</segment>
		<segment id="103" parent="190" relname="span">И ярость ("ДАЙ!!!) сменяется ненавистью ("ТОГДА СТРАДАЙ САМ!!!"),</segment>
		<segment id="104" parent="189" relname="span">переходящей в ярость и ненависть к себе</segment>
		<segment id="105" parent="106" relname="condition">("если бы я был лучше</segment>
		<segment id="106" parent="188" relname="span">- я бы не был оставлен!").</segment>
		<segment id="107" parent="196" relname="joint">Но есть и другой полюс переживаний,</segment>
		<segment id="108" parent="197" relname="span">и именно в нем заключается возможность взросления и сепарации,</segment>
		<segment id="109" parent="108" relname="condition">когда происходит чудо:</segment>
		<segment id="110" parent="198" relname="contrast">ты обнаруживаешь, что да, больше никто в мире не может быть тебе заменой матери,</segment>
		<segment id="111" parent="198" relname="contrast">но есть люди, которые всё равно что-то могут дать тебе.</segment>
		<segment id="112" parent="201" relname="contrast">Эти люди не в состоянии удовлетворить всю потребность в любви</segment>
		<segment id="113" parent="201" relname="contrast">- но ты можешь брать по чуть-чуть,</segment>
		<segment id="114" parent="202" relname="span">и из этих маленьких огоньков и складывается то, что греет тебя,</segment>
		<segment id="115" parent="114" relname="condition">даже когда ты один.</segment>
		<segment id="116" parent="227" relname="joint">Это полюс грусти и горевания.</segment>
		<segment id="117" parent="227" relname="joint">Но о нём продолжу позже.</segment>
		<group id="118" type="span" parent="119" relname="same-unit"/>
		<group id="119" type="multinuc" parent="120" relname="span"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="preparation"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" parent="131" relname="span"/>
		<group id="124" type="span" parent="130" relname="span"/>
		<group id="125" type="multinuc" parent="15" relname="evidence"/>
		<group id="126" type="span" parent="14" relname="elaboration"/>
		<group id="127" type="span" parent="128" relname="contrast"/>
		<group id="128" type="multinuc" parent="140" relname="span"/>
		<group id="129" type="span" parent="124" relname="elaboration"/>
		<group id="130" type="span" parent="123" relname="evidence"/>
		<group id="131" type="span" />
		<group id="132" type="multinuc" parent="135" relname="span"/>
		<group id="133" type="multinuc" parent="135" relname="elaboration"/>
		<group id="134" type="multinuc" parent="207" relname="contrast"/>
		<group id="135" type="span" parent="136" relname="span"/>
		<group id="136" type="span" parent="21" relname="elaboration"/>
		<group id="137" type="span" parent="138" relname="joint"/>
		<group id="138" type="multinuc" parent="20" relname="elaboration"/>
		<group id="139" type="span" parent="140" relname="elaboration"/>
		<group id="140" type="span" parent="141" relname="span"/>
		<group id="141" type="span" parent="12" relname="elaboration"/>
		<group id="142" type="multinuc" parent="220" relname="cause"/>
		<group id="143" type="span" parent="145" relname="span"/>
		<group id="144" type="span" parent="143" relname="elaboration"/>
		<group id="145" type="span" />
		<group id="146" type="span" parent="147" relname="joint"/>
		<group id="147" type="multinuc" parent="208" relname="comparison"/>
		<group id="148" type="span" parent="149" relname="span"/>
		<group id="149" type="span" />
		<group id="150" type="multinuc" parent="151" relname="contrast"/>
		<group id="151" type="multinuc" parent="45" relname="evaluation"/>
		<group id="152" type="multinuc" parent="223" relname="elaboration"/>
		<group id="153" type="span" parent="154" relname="contrast"/>
		<group id="154" type="multinuc" />
		<group id="155" type="multinuc" parent="56" relname="elaboration"/>
		<group id="156" type="span" parent="181" relname="span"/>
		<group id="157" type="multinuc" parent="61" relname="elaboration"/>
		<group id="158" type="span" parent="159" relname="same-unit"/>
		<group id="159" type="multinuc" parent="160" relname="joint"/>
		<group id="160" type="multinuc" parent="161" relname="span"/>
		<group id="161" type="span" parent="224" relname="elaboration"/>
		<group id="162" type="multinuc" parent="212" relname="span"/>
		<group id="163" type="span" parent="212" relname="elaboration"/>
		<group id="164" type="span" parent="180" relname="span"/>
		<group id="165" type="span" parent="176" relname="span"/>
		<group id="166" type="multinuc" parent="176" relname="evaluation"/>
		<group id="167" type="multinuc" parent="170" relname="cause"/>
		<group id="168" type="span" parent="169" relname="contrast"/>
		<group id="169" type="multinuc" parent="170" relname="span"/>
		<group id="170" type="span" parent="171" relname="span"/>
		<group id="171" type="span" parent="174" relname="joint"/>
		<group id="172" type="span" parent="173" relname="contrast"/>
		<group id="173" type="multinuc" parent="174" relname="joint"/>
		<group id="174" type="multinuc" parent="175" relname="contrast"/>
		<group id="175" type="multinuc" parent="178" relname="joint"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" parent="178" relname="joint"/>
		<group id="178" type="multinuc" parent="76" relname="evidence"/>
		<group id="179" type="span" parent="164" relname="elaboration"/>
		<group id="180" type="span" parent="225" relname="elaboration"/>
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" />
		<group id="183" type="span" parent="195" relname="span"/>
		<group id="184" type="span" parent="191" relname="span"/>
		<group id="185" type="span" parent="186" relname="comparison"/>
		<group id="186" type="multinuc" parent="184" relname="elaboration"/>
		<group id="187" type="span" parent="192" relname="span"/>
		<group id="188" type="span" parent="104" relname="evidence"/>
		<group id="189" type="span" parent="103" relname="elaboration"/>
		<group id="190" type="span" parent="192" relname="evidence"/>
		<group id="191" type="span" parent="194" relname="comparison"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" parent="194" relname="comparison"/>
		<group id="194" type="multinuc" parent="183" relname="elaboration"/>
		<group id="195" type="span" />
		<group id="196" type="multinuc" parent="199" relname="span"/>
		<group id="197" type="span" parent="196" relname="joint"/>
		<group id="198" type="multinuc" parent="199" relname="elaboration"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="204" relname="span"/>
		<group id="201" type="multinuc" parent="202" relname="cause"/>
		<group id="202" type="span" parent="203" relname="span"/>
		<group id="203" type="span" parent="200" relname="elaboration"/>
		<group id="204" type="span" parent="206" relname="span"/>
		<group id="206" type="span" />
		<group id="207" type="multinuc" parent="138" relname="joint"/>
		<group id="208" type="multinuc" parent="40" relname="evidence"/>
		<group id="209" type="span" parent="148" relname="elaboration"/>
		<group id="210" type="span" parent="154" relname="contrast"/>
		<group id="211" type="span" parent="214" relname="span"/>
		<group id="212" type="span" parent="213" relname="span"/>
		<group id="213" type="span" parent="211" relname="cause"/>
		<group id="214" type="span" parent="160" relname="joint"/>
		<group id="215" type="span" parent="73" relname="elaboration"/>
		<group id="216" type="span" parent="173" relname="contrast"/>
		<group id="217" type="span" parent="125" relname="joint"/>
		<group id="218" type="span" parent="132" relname="contrast"/>
		<group id="219" type="multinuc" parent="220" relname="span"/>
		<group id="220" type="span" parent="143" relname="span"/>
		<group id="221" type="multinuc" parent="222" relname="span"/>
		<group id="222" type="span" parent="144" relname="span"/>
		<group id="223" type="span" parent="153" relname="span"/>
		<group id="224" type="span" parent="225" relname="span"/>
		<group id="225" type="span" parent="226" relname="span"/>
		<group id="226" type="span" parent="181" relname="elaboration"/>
		<group id="227" type="multinuc" parent="204" relname="evaluation"/>
	</body>
</rst>