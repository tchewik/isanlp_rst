<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://koshkindom.kosmetista.ru/blog/98018.html</segment>
		<segment id="2" >Палитра теней Zoeva Cocoa Blend</segment>
		<segment id="3" parent="112" relname="preparation">Всем привет! IMG</segment>
		<segment id="4" parent="105" relname="preparation">Палитра теней Zoeva Cocoa Blend</segment>
		<segment id="5" parent="105" relname="span">Сегодня на повестке дня симпатичная базовая палетка.</segment>
		<segment id="6" parent="102" relname="contrast">Бренд Zoeva знаком мне, прежде всего, благодаря кистям.</segment>
		<segment id="7" parent="101" relname="span">А вот из декоративной косметики я не пробовала почти ничего,</segment>
		<segment id="8" parent="7" relname="concession">хотя и слышала хорошие отзывы.</segment>
		<segment id="9" parent="103" relname="span">Обычно я начинаю знакомство с брендами со своей любимой категории – теней для век.</segment>
		<segment id="10" parent="9" relname="elaboration">Случай с Zoeva не стал исключением.</segment>
		<segment id="11" parent="111" relname="span">Итак, упаковка палетки Cocoa Blend внешне похожа на плитку шоколада.</segment>
		<segment id="12" parent="106" relname="joint">Внешняя обложка изготовлена из картона,</segment>
		<segment id="13" parent="106" relname="joint">снимается, как чехол. IMG</segment>
		<segment id="14" parent="107" relname="joint">Футляр тоже картонный,</segment>
		<segment id="15" parent="107" relname="joint">закрывается на магнит.</segment>
		<segment id="16" parent="108" relname="span">Зеркала и инструментов</segment>
		<segment id="17" parent="16" relname="purpose">для нанесения</segment>
		<segment id="18" parent="109" relname="same-unit">не предусмотрено.</segment>
		<segment id="19" parent="113" relname="joint">Произведены тени в Италии.</segment>
		<segment id="20" parent="113" relname="joint">Совокупный вес составляет 15 грамм (10 рефилов по 1,5 грамм).</segment>
		<segment id="21" parent="113" relname="joint">Срок годности с открытой крышечкой – 36 месяцев.</segment>
		<segment id="22" parent="113" relname="joint">Цена 1500 руб.</segment>
		<segment id="23" parent="114" relname="span">Внутри палетки содержится 10 оттенков теней, среди которых 4 матовых и 6 сатиновых.</segment>
		<segment id="24" parent="23" relname="elaboration">Давайте рассмотрим их поближе. IMG IMG</segment>
		<segment id="25" parent="118" relname="span">Bitter Start – матовый телесный оттенок.</segment>
		<segment id="26" parent="116" relname="joint">Им хорошо закреплять базу,</segment>
		<segment id="27" parent="116" relname="joint">высветлять пространство под бровью,</segment>
		<segment id="28" parent="116" relname="joint">подчищать растушевку.</segment>
		<segment id="29" parent="117" relname="joint">Достаточно пигментированный и немного пыльный. IMG</segment>
		<segment id="30" parent="122" relname="span">Sweeter End – оттенок-вуаль.</segment>
		<segment id="31" parent="119" relname="comparison">Под прямыми лучами света кажется розово-золотым,</segment>
		<segment id="32" parent="119" relname="comparison">в динамике проявляются лиловые нотки.</segment>
		<segment id="33" parent="120" relname="span">Хорошо подходит</segment>
		<segment id="34" parent="33" relname="purpose">для макияжа «без макияжа»,</segment>
		<segment id="35" parent="121" relname="joint">создает едва заметный перелив на веке. IMG</segment>
		<segment id="36" parent="127" relname="span">Warm Notes – насыщенный бордовый оттенок на коричневой базе.</segment>
		<segment id="37" parent="124" relname="joint">Хорошо поддается наслоению,</segment>
		<segment id="38" parent="124" relname="joint">растушевывается в едва заметную вуаль.</segment>
		<segment id="39" parent="125" relname="evaluation">Абсолютно беспроблемный. IMG</segment>
		<segment id="40" parent="128" relname="span">Subtle Blend – классический бронзовый оттенок с сатиновым финишем.</segment>
		<segment id="41" parent="40" relname="evaluation">Универсальный и, пожалуй, самый ходовой из этой палетки. IMG</segment>
		<segment id="42" parent="130" relname="span">Beans Are White – темно-коричневый матовый оттенок.</segment>
		<segment id="43" parent="129" relname="span">Не самый послушный,</segment>
		<segment id="44" parent="43" relname="cause">может осыпаться под глаза. IMG</segment>
		<segment id="45" parent="132" relname="span">Общий свотч верхнего ряда оттенков. IMG</segment>
		<segment id="46" parent="131" relname="span">Тени нанесены подушечкой пальца</segment>
		<segment id="47" parent="46" relname="condition">без использования базы</segment>
		<segment id="48" parent="135" relname="span">Pure Ganache – медно-золотой сатиновый оттенок.</segment>
		<segment id="49" parent="134" relname="span">Красивый, яркий, послушный.</segment>
		<segment id="50" parent="49" relname="evaluation">Из всех сатинов палетки у этого самая кремовая и послушная текстура. IMG</segment>
		<segment id="51" parent="139" relname="span">Substitute For Love – матовый рыже-коричневый оттенок.</segment>
		<segment id="52" parent="138" relname="joint">Использую его в качестве переходного в складке века.</segment>
		<segment id="53" parent="137" relname="span">Он отлично сочетается со всеми тенями из палетки</segment>
		<segment id="54" parent="55" relname="cause">и за счет своей полупрозрачности</segment>
		<segment id="55" parent="136" relname="span">позволяет уводить более яркие оттенки в мягкую растушевку. IMG</segment>
		<segment id="56" parent="145" relname="span">Freshly Toasted – бордово-коричневый матовый оттенок.</segment>
		<segment id="57" parent="140" relname="span">Соло его не использую,</segment>
		<segment id="58" parent="57" relname="cause">поскольку он плотно спрессован</segment>
		<segment id="59" parent="60" relname="purpose">и для получения заметного цвета</segment>
		<segment id="60" parent="141" relname="span">его нужно сильно наслаивать.</segment>
		<segment id="61" parent="144" relname="span">Но зато он хорошо подходит</segment>
		<segment id="62" parent="61" relname="purpose">для углубления складки века, оформления внешнего уголка глаза и линии роста ресниц. IMG</segment>
		<segment id="63" parent="159" relname="span">Infusion – темный коричнево-серый оттенок.</segment>
		<segment id="64" parent="146" relname="span">Текстура этого оттенка не является однородной.</segment>
		<segment id="65" parent="64" relname="elaboration">В ней содержатся вкрапления золотистого шиммера.</segment>
		<segment id="66" parent="148" relname="span">К сожалению, на веке эти золотые искорки практически не заметны.</segment>
		<segment id="67" parent="147" relname="span">Только если сильно наслаивать,</segment>
		<segment id="68" parent="67" relname="condition">используя липкую базу.</segment>
		<segment id="69" parent="150" relname="evaluation">Оттенок довольно пыльный,</segment>
		<segment id="70" parent="150" relname="span">может осыпаться в процессе нанесения,</segment>
		<segment id="71" parent="70" relname="cause">так что я наношу тон только после макияжа глаз с его участием. IMG</segment>
		<segment id="72" parent="154" relname="span">Delicate Acidity – единственный холодный оттенок палетки.</segment>
		<segment id="73" parent="72" relname="elaboration">Лилово-сиреневый на серой базе.</segment>
		<segment id="74" parent="154" relname="evaluation">Мягкий и послушный, отличный вариант под стрелку. IMG</segment>
		<segment id="75" parent="157" relname="span">Общий свотч нижнего ряда оттенков. IMG</segment>
		<segment id="76" parent="156" relname="span">Тени нанесены подушечкой пальца</segment>
		<segment id="77" parent="76" relname="condition">без использования базы</segment>
		<segment id="78" parent="158" relname="elaboration">Покажу несколько макияжей. IMG IMG IMG IMG</segment>
		<segment id="79" parent="167" relname="contrast">В качестве резюме хочу сказать, что это далеко не самая крутая палетка в моей коллекции.</segment>
		<segment id="80" parent="164" relname="span">Тем не менее, в процессе ее использования я поняла, что это отличный повседневный вариант</segment>
		<segment id="81" parent="80" relname="purpose">для создания неброского дневного макияжа.</segment>
		<segment id="82" parent="83" relname="condition">Когда не нужна мега-пигментация и 100500 цветных переливов на веках,</segment>
		<segment id="83" parent="165" relname="span">тени Zoeva придутся кстати.</segment>
		<segment id="84" parent="183" relname="joint">Технические характеристики хорошие,</segment>
		<segment id="85" parent="183" relname="joint">тени отлично держатся на базе до демакияжа.</segment>
		<segment id="86" parent="182" relname="joint">В течение дня не тускнеют</segment>
		<segment id="87" parent="182" relname="joint">и не скатываются.</segment>
		<segment id="88" parent="169" relname="joint">Гармонично сочетаются между собой</segment>
		<segment id="89" parent="169" relname="joint">и дружат с любыми инструментами.</segment>
		<segment id="90" parent="181" relname="contrast">Есть небольшие недочеты у оттенков Beans Are White и Infusion (о которых я писала выше),</segment>
		<segment id="91" parent="185" relname="span">но я не считаю это критичным минусом.</segment>
		<segment id="92" parent="91" relname="cause">В моей коллекции есть гораздо более сложные экземпляры.</segment>
		<segment id="93" parent="174" relname="contrast">Безусловно, кому-то палетка покажется скучной.</segment>
		<segment id="94" parent="172" relname="joint">Но тем, кто, наоборот, предпочитает что-то непритязательное</segment>
		<segment id="95" parent="172" relname="joint">и любит теплую гамму в макияже,</segment>
		<segment id="96" parent="173" relname="span">я могу палетку порекомендовать.</segment>
		<segment id="97" parent="175" relname="joint">Она стоит вполне вменяемых денег</segment>
		<segment id="98" parent="175" relname="joint">и, на мой взгляд, имеет оптимальное сочетание цена/качество.</segment>
		<segment id="99" >Спасибо за внимание!</segment>
		<segment id="100" >Дарья😊</segment>
		<group id="101" type="span" parent="102" relname="contrast"/>
		<group id="102" type="multinuc" parent="103" relname="solutionhood"/>
		<group id="103" type="span" parent="104" relname="span"/>
		<group id="104" type="span" parent="5" relname="background"/>
		<group id="105" type="span" parent="112" relname="span"/>
		<group id="106" type="multinuc" parent="110" relname="joint"/>
		<group id="107" type="multinuc" parent="110" relname="joint"/>
		<group id="108" type="span" parent="109" relname="same-unit"/>
		<group id="109" type="multinuc" parent="110" relname="joint"/>
		<group id="110" type="multinuc" parent="113" relname="joint"/>
		<group id="111" type="span" parent="115" relname="span"/>
		<group id="112" type="span" parent="184" relname="span"/>
		<group id="113" type="multinuc" parent="11" relname="elaboration"/>
		<group id="114" type="span" parent="161" relname="preparation"/>
		<group id="115" type="span" />
		<group id="116" type="multinuc" parent="117" relname="joint"/>
		<group id="117" type="multinuc" parent="25" relname="elaboration"/>
		<group id="118" type="span" parent="160" relname="joint"/>
		<group id="119" type="multinuc" parent="30" relname="elaboration"/>
		<group id="120" type="span" parent="121" relname="joint"/>
		<group id="121" type="multinuc" parent="122" relname="elaboration"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" parent="160" relname="joint"/>
		<group id="124" type="multinuc" parent="125" relname="span"/>
		<group id="125" type="span" parent="126" relname="span"/>
		<group id="126" type="span" parent="36" relname="elaboration"/>
		<group id="127" type="span" parent="160" relname="joint"/>
		<group id="128" type="span" parent="160" relname="joint"/>
		<group id="129" type="span" parent="42" relname="evaluation"/>
		<group id="130" type="span" parent="133" relname="span"/>
		<group id="131" type="span" parent="45" relname="elaboration"/>
		<group id="132" type="span" parent="130" relname="elaboration"/>
		<group id="133" type="span" parent="160" relname="joint"/>
		<group id="134" type="span" parent="48" relname="elaboration"/>
		<group id="135" type="span" parent="160" relname="joint"/>
		<group id="136" type="span" parent="53" relname="purpose"/>
		<group id="137" type="span" parent="138" relname="joint"/>
		<group id="138" type="multinuc" parent="51" relname="elaboration"/>
		<group id="139" type="span" parent="160" relname="joint"/>
		<group id="140" type="span" parent="142" relname="joint"/>
		<group id="141" type="span" parent="142" relname="joint"/>
		<group id="142" type="multinuc" parent="143" relname="contrast"/>
		<group id="143" type="multinuc" parent="56" relname="elaboration"/>
		<group id="144" type="span" parent="143" relname="contrast"/>
		<group id="145" type="span" parent="160" relname="joint"/>
		<group id="146" type="span" parent="149" relname="contrast"/>
		<group id="147" type="span" parent="66" relname="condition"/>
		<group id="148" type="span" parent="149" relname="contrast"/>
		<group id="149" type="multinuc" parent="152" relname="span"/>
		<group id="150" type="span" parent="151" relname="span"/>
		<group id="151" type="span" parent="152" relname="elaboration"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" parent="63" relname="elaboration"/>
		<group id="154" type="span" parent="155" relname="span"/>
		<group id="155" type="span" parent="158" relname="span"/>
		<group id="156" type="span" parent="75" relname="elaboration"/>
		<group id="157" type="span" parent="155" relname="elaboration"/>
		<group id="158" type="span" parent="163" relname="span"/>
		<group id="159" type="span" parent="160" relname="joint"/>
		<group id="160" type="multinuc" parent="161" relname="span"/>
		<group id="161" type="span" parent="162" relname="span"/>
		<group id="162" type="span" />
		<group id="163" type="span" parent="160" relname="joint"/>
		<group id="164" type="span" parent="166" relname="span"/>
		<group id="165" type="span" parent="164" relname="elaboration"/>
		<group id="166" type="span" parent="167" relname="contrast"/>
		<group id="167" type="multinuc" parent="179" relname="preparation"/>
		<group id="168" type="multinuc" parent="177" relname="joint"/>
		<group id="169" type="multinuc" parent="177" relname="joint"/>
		<group id="171" type="multinuc" parent="178" relname="joint"/>
		<group id="172" type="multinuc" parent="96" relname="condition"/>
		<group id="173" type="span" parent="176" relname="span"/>
		<group id="174" type="multinuc" parent="178" relname="joint"/>
		<group id="175" type="multinuc" parent="173" relname="evaluation"/>
		<group id="176" type="span" parent="174" relname="contrast"/>
		<group id="177" type="multinuc" parent="171" relname="contrast"/>
		<group id="178" type="multinuc" parent="179" relname="span"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" />
		<group id="181" type="multinuc" parent="171" relname="contrast"/>
		<group id="182" type="multinuc" parent="168" relname="joint"/>
		<group id="183" type="multinuc" parent="168" relname="joint"/>
		<group id="184" type="span" parent="111" relname="preparation"/>
		<group id="185" type="span" parent="181" relname="contrast"/>
	</body>
</rst>