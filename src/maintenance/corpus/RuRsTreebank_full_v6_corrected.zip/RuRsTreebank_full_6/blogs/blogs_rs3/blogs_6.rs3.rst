<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://kosmetista.ru/blog/uhodovaya-kosmetika/96446.html</segment>
		<segment id="2" >Косметика поколения Z: Milk Makeup Urban Defense Mask</segment>
		<segment id="3" parent="113" relname="preparation">Всем привет!</segment>
		<segment id="4" parent="113" relname="span">Я неоднократно натыкалась на обзоры косметики Milk Makeup в видео американских блогеров.</segment>
		<segment id="5" parent="4" relname="evaluation">Некоторые из продуктов меня очень даже манили.</segment>
		<segment id="6" parent="112" relname="same-unit">Поэтому,</segment>
		<segment id="7" parent="110" relname="condition">когда в «стоковом» магазине я увидела данную маску по привлекательной цене,</segment>
		<segment id="8" parent="109" relname="joint">решила рискнуть</segment>
		<segment id="9" parent="109" relname="joint">и протестировать, что это за модный бренд.</segment>
		<segment id="10" parent="11" relname="condition">С учетом того, что продукция Milk Makeup только что стала доступна в одном из британских онлайн магазинов,</segment>
		<segment id="11" parent="116" relname="span">решила поделиться своим опытом знакомства с брендом. IMG</segment>
		<segment id="12" parent="118" relname="span">Маска молодой компании Milk Makeup — Urban Defense Mask — была выпущена в сотрудничестве с магазином одежды и lifestyle товаров Urban Outfitters,</segment>
		<segment id="13" parent="12" relname="elaboration">аудитория которого, на мой взгляд, пересекается с целевой группой Milk Makeup.</segment>
		<segment id="14" parent="119" relname="span">Сам бренд позиционирует себя, как модный, стильный, молодежный</segment>
		<segment id="15" parent="14" relname="elaboration">вдохновленный «креативностью, красотой каждого, стилем как улиц, так и фотостудий».</segment>
		<segment id="16" parent="120" relname="span">Бренд прославился своими продуктами в стиках (от хайлайтера, до огуречной маски под глаза) несколько лет назад</segment>
		<segment id="17" parent="16" relname="cause">благодаря продвижению через блогеров.</segment>
		<segment id="18" parent="122" relname="span">Основной площадкой продаж является их сайт,</segment>
		<segment id="19" parent="121" relname="contrast">который на данный момент осуществляет доставку только по Америке,</segment>
		<segment id="20" parent="121" relname="contrast">а оффлайн в других странах марка не представлена.</segment>
		<segment id="21" parent="22" relname="solutionhood">Это всё к чему? 😄</segment>
		<segment id="22" parent="126" relname="span">К тому, что я была очень заинтригована возможностью попробовать хоть какой-нибудь продукт от Milk Makeup. IMG</segment>
		<segment id="23" parent="130" relname="span">Данная маска продается в достаточно интересной упаковке — в картонном «тубусе» скрывается пластиковая баночка с откидной крышкой.</segment>
		<segment id="24" parent="129" relname="span">Баночка содержит аж 128 г продукта!</segment>
		<segment id="25" parent="24" relname="elaboration">Сама маска была защищена алюминиевой мембраной.</segment>
		<segment id="26" parent="128" relname="span">На мой взгляд, такой формат достаточно удобен:</segment>
		<segment id="27" parent="127" relname="joint">крышка закрывается с характерным щелчком,</segment>
		<segment id="28" parent="127" relname="joint">а пластиковую баночку нет шансов разбить в ванной.</segment>
		<segment id="29" parent="132" relname="span">Косметика произведена в США,</segment>
		<segment id="30" parent="212" relname="joint">не тестировалась на веганах</segment>
		<segment id="31" parent="212" relname="joint">и подходит для животных</segment>
		<segment id="32" parent="138" relname="joint">подходит для веганов</segment>
		<segment id="33" parent="138" relname="joint">и маркирована как cruelty-free. IMG</segment>
		<segment id="34" parent="133" relname="span">Маска предназначена</segment>
		<segment id="35" parent="34" relname="purpose">для очищения и питания кожи,</segment>
		<segment id="36" parent="134" relname="joint">предлагается использовать её через день.</segment>
		<segment id="37" parent="135" relname="span">На мой взгляд, это довольно часто для маски,</segment>
		<segment id="38" parent="37" relname="cause">так как эта категория уходовой косметики, по идее, должна давать быстрый результат за одно нанесение.🤔</segment>
		<segment id="39" parent="142" relname="condition">Попробовав действие маски несколько раз в отдельные дни,</segment>
		<segment id="40" parent="141" relname="same-unit">я</segment>
		<segment id="41" parent="42" relname="purpose">для чистоты эксперимента</segment>
		<segment id="42" parent="140" relname="span">решила пользоваться её на протяжении двух недель каждый второй вечер.</segment>
		<segment id="43" parent="149" relname="span">Консистенция маски довольно интересная — это густое мутноватое желе, но не «противно-холодное», как фруктовое желе, а скорее липкое и тягучее, как какой-то сироп.</segment>
		<segment id="44" parent="45" relname="cause">Довольно сильный аромат засахаренной розы сразу напомнил мне о рахат-лукуме</segment>
		<segment id="45" parent="148" relname="span">и так и подстегивал облизать пальцы во время нанесения. IMG</segment>
		<segment id="46" parent="176" relname="span">Наносить маску следует на чистое сухое лицо плотным слоем.</segment>
		<segment id="47" parent="151" relname="cause">Так как я обычно делала маску перед вечерним душем,</segment>
		<segment id="48" parent="150" relname="span">то или умывалась пенкой,</segment>
		<segment id="49" parent="48" relname="condition">если до этого смывала косметику,</segment>
		<segment id="50" parent="152" relname="joint">или протирала лицо мицеллярной водой в дни без косметики. IMG</segment>
		<segment id="51" parent="52" relname="purpose">Для щедрого нанесения на всё лицо</segment>
		<segment id="52" parent="154" relname="span">мне нужно примерно такое количество, как на фото выше, умноженное на 4.</segment>
		<segment id="53" parent="154" relname="elaboration">С таким расходом за две недели активного использования ушло меньше половины баночки.</segment>
		<segment id="54" parent="156" relname="span">У меня чувствительная комбинированная кожа (нормальная/сухая),</segment>
		<segment id="55" parent="155" relname="joint">склонная к шелушениям и обезвоживанию,</segment>
		<segment id="56" parent="155" relname="joint">присутствует гормональное акне.</segment>
		<segment id="57" parent="157" relname="span">Маска ложится на кожу приятно:</segment>
		<segment id="58" parent="57" relname="evaluation">наносить её пальцами — одно удовольствие!</segment>
		<segment id="59" parent="60" relname="concession">Хотя у меня были опасения,</segment>
		<segment id="60" parent="159" relname="span">что маска будет тянуть за собой пушковый волос,</segment>
		<segment id="61" parent="160" relname="contrast">но такого не происходит.</segment>
		<segment id="62" parent="164" relname="span">Предлагается держать маску на коже 5 минут</segment>
		<segment id="63" parent="162" relname="contrast">(она не застывает,</segment>
		<segment id="64" parent="163" relname="span">а остается такой же липкой,</segment>
		<segment id="65" parent="64" relname="concession">только подсыхая самую малость). IMG</segment>
		<segment id="66" parent="166" relname="span">Нанесла маску на сухую кожу</segment>
		<segment id="67" parent="66" relname="elaboration">(здесь достаточно тонкий слой)</segment>
		<segment id="68" parent="165" relname="span">Затем рекомендуется начать массировать лицо водой,</segment>
		<segment id="69" parent="68" relname="condition">смывая маску,</segment>
		<segment id="70" parent="165" relname="elaboration">которая превращается в эмульсию.</segment>
		<segment id="71" parent="170" relname="span">Второй вариант — удалить влажным спонжем</segment>
		<segment id="72" parent="71" relname="evaluation">(но на мой взгляд, смыть в душе намного проще). IMG</segment>
		<segment id="73" parent="172" relname="elaboration">Вот так выглядит маска на лице после добавления воды.</segment>
		<segment id="74" parent="195" relname="span">еперь перейдем к эффекту — после использования маски кожа на ощупь довольно нежная и бархатистая, не стянутая.</segment>
		<segment id="75" parent="182" relname="concession">Несмотря на отдушку,</segment>
		<segment id="76" parent="181" relname="joint">маска не вызвала покраснений</segment>
		<segment id="77" parent="181" relname="joint">и не щипала кожу.</segment>
		<segment id="78" parent="184" relname="contrast">Особого воздействия на поры или прыщи я не заметила,</segment>
		<segment id="79" parent="185" relname="joint">но маска удаляет остатки косметики и загрязнений,</segment>
		<segment id="80" parent="185" relname="joint">увлажняющий эффект чувствуется в том, что кожа нежная после использования маски.</segment>
		<segment id="81" parent="188" relname="same-unit">Пролонгированного эффекта</segment>
		<segment id="82" parent="83" relname="condition">при регулярном использовании</segment>
		<segment id="83" parent="187" relname="span">маски я не заметила. IMG</segment>
		<segment id="84" parent="213" relname="sequence">Смысла маску</segment>
		<segment id="85" parent="213" relname="sequence">и промокнула кожу полотенцем.</segment>
		<segment id="86" parent="87" relname="condition">При рассмотрении состава маски,</segment>
		<segment id="87" parent="189" relname="span">в нем не было найдено ничего особенного (на мой взгляд).</segment>
		<segment id="88" parent="192" relname="concession">Хотя интересно, что маска сочетает в себе «очищающее» и «увлажняющее» средство.</segment>
		<segment id="89" parent="190" relname="sequence">Но на мой взгляд, проще очистить кожу за 30 секунд пенкой</segment>
		<segment id="90" parent="190" relname="sequence">и затем нанести увлажняющее средство,</segment>
		<segment id="91" parent="191" relname="contrast">а не сидеть 5 минут с рахат-лукумом на лице! 😄 IMG</segment>
		<segment id="92" parent="93" relname="cause">Подводя итоги, на мой взгляд данная маска оказалась довольно бестолковой,</segment>
		<segment id="93" parent="199" relname="span">что вызывает скепсис по отношению к уходовой продукции марки Milk Makeup в целом</segment>
		<segment id="94" parent="201" relname="span">(а они как раз обновили свою линейку масок</segment>
		<segment id="95" parent="200" relname="span">— теперь банановый!</segment>
		<segment id="96" parent="95" relname="elaboration">они тоже в стиках! 😅 )</segment>
		<segment id="97" parent="203" relname="span">Хотя, я пожалуй, рискну заказать миниатюру туши с конопляным маслом — Kush Mascara,</segment>
		<segment id="98" parent="97" relname="evaluation">очень понравились отзывы и эффект на глазах!</segment>
		<segment id="99" parent="208" relname="span">Оценка: 3/5</segment>
		<segment id="100" parent="207" relname="joint">— потому что маска хуже не сделала</segment>
		<segment id="101" parent="207" relname="joint">и дала возможность попробовать новую для меня текстуру</segment>
		<segment id="102" parent="209" relname="comparison">Цена: мне досталась за £5,</segment>
		<segment id="103" parent="209" relname="comparison">изначальная цена ок. $25 (снятость)</segment>
		<segment id="104" parent="210" relname="joint">Срок тестирования: более 14 применений</segment>
		<segment id="105" >А вы пробовали что-нибудь от бренда Milk Makeup?</segment>
		<segment id="106" >Вызывают ли какие-нибудь их продукты ваш интерес?</segment>
		<segment id="107" >Спасибо, что читаете!</segment>
		<segment id="108" >Мария</segment>
		<group id="109" type="multinuc" parent="110" relname="span"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="112" relname="same-unit"/>
		<group id="112" type="multinuc" parent="114" relname="span"/>
		<group id="113" type="span" parent="215" relname="span"/>
		<group id="114" type="span" parent="115" relname="span"/>
		<group id="115" type="span" parent="117" relname="joint"/>
		<group id="116" type="span" parent="117" relname="joint"/>
		<group id="117" type="multinuc" parent="118" relname="preparation"/>
		<group id="118" type="span" parent="125" relname="span"/>
		<group id="119" type="span" parent="123" relname="span"/>
		<group id="120" type="span" parent="119" relname="elaboration"/>
		<group id="121" type="multinuc" parent="18" relname="elaboration"/>
		<group id="122" type="span" parent="123" relname="elaboration"/>
		<group id="123" type="span" parent="124" relname="span"/>
		<group id="124" type="span" parent="136" relname="span"/>
		<group id="125" type="span" parent="136" relname="preparation"/>
		<group id="126" type="span" parent="124" relname="evaluation"/>
		<group id="127" type="multinuc" parent="26" relname="cause"/>
		<group id="128" type="span" parent="130" relname="evaluation"/>
		<group id="129" type="span" parent="23" relname="elaboration"/>
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" parent="147" relname="span"/>
		<group id="132" type="span" parent="131" relname="background"/>
		<group id="133" type="span" parent="134" relname="joint"/>
		<group id="134" type="multinuc" parent="144" relname="span"/>
		<group id="135" type="span" parent="144" relname="evaluation"/>
		<group id="136" type="span" parent="137" relname="span"/>
		<group id="137" type="span" />
		<group id="138" type="multinuc" parent="139" relname="contrast"/>
		<group id="139" type="multinuc" parent="29" relname="elaboration"/>
		<group id="140" type="span" parent="141" relname="same-unit"/>
		<group id="141" type="multinuc" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="span"/>
		<group id="143" type="span" parent="146" relname="span"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" parent="143" relname="solutionhood"/>
		<group id="146" type="span" />
		<group id="147" type="span" />
		<group id="148" type="span" parent="43" relname="evaluation"/>
		<group id="149" type="span" parent="179" relname="preparation"/>
		<group id="150" type="span" parent="152" relname="joint"/>
		<group id="151" type="span" parent="153" relname="span"/>
		<group id="152" type="multinuc" parent="151" relname="span"/>
		<group id="153" type="span" parent="46" relname="background"/>
		<group id="154" type="span" parent="161" relname="span"/>
		<group id="155" type="multinuc" parent="54" relname="condition"/>
		<group id="156" type="span" parent="158" relname="span"/>
		<group id="157" type="span" parent="156" relname="evaluation"/>
		<group id="158" type="span" parent="175" relname="span"/>
		<group id="159" type="span" parent="160" relname="contrast"/>
		<group id="160" type="multinuc" parent="158" relname="elaboration"/>
		<group id="161" type="span" parent="176" relname="elaboration"/>
		<group id="162" type="multinuc" parent="62" relname="elaboration"/>
		<group id="163" type="span" parent="162" relname="contrast"/>
		<group id="164" type="span" parent="173" relname="preparation"/>
		<group id="165" type="span" parent="168" relname="span"/>
		<group id="166" type="span" parent="167" relname="sequence"/>
		<group id="167" type="multinuc" parent="173" relname="span"/>
		<group id="168" type="span" parent="169" relname="comparison"/>
		<group id="169" type="multinuc" parent="172" relname="span"/>
		<group id="170" type="span" parent="169" relname="comparison"/>
		<group id="171" type="span" parent="196" relname="span"/>
		<group id="172" type="span" parent="171" relname="span"/>
		<group id="173" type="span" parent="174" relname="span"/>
		<group id="174" type="span" />
		<group id="175" type="span" parent="178" relname="joint"/>
		<group id="176" type="span" parent="177" relname="span"/>
		<group id="177" type="span" parent="178" relname="joint"/>
		<group id="178" type="multinuc" parent="179" relname="span"/>
		<group id="179" type="span" parent="180" relname="span"/>
		<group id="180" type="span" />
		<group id="181" type="multinuc" parent="182" relname="span"/>
		<group id="182" type="span" parent="183" relname="span"/>
		<group id="183" type="span" parent="186" relname="joint"/>
		<group id="184" type="multinuc" parent="186" relname="joint"/>
		<group id="185" type="multinuc" parent="184" relname="contrast"/>
		<group id="186" type="multinuc" parent="74" relname="evaluation"/>
		<group id="187" type="span" parent="188" relname="same-unit"/>
		<group id="188" type="multinuc" parent="185" relname="joint"/>
		<group id="189" type="span" parent="198" relname="span"/>
		<group id="190" type="multinuc" parent="191" relname="contrast"/>
		<group id="191" type="multinuc" parent="192" relname="span"/>
		<group id="192" type="span" parent="193" relname="span"/>
		<group id="193" type="span" parent="189" relname="evaluation"/>
		<group id="194" type="span" parent="167" relname="sequence"/>
		<group id="195" type="span" parent="196" relname="evaluation"/>
		<group id="196" type="span" parent="197" relname="span"/>
		<group id="197" type="span" parent="167" relname="sequence"/>
		<group id="198" type="span" parent="214" relname="elaboration"/>
		<group id="199" type="span" parent="202" relname="contrast"/>
		<group id="200" type="span" parent="94" relname="evaluation"/>
		<group id="201" type="span" parent="202" relname="contrast"/>
		<group id="202" type="multinuc" parent="204" relname="span"/>
		<group id="203" type="span" parent="204" relname="concession"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="206" relname="span"/>
		<group id="206" type="span" parent="211" relname="span"/>
		<group id="207" type="multinuc" parent="99" relname="cause"/>
		<group id="208" type="span" parent="205" relname="evaluation"/>
		<group id="209" type="multinuc" parent="210" relname="joint"/>
		<group id="210" type="multinuc" parent="206" relname="background"/>
		<group id="211" type="span" />
		<group id="212" type="multinuc" parent="139" relname="contrast"/>
		<group id="213" type="multinuc" parent="214" relname="span"/>
		<group id="214" type="span" parent="194" relname="span"/>
		<group id="215" type="span" parent="114" relname="cause"/>
	</body>
</rst>