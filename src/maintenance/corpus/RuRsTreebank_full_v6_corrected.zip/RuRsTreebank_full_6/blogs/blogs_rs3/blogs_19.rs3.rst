<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://odin-moy-den.livejournal.com/2211666.html</segment>
		<segment id="2" >Один день в Вене с Питером Брейгелем</segment>
		<segment id="3" parent="298" relname="span">Добрый день, меня зовут Катерина,</segment>
		<segment id="4" parent="294" relname="joint">я живу в Иерусалиме</segment>
		<segment id="5" parent="294" relname="joint">и работаю старшей (и единственной) медицинской сестрой в маленькой районной поликлинике.</segment>
		<segment id="6" parent="286" relname="span">Но в сегодняшнем моем дне 24 ноября 2018 года не будет ни Иерусалима,</segment>
		<segment id="7" parent="6" relname="background">где прошла бОльшая часть моей 48-летней жизни,</segment>
		<segment id="8" parent="287" relname="same-unit">ни работы.</segment>
		<segment id="9" parent="288" relname="joint">В этом дне также не появятся другие составляющие моей повседневной реальности: семья, друзья и даже кошечка.</segment>
		<segment id="10" parent="290" relname="joint">Этот день я проведу одна,</segment>
		<segment id="11" parent="289" relname="span">и пройдет он в столице Австрии, Вене,</segment>
		<segment id="12" parent="11" relname="purpose">куда я приехала на выставку Питера Брейгеля.</segment>
		<segment id="13" parent="292" relname="span">Под катом 33 телефонофото.</segment>
		<segment id="14" parent="293" relname="span">Прошу прощения за качество,</segment>
		<segment id="15" parent="14" relname="cause">но я прилетела всего на полтора дня, без багажа и нормального фотоаппарата.</segment>
		<segment id="16" parent="303" relname="span">Просыпаюсь по будильнику.</segment>
		<segment id="17" parent="302" relname="contrast">Эх, как же нам, совам, тяжко живется в этом несовершенном мире с его ранними подъемами!</segment>
		<segment id="18" parent="301" relname="span">Но ничего не поделаешь,</segment>
		<segment id="19" parent="299" relname="contrast">я прилетела в Вену вчера утром,</segment>
		<segment id="20" parent="299" relname="contrast">а сегодня вечером уже улетаю.</segment>
		<segment id="21" parent="300" relname="span">Так что каждый час на счету.</segment>
		<segment id="22" parent="303" relname="elaboration">IMG На улице за окном еще не рассвело толком, горит фонарь. IMG</segment>
		<segment id="23" parent="310" relname="preparation">Из зеркала напротив кровати на меня кто-то злобно таращится.</segment>
		<segment id="24" parent="304" relname="joint">«Кто Вы, женщина? – спрашиваю я строго,</segment>
		<segment id="25" parent="304" relname="joint">- что Вы себе позволяете</segment>
		<segment id="26" parent="304" relname="joint">и что прикажете с Вами делать?».</segment>
		<segment id="27" parent="307" relname="joint">Вздохнув, начинаю реанимационные мероприятия: душ, умывание, немного боевой раскраски.</segment>
		<segment id="28" parent="305" relname="span">Заодно мажу шею кремом с вольтареном,</segment>
		<segment id="29" parent="28" relname="cause">а то после вчерашнего сна в самолетном кресле ее слегка заклинило .</segment>
		<segment id="30" parent="309" relname="elaboration">IMG</segment>
		<segment id="31" parent="523" relname="preparation">Потом одеваюсь.</segment>
		<segment id="32" parent="33" relname="condition">Что бы я на себя ни надела,</segment>
		<segment id="33" parent="313" relname="span">перед выходом это придется чистить.</segment>
		<segment id="34" parent="315" relname="span">Ведь дома у меня проживает абсолютно белое кошИчкО, но с черным хвостом и серой маской на морде, как у енота.</segment>
		<segment id="35" parent="543" relname="span">Такой оригинальный раскрас</segment>
		<segment id="36" parent="35" relname="purpose">позволяет ей злонамеренно линять на светлые вещи черными волосьями, а на темные – белыми.</segment>
		<segment id="37" parent="316" relname="joint">Что ж, липкая лента и щетки – наше все,</segment>
		<segment id="38" parent="316" relname="joint">а кошачий пух и мех – не грязь, а аксессуар.</segment>
		<segment id="39" parent="522" relname="elaboration">IMG</segment>
		<segment id="40" parent="320" relname="span">Ну вот, я готова спускаться на завтрак.Тайм-чек.</segment>
		<segment id="41" parent="40" relname="elaboration">IMG</segment>
		<segment id="42" parent="317" relname="contrast">Пытаюсь сфотографировать себя в зеркале,</segment>
		<segment id="43" parent="318" relname="span">но его извивы и формы моего тела явно находятся в противофазе.</segment>
		<segment id="44" parent="319" relname="span">Уж как получилось, извините.</segment>
		<segment id="45" parent="44" relname="elaboration">IMG</segment>
		<segment id="46" parent="325" relname="preparation">В холле отеля фотографируюсь с симпатичным молодым человеком.</segment>
		<segment id="47" parent="322" relname="contrast">Личность его установить не удалось,</segment>
		<segment id="48" parent="323" relname="span">но мне почему-то кажется, что его зовут Теодор.</segment>
		<segment id="49" parent="324" relname="span">Как-то соответствует он этому имени.</segment>
		<segment id="50" parent="49" relname="elaboration">IMG</segment>
		<segment id="51" parent="332" relname="preparation">Завтрак.</segment>
		<segment id="52" parent="327" relname="span">Я не умею делать селфи</segment>
		<segment id="53" parent="52" relname="evaluation">(вы в этом еще убедитесь)</segment>
		<segment id="54" parent="328" relname="joint">и не умею завтракать.</segment>
		<segment id="55" parent="329" relname="span">Поэтому немного хлопьев и чашка чая.</segment>
		<segment id="56" parent="55" relname="elaboration">Больше утром я в себя запихнуть не могу.</segment>
		<segment id="57" parent="330" relname="elaboration">IMG</segment>
		<segment id="58" parent="333" relname="sequence">Собираю свой мини-чемодан,</segment>
		<segment id="59" parent="333" relname="sequence">оставляю его в отеле,</segment>
		<segment id="60" parent="528" relname="span">выхожу в город.</segment>
		<segment id="61" parent="334" relname="span">Рядом с моим отелем находится знаменитое венское кафе «Шперль»,</segment>
		<segment id="62" parent="61" relname="background">где я вчера обедала сразу после приезда.</segment>
		<segment id="63" parent="334" relname="evaluation">М-м-м, какой у них запеченный камамбер с грушей и ветчиной!..</segment>
		<segment id="64" parent="525" relname="evaluation">Надеюсь, что успею сегодня туда забежать.</segment>
		<segment id="65" parent="335" relname="elaboration">IMG</segment>
		<segment id="66" parent="336" relname="span">Тем более что альтернативный вариант на другой стороне улицы меня совсем не прельщает своим названием))))</segment>
		<segment id="67" parent="66" relname="elaboration">IMG</segment>
		<segment id="68" parent="337" relname="span">Встречаю воинственно настроенное жЫвотное</segment>
		<segment id="69" parent="68" relname="elaboration">IMG</segment>
		<segment id="70" parent="338" relname="joint">Перед музеем у меня остается немного времени,</segment>
		<segment id="71" parent="338" relname="joint">и я решаю порыскать по окрестным магазинам на предмет какой-нибудь обувки.</segment>
		<segment id="72" parent="345" relname="span">Вокруг Вена понемногу готовится к Рождеству.</segment>
		<segment id="73" parent="341" relname="span">Вчера я была на Штефанплац,</segment>
		<segment id="74" parent="340" relname="joint">там уже работает рождественский базар,</segment>
		<segment id="75" parent="340" relname="joint">глинтвейн разливают,</segment>
		<segment id="76" parent="340" relname="joint">пряниками кормят…</segment>
		<segment id="77" parent="342" relname="elaboration">IMG</segment>
		<segment id="78" parent="344" relname="span">Тайм-чек</segment>
		<segment id="79" parent="78" relname="elaboration">IMG</segment>
		<segment id="80" parent="346" relname="sequence">Обувка найдена,</segment>
		<segment id="81" parent="346" relname="sequence">оплачена</segment>
		<segment id="82" parent="346" relname="sequence">и оставлена в магазине.</segment>
		<segment id="83" parent="529" relname="sequence">Вернусь за ней после.</segment>
		<segment id="84" parent="347" relname="elaboration">IMG</segment>
		<segment id="85" parent="557" relname="span">Пора выдвигаться в сторону выставки.</segment>
		<segment id="86" parent="85" relname="elaboration">Скажу о ней буквально пару слов.</segment>
		<segment id="87" parent="356" relname="joint">Выставка приурочена к 450-летию со дня смерти Питера Брейгеля-старшего.</segment>
		<segment id="88" parent="352" relname="background">И помимо собрания, которое постоянно хранится в Венском Музее истории искусств,</segment>
		<segment id="89" parent="90" relname="purpose">на ней можно увидеть полотна,</segment>
		<segment id="90" parent="352" relname="span">специально доставленные из других музеев.</segment>
		<segment id="91" parent="355" relname="span">Это по-настоящему уникальное событие,</segment>
		<segment id="92" parent="354" relname="span">ведь речь идет о бесценных шедеврах,</segment>
		<segment id="93" parent="92" relname="elaboration">а их крайне редко и неохотно перемещают с места на место, из страны в страну.</segment>
		<segment id="94" parent="532" relname="elaboration">IMG</segment>
		<segment id="95" parent="357" relname="contrast">Захожу в музей,</segment>
		<segment id="96" parent="358" relname="joint">но решаю слегка перезагрузиться после забега по магазинам,</segment>
		<segment id="97" parent="358" relname="joint">передохнуть</segment>
		<segment id="98" parent="358" relname="joint">и подарить организму сразу много очень вкусных калорий. IMG</segment>
		<segment id="99" parent="359" relname="background">Интерьер музейного кафе располагает к мыслям о вечных ценностях... IMG</segment>
		<segment id="100" parent="364" relname="contrast">И вот я на выставке.</segment>
		<segment id="101" parent="363" relname="span">Не буду утомлять вас фотографиями всех картин.</segment>
		<segment id="102" parent="362" relname="same-unit">Тем более что мои любительские снимки не могут сравниться ни с качественными репродукциями,</segment>
		<segment id="103" parent="361" relname="span">ни с онлайн-каталогом,</segment>
		<segment id="104" parent="103" relname="background">который венский KHM недавно выложил в сеть.</segment>
		<segment id="105" parent="373" relname="preparation">Покажу две своих самых любимых .</segment>
		<segment id="106" parent="372" relname="span">Первая – "Поклонение волхвов в снегу".</segment>
		<segment id="107" parent="365" relname="joint">Эта картина, как и многие другие работы Брейгеля, иллюстрирует идею, что главное в жизни всегда неявно.</segment>
		<segment id="108" parent="365" relname="joint">Оно обычно скрыто за множеством повседневных событий и явлений.</segment>
		<segment id="109" parent="366" relname="span">На полотне от снега рябит в глазах</segment>
		<segment id="110" parent="109" relname="evaluation">(как? как Брейгелю удалось передать это неуловимое мельтешение снежных хлопьев?!),</segment>
		<segment id="111" parent="367" relname="joint">и снег, подобно полупрозрачному занавесу, маскирует происходящее.</segment>
		<segment id="112" parent="368" relname="joint">А присутствующие люди суетятся,</segment>
		<segment id="113" parent="368" relname="joint">толпятся,</segment>
		<segment id="114" parent="368" relname="joint">заслоняют своими неуклюжими телами истинное Чудо.</segment>
		<segment id="115" parent="370" relname="elaboration">IMG</segment>
		<segment id="116" parent="536" relname="preparation">Вторая картина, тоже зимняя, «Охотники на снегу».</segment>
		<segment id="117" parent="118" relname="evaluation">Трудно выразить словами,</segment>
		<segment id="118" parent="375" relname="span">что она значит для меня.</segment>
		<segment id="119" parent="555" relname="contrast">Попробую изложить кратко,</segment>
		<segment id="120" parent="377" relname="span">но смело пропускайте это лирическое отступление ,</segment>
		<segment id="121" parent="120" relname="condition">если вам неинтересно.</segment>
		<segment id="122" parent="123" relname="background">В общем, когда я была маленькой,</segment>
		<segment id="123" parent="378" relname="span">я иногда любила поболеть,</segment>
		<segment id="124" parent="380" relname="span">потому что радовалась возможности не ходить в детский сад.</segment>
		<segment id="125" parent="124" relname="cause">Ну не прельщали меня пение хором и манная каша с комками на завтрак.</segment>
		<segment id="126" parent="381" relname="joint">А когда болеешь</segment>
		<segment id="127" parent="381" relname="joint">и в садик не идешь,</segment>
		<segment id="128" parent="383" relname="joint">можно валяться в кровати,</segment>
		<segment id="129" parent="383" relname="joint">читать толстые книжки со сказками</segment>
		<segment id="130" parent="383" relname="joint">и рассматривать открытки.</segment>
		<segment id="131" parent="132" relname="background">Помните, когда-то было принято посылать друг другу поздравления с Днем рождения, с Новым годом и 8 марта?</segment>
		<segment id="132" parent="385" relname="span">Таких открыток у нас в семье скопилась огромная пачка.</segment>
		<segment id="133" parent="386" relname="joint">Вот во время болезни,</segment>
		<segment id="134" parent="386" relname="joint">лежа в постели,</segment>
		<segment id="135" parent="387" relname="span">я их перебирала:</segment>
		<segment id="136" parent="388" relname="joint">рассматривала картинки,</segment>
		<segment id="137" parent="389" relname="span">с трудом разбирала непонятный взрослый почерк,</segment>
		<segment id="138" parent="137" relname="elaboration">которым на обороте были написаны пожелания счастья и здоровья.</segment>
		<segment id="139" parent="415" relname="span">На одной открытке была напечатана репродукция «Охотников на снегу».</segment>
		<segment id="140" parent="397" relname="joint">Глядя на нее, я словно попадала в сказку,</segment>
		<segment id="141" parent="397" relname="joint">где все всегда хорошо кончается.</segment>
		<segment id="142" parent="398" relname="sequence">Я представляла себе, что уставшие и озябшие охотники вот-вот спустятся с холма в деревню,</segment>
		<segment id="143" parent="398" relname="sequence">согреются,</segment>
		<segment id="144" parent="398" relname="sequence">поедят сами</segment>
		<segment id="145" parent="398" relname="sequence">и накормят изголодавшихся собак.</segment>
		<segment id="146" parent="399" relname="sequence">Детей, катающихся на коньках, позовут с улицы в дом,</segment>
		<segment id="147" parent="399" relname="sequence">переоденут в сухую одежду,</segment>
		<segment id="148" parent="399" relname="sequence">посадят за стол,</segment>
		<segment id="149" parent="399" relname="sequence">а потом уложат спать.</segment>
		<segment id="150" parent="400" relname="contrast">Короткий зимний день кончится,</segment>
		<segment id="151" parent="400" relname="contrast">но завтра снова взойдет солнце.</segment>
		<segment id="152" parent="402" relname="evaluation">Мне, маленькой, очень нравилось,</segment>
		<segment id="153" parent="401" relname="joint">что мир на этой картине выглядел предсказуемым,</segment>
		<segment id="154" parent="401" relname="joint">понятным</segment>
		<segment id="155" parent="401" relname="joint">и каким-то правильным.</segment>
		<segment id="156" parent="405" relname="cause">В нем все идет своим чередом,</segment>
		<segment id="157" parent="404" relname="joint">нужно только запастись терпением</segment>
		<segment id="158" parent="409" relname="span">и подождать:</segment>
		<segment id="159" parent="407" relname="sequence">охотники доберутся до дома,</segment>
		<segment id="160" parent="407" relname="sequence">собаки улягутся у очага,</segment>
		<segment id="161" parent="162" relname="cause">я скоро вырасту</segment>
		<segment id="162" parent="408" relname="span">и никогда больше не пойду в детский сад.</segment>
		<segment id="163" parent="521" relname="contrast">И само собой, пожелания счастья, написанные на открытках, непременно сбудутся.</segment>
		<segment id="164" parent="521" relname="contrast">А как же иначе?</segment>
		<segment id="165" parent="409" relname="elaboration">IMG</segment>
		<segment id="166" parent="167" relname="condition">При своем заметном сарказме и изрядной доле мизантропии,</segment>
		<segment id="167" parent="417" relname="span">Брейгель, как мне кажется, был очень тонко чувствующим человеком</segment>
		<segment id="168" parent="416" relname="joint">и ценил красоту обыденных предметов, магию смены времен года, величие природы.</segment>
		<segment id="169" parent="418" relname="span">Чем иначе можно объяснить то перламутровое свечение и ту нежную ауру,</segment>
		<segment id="170" parent="169" relname="elaboration">которые исходят от его картин и которые, увы, бессильны передать репродукции (а уж мои телефонофото и подавно)?</segment>
		<segment id="171" parent="419" relname="contrast">Но остановите меня,</segment>
		<segment id="172" parent="419" relname="contrast">я заболталась.</segment>
		<segment id="173" parent="423" relname="sequence">Хожу из зала в зал,</segment>
		<segment id="174" parent="428" relname="span">снова и снова возвращаюсь к "Охотникам на снегу".</segment>
		<segment id="175" parent="176" relname="cause">Ну что ж, мечта моя увидеть картины Брейгеля сбылась.</segment>
		<segment id="176" parent="424" relname="span">Можно ехать назад.</segment>
		<segment id="177" parent="425" relname="joint">Еще до отлета в Вену я решила, что на другие экспонаты Музея смотреть не буду,</segment>
		<segment id="178" parent="425" relname="joint">и этого плана придерживаюсь.</segment>
		<segment id="179" parent="427" relname="joint">Правда, каюсь, вчера не удержалась</segment>
		<segment id="180" parent="427" relname="joint">и сходила полюбоваться коллекцией Климта в Бельведере.</segment>
		<segment id="181" parent="429" relname="span">Направляюсь к выходу.Еще</segment>
		<segment id="182" parent="181" relname="elaboration">одна, последняя и милая деталь с выставки – обувь соответствующей эпохи. IMG</segment>
		<segment id="183" parent="184" relname="cause">А в спину мне внимательно смотрят.</segment>
		<segment id="184" parent="430" relname="span">Приходится остановиться.</segment>
		<segment id="185" parent="430" relname="evaluation">До свидания, обезьянки, не грустите. IMG</segment>
		<segment id="186" parent="433" relname="sequence">Покидаю музей,</segment>
		<segment id="187" parent="433" relname="sequence">забегаю в соседний магазин за отложенными покупками</segment>
		<segment id="188" parent="434" relname="span">и решаю смотаться в универмаг Steffl,</segment>
		<segment id="189" parent="188" relname="purpose">чтобы получить возврат налога.</segment>
		<segment id="190" parent="539" relname="sequence">Спускаюсь в метро</segment>
		<segment id="191" parent="436" relname="span">и общаюсь с автоматом по продаже билетов.</segment>
		<segment id="192" parent="193" relname="attribution">Как там Высоцкий пел:</segment>
		<segment id="193" parent="437" relname="span">"У автомата, в нем ума палата, стою я, улыбаясь глуповато..."</segment>
		<segment id="194" parent="436" relname="evaluation">Нам с автоматом все-таки удалось достичь взаимопонимания,</segment>
		<segment id="195" parent="435" relname="sequence">и на радостях я заодно покупаю билет на электричку до аэропорта.</segment>
		<segment id="196" parent="541" relname="elaboration">IMG</segment>
		<segment id="197" parent="444" relname="sequence">Проезжаю пару остановок на метро,</segment>
		<segment id="198" parent="439" relname="span">поднимаюсь на Штефанплац,</segment>
		<segment id="199" parent="443" relname="span">прямо рядом с собором Святого Стефана.</segment>
		<segment id="200" parent="440" relname="joint">Вчера я заходила внутрь,</segment>
		<segment id="201" parent="440" relname="joint">как раз шла месса,</segment>
		<segment id="202" parent="440" relname="joint">удалось послушать пение и органную музыку.</segment>
		<segment id="203" parent="441" relname="elaboration">IMG</segment>
		<segment id="204" parent="446" relname="span">По дороге в Steffl сталкиваюсь с какой-то демонстрацией.</segment>
		<segment id="205" parent="445" relname="contrast">Вроде как защищают женщин и детей,</segment>
		<segment id="206" parent="445" relname="contrast">но от чего?</segment>
		<segment id="207" parent="446" relname="elaboration">IMG</segment>
		<segment id="208" parent="448" relname="contrast">Выражаю свою солидарность.</segment>
		<segment id="209" parent="448" relname="contrast">Интересно, с чем?</segment>
		<segment id="210" parent="449" relname="elaboration">IMG</segment>
		<segment id="211" parent="451" relname="contrast">Еду в отель,</segment>
		<segment id="212" parent="451" relname="contrast">но организм требует топлива.</segment>
		<segment id="213" parent="452" relname="span">Так что захожу в «Шперль».</segment>
		<segment id="214" parent="453" relname="same-unit">Прошу официанта принести мне шницель, а к нему – стакан воды</segment>
		<segment id="215" parent="454" relname="span">и сразу же счет,</segment>
		<segment id="216" parent="215" relname="cause">поскольку время начинает поджимать.</segment>
		<segment id="217" parent="455" relname="contrast">На лице официанта явно читается «мадам, вы не в Макдоналдсе,</segment>
		<segment id="218" parent="455" relname="contrast">у нас едят долго и вдумчиво».</segment>
		<segment id="219" parent="458" relname="joint">В «Шперле» никуда не торопятся,</segment>
		<segment id="220" parent="458" relname="joint">пытаются делать вид, что безумный 21-ый век не наступил.</segment>
		<segment id="221" parent="461" relname="span">Да и с 20-ым веком, по-моему, еще не до конца свыклись..</segment>
		<segment id="222" parent="460" relname="joint">Здесь посетители до сих пор читают бумажные газеты.</segment>
		<segment id="223" parent="460" relname="joint">А для удобства подпирают их специальными смешными подставочками.</segment>
		<segment id="224" parent="462" relname="evaluation">Венские традиции...</segment>
		<segment id="225" parent="463" relname="elaboration">IMG</segment>
		<segment id="226" parent="466" relname="sequence">Но шницель мне все же приносят,</segment>
		<segment id="227" parent="466" relname="sequence">я отрезаю от него кусок</segment>
		<segment id="228" parent="466" relname="sequence">и лишь потом вспоминаю, что еду надо запечатлеть.</segment>
		<segment id="229" parent="466" relname="sequence">Далее на 15 минут мир вокруг перестает существовать.</segment>
		<segment id="230" parent="467" relname="elaboration">IMG</segment>
		<segment id="231" parent="475" relname="preparation">Телефон делает «плим-плим».</segment>
		<segment id="232" parent="542" relname="sequence">Сначала мама справляется, не обижают ли меня в Вене.</segment>
		<segment id="233" parent="470" relname="joint">Потом Луна Моей Жизни интересуется, как мое самочувствие с настроением</segment>
		<segment id="234" parent="470" relname="joint">и не собираюсь ли я в обратный путь.</segment>
		<segment id="235" parent="471" relname="contrast">Решаю отправить ему довольное фото,</segment>
		<segment id="236" parent="472" relname="span">но выходит почему-то грустно.</segment>
		<segment id="237" parent="236" relname="evaluation">Не мастер я селфи, увы…</segment>
		<segment id="238" parent="473" relname="elaboration">IMG</segment>
		<segment id="239" parent="544" relname="span">За спиной у меня – огромное старинное зеркало. И фортепьяно.</segment>
		<segment id="240" parent="239" relname="elaboration">Пианист играет легкий джаз.</segment>
		<segment id="241" parent="481" relname="contrast">Не хочется уходить…</segment>
		<segment id="242" parent="481" relname="contrast">Но надо.</segment>
		<segment id="243" parent="545" relname="evaluation">IMG</segment>
		<segment id="244" parent="484" relname="joint">Отель-чемодан-метро.</segment>
		<segment id="245" parent="484" relname="joint">Тайм-чек. IMG</segment>
		<segment id="246" parent="491" relname="sequence">Тут батарейка в моем телефоне окончательно садится.</segment>
		<segment id="247" parent="489" relname="contrast">Позже я ее немного подзарядила в электричке по дороге в аэропорт,</segment>
		<segment id="248" parent="488" relname="same-unit">но</segment>
		<segment id="249" parent="250" relname="purpose">для съемки</segment>
		<segment id="250" parent="487" relname="span">этого мало.</segment>
		<segment id="251" parent="490" relname="span">Впрочем, в аэропорту все прошло обыденно,</segment>
		<segment id="252" parent="251" relname="condition">если не считать паспортного контроля.</segment>
		<segment id="253" parent="508" relname="span">Пограничник обнаружил, что последняя страница в моем паспорте слегка – ну то есть совсем слегка – помята,</segment>
		<segment id="254" parent="494" relname="sequence">и грозным голосом спросил вас ист, собственно, дас.</segment>
		<segment id="255" parent="553" relname="attribution">Я ему чисто по-человечески попыталась объяснить,</segment>
		<segment id="256" parent="495" relname="evaluation">дескать, энтшульдиген зи,</segment>
		<segment id="257" parent="495" relname="span">помялся аусвайс,</segment>
		<segment id="258" parent="257" relname="evaluation">дело житейское.</segment>
		<segment id="259" parent="498" relname="cause">Но в ответ он разразился такой гневной тирадой,</segment>
		<segment id="260" parent="498" relname="span">что я всерьез принялась подсчитывать,</segment>
		<segment id="261" parent="497" relname="span">сколько лет мне исполнится,</segment>
		<segment id="262" parent="500" relname="span">когда я выйду на свободу,</segment>
		<segment id="263" parent="262" relname="condition">отбарабанив положенный срок в австрийской тюрьме.</segment>
		<segment id="264" parent="502" relname="span">Всех деталей я не поняла,</segment>
		<segment id="265" parent="501" relname="joint">поскольку немецким почти не владею,</segment>
		<segment id="266" parent="501" relname="joint">а на английский язык свои угрозы пограничник переводить поленился.</segment>
		<segment id="267" parent="504" relname="sequence">В итоге он закончил меня отчитывать,</segment>
		<segment id="268" parent="504" relname="sequence">шлепнул печать</segment>
		<segment id="269" parent="504" relname="sequence">и махнул рукой, мол, проваливай, несознательная фрау.</segment>
		<segment id="270" parent="505" relname="sequence">Уф, перевожу дыхание,</segment>
		<segment id="271" parent="505" relname="sequence">ищу на табло свой рейс на Тель-Авив. IMG</segment>
		<segment id="272" parent="505" relname="sequence">Кофе и десерт на дорожку IMG</segment>
		<segment id="273" parent="505" relname="sequence">Нахожу свой выход.</segment>
		<segment id="274" parent="506" relname="contrast">Прощай, Вена, прощай Брейгель! IMG</segment>
		<segment id="275" parent="517" relname="span">Но не тут-то было.</segment>
		<segment id="276" parent="510" relname="span">Мы просидели в самолете больше часа,</segment>
		<segment id="277" parent="276" relname="cause">поскольку на борту обнаружили чей-то бесхозный чемодан.</segment>
		<segment id="278" parent="511" relname="sequence">Поднялась суматоха,</segment>
		<segment id="279" parent="511" relname="sequence">весь багаж переворошили,</segment>
		<segment id="280" parent="512" relname="contrast">подозрительный чемодан выгнали вон,</segment>
		<segment id="281" parent="512" relname="contrast">но в результате рейс наш вылетел с немалым опозданием.</segment>
		<segment id="282" parent="513" relname="sequence">А потом я заснула</segment>
		<segment id="283" parent="513" relname="sequence">и проснулась уже в Израиле.</segment>
		<segment id="284" parent="513" relname="sequence">Наступил новый день, в котором была дорога в Иерусалим, семья и работа…</segment>
		<segment id="285" parent="514" relname="evaluation">Спасибо, что дочитали до конца.</segment>
		<group id="286" type="span" parent="287" relname="same-unit"/>
		<group id="287" type="multinuc" parent="297" relname="span"/>
		<group id="288" type="multinuc" parent="297" relname="elaboration"/>
		<group id="289" type="span" parent="291" relname="span"/>
		<group id="290" type="multinuc" parent="288" relname="joint"/>
		<group id="291" type="span" parent="290" relname="joint"/>
		<group id="292" type="span" parent="289" relname="elaboration"/>
		<group id="293" type="span" parent="13" relname="evaluation"/>
		<group id="294" type="multinuc" parent="3" relname="elaboration"/>
		<group id="295" type="multinuc" />
		<group id="296" type="span" parent="295" relname="contrast"/>
		<group id="297" type="span" parent="296" relname="span"/>
		<group id="298" type="span" parent="295" relname="contrast"/>
		<group id="299" type="multinuc" parent="21" relname="cause"/>
		<group id="300" type="span" parent="18" relname="cause"/>
		<group id="301" type="span" parent="302" relname="contrast"/>
		<group id="302" type="multinuc" parent="16" relname="evaluation"/>
		<group id="303" type="span" parent="306" relname="span"/>
		<group id="304" type="multinuc" parent="310" relname="span"/>
		<group id="305" type="span" parent="307" relname="joint"/>
		<group id="306" type="span" />
		<group id="307" type="multinuc" parent="308" relname="span"/>
		<group id="308" type="span" parent="309" relname="span"/>
		<group id="309" type="span" parent="312" relname="span"/>
		<group id="310" type="span" parent="311" relname="span"/>
		<group id="311" type="span" parent="308" relname="solutionhood"/>
		<group id="312" type="span" />
		<group id="313" type="span" parent="314" relname="span"/>
		<group id="314" type="span" parent="522" relname="span"/>
		<group id="315" type="span" parent="313" relname="cause"/>
		<group id="316" type="multinuc" parent="314" relname="evaluation"/>
		<group id="317" type="multinuc" parent="321" relname="sequence"/>
		<group id="318" type="span" parent="317" relname="contrast"/>
		<group id="319" type="span" parent="43" relname="evaluation"/>
		<group id="320" type="span" parent="321" relname="sequence"/>
		<group id="321" type="multinuc" />
		<group id="322" type="multinuc" parent="325" relname="span"/>
		<group id="323" type="span" parent="322" relname="contrast"/>
		<group id="324" type="span" parent="48" relname="evaluation"/>
		<group id="325" type="span" parent="326" relname="span"/>
		<group id="326" type="span" parent="321" relname="sequence"/>
		<group id="327" type="span" parent="328" relname="joint"/>
		<group id="328" type="multinuc" parent="329" relname="cause"/>
		<group id="329" type="span" parent="330" relname="span"/>
		<group id="330" type="span" parent="332" relname="span"/>
		<group id="331" type="span" />
		<group id="332" type="span" parent="331" relname="span"/>
		<group id="333" type="multinuc" parent="339" relname="sequence"/>
		<group id="334" type="span" parent="525" relname="span"/>
		<group id="335" type="span" parent="527" relname="span"/>
		<group id="336" type="span" parent="526" relname="contrast"/>
		<group id="337" type="span" parent="339" relname="sequence"/>
		<group id="338" type="multinuc" parent="350" relname="preparation"/>
		<group id="339" type="multinuc" />
		<group id="340" type="multinuc" parent="342" relname="span"/>
		<group id="341" type="span" parent="72" relname="elaboration"/>
		<group id="342" type="span" parent="343" relname="span"/>
		<group id="343" type="span" parent="73" relname="elaboration"/>
		<group id="344" type="span" parent="349" relname="sequence"/>
		<group id="345" type="span" parent="349" relname="sequence"/>
		<group id="346" type="multinuc" parent="529" relname="sequence"/>
		<group id="347" type="span" parent="348" relname="span"/>
		<group id="348" type="span" parent="349" relname="sequence"/>
		<group id="349" type="multinuc" parent="350" relname="span"/>
		<group id="350" type="span" parent="351" relname="span"/>
		<group id="351" type="span" />
		<group id="352" type="span" parent="353" relname="span"/>
		<group id="353" type="span" parent="356" relname="joint"/>
		<group id="354" type="span" parent="91" relname="cause"/>
		<group id="355" type="span" parent="531" relname="evaluation"/>
		<group id="356" type="multinuc" parent="531" relname="span"/>
		<group id="357" type="multinuc" parent="359" relname="span"/>
		<group id="358" type="multinuc" parent="357" relname="contrast"/>
		<group id="359" type="span" parent="360" relname="span"/>
		<group id="360" type="span" parent="547" relname="sequence"/>
		<group id="361" type="span" parent="362" relname="same-unit"/>
		<group id="362" type="multinuc" parent="101" relname="elaboration"/>
		<group id="363" type="span" parent="364" relname="contrast"/>
		<group id="364" type="multinuc" parent="547" relname="sequence"/>
		<group id="365" type="multinuc" parent="106" relname="evaluation"/>
		<group id="366" type="span" parent="367" relname="joint"/>
		<group id="367" type="multinuc" parent="369" relname="contrast"/>
		<group id="368" type="multinuc" parent="369" relname="contrast"/>
		<group id="369" type="multinuc" parent="370" relname="span"/>
		<group id="370" type="span" parent="371" relname="span"/>
		<group id="371" type="span" parent="372" relname="elaboration"/>
		<group id="372" type="span" parent="373" relname="span"/>
		<group id="373" type="span" parent="374" relname="span"/>
		<group id="374" type="span" />
		<group id="375" type="span" parent="556" relname="span"/>
		<group id="377" type="span" parent="555" relname="contrast"/>
		<group id="378" type="span" parent="379" relname="span"/>
		<group id="379" type="span" parent="392" relname="span"/>
		<group id="380" type="span" parent="378" relname="cause"/>
		<group id="381" type="multinuc" parent="384" relname="condition"/>
		<group id="382" type="span" parent="535" relname="span"/>
		<group id="383" type="multinuc" parent="384" relname="span"/>
		<group id="384" type="span" parent="382" relname="span"/>
		<group id="385" type="span" parent="391" relname="span"/>
		<group id="386" type="multinuc" parent="135" relname="condition"/>
		<group id="387" type="span" parent="390" relname="span"/>
		<group id="388" type="multinuc" parent="387" relname="elaboration"/>
		<group id="389" type="span" parent="388" relname="joint"/>
		<group id="390" type="span" parent="385" relname="elaboration"/>
		<group id="391" type="span" parent="382" relname="elaboration"/>
		<group id="392" type="span" parent="396" relname="span"/>
		<group id="396" type="span" parent="536" relname="span"/>
		<group id="397" type="multinuc" parent="139" relname="evaluation"/>
		<group id="398" type="multinuc" parent="411" relname="joint"/>
		<group id="399" type="multinuc" parent="411" relname="joint"/>
		<group id="400" type="multinuc" parent="411" relname="joint"/>
		<group id="401" type="multinuc" parent="402" relname="span"/>
		<group id="402" type="span" parent="403" relname="span"/>
		<group id="403" type="span" parent="412" relname="evaluation"/>
		<group id="404" type="multinuc" parent="405" relname="span"/>
		<group id="405" type="span" parent="406" relname="span"/>
		<group id="406" type="span" parent="421" relname="solutionhood"/>
		<group id="407" type="multinuc" parent="158" relname="elaboration"/>
		<group id="408" type="span" parent="407" relname="sequence"/>
		<group id="409" type="span" parent="410" relname="span"/>
		<group id="410" type="span" parent="404" relname="joint"/>
		<group id="411" type="multinuc" parent="414" relname="span"/>
		<group id="412" type="span" parent="413" relname="span"/>
		<group id="413" type="span" />
		<group id="414" type="span" parent="412" relname="span"/>
		<group id="415" type="span" parent="414" relname="preparation"/>
		<group id="416" type="multinuc" parent="418" relname="cause"/>
		<group id="417" type="span" parent="416" relname="joint"/>
		<group id="418" type="span" parent="420" relname="span"/>
		<group id="419" type="multinuc" parent="420" relname="evaluation"/>
		<group id="420" type="span" parent="421" relname="span"/>
		<group id="421" type="span" parent="422" relname="span"/>
		<group id="422" type="span" />
		<group id="423" type="multinuc" parent="538" relname="sequence"/>
		<group id="424" type="span" parent="537" relname="span"/>
		<group id="425" type="multinuc" parent="426" relname="contrast"/>
		<group id="426" type="multinuc" parent="424" relname="background"/>
		<group id="427" type="multinuc" parent="426" relname="contrast"/>
		<group id="428" type="span" parent="423" relname="sequence"/>
		<group id="429" type="span" parent="432" relname="contrast"/>
		<group id="430" type="span" parent="431" relname="span"/>
		<group id="431" type="span" parent="432" relname="contrast"/>
		<group id="432" type="multinuc" parent="538" relname="sequence"/>
		<group id="433" type="multinuc" parent="483" relname="sequence"/>
		<group id="434" type="span" parent="433" relname="sequence"/>
		<group id="435" type="multinuc" parent="541" relname="span"/>
		<group id="436" type="span" parent="438" relname="span"/>
		<group id="437" type="span" parent="191" relname="evaluation"/>
		<group id="438" type="span" parent="435" relname="sequence"/>
		<group id="439" type="span" parent="444" relname="sequence"/>
		<group id="440" type="multinuc" parent="441" relname="span"/>
		<group id="441" type="span" parent="442" relname="span"/>
		<group id="442" type="span" parent="199" relname="elaboration"/>
		<group id="443" type="span" parent="198" relname="background"/>
		<group id="444" type="multinuc" parent="483" relname="sequence"/>
		<group id="445" type="multinuc" parent="204" relname="evaluation"/>
		<group id="446" type="span" parent="447" relname="span"/>
		<group id="447" type="span" parent="482" relname="span"/>
		<group id="448" type="multinuc" parent="449" relname="span"/>
		<group id="449" type="span" parent="450" relname="span"/>
		<group id="450" type="span" parent="447" relname="evaluation"/>
		<group id="451" type="multinuc" parent="213" relname="cause"/>
		<group id="452" type="span" parent="465" relname="preparation"/>
		<group id="453" type="multinuc" parent="465" relname="span"/>
		<group id="454" type="span" parent="457" relname="span"/>
		<group id="455" type="multinuc" parent="477" relname="span"/>
		<group id="456" type="span" parent="453" relname="same-unit"/>
		<group id="457" type="span" parent="456" relname="span"/>
		<group id="458" type="multinuc" parent="459" relname="joint"/>
		<group id="459" type="multinuc" parent="477" relname="background"/>
		<group id="460" type="multinuc" parent="462" relname="span"/>
		<group id="461" type="span" parent="459" relname="joint"/>
		<group id="462" type="span" parent="463" relname="span"/>
		<group id="463" type="span" parent="464" relname="span"/>
		<group id="464" type="span" parent="221" relname="elaboration"/>
		<group id="465" type="span" parent="480" relname="span"/>
		<group id="466" type="multinuc" parent="467" relname="span"/>
		<group id="467" type="span" parent="468" relname="span"/>
		<group id="468" type="span" parent="479" relname="contrast"/>
		<group id="469" type="multinuc" parent="542" relname="sequence"/>
		<group id="470" type="multinuc" parent="469" relname="sequence"/>
		<group id="471" type="multinuc" parent="473" relname="span"/>
		<group id="472" type="span" parent="471" relname="contrast"/>
		<group id="473" type="span" parent="474" relname="span"/>
		<group id="474" type="span" parent="469" relname="sequence"/>
		<group id="475" type="span" parent="476" relname="span"/>
		<group id="476" type="span" />
		<group id="477" type="span" parent="478" relname="span"/>
		<group id="478" type="span" parent="457" relname="evaluation"/>
		<group id="479" type="multinuc" />
		<group id="480" type="span" parent="479" relname="contrast"/>
		<group id="481" type="multinuc" parent="544" relname="evaluation"/>
		<group id="482" type="span" parent="483" relname="sequence"/>
		<group id="483" type="multinuc" />
		<group id="484" type="multinuc" parent="485" relname="span"/>
		<group id="485" type="span" parent="486" relname="span"/>
		<group id="486" type="span" parent="492" relname="preparation"/>
		<group id="487" type="span" parent="488" relname="same-unit"/>
		<group id="488" type="multinuc" parent="489" relname="contrast"/>
		<group id="489" type="multinuc" parent="491" relname="sequence"/>
		<group id="490" type="span" parent="253" relname="preparation"/>
		<group id="491" type="multinuc" parent="492" relname="span"/>
		<group id="492" type="span" parent="493" relname="span"/>
		<group id="493" type="span" />
		<group id="494" type="multinuc" parent="507" relname="solutionhood"/>
		<group id="495" type="span" parent="553" relname="span"/>
		<group id="496" type="multinuc" parent="494" relname="sequence"/>
		<group id="497" type="span" parent="260" relname="evaluation"/>
		<group id="498" type="span" parent="499" relname="span"/>
		<group id="499" type="span" parent="503" relname="span"/>
		<group id="500" type="span" parent="261" relname="condition"/>
		<group id="501" type="multinuc" parent="264" relname="cause"/>
		<group id="502" type="span" parent="499" relname="evaluation"/>
		<group id="503" type="span" parent="496" relname="contrast"/>
		<group id="504" type="multinuc" parent="507" relname="span"/>
		<group id="505" type="multinuc" parent="520" relname="preparation"/>
		<group id="506" type="multinuc" parent="520" relname="span"/>
		<group id="507" type="span" parent="509" relname="span"/>
		<group id="508" type="span" parent="494" relname="sequence"/>
		<group id="509" type="span" />
		<group id="510" type="span" parent="516" relname="span"/>
		<group id="511" type="multinuc" parent="510" relname="elaboration"/>
		<group id="512" type="multinuc" parent="511" relname="sequence"/>
		<group id="513" type="multinuc" parent="514" relname="span"/>
		<group id="514" type="span" parent="515" relname="span"/>
		<group id="515" type="span" parent="518" relname="sequence"/>
		<group id="516" type="span" parent="275" relname="elaboration"/>
		<group id="517" type="span" parent="506" relname="contrast"/>
		<group id="518" type="multinuc" />
		<group id="519" type="span" parent="518" relname="sequence"/>
		<group id="520" type="span" parent="519" relname="span"/>
		<group id="521" type="multinuc" parent="407" relname="sequence"/>
		<group id="522" type="span" parent="523" relname="span"/>
		<group id="523" type="span" parent="524" relname="span"/>
		<group id="524" type="span" parent="321" relname="sequence"/>
		<group id="525" type="span" parent="335" relname="span"/>
		<group id="526" type="multinuc" parent="60" relname="background"/>
		<group id="527" type="span" parent="526" relname="contrast"/>
		<group id="528" type="span" parent="333" relname="sequence"/>
		<group id="529" type="multinuc" parent="347" relname="span"/>
		<group id="531" type="span" parent="532" relname="span"/>
		<group id="532" type="span" parent="548" relname="span"/>
		<group id="535" type="span" parent="379" relname="elaboration"/>
		<group id="536" type="span" parent="551" relname="span"/>
		<group id="537" type="span" parent="174" relname="evaluation"/>
		<group id="538" type="multinuc" />
		<group id="539" type="multinuc" parent="483" relname="sequence"/>
		<group id="540" type="span" parent="539" relname="sequence"/>
		<group id="541" type="span" parent="540" relname="span"/>
		<group id="542" type="multinuc" parent="475" relname="span"/>
		<group id="543" type="span" parent="34" relname="elaboration"/>
		<group id="544" type="span" parent="545" relname="span"/>
		<group id="545" type="span" parent="546" relname="span"/>
		<group id="546" type="span" />
		<group id="547" type="multinuc" />
		<group id="548" type="span" parent="558" relname="span"/>
		<group id="551" type="span" />
		<group id="553" type="span" parent="554" relname="span"/>
		<group id="554" type="span" parent="496" relname="contrast"/>
		<group id="555" type="multinuc" parent="375" relname="elaboration"/>
		<group id="556" type="span" parent="396" relname="preparation"/>
		<group id="557" type="span" parent="548" relname="preparation"/>
		<group id="558" type="span" />
	</body>
</rst>