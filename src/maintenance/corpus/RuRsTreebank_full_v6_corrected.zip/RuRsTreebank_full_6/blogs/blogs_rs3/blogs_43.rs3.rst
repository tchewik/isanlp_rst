<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://habr.com/ru/post/460161/</segment>
		<segment id="2" >FusionPBX и ACL</segment>
		<segment id="3" parent="104" relname="contrast">Моя статья — не полноценное описание продукта,</segment>
		<segment id="4" parent="180" relname="span">а только небольшое уточнение хорошей публикации «FusionPBX, или снова-здорово, FreeSWITCH».</segment>
		<segment id="5" parent="4" relname="evaluation">Мне кажется в ней не очень хорошо раскрыта тема ACL в FusionPBX.</segment>
		<segment id="6" parent="105" relname="span">Попробую заполнить этот пробел,</segment>
		<segment id="7" parent="6" relname="cause">исходя из собственного опыта работы с FreeSWITCH/FusionPBX.</segment>
		<segment id="8" parent="106" relname="span">И так, имеем установленный FusionPBX с зарегистрированным внутренним номером 1010 в домене domain.local и настроенным маршрутом</segment>
		<segment id="9" parent="8" relname="purpose">для внешних вызовов в город.</segment>
		<segment id="10" parent="107" relname="span">ACL используем,</segment>
		<segment id="11" parent="10" relname="purpose">чтобы обезопасить нашу систему телефонии от несанкционированных вызовов, которые унесут наши денежки.</segment>
		<segment id="12" parent="108" relname="restatement">Т.е. только из описанных в ACL сетей разрешить исходящие вызовы.</segment>
		<segment id="13" parent="190" relname="elaboration">И здесь нужно совершенно четкое понимание, как работает ACL в FusionPBX, его особенности, логику и точку его привязки.</segment>
		<segment id="14" parent="188" relname="span">Как и уважаемый автор вышеупомянутой статьи, я так же наступил на все грабли,</segment>
		<segment id="15" parent="14" relname="cause">связанные с ACL.</segment>
		<segment id="16" parent="115" relname="preparation">Начну с SipProfiles.</segment>
		<segment id="17" parent="112" relname="span">Оба профиля</segment>
		<segment id="18" parent="17" relname="elaboration">(буду их так называть),</segment>
		<segment id="19" parent="113" relname="same-unit">и internal, и external находятся в контексте Public,</segment>
		<segment id="20" parent="114" relname="joint">и это не случайно.</segment>
		<segment id="21" parent="22" relname="cause">Регистрация номеров происходит в профиле internal,</segment>
		<segment id="22" parent="117" relname="span">на него и обратим внимание.</segment>
		<segment id="23" parent="118" relname="span">В профиле internal привязан ACL-лист domains как apply-inbound-acl.</segment>
		<segment id="24" parent="23" relname="elaboration">Именно эта строчка отвечает за работу ACL на уровне профиля.</segment>
		<segment id="25" parent="119" relname="evaluation">Пока с профилями всё.</segment>
		<segment id="26" parent="27" relname="preparation">Context</segment>
		<segment id="27" parent="121" relname="span">Контекст, кроме всего прочего, используется в маршрутизации вызовов.</segment>
		<segment id="28" parent="183" relname="span">Все входящие маршруты привязаны к контексту Public.</segment>
		<segment id="29" parent="122" relname="span">Исходящие (в город, на сотовые, междугородка, международка, и любые другие) маршруты находятся (по умолчанию) в контексте имени домена</segment>
		<segment id="30" parent="29" relname="elaboration">(назовем его domain.local).</segment>
		<segment id="31" parent="32" relname="preparation">ACL</segment>
		<segment id="32" parent="124" relname="span">Теперь давайте разберемся с ACL.</segment>
		<segment id="33" parent="127" relname="span">По умолчанию, в только что установленной FusionPBX есть два ACL-листа:</segment>
		<segment id="34" parent="126" relname="span">domains действие по умолчанию:</segment>
		<segment id="35" parent="125" relname="joint">deny — этот лист привязан к профилю internal</segment>
		<segment id="36" parent="125" relname="joint">lan действие по умолчанию: allow</segment>
		<segment id="37" parent="128" relname="sequence">В ACL-лист domains прописываем сеть (ну к примеру 192.168.0.0/24),</segment>
		<segment id="38" parent="128" relname="sequence">делаем этой сети разрешение allow,</segment>
		<segment id="39" parent="128" relname="sequence">применяем reloadacl.</segment>
		<segment id="40" parent="130" relname="span">Далее регистрируем телефон из этой сети,</segment>
		<segment id="41" parent="40" relname="evaluation">и вроде бы все хорошо и по инструкции и логично.</segment>
		<segment id="42" parent="131" relname="joint">Начинаем тестировать,</segment>
		<segment id="43" parent="131" relname="joint">делаем вызов на внешний номер</segment>
		<segment id="44" parent="189" relname="span">и… получаем бублик, а точнее дырку от бублика.</segment>
		<segment id="45" parent="44" relname="evaluation">Неожиданно!</segment>
		<segment id="46" parent="145" relname="span">Начинаем анализировать лог в консоли или через Log Viewer FusioPBX.</segment>
		<segment id="47" parent="133" relname="span">Видим наш вызов:</segment>
		<segment id="48" parent="47" relname="elaboration">[код]</segment>
		<segment id="49" parent="134" relname="span">Видим сработавший ACL:</segment>
		<segment id="50" parent="49" relname="elaboration">[код]</segment>
		<segment id="51" parent="135" relname="span">И далее:</segment>
		<segment id="52" parent="51" relname="elaboration">[код]</segment>
		<segment id="53" parent="184" relname="contrast">Нет маршрута!</segment>
		<segment id="54" parent="137" relname="concession">Хотя маршрут у нас честно прописан.</segment>
		<segment id="55" parent="144" relname="span">Ответ на самом деле прост.</segment>
		<segment id="56" parent="139" relname="sequence">Вызов пришел.</segment>
		<segment id="57" parent="186" relname="span">ACL его пропустил.</segment>
		<segment id="58" parent="140" relname="joint">А так как ACL привязан в профилю internal,</segment>
		<segment id="59" parent="140" relname="joint">а этот профиль находится в контексте public,</segment>
		<segment id="60" parent="141" relname="span">FreeSWITCH честно смотрит маршрутизацию в контексте public.</segment>
		<segment id="61" parent="142" relname="joint">Но в контексте public только входящая маршрутизация,</segment>
		<segment id="62" parent="63" relname="attribution">и система честно нам говорит,</segment>
		<segment id="63" parent="192" relname="span">что нет там ни каких маршрутов в город.</segment>
		<segment id="64" parent="161" relname="span">Из сложившейся ситуации есть как минимум два выхода.</segment>
		<segment id="65" parent="150" relname="span">1. Прикрутить этот ACL не к профилю, а к самому внутреннему номеру.</segment>
		<segment id="66" parent="149" relname="span">Это может быть и самый правильный способ решения,</segment>
		<segment id="67" parent="148" relname="span">т.к. ACL лучше привязывать как можно ближе к Extension</segment>
		<segment id="68" parent="67" relname="purpose">для более тонкой настройки.</segment>
		<segment id="69" parent="151" relname="restatement">Т.е. можно прописать конкретный адрес/адрес сети телефона, с которого он сможет сделать исходящий вызов.</segment>
		<segment id="70" parent="152" relname="contrast">Минус этого варианта в том, что в каждом Extension придется это делать.</segment>
		<segment id="71" parent="153" relname="span">2. Поправить ACL так,</segment>
		<segment id="72" parent="71" relname="purpose">чтобы он корректно работал на уровне профиля.</segment>
		<segment id="73" parent="155" relname="span">Я выбрал именно этот вариант,</segment>
		<segment id="74" parent="154" relname="comparison">ибо добавить один раз сеть в ACL мне показалось проще,</segment>
		<segment id="75" parent="154" relname="comparison">чем прописывать его в каждом Extension.</segment>
		<segment id="76" parent="157" relname="span">Но это конкретно под мою задачу.</segment>
		<segment id="77" parent="78" relname="purpose">Для других задач,</segment>
		<segment id="78" parent="156" relname="span">возможно, нужна другая логика принятия решения.</segment>
		<segment id="79" parent="166" relname="preparation">И так.</segment>
		<segment id="80" parent="163" relname="span">Поправим ACL domains следующим образом:</segment>
		<segment id="81" parent="80" relname="elaboration">domains действие по умолчанию: allow</segment>
		<segment id="82" parent="162" relname="span">В ACL-лист domains прописываем сеть:</segment>
		<segment id="83" parent="82" relname="elaboration">deny 192.168.0.0/24</segment>
		<segment id="84" parent="164" relname="sequence">Применяем, reloadacl.</segment>
		<segment id="85" parent="165" relname="sequence">Тестируем: набираем снова номер 98343379хххх</segment>
		<segment id="86" parent="165" relname="sequence">и… идёт КПВ…</segment>
		<segment id="87" parent="166" relname="span">АЛЛО. Всё работает.</segment>
		<segment id="88" parent="172" relname="span">Смотрим, что происходило в FreeSWITCH:</segment>
		<segment id="89" parent="168" relname="span">начинается вызов:</segment>
		<segment id="90" parent="89" relname="elaboration">[код]</segment>
		<segment id="91" parent="169" relname="span">ACL не пропустил:</segment>
		<segment id="92" parent="91" relname="elaboration">[код]</segment>
		<segment id="93" parent="170" relname="span">и далее:</segment>
		<segment id="94" parent="93" relname="elaboration">[код]</segment>
		<segment id="95" parent="173" relname="sequence">Маршрутизация прошла,</segment>
		<segment id="96" parent="173" relname="sequence">и далее идет установление соединения, которое выходит за рамки темы.</segment>
		<segment id="97" parent="98" relname="condition">Если мы поменяем адрес сети в ACL,</segment>
		<segment id="98" parent="174" relname="span">но получим картину из первого тестирования,</segment>
		<segment id="99" parent="175" relname="joint">т.е. ACL вызов пропустит</segment>
		<segment id="100" parent="193" relname="span">и маршрутизация скажет</segment>
		<segment id="101" parent="100" relname="elaboration">NO_ROUTE_DESTINATION.</segment>
		<segment id="102" >Вот наверное и всё, что я хотел дополнить по ACL FusionPBX.</segment>
		<segment id="103" >Надеюсь кому нибудь пригодится.</segment>
		<group id="104" type="multinuc" parent="105" relname="solutionhood"/>
		<group id="105" type="span" parent="181" relname="span"/>
		<group id="106" type="span" parent="109" relname="joint"/>
		<group id="107" type="span" parent="108" relname="restatement"/>
		<group id="108" type="multinuc" parent="109" relname="joint"/>
		<group id="109" type="multinuc" parent="190" relname="span"/>
		<group id="111" type="multinuc" />
		<group id="112" type="span" parent="113" relname="same-unit"/>
		<group id="113" type="multinuc" parent="114" relname="joint"/>
		<group id="114" type="multinuc" parent="115" relname="span"/>
		<group id="115" type="span" parent="116" relname="span"/>
		<group id="116" type="span" parent="119" relname="span"/>
		<group id="117" type="span" parent="182" relname="span"/>
		<group id="118" type="span" parent="117" relname="elaboration"/>
		<group id="119" type="span" parent="120" relname="span"/>
		<group id="120" type="span" />
		<group id="121" type="span" parent="123" relname="span"/>
		<group id="122" type="span" parent="28" relname="elaboration"/>
		<group id="123" type="span" />
		<group id="124" type="span" parent="129" relname="span"/>
		<group id="125" type="multinuc" parent="34" relname="elaboration"/>
		<group id="126" type="span" parent="33" relname="elaboration"/>
		<group id="127" type="span" parent="124" relname="elaboration"/>
		<group id="128" type="multinuc" parent="132" relname="sequence"/>
		<group id="129" type="span" parent="146" relname="background"/>
		<group id="130" type="span" parent="132" relname="sequence"/>
		<group id="131" type="multinuc" parent="132" relname="sequence"/>
		<group id="132" type="multinuc" parent="146" relname="span"/>
		<group id="133" type="span" parent="136" relname="sequence"/>
		<group id="134" type="span" parent="136" relname="sequence"/>
		<group id="135" type="span" parent="136" relname="sequence"/>
		<group id="136" type="multinuc" parent="184" relname="contrast"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="144" relname="solutionhood"/>
		<group id="139" type="multinuc" parent="55" relname="elaboration"/>
		<group id="140" type="multinuc" parent="60" relname="cause"/>
		<group id="141" type="span" parent="143" relname="contrast"/>
		<group id="142" type="multinuc" parent="143" relname="contrast"/>
		<group id="143" type="multinuc" parent="57" relname="cause"/>
		<group id="144" type="span" parent="185" relname="span"/>
		<group id="145" type="span" parent="132" relname="sequence"/>
		<group id="146" type="span" parent="147" relname="span"/>
		<group id="147" type="span" />
		<group id="148" type="span" parent="66" relname="cause"/>
		<group id="149" type="span" parent="65" relname="evaluation"/>
		<group id="150" type="span" parent="151" relname="restatement"/>
		<group id="151" type="multinuc" parent="152" relname="contrast"/>
		<group id="152" type="multinuc" parent="160" relname="joint"/>
		<group id="153" type="span" parent="159" relname="span"/>
		<group id="154" type="multinuc" parent="73" relname="cause"/>
		<group id="155" type="span" parent="158" relname="contrast"/>
		<group id="156" type="span" parent="76" relname="evaluation"/>
		<group id="157" type="span" parent="158" relname="contrast"/>
		<group id="158" type="multinuc" parent="153" relname="evaluation"/>
		<group id="159" type="span" parent="160" relname="joint"/>
		<group id="160" type="multinuc" parent="64" relname="elaboration"/>
		<group id="161" type="span" />
		<group id="162" type="span" parent="164" relname="sequence"/>
		<group id="163" type="span" parent="164" relname="sequence"/>
		<group id="164" type="multinuc" parent="87" relname="solutionhood"/>
		<group id="165" type="multinuc" parent="164" relname="sequence"/>
		<group id="166" type="span" parent="167" relname="span"/>
		<group id="167" type="span" parent="179" relname="comparison"/>
		<group id="168" type="span" parent="171" relname="sequence"/>
		<group id="169" type="span" parent="171" relname="sequence"/>
		<group id="170" type="span" parent="171" relname="sequence"/>
		<group id="171" type="multinuc" parent="88" relname="elaboration"/>
		<group id="172" type="span" parent="187" relname="span"/>
		<group id="173" type="multinuc" parent="177" relname="span"/>
		<group id="174" type="span" parent="176" relname="restatement"/>
		<group id="175" type="multinuc" parent="176" relname="restatement"/>
		<group id="176" type="multinuc" parent="177" relname="elaboration"/>
		<group id="177" type="span" parent="178" relname="span"/>
		<group id="178" type="span" parent="172" relname="evaluation"/>
		<group id="179" type="multinuc" />
		<group id="180" type="span" parent="104" relname="contrast"/>
		<group id="181" type="span" />
		<group id="182" type="span" parent="116" relname="elaboration"/>
		<group id="183" type="span" parent="121" relname="elaboration"/>
		<group id="184" type="multinuc" parent="137" relname="span"/>
		<group id="185" type="span" parent="46" relname="elaboration"/>
		<group id="186" type="span" parent="139" relname="sequence"/>
		<group id="187" type="span" parent="179" relname="comparison"/>
		<group id="188" type="span" parent="111" relname="joint"/>
		<group id="189" type="span" parent="132" relname="sequence"/>
		<group id="190" type="span" parent="191" relname="span"/>
		<group id="191" type="span" parent="111" relname="joint"/>
		<group id="192" type="span" parent="142" relname="joint"/>
		<group id="193" type="span" parent="175" relname="joint"/>
	</body>
</rst>