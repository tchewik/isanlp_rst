<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://my-first-time.livejournal.com/574158.html</segment>
		<segment id="2" >Как я впервые сморчки искала.</segment>
		<segment id="3" parent="106" relname="joint">Первомай встречали на даче.</segment>
		<segment id="4" parent="106" relname="joint">Впервые решила попробовать отыскать весенние грибы - сморчки.</segment>
		<segment id="5" parent="107" relname="span">Идея появилась на михневском рынке.</segment>
		<segment id="6" parent="5" relname="elaboration">Там они продавались по 100р за кучку.</segment>
		<segment id="7" parent="8" relname="cause">Тщательно осмотрев и обнюхав грибы,</segment>
		<segment id="8" parent="108" relname="span">подумала - сходим</segment>
		<segment id="9" parent="109" relname="joint">и найдём сами.</segment>
		<segment id="10" parent="11" relname="attribution">Тем более, что друзья рассказывали,</segment>
		<segment id="11" parent="213" relname="span">как в прошлые годы собирали сморчки</segment>
		<segment id="12" parent="112" relname="joint">и даже готовили из них что-то вкусное.</segment>
		<segment id="13" parent="190" relname="span">Итак, за грибами.</segment>
		<segment id="14" parent="115" relname="joint">IMG Везде уже наросла сныть</segment>
		<segment id="15" parent="115" relname="joint">и зацвели желтые и сиреневые цветочки, очень симпатичные в яркой траве. IMG</segment>
		<segment id="16" parent="193" relname="span">Найти сморчки сначала пыталась среди молодой зелени.</segment>
		<segment id="17" parent="191" relname="span">Лес был влажным</segment>
		<segment id="18" parent="17" relname="cause">от прошедших недавно дождей.</segment>
		<segment id="19" parent="191" relname="evaluation">Сапоги - наше всё. IMG</segment>
		<segment id="20" parent="117" relname="span">Ищу сморчки.</segment>
		<segment id="21" parent="20" relname="evaluation">Это оказалось весьма непросто.</segment>
		<segment id="22" parent="116" relname="joint">Целый час ходила</segment>
		<segment id="23" parent="178" relname="contrast">и никаких признаков этих грибов не было.</segment>
		<segment id="24" parent="177" relname="joint">Были поганки, куда же без них. IMG</segment>
		<segment id="25" parent="197" relname="joint">Множество различных древесных грибов, свеженьких и мягких наощупь. IMG</segment>
		<segment id="26" parent="197" relname="joint">А также старых, гигантских размеров.</segment>
		<segment id="27" parent="211" relname="span">Помню, в детском лагере делала пепельницу для папы из такого гриба.</segment>
		<segment id="28" parent="120" relname="joint">Старательно выдалбливала внутренность</segment>
		<segment id="29" parent="120" relname="joint">и подарила на "родительском дне".</segment>
		<segment id="30" parent="121" relname="span">Наверное, он выкинул этот "шедевр",</segment>
		<segment id="31" parent="30" relname="cause">дома я таких пепельниц не помню.</segment>
		<segment id="32" parent="211" relname="elaboration">IMG</segment>
		<segment id="33" parent="34" relname="cause">Обследовав пни,</segment>
		<segment id="34" parent="200" relname="span">обнаружила еще и старые непрезентабельного вида дымовики, которые исправно дымили,</segment>
		<segment id="35" parent="200" relname="concession">несмотря на пережитую зиму. IMG</segment>
		<segment id="36" parent="124" relname="span">Вот это явно не грибы,</segment>
		<segment id="37" parent="36" relname="evaluation">больше похоже на цветок.</segment>
		<segment id="38" parent="179" relname="span">Рвать не стала,</segment>
		<segment id="39" parent="38" relname="cause">кто знает что за чудо такое без листочков, прямо из земли растущее?</segment>
		<segment id="40" parent="126" relname="elaboration">IMG</segment>
		<segment id="41" parent="129" relname="joint">Проснулась бабочка,</segment>
		<segment id="42" parent="129" relname="joint">долго сидела,</segment>
		<segment id="43" parent="129" relname="joint">грелась на солнышке, расправив крылья. IMG</segment>
		<segment id="44" parent="204" relname="preparation">Попадалось всё что угодно, кроме искомых сморчков.</segment>
		<segment id="45" parent="167" relname="span">Возле ствола дерева почти незаметное зеркальце от мотоцикла и босоножки, висящие на ремешке.</segment>
		<segment id="46" parent="45" relname="evaluation">Примерять не стала, еще не сезон.</segment>
		<segment id="47" parent="167" relname="elaboration">IMG</segment>
		<segment id="48" parent="168" relname="joint">В зеркальце посмотрелась. Как-то так. IMG</segment>
		<segment id="49" parent="130" relname="span">Но вот прошел небольшой отряд грибников,</segment>
		<segment id="50" parent="49" relname="elaboration">у них были сморчки!</segment>
		<segment id="51" parent="130" relname="elaboration">Оказывается, искать надо там, где поваленные деревья.</segment>
		<segment id="52" parent="181" relname="sequence">Свернув к бурелому, я долго "продиралась как медведь сквозь лесной валежник",</segment>
		<segment id="53" parent="181" relname="sequence">и вот он - первый гриб!</segment>
		<segment id="54" parent="133" relname="span">То есть это уже второй,</segment>
		<segment id="55" parent="206" relname="span">первый я сорвала,</segment>
		<segment id="56" parent="55" relname="cause">забыв сфотографировать.</segment>
		<segment id="57" parent="134" relname="cause">Поскольку уж очень долго искала.</segment>
		<segment id="58" parent="136" relname="elaboration">IMG</segment>
		<segment id="59" parent="138" relname="joint">Они прохладные в руке</segment>
		<segment id="60" parent="138" relname="joint">и пахнут хорошими грибами, эти сморчки.</segment>
		<segment id="61" parent="139" relname="span">Много собирать не стала,</segment>
		<segment id="62" parent="61" relname="cause">вдруг не понравятся на вкус.</segment>
		<segment id="63" parent="139" relname="evaluation">А лазить по бурелому удовольствие то ещё.</segment>
		<segment id="64" parent="65" relname="cause">Зацепившись за ветку, не удержалась</segment>
		<segment id="65" parent="183" relname="span">и встала на коленки в небольшое лесное болотце.</segment>
		<segment id="66" parent="184" relname="sequence">Потом, правда, джинсы быстро высохли - жара.</segment>
		<segment id="67" parent="144" relname="elaboration">IMG</segment>
		<segment id="68" parent="146" relname="span">На обратном пути заглянула в ельник возле дач,</segment>
		<segment id="69" parent="68" relname="background">который сажали пионеры в 50-х годах</segment>
		<segment id="70" parent="147" relname="joint">Ёлки вымахали огромные,</segment>
		<segment id="71" parent="147" relname="joint">там было прохладно, тень и хвойный запах.</segment>
		<segment id="72" parent="148" relname="joint">На толстом слое веток, среди шишек и опавшей хвои лежали скорлупки голубых птичьих яиц. IMG</segment>
		<segment id="73" parent="152" relname="span">Предположительно это были скорлупки яиц дрозда.</segment>
		<segment id="74" parent="151" relname="span">Самих дроздов на дачах мы встречали неоднократно, как черных, так и рябинников.</segment>
		<segment id="75" parent="74" relname="elaboration">Они, видимо, вьют гнёзда в нашем ельнике.</segment>
		<segment id="76" parent="153" relname="joint">Погода была отличная,</segment>
		<segment id="77" parent="153" relname="joint">прогулялась я от души</segment>
		<segment id="78" parent="153" relname="joint">и шагомер в телефоне к концу прогулки показал больше пяти километров пройденного пути по "пересеченной местности".</segment>
		<segment id="79" parent="185" relname="comparison">А сморчки приготовить оказалось не очень сложно.</segment>
		<segment id="80" parent="185" relname="comparison">На вкус они чем-то напомнили лисички.</segment>
		<segment id="81" parent="82" relname="condition">При жарке</segment>
		<segment id="82" parent="207" relname="span">"стреляли",</segment>
		<segment id="83" parent="207" relname="cause">поскольку в них много пустых полостей,</segment>
		<segment id="84" parent="155" relname="span">их надо резать помельче.</segment>
		<segment id="85" parent="209" relname="span">И перед жаркой три раза слить закипевшую воду,</segment>
		<segment id="86" parent="85" relname="cause">ибо условно-съедобность их очевидна.</segment>
		<segment id="87" parent="88" relname="cause">Попробовав одну штучку,</segment>
		<segment id="88" parent="157" relname="span">успокоилась,</segment>
		<segment id="89" parent="158" relname="contrast">а всеядные домашние доели всю оставшуюся сковородку под жареную картошку.</segment>
		<segment id="90" parent="160" relname="span">Сбор грибов прошёл не даром.</segment>
		<segment id="91" parent="159" relname="joint">И прогулялись,</segment>
		<segment id="92" parent="159" relname="joint">и новое блюдо опробовали.</segment>
		<segment id="93" parent="165" relname="elaboration">IMG</segment>
		<segment id="94" parent="210" relname="span">Через некоторое время получаю я информацию, что это были не сморчки, а строчки!</segment>
		<segment id="95" parent="94" relname="evaluation">Вот как тут разобрать непонятные весенние условно-съедобные грибы?</segment>
		<segment id="96" parent="169" relname="span">Вот эти самые сморчки попались уже позже,</segment>
		<segment id="97" parent="96" relname="condition">когда мы их не искали совсем.</segment>
		<segment id="98" parent="170" relname="joint">Они росли прямо на участке</segment>
		<segment id="99" parent="170" relname="joint">и выглядели вот так: IMG</segment>
		<segment id="100" parent="171" relname="evaluation">На мой взгляд, не особенно аппетитно.</segment>
		<segment id="101" parent="172" relname="span">И пылили спорами,</segment>
		<segment id="102" parent="101" relname="condition">когда до них дотронешься.</segment>
		<segment id="103" parent="173" relname="joint">Кто собирал такие грибы</segment>
		<segment id="104" parent="173" relname="joint">и, главное, осмелился их пробовать?</segment>
		<segment id="105" parent="174" relname="span">Поделитесь опытом, грибоеды!</segment>
		<group id="106" type="multinuc" parent="113" relname="preparation"/>
		<group id="107" type="span" parent="113" relname="span"/>
		<group id="108" type="span" parent="109" relname="joint"/>
		<group id="109" type="multinuc" parent="110" relname="span"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" parent="107" relname="elaboration"/>
		<group id="112" type="multinuc" parent="110" relname="elaboration"/>
		<group id="113" type="span" parent="114" relname="span"/>
		<group id="114" type="span" parent="13" relname="preparation"/>
		<group id="115" type="multinuc" parent="195" relname="preparation"/>
		<group id="116" type="multinuc" parent="117" relname="elaboration"/>
		<group id="117" type="span" parent="118" relname="span"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" parent="194" relname="joint"/>
		<group id="120" type="multinuc" parent="122" relname="span"/>
		<group id="121" type="span" parent="122" relname="evaluation"/>
		<group id="122" type="span" parent="123" relname="span"/>
		<group id="123" type="span" parent="27" relname="elaboration"/>
		<group id="124" type="span" parent="125" relname="joint"/>
		<group id="125" type="multinuc" parent="126" relname="span"/>
		<group id="126" type="span" parent="127" relname="span"/>
		<group id="127" type="span" parent="201" relname="elaboration"/>
		<group id="128" type="multinuc" />
		<group id="129" type="multinuc" parent="128" relname="joint"/>
		<group id="130" type="span" parent="131" relname="span"/>
		<group id="131" type="span" parent="135" relname="cause"/>
		<group id="132" type="span" parent="182" relname="same-unit"/>
		<group id="133" type="span" parent="182" relname="same-unit"/>
		<group id="134" type="span" parent="135" relname="span"/>
		<group id="135" type="span" parent="136" relname="span"/>
		<group id="136" type="span" parent="137" relname="span"/>
		<group id="137" type="span" parent="180" relname="contrast"/>
		<group id="138" type="multinuc" parent="141" relname="span"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="141" relname="elaboration"/>
		<group id="141" type="span" parent="142" relname="span"/>
		<group id="142" type="span" parent="143" relname="joint"/>
		<group id="143" type="multinuc" parent="144" relname="span"/>
		<group id="144" type="span" parent="145" relname="span"/>
		<group id="145" type="span" />
		<group id="146" type="span" parent="149" relname="span"/>
		<group id="147" type="multinuc" parent="148" relname="joint"/>
		<group id="148" type="multinuc" parent="146" relname="elaboration"/>
		<group id="149" type="span" parent="150" relname="span"/>
		<group id="150" type="span" />
		<group id="151" type="span" parent="73" relname="elaboration"/>
		<group id="152" type="span" parent="163" relname="joint"/>
		<group id="153" type="multinuc" parent="163" relname="joint"/>
		<group id="154" type="span" parent="161" relname="span"/>
		<group id="155" type="span" parent="156" relname="joint"/>
		<group id="156" type="multinuc" parent="154" relname="elaboration"/>
		<group id="157" type="span" parent="158" relname="contrast"/>
		<group id="158" type="multinuc" parent="187" relname="span"/>
		<group id="159" type="multinuc" parent="90" relname="elaboration"/>
		<group id="160" type="span" parent="187" relname="evaluation"/>
		<group id="161" type="span" parent="162" relname="span"/>
		<group id="162" type="span" parent="164" relname="span"/>
		<group id="163" type="multinuc" parent="165" relname="span"/>
		<group id="164" type="span" parent="163" relname="joint"/>
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" />
		<group id="167" type="span" parent="203" relname="span"/>
		<group id="168" type="multinuc" parent="204" relname="span"/>
		<group id="169" type="span" parent="171" relname="span"/>
		<group id="170" type="multinuc" parent="169" relname="elaboration"/>
		<group id="171" type="span" parent="189" relname="span"/>
		<group id="172" type="span" parent="175" relname="joint"/>
		<group id="173" type="multinuc" parent="105" relname="condition"/>
		<group id="174" type="span" parent="175" relname="joint"/>
		<group id="175" type="multinuc" />
		<group id="176" type="span" parent="116" relname="joint"/>
		<group id="177" type="multinuc" parent="178" relname="contrast"/>
		<group id="178" type="multinuc" parent="176" relname="span"/>
		<group id="179" type="span" parent="125" relname="joint"/>
		<group id="180" type="multinuc" />
		<group id="181" type="multinuc" parent="132" relname="span"/>
		<group id="182" type="multinuc" parent="134" relname="span"/>
		<group id="183" type="span" parent="184" relname="sequence"/>
		<group id="184" type="multinuc" parent="143" relname="joint"/>
		<group id="185" type="multinuc" parent="154" relname="span"/>
		<group id="186" type="span" parent="161" relname="elaboration"/>
		<group id="187" type="span" parent="186" relname="span"/>
		<group id="188" type="multinuc" />
		<group id="189" type="span" parent="188" relname="contrast"/>
		<group id="190" type="span" />
		<group id="191" type="span" parent="192" relname="span"/>
		<group id="192" type="span" parent="16" relname="elaboration"/>
		<group id="193" type="span" parent="194" relname="joint"/>
		<group id="194" type="multinuc" parent="195" relname="span"/>
		<group id="195" type="span" parent="196" relname="span"/>
		<group id="196" type="span" />
		<group id="197" type="multinuc" parent="177" relname="joint"/>
		<group id="200" type="span" parent="201" relname="span"/>
		<group id="201" type="span" parent="202" relname="span"/>
		<group id="202" type="span" parent="128" relname="joint"/>
		<group id="203" type="span" parent="168" relname="joint"/>
		<group id="204" type="span" parent="205" relname="span"/>
		<group id="205" type="span" parent="180" relname="contrast"/>
		<group id="206" type="span" parent="54" relname="elaboration"/>
		<group id="207" type="span" parent="208" relname="span"/>
		<group id="208" type="span" parent="84" relname="cause"/>
		<group id="209" type="span" parent="156" relname="joint"/>
		<group id="210" type="span" parent="188" relname="contrast"/>
		<group id="211" type="span" parent="212" relname="span"/>
		<group id="212" type="span" parent="128" relname="joint"/>
		<group id="213" type="span" parent="112" relname="joint"/>
	</body>
</rst>