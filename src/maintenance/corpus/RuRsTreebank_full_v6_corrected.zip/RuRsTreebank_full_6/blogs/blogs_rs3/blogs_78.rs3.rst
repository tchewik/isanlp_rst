<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://www.facebook.com/mitya.aleshkovskiy/posts/10220279171028844</segment>
		<segment id="2" parent="110" relname="span">Бедность в России — одна из самых главных проблем.</segment>
		<segment id="3" parent="109" relname="span">Наши люди живут в такой беспроглядной нищите,</segment>
		<segment id="4" parent="3" relname="evaluation">что большинство из нас даже представить себе не могут.</segment>
		<segment id="5" parent="114" relname="span">Пришла новость — в 13 российских регионов направят семь миллиардов рублей в рамках федерального софинансирования программы соцконтракта</segment>
		<segment id="6" parent="5" relname="purpose">для борьбы с бедностью.</segment>
		<segment id="7" parent="113" relname="span">И знаете, я очень рад этой программе,</segment>
		<segment id="8" parent="112" relname="same-unit">потому, что</segment>
		<segment id="9" parent="116" relname="evaluation">в целом затея разумная</segment>
		<segment id="10" parent="115" relname="joint">— дать человеку не рыбу, а удочку,</segment>
		<segment id="11" parent="115" relname="joint">и постараться его вытащить из той ямы в которой он находится.</segment>
		<segment id="12" parent="117" relname="contrast">Но есть одно большое НО.</segment>
		<segment id="13" parent="123" relname="span">В России все государственные органы заточены на то,</segment>
		<segment id="14" parent="120" relname="joint">чтобы наблюдать,</segment>
		<segment id="15" parent="120" relname="joint">контролировать</segment>
		<segment id="16" parent="120" relname="joint">и применять репрессивную функцию,</segment>
		<segment id="17" parent="121" relname="condition">если после серии предупреждений ситуация не нормализуется.</segment>
		<segment id="18" parent="122" relname="elaboration">Возьмем, к примеру, малоимущую семью проживающую в маленьком райцентре.</segment>
		<segment id="19" parent="189" relname="span">Женщина. Двое детей (без фанатизма,</segment>
		<segment id="20" parent="19" relname="elaboration">потому, что полно семей, где детей 5-6).</segment>
		<segment id="21" parent="124" relname="joint">Муж пропал.</segment>
		<segment id="22" parent="124" relname="joint">Умер.</segment>
		<segment id="23" parent="124" relname="joint">Ушел.</segment>
		<segment id="24" parent="124" relname="joint">Сидит.</segment>
		<segment id="25" parent="124" relname="joint">Что угодно.</segment>
		<segment id="26" parent="125" relname="span">Осталась одна.</segment>
		<segment id="27" parent="126" relname="joint">Работает, например, на фабрике за 13 тысяч.</segment>
		<segment id="28" parent="126" relname="joint">Кредит 50-90 тысяч рублей.</segment>
		<segment id="29" parent="126" relname="joint">Живут в одной, полутора комнатах.</segment>
		<segment id="30" parent="126" relname="joint">Денег хватает на базовые продукты — макароны, хлеб, молоко, консервы, чай.</segment>
		<segment id="31" parent="128" relname="sequence">И приходят к ней государственные службы</segment>
		<segment id="32" parent="33" relname="attribution">и говорят</segment>
		<segment id="33" parent="193" relname="span">— слыш, че-то у тебя тут печка потрескалась,</segment>
		<segment id="34" parent="129" relname="span">сделай ка ремонт,</segment>
		<segment id="35" parent="130" relname="contrast">иначе дети будут находится в опасной ситуации.</segment>
		<segment id="36" parent="37" relname="condition">А если не сделаешь,</segment>
		<segment id="37" parent="131" relname="span">изымем.</segment>
		<segment id="38" parent="135" relname="sequence">Понятное дело, что 200 тысяч на новую печку у нее нет</segment>
		<segment id="39" parent="135" relname="sequence">и заканчивается все тем, что она теряет детей</segment>
		<segment id="40" parent="135" relname="sequence">и уходит в запой,</segment>
		<segment id="41" parent="135" relname="sequence">а потом — на тот свет.</segment>
		<segment id="42" parent="136" relname="joint">Не существует ни одной государственной службы, которая _поддержала_ бы человека в такой ситуации.</segment>
		<segment id="43" parent="136" relname="joint">Которая его репрессирует,</segment>
		<segment id="44" parent="136" relname="joint">контролирует</segment>
		<segment id="45" parent="136" relname="joint">и хает</segment>
		<segment id="46" parent="137" relname="elaboration">— есть и не одна,</segment>
		<segment id="47" parent="142" relname="span">а вот поддерживающей нет.</segment>
		<segment id="48" parent="47" relname="elaboration">Ни существует ни одного государственного органа, который отнесся бы к человеку как к человеку.</segment>
		<segment id="49" parent="195" relname="condition">Каждый раз, когда подобная семья попадается кому-то из нас на глаза</segment>
		<segment id="50" parent="194" relname="joint">мы говорим "фууу"</segment>
		<segment id="51" parent="194" relname="joint">или "сама виновата".</segment>
		<segment id="52" parent="146" relname="span">А ведь решение проблемы заключается ровно в том,</segment>
		<segment id="53" parent="145" relname="joint">чтобы не отводить глаза,</segment>
		<segment id="54" parent="145" relname="joint">чтобы не "корчить рожу",</segment>
		<segment id="55" parent="145" relname="joint">чтобы увидеть в человеке человека</segment>
		<segment id="56" parent="145" relname="joint">и поддержать его в трудной ситуации.</segment>
		<segment id="57" parent="147" relname="joint">Понять его,</segment>
		<segment id="58" parent="147" relname="joint">понять, почему он оказался там, где он есть,</segment>
		<segment id="59" parent="147" relname="joint">какие он сделал ошибки,</segment>
		<segment id="60" parent="147" relname="joint">и что привело его к тому разбитому корыту у которого он сидит.</segment>
		<segment id="61" parent="151" relname="joint">Понять</segment>
		<segment id="62" parent="151" relname="joint">и поддержать.</segment>
		<segment id="63" parent="152" relname="joint">Разработать план, дорожную карту.</segment>
		<segment id="64" parent="152" relname="joint">И вести человека по ней.</segment>
		<segment id="65" parent="156" relname="span">И если на каком-то из шагов он будет оступаться</segment>
		<segment id="66" parent="65" relname="elaboration">(а он будет оступаться!),</segment>
		<segment id="67" parent="153" relname="joint">то его надо брать под руки,</segment>
		<segment id="68" parent="153" relname="joint">успокаивать,</segment>
		<segment id="69" parent="153" relname="joint">приободрять</segment>
		<segment id="70" parent="71" relname="attribution">и говорить,</segment>
		<segment id="71" parent="190" relname="span">ничего у тебя все получится,</segment>
		<segment id="72" parent="154" relname="joint">тебе есть ради чего жить,</segment>
		<segment id="73" parent="154" relname="joint">есть ради чего стараться,</segment>
		<segment id="74" parent="154" relname="joint">ты сможешь.</segment>
		<segment id="75" parent="153" relname="joint">И дальше, дальше, вытягивать из этой ямы, из этого ада.</segment>
		<segment id="76" parent="159" relname="solutionhood">Так помогут ли эти миллиарды и социальные контракты побороть бедность?</segment>
		<segment id="77" parent="159" relname="span">Сами по себе — нет.</segment>
		<segment id="78" parent="77" relname="condition">Без человеческого подхода — никогда.</segment>
		<segment id="79" parent="160" relname="span">Можно ли использовать эти контракты</segment>
		<segment id="80" parent="79" relname="purpose">для поддержки нуждающихся?</segment>
		<segment id="81" parent="165" relname="span">Да! Безусловно!</segment>
		<segment id="82" parent="164" relname="span">И тут я вижу ключевую функцию благотворительных организаций.</segment>
		<segment id="83" parent="162" relname="contrast">Повторюсь, не существует государственных служб с человеческим подходом и лицом.</segment>
		<segment id="84" parent="163" relname="joint">А благотворительные — есть.</segment>
		<segment id="85" parent="163" relname="joint">И они могут используя возможности государственных служб помогать нуждающимся выбираться из трясины.</segment>
		<segment id="86" parent="169" relname="solutionhood">Захотят ли чиновники работать с такими организациями?</segment>
		<segment id="87" parent="169" relname="span">В большинстве случаев — нет.</segment>
		<segment id="88" parent="168" relname="span">Десятки лет уходят на то,</segment>
		<segment id="89" parent="88" relname="purpose">чтобы доказать местным руководителям, что НКО — это друзья, а не враги, союзники, а не противники.</segment>
		<segment id="90" parent="171" relname="solutionhood">Значит ли это, что надо прекратить все попытки?</segment>
		<segment id="91" parent="171" relname="span">не значит.</segment>
		<segment id="92" parent="91" relname="cause">Потому, что без НКО вообще никакого шанса на счастливый исход у всей этой затеи, на мой взгляд, не будет.</segment>
		<segment id="93" parent="185" relname="span">Еще, как мне кажется, важнейшей частью борьбы с бедностью должна стать инфраструктура для малоимущих людей.</segment>
		<segment id="94" parent="93" relname="elaboration">Ну, например, прачечные.</segment>
		<segment id="95" parent="184" relname="contrast">Вы просто не представляете себе, в каких ужасающих условиях эти люди живут.</segment>
		<segment id="96" parent="97" relname="condition">А если дать им возможность бесплатно стирать одежду,</segment>
		<segment id="97" parent="174" relname="span">то качество жизни повысится значительно.</segment>
		<segment id="98" parent="175" relname="condition">А ведь пока одежда стирается (час!)</segment>
		<segment id="99" parent="176" relname="joint">можно проводить с этим человеком какие-то занятия, терапию, разговоры,</segment>
		<segment id="100" parent="176" relname="joint">короче, работать с ним.</segment>
		<segment id="101" parent="180" relname="span">Простая же мысль, сделать, например, досуговый центр,</segment>
		<segment id="102" parent="178" relname="joint">где таким людям помогут не только найти работу,</segment>
		<segment id="103" parent="178" relname="joint">получить новые навыки,</segment>
		<segment id="104" parent="179" relname="joint">но и почувствовать себя людьми,</segment>
		<segment id="105" parent="179" relname="joint">помогут обрести смыслы,</segment>
		<segment id="106" parent="179" relname="joint">полюбить жизнь,</segment>
		<segment id="107" parent="179" relname="joint">полюбить себя и других.</segment>
		<segment id="108" parent="180" relname="evaluation">Блин, ну почему министр не я :(</segment>
		<group id="109" type="span" parent="2" relname="elaboration"/>
		<group id="110" type="span" parent="118" relname="preparation"/>
		<group id="111" type="span" parent="112" relname="same-unit"/>
		<group id="112" type="multinuc" parent="117" relname="contrast"/>
		<group id="113" type="span" parent="114" relname="evaluation"/>
		<group id="114" type="span" parent="118" relname="span"/>
		<group id="115" type="multinuc" parent="116" relname="span"/>
		<group id="116" type="span" parent="111" relname="span"/>
		<group id="117" type="multinuc" parent="7" relname="cause"/>
		<group id="118" type="span" parent="119" relname="span"/>
		<group id="119" type="span" />
		<group id="120" type="multinuc" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="span"/>
		<group id="122" type="span" parent="188" relname="span"/>
		<group id="123" type="span" />
		<group id="124" type="multinuc" parent="26" relname="cause"/>
		<group id="125" type="span" parent="126" relname="joint"/>
		<group id="126" type="multinuc" parent="189" relname="elaboration"/>
		<group id="127" type="span" parent="128" relname="sequence"/>
		<group id="128" type="multinuc" parent="133" relname="span"/>
		<group id="129" type="span" parent="130" relname="contrast"/>
		<group id="130" type="multinuc" parent="132" relname="contrast"/>
		<group id="131" type="span" parent="132" relname="contrast"/>
		<group id="132" type="multinuc" parent="128" relname="sequence"/>
		<group id="133" type="span" parent="134" relname="span"/>
		<group id="134" type="span" />
		<group id="135" type="multinuc" parent="140" relname="span"/>
		<group id="136" type="multinuc" parent="137" relname="span"/>
		<group id="137" type="span" parent="138" relname="span"/>
		<group id="138" type="span" parent="139" relname="contrast"/>
		<group id="139" type="multinuc" parent="140" relname="cause"/>
		<group id="140" type="span" parent="141" relname="span"/>
		<group id="141" type="span" parent="198" relname="solutionhood"/>
		<group id="142" type="span" parent="139" relname="contrast"/>
		<group id="145" type="multinuc" parent="52" relname="elaboration"/>
		<group id="146" type="span" parent="197" relname="contrast"/>
		<group id="147" type="multinuc" parent="158" relname="joint"/>
		<group id="151" type="multinuc" parent="147" relname="joint"/>
		<group id="152" type="multinuc" parent="151" relname="joint"/>
		<group id="153" type="multinuc" parent="155" relname="span"/>
		<group id="154" type="multinuc" parent="153" relname="joint"/>
		<group id="155" type="span" parent="157" relname="span"/>
		<group id="156" type="span" parent="155" relname="condition"/>
		<group id="157" type="span" parent="158" relname="joint"/>
		<group id="158" type="multinuc" />
		<group id="159" type="span" parent="161" relname="span"/>
		<group id="160" type="span" parent="165" relname="solutionhood"/>
		<group id="161" type="span" parent="167" relname="joint"/>
		<group id="162" type="multinuc" parent="82" relname="elaboration"/>
		<group id="163" type="multinuc" parent="162" relname="contrast"/>
		<group id="164" type="span" parent="81" relname="evidence"/>
		<group id="165" type="span" parent="166" relname="span"/>
		<group id="166" type="span" parent="167" relname="joint"/>
		<group id="167" type="multinuc" />
		<group id="168" type="span" parent="87" relname="cause"/>
		<group id="169" type="span" parent="170" relname="span"/>
		<group id="170" type="span" parent="173" relname="joint"/>
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" parent="173" relname="joint"/>
		<group id="173" type="multinuc" />
		<group id="174" type="span" parent="183" relname="span"/>
		<group id="175" type="span" parent="177" relname="span"/>
		<group id="176" type="multinuc" parent="181" relname="span"/>
		<group id="177" type="span" parent="174" relname="elaboration"/>
		<group id="178" type="multinuc" parent="179" relname="joint"/>
		<group id="179" type="multinuc" parent="101" relname="purpose"/>
		<group id="180" type="span" parent="182" relname="span"/>
		<group id="181" type="span" parent="175" relname="span"/>
		<group id="182" type="span" parent="181" relname="elaboration"/>
		<group id="183" type="span" parent="184" relname="contrast"/>
		<group id="184" type="multinuc" parent="186" relname="span"/>
		<group id="185" type="span" parent="186" relname="preparation"/>
		<group id="186" type="span" parent="187" relname="span"/>
		<group id="187" type="span" />
		<group id="188" type="span" parent="13" relname="purpose"/>
		<group id="189" type="span" parent="127" relname="span"/>
		<group id="190" type="span" parent="153" relname="joint"/>
		<group id="193" type="span" parent="34" relname="cause"/>
		<group id="194" type="multinuc" parent="195" relname="span"/>
		<group id="195" type="span" parent="196" relname="span"/>
		<group id="196" type="span" parent="197" relname="contrast"/>
		<group id="197" type="multinuc" parent="198" relname="span"/>
		<group id="198" type="span" parent="199" relname="span"/>
		<group id="199" type="span" />
	</body>
</rst>