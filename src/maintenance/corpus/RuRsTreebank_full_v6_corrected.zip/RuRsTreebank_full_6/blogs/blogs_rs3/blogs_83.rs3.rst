<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://t.me/corpequities/276</segment>
		<segment id="2" parent="35" relname="span">«Компании делают что-то хорошее только там, где они делают что-то плохое», —</segment>
		<segment id="3" parent="2" relname="attribution">отреагировала на днях на мою возвышенную речь об экологичности нашего производства собеседница, представляющая отдел закупок большого авиаперевозчика.</segment>
		<segment id="4" parent="35" relname="evaluation">— «Это такая «отмывка совести», по большому счёту».</segment>
		<segment id="5" parent="37" relname="joint">Распространённое и, увы, подкреплённое практикой взаимодействия производственных предприятий с местными сообществами мнение.</segment>
		<segment id="6" parent="38" relname="span">А ещё — очень удобное,</segment>
		<segment id="7" parent="6" relname="purpose">позволяющее заведомо обесценивать все, что корпорации делают сверх требований законодательства или отраслевых стандартов — например, экологических.</segment>
		<segment id="8" parent="41" relname="span">За маркировку по экостандартам «первого уровня», охватывающим весь жизненный цикл продукта, как инструмент повышения доверия ратовали сегодня на комитете по #КСО Ассоциации менеджеров коллеги из #Opticom, крупнейшего производителя расходных офисных материалов.</segment>
		<segment id="9" parent="40" relname="span">О скепсисе ведущих мировых экспертов относительно способности систем маркировки и прослеживаемости как-то восстанавливать разрушенную веру потребителей в бренды писала здесь уже не раз</segment>
		<segment id="10" parent="9" relname="attribution">(например, https://t.me/corpequities/234).</segment>
		<segment id="11" parent="42" relname="joint">Мало того, что существующие «зелёные стандарты» никак не отражают такую существенную часть производственного цикла, как, например, использование предприятиями возобновляемой энергии или переработанных (вторичных) материалов в упаковке,</segment>
		<segment id="12" parent="52" relname="span">они часто необоснованно перетягивают внимание и брендов, и покупателей на «безопасность» формулы продукта для здоровья человека в ущерб проблемам безопасности производства этого продукта и утилизации его отходов для планеты.</segment>
		<segment id="13" parent="43" relname="joint">Скажем, прекрасный натуральный продукт без синтетических добавок — вода из именитого минерального источника или целебная грязь Мертвого моря — сам по себе может нести огромные преимущества для здоровья пользователя</segment>
		<segment id="14" parent="43" relname="joint">и быть достойным всяческих знаков отличия.</segment>
		<segment id="15" parent="46" relname="span">Однако процесс выкачивания (выгребания) исходного природного сырья в промышленных масштабах, фасовки в нерационально мелкую тару в заведомо не перерабатываемой и не разлагаемой упаковке, а также транспортировки неэкологичным способом за тридевять земель</segment>
		<segment id="16" parent="45" relname="joint">— с приучением этого самого пользователя к тому, что «так удобно,</segment>
		<segment id="17" parent="45" relname="joint">так безопасно</segment>
		<segment id="18" parent="45" relname="joint">или так и должно быть»</segment>
		<segment id="19" parent="46" relname="evaluation">— будет ли когда-то приниматься в расчёт дотошными эко-сертификаторами?</segment>
		<segment id="20" parent="48" relname="span">(О принципах этичного отношения к воде,</segment>
		<segment id="21" parent="20" relname="purpose">используемой для бутилирования и экспорта из страны происхождения,</segment>
		<segment id="22" parent="51" relname="span">в этом канале тоже написано немало, как, собственно, и о рациональном формате бутылки,</segment>
		<segment id="23" parent="24" relname="cause">который, снизившись до 330 мл,</segment>
		<segment id="24" parent="50" relname="span">давно вытеснил со столов переговоров стеклянные стаканы, а из умов жаждущих постоянно увлажнять организм изнутри и снаружи — мысли об ответственном потреблении.)</segment>
		<segment id="25" parent="62" relname="attribution">Скромное пособие по истории и философии науки для аспирантов, найденное мной вчера в библиотеке Высшей школы менеджмента #СПБГУ, поразительно четко суммировало проблему ещё 10 лет назад:</segment>
		<segment id="26" parent="55" relname="contrast">«Один ребёнок на Западе потребляет столько, сколько 125 человек на Востоке.</segment>
		<segment id="27" parent="56" relname="span">И все же большинство жителей развитых стран не захотят отказаться от жизненных благ,</segment>
		<segment id="28" parent="27" relname="concession">несмотря на то, что безудержный рост потребления составляет основную причину деградации природной среды в развивающихся странах.»</segment>
		<segment id="29" parent="66" relname="same-unit">Экологическую безнравственность</segment>
		<segment id="30" parent="31" relname="attribution">авторы пособия объясняли</segment>
		<segment id="31" parent="65" relname="span">несколькими простыми психологическими причинами, а именно: эгоизмом, жадностью, невежеством и недальновидностью жителей развитых стран.</segment>
		<segment id="32" parent="57" relname="span">Очевидно, за минувшие 10 лет болезнь, от которой постепенно пробуждаются западные потребители, широко распространилась на Востоке,</segment>
		<segment id="33" parent="32" relname="condition">— и отнюдь не без содействия большого и малого бизнеса.</segment>
		<segment id="34" >(И в мыслях не было никого обидеть, как говорится).</segment>
		<group id="35" type="span" parent="36" relname="span"/>
		<group id="36" type="span" parent="39" relname="span"/>
		<group id="37" type="multinuc" parent="36" relname="evaluation"/>
		<group id="38" type="span" parent="37" relname="joint"/>
		<group id="39" type="span" />
		<group id="40" type="span" parent="8" relname="background"/>
		<group id="41" type="span" parent="61" relname="preparation"/>
		<group id="42" type="multinuc" parent="61" relname="span"/>
		<group id="43" type="multinuc" parent="44" relname="contrast"/>
		<group id="44" type="multinuc" parent="12" relname="elaboration"/>
		<group id="45" type="multinuc" parent="15" relname="condition"/>
		<group id="46" type="span" parent="47" relname="span"/>
		<group id="47" type="span" parent="44" relname="contrast"/>
		<group id="48" type="span" parent="49" relname="same-unit"/>
		<group id="49" type="multinuc" parent="53" relname="span"/>
		<group id="50" type="span" parent="22" relname="elaboration"/>
		<group id="51" type="span" parent="49" relname="same-unit"/>
		<group id="52" type="span" parent="42" relname="joint"/>
		<group id="53" type="span" parent="54" relname="span"/>
		<group id="54" type="span" />
		<group id="55" type="multinuc" parent="62" relname="span"/>
		<group id="56" type="span" parent="55" relname="contrast"/>
		<group id="57" type="span" parent="67" relname="evidence"/>
		<group id="60" type="span" parent="53" relname="solutionhood"/>
		<group id="61" type="span" parent="60" relname="span"/>
		<group id="62" type="span" parent="63" relname="span"/>
		<group id="63" type="span" parent="64" relname="span"/>
		<group id="64" type="span" />
		<group id="65" type="span" parent="66" relname="same-unit"/>
		<group id="66" type="multinuc" parent="67" relname="span"/>
		<group id="67" type="span" parent="68" relname="span"/>
		<group id="68" type="span" parent="63" relname="evaluation"/>
	</body>
</rst>