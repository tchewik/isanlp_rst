<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >https://kosmetista.ru/blog/otzivi/94681.html</segment>
		<segment id="2" >Lime Crime Velvetines #Red Velvet</segment>
		<segment id="3" parent="4" relname="elaboration">IMG</segment>
		<segment id="4" parent="97" relname="span">Пост об отличной красной помаде)</segment>
		<segment id="5" parent="6" relname="cause">Моя помада – подарок за покупку,</segment>
		<segment id="6" parent="59" relname="span">поэтому дополнительной упаковки у нее не было.</segment>
		<segment id="7" parent="59" relname="evidence">Насколько я знаю, обычно они упакованы в картонные коробки.</segment>
		<segment id="8" parent="95" relname="joint">Футляр сделан из крепкого пластика,</segment>
		<segment id="9" parent="10" relname="cause">розочки и надписи на колпачке медленно, но верно стираются.</segment>
		<segment id="10" parent="62" relname="span">Поэтому просто в сумке помаду лучше не носить.</segment>
		<segment id="11" parent="63" relname="joint">Объем полноразмера как у некоторых миниатюр 😑 – 2,6 мл.</segment>
		<segment id="12" parent="64" relname="elaboration">IMG</segment>
		<segment id="13" parent="66" relname="span">Спонжик скошенный,</segment>
		<segment id="14" parent="13" relname="evaluation">для меня он удобен.</segment>
		<segment id="15" parent="68" relname="contrast">Ограничитель вроде бы есть,</segment>
		<segment id="16" parent="17" relname="cause">но в то же время свою функцию он выполняет плохо,</segment>
		<segment id="17" parent="67" relname="span">поэтому излишки помады я всегда убираю о горлышко.</segment>
		<segment id="18" parent="70" relname="elaboration">IMG</segment>
		<segment id="19" parent="72" relname="joint">По текстуре помада очень жидкая,</segment>
		<segment id="20" parent="72" relname="joint">на губы ложится тонким слоем.</segment>
		<segment id="21" parent="98" relname="evaluation">Пигментация – огонь,</segment>
		<segment id="22" parent="73" relname="joint">помада сразу перекрывает родной цвет</segment>
		<segment id="23" parent="73" relname="joint">и ложится ровно,</segment>
		<segment id="24" parent="73" relname="joint">наслаивания не требует.</segment>
		<segment id="25" parent="74" relname="joint">Отдушка ванильная, довольно яркая и немного химозная.</segment>
		<segment id="26" parent="74" relname="joint">Оттенок – классический красный.</segment>
		<segment id="27" parent="76" relname="sequence">IMG Только нанесла, дневной свет от окна</segment>
		<segment id="28" parent="75" relname="contrast">IMG Помада застыла, также свет от окна,</segment>
		<segment id="29" parent="75" relname="contrast">но солнце успело спрятаться</segment>
		<segment id="30" parent="78" relname="span">По тх помада хороша</segment>
		<segment id="31" parent="77" relname="joint">– ложится ровно,</segment>
		<segment id="32" parent="77" relname="joint">никуда не проваливается</segment>
		<segment id="33" parent="77" relname="joint">и не затекает,</segment>
		<segment id="34" parent="77" relname="joint">ни на чем не отпечатывается</segment>
		<segment id="35" parent="102" relname="span">и боится только жирной пищи.</segment>
		<segment id="36" parent="79" relname="contrast">После обеда ее можно аккуратно подправить,</segment>
		<segment id="37" parent="79" relname="contrast">но, конечно, зависит от того, что вы ели)</segment>
		<segment id="38" parent="80" relname="joint">Финиш полностью матовый,</segment>
		<segment id="39" parent="80" relname="joint">застывает помада где-то за минуту.</segment>
		<segment id="40" parent="81" relname="span">Мне очень нравится, как вельветины выглядят на губах</segment>
		<segment id="41" parent="40" relname="evidence">– даже на макро видно, что рельеф не подчеркнут.</segment>
		<segment id="42" parent="82" relname="contrast">Конечно, губы должны быть в хорошем состоянии перед нанесением,</segment>
		<segment id="43" parent="82" relname="contrast">но пару мелких шелушинок помада простит.</segment>
		<segment id="44" parent="109" relname="span">Касательно комфорта – я наношу помаду на голые губы,</segment>
		<segment id="45" parent="44" relname="condition">без подложки в виде бальзама,</segment>
		<segment id="46" parent="85" relname="span">к вечеру может появиться легкая стянутость.</segment>
		<segment id="47" parent="86" relname="joint">Если носить вельветины несколько дней подряд</segment>
		<segment id="48" parent="86" relname="joint">и на ночь использовать легкий бальзам,</segment>
		<segment id="49" parent="87" relname="span">то губы довольно сильно начинают сохнуть.</segment>
		<segment id="50" parent="88" relname="span">Я обычно после них ночью использую что-то более мощное, например, carmex или blistex.</segment>
		<segment id="51" parent="50" relname="evaluation">Тогда все отлично)</segment>
		<segment id="52" parent="92" relname="span">Демакияж беспроблемный,</segment>
		<segment id="53" parent="91" relname="joint">я использую двухфазное средство или гидрофильное масло,</segment>
		<segment id="54" parent="91" relname="joint">тинта помада не оставляет.</segment>
		<segment id="55" parent="92" relname="elaboration">IMG IMG</segment>
		<segment id="56" parent="106" relname="span">20$ цена</segment>
		<segment id="57" parent="105" relname="span">10/10 оценка</segment>
		<segment id="58" parent="57" relname="elaboration">4 месяца, 1р/в неделю использование</segment>
		<group id="59" type="span" parent="60" relname="span"/>
		<group id="60" type="span" parent="61" relname="span"/>
		<group id="61" type="span" parent="96" relname="span"/>
		<group id="62" type="span" parent="95" relname="joint"/>
		<group id="63" type="multinuc" parent="64" relname="span"/>
		<group id="64" type="span" parent="65" relname="span"/>
		<group id="65" type="span" parent="61" relname="elaboration"/>
		<group id="66" type="span" parent="69" relname="joint"/>
		<group id="67" type="span" parent="68" relname="contrast"/>
		<group id="68" type="multinuc" parent="69" relname="joint"/>
		<group id="69" type="multinuc" parent="70" relname="span"/>
		<group id="70" type="span" parent="71" relname="span"/>
		<group id="71" type="span" />
		<group id="72" type="multinuc" parent="74" relname="joint"/>
		<group id="73" type="multinuc" parent="98" relname="span"/>
		<group id="74" type="multinuc" parent="100" relname="span"/>
		<group id="75" type="multinuc" parent="76" relname="sequence"/>
		<group id="76" type="multinuc" parent="100" relname="elaboration"/>
		<group id="77" type="multinuc" parent="30" relname="evidence"/>
		<group id="78" type="span" parent="103" relname="joint"/>
		<group id="79" type="multinuc" parent="35" relname="elaboration"/>
		<group id="80" type="multinuc" parent="84" relname="joint"/>
		<group id="81" type="span" parent="83" relname="span"/>
		<group id="82" type="multinuc" parent="81" relname="evaluation"/>
		<group id="83" type="span" parent="84" relname="joint"/>
		<group id="84" type="multinuc" parent="103" relname="joint"/>
		<group id="85" type="span" parent="90" relname="span"/>
		<group id="86" type="multinuc" parent="49" relname="condition"/>
		<group id="87" type="span" parent="89" relname="span"/>
		<group id="88" type="span" parent="87" relname="elaboration"/>
		<group id="89" type="span" parent="85" relname="elaboration"/>
		<group id="90" type="span" parent="104" relname="joint"/>
		<group id="91" type="multinuc" parent="52" relname="elaboration"/>
		<group id="92" type="span" parent="93" relname="span"/>
		<group id="93" type="span" parent="104" relname="joint"/>
		<group id="95" type="multinuc" parent="63" relname="joint"/>
		<group id="96" type="span" />
		<group id="97" type="span" parent="60" relname="preparation"/>
		<group id="98" type="span" parent="99" relname="span"/>
		<group id="99" type="span" parent="74" relname="joint"/>
		<group id="100" type="span" parent="101" relname="span"/>
		<group id="101" type="span" />
		<group id="102" type="span" parent="77" relname="joint"/>
		<group id="103" type="multinuc" />
		<group id="104" type="multinuc" parent="107" relname="span"/>
		<group id="105" type="span" parent="56" relname="evaluation"/>
		<group id="106" type="span" parent="107" relname="elaboration"/>
		<group id="107" type="span" parent="108" relname="span"/>
		<group id="108" type="span" />
		<group id="109" type="span" parent="46" relname="cause"/>
	</body>
</rst>