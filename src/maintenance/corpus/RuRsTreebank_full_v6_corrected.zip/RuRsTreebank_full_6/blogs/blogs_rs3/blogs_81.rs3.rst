<rst>
	<header>
		<relations>
			<rel name="antithesis" type="rst"/>
			<rel name="attribution" type="rst"/>
			<rel name="background" type="rst"/>
			<rel name="cause" type="rst"/>
			<rel name="comparison" type="multinuc"/>
			<rel name="concession" type="rst"/>
			<rel name="conclusion" type="rst"/>
			<rel name="condition" type="rst"/>
			<rel name="contrast" type="multinuc"/>
			<rel name="effect" type="rst"/>
			<rel name="elaboration" type="rst"/>
			<rel name="evaluation" type="rst"/>
			<rel name="evidence" type="rst"/>
			<rel name="joint" type="multinuc"/>
			<rel name="motivation" type="rst"/>
			<rel name="preparation" type="rst"/>
			<rel name="purpose" type="rst"/>
			<rel name="restatement" type="multinuc"/>
			<rel name="same-unit" type="multinuc"/>
			<rel name="sequence" type="multinuc"/>
			<rel name="solutionhood" type="rst"/>
		</relations>
	</header>
	<body>
		<segment id="1" >http://www.imorganic.ru/bioplim/</segment>
		<segment id="2" >Одноразовое — вот где начинаются все проблемы</segment>
		<segment id="3" parent="104" relname="span">Недавно стали известны результаты эксперимента исследователей из Университета Плимута в Великобритании,</segment>
		<segment id="4" parent="103" relname="span">целью которого было понять, как разные виды пластика, в том числе компостируемого и биоразлагаемого, ведут себя в естественной среде,</segment>
		<segment id="5" parent="4" relname="elaboration">как каждый из них влияет на засорение окружающей среды.</segment>
		<segment id="6" parent="199" relname="evaluation">Выводы неприятно удивили общественность.</segment>
		<segment id="7" parent="8" relname="attribution">Учёные заговорили о том,</segment>
		<segment id="8" parent="199" relname="span">что безобидного пластика в принципе не существует.</segment>
		<segment id="9" parent="106" relname="contrast">Я уже подробно рассказывала о проблеме биоразлагаемого пластика,</segment>
		<segment id="10" parent="107" relname="contrast">но намного эффективнее — показать, что с ним происходит</segment>
		<segment id="11" parent="107" relname="contrast">(или не происходит)</segment>
		<segment id="12" parent="108" relname="same-unit">в естественной среде на самом деле.</segment>
		<segment id="13" parent="113" relname="attribution">Ведь производители биоразлагаемых и оксобиоразлагаемых пакетов и упаковки постоянно твердят,</segment>
		<segment id="14" parent="112" relname="joint">что их пластик разлагается на органические вещества в естественной среде,</segment>
		<segment id="15" parent="112" relname="joint">причём делает это быстро, буквально за 1-3 года.</segment>
		<segment id="16" parent="122" relname="contrast">Звучит здорово,</segment>
		<segment id="17" parent="120" relname="attribution">однако ещё в 2015 году ООН сообщила,</segment>
		<segment id="18" parent="19" relname="cause">что биоразлагаемый пластик редко полностью разлагается естественной среде,</segment>
		<segment id="19" parent="118" relname="span">и если продолжать маркировать биопластик как полностью разлагаемый,</segment>
		<segment id="20" parent="114" relname="joint">это приведёт к тому, что люди станут больше его использовать,</segment>
		<segment id="21" parent="114" relname="joint">легкомысленно выбрасывая,</segment>
		<segment id="22" parent="119" relname="span">а не перерабатывая,</segment>
		<segment id="23" parent="22" relname="cause">поскольку будут уверены, что пластик быстро разложится без следа.</segment>
		<segment id="24" parent="132" relname="preparation">Очередным подтверждением тому стал эксперимент, проведённый Университетом Плимута.</segment>
		<segment id="25" parent="126" relname="same-unit">Исследователи взяли пять разных пакетов: обычный пластиковый; два оксобиоразлагаемых;</segment>
		<segment id="26" parent="127" relname="span">один пакет,</segment>
		<segment id="27" parent="123" relname="contrast">продаваемый как биоразлагаемый,</segment>
		<segment id="28" parent="123" relname="contrast">но без подтверждения разлагаемости;</segment>
		<segment id="29" parent="124" relname="span">и один пакет,</segment>
		<segment id="30" parent="29" relname="purpose">пригодный для компостирования,</segment>
		<segment id="31" parent="124" relname="elaboration">сертифицированный в соответствии с европейским стандартом 13432.</segment>
		<segment id="32" parent="128" relname="sequence">Они поместили по одному такому «пластиковому» набору в морскую воду, почву, а также в среду с доступом кислорода.</segment>
		<segment id="33" parent="129" relname="contrast">В итоге, спустя три года, в море «выжили» все пакеты,</segment>
		<segment id="34" parent="129" relname="contrast">кроме компостируемого, который растворился через три месяца.</segment>
		<segment id="35" parent="130" relname="span">В земле компостируемый пакет тоже повёл себя лучше остальных,</segment>
		<segment id="36" parent="35" relname="concession">хотя его частицы обнаружили в почве спустя 27 месяцев.</segment>
		<segment id="37" parent="138" relname="span">На воздухе все мешки развалились на куски за девять месяцев.</segment>
		<segment id="38" parent="136" relname="span">IMG</segment>
		<segment id="39" parent="134" relname="joint">Биоразлагаемый пакет, который пробыл в морской воде три года</segment>
		<segment id="40" parent="134" relname="joint">и не разложился.</segment>
		<segment id="41" parent="135" relname="contrast">Он легко выдержал вес покупок.</segment>
		<segment id="42" parent="136" relname="elaboration">Фото: Университет Плимута</segment>
		<segment id="43" parent="139" relname="evidence">После эксперимента стало понятно:</segment>
		<segment id="44" parent="139" relname="span">только сертифицированные компостируемые пакеты можно использовать</segment>
		<segment id="45" parent="44" relname="purpose">для сбора пищевых отходов и переработки на специальных компостных заводах.</segment>
		<segment id="46" parent="47" relname="condition">Даже если такие пакеты случайно попадут в окружающую среду,</segment>
		<segment id="47" parent="141" relname="span">вред от них будет меньше, чем от обычных или оксобиоразлагаемых.</segment>
		<segment id="48" parent="145" relname="attribution">Исследование в очередной раз напомнило нам,</segment>
		<segment id="49" parent="143" relname="joint">что волшебных материалов не существует,</segment>
		<segment id="50" parent="144" relname="span">что на первый взгляд безобидные биопластики следует утилизировать на специальных предприятиях,</segment>
		<segment id="51" parent="50" relname="purpose">дабы избежать загрязнения окружающей среды.</segment>
		<segment id="52" parent="53" relname="preparation">Плюсы и минусы биопластика</segment>
		<segment id="53" parent="156" relname="span">У биопластика есть преимущества.</segment>
		<segment id="54" parent="148" relname="condition">Когда мы используем биомассу вроде того же кукурузного крахмала,</segment>
		<segment id="55" parent="56" relname="cause">мы не используем ископаемое топливо,</segment>
		<segment id="56" parent="148" relname="span">тем самым сокращая выбросы углекислого газа.</segment>
		<segment id="57" parent="150" relname="span">Это важно,</segment>
		<segment id="58" parent="57" relname="cause">потому что пластик производится в огромных количествах — для пищевой промышленности, сферы общественного питания, сельского хозяйства, медицины, бытовой электроники и автопрома.</segment>
		<segment id="59" parent="152" relname="span">В Евросоюзе продаётся 100 млрд. пластиковых пакетов каждый год,</segment>
		<segment id="60" parent="59" relname="elaboration">из них до 8 млрд. в конечном итоге превращаются в мусор.</segment>
		<segment id="61" parent="152" relname="attribution">(отчёт Европейской комиссии, 2013)</segment>
		<segment id="62" parent="157" relname="preparation">Но у биопластика есть ярые противники.</segment>
		<segment id="63" parent="64" relname="attribution">Так, по мнению архитектора и эксперта по переработке Артура Хуанга,</segment>
		<segment id="64" parent="157" relname="span">биопластики могут представлять большую опасность для окружающей среды, чем обычный пластик.</segment>
		<segment id="65" parent="164" relname="attribution">Он утверждает, что</segment>
		<segment id="66" parent="67" relname="purpose">для перехода на пластик, произведённый из растений вместо ископаемого топлива,</segment>
		<segment id="67" parent="158" relname="span">потребуется огромное количество сельскохозяйственных угодий,</segment>
		<segment id="68" parent="159" relname="span">а это может привести к экологическим проблемам</segment>
		<segment id="69" parent="160" relname="span">и лишить людей пищи.</segment>
		<segment id="70" parent="161" relname="span">Кроме того, биопластик может нанести ущерб</segment>
		<segment id="71" parent="70" relname="condition">при компостировании,</segment>
		<segment id="72" parent="197" relname="same-unit">поскольку,</segment>
		<segment id="73" parent="198" relname="attribution">по его словам,</segment>
		<segment id="74" parent="198" relname="span">он меняет pH почвы и воды,</segment>
		<segment id="75" parent="74" relname="elaboration">повышая её кислотность.</segment>
		<segment id="76" parent="170" relname="attribution">Хуанг называет</segment>
		<segment id="77" parent="168" relname="span">обычный океанский пластик эстетической проблемой:</segment>
		<segment id="78" parent="166" relname="contrast">да, некрасиво,</segment>
		<segment id="79" parent="167" relname="span">но такой пластик практически не деформируется,</segment>
		<segment id="80" parent="79" relname="cause">поскольку не наносит физического ущерба экосистемам.</segment>
		<segment id="81" parent="169" relname="contrast">А вот биопластик превращает эстетическую проблему в химическую.</segment>
		<segment id="82" parent="171" relname="evaluation">Тем самым Хуанг бросил вызов идее, что биопластики лучше пластика из ископаемого топлива.</segment>
		<segment id="83" parent="202" relname="span">Я не соглашусь с Хуангом как минимум по одной причине:</segment>
		<segment id="84" parent="85" relname="cause">из-за пластикового мусора</segment>
		<segment id="85" parent="195" relname="span">ежегодно погибают сотни живых существ,</segment>
		<segment id="86" parent="201" relname="span">поэтому нельзя так безапелляционно утверждать, что опасности для экосистем нет.</segment>
		<segment id="87" parent="186" relname="preparation">Возражают Хуангу и сторонники биопластика.</segment>
		<segment id="88" parent="178" relname="span">Французский архитектор Артур Маму-Мани, работающий с биопластиком</segment>
		<segment id="89" parent="88" relname="purpose">для 3D-печати,</segment>
		<segment id="90" parent="179" relname="same-unit">утверждает,</segment>
		<segment id="91" parent="180" relname="joint">что это очень чистый материал,</segment>
		<segment id="92" parent="180" relname="joint">что он менее токсичен</segment>
		<segment id="93" parent="181" relname="purpose">и позволяет снизить выбросы СО2 до 68%.</segment>
		<segment id="94" parent="95" relname="attribution">Маму-Мани</segment>
		<segment id="95" parent="184" relname="span">также опроверг утверждение об изменении pH почвы и воды.</segment>
		<segment id="96" parent="188" relname="contrast">И хотя у биопластика есть сторонники и противники,</segment>
		<segment id="97" parent="189" relname="span">но и те, и другие сходятся в одном:</segment>
		<segment id="98" parent="97" relname="elaboration">главная проблема — в одноразовости.</segment>
		<segment id="99" parent="190" relname="contrast">Правильная переработка и компостирование могут частично решить проблему пластикового мусора,</segment>
		<segment id="100" parent="191" relname="span">но по-настоящему её можно решить,</segment>
		<segment id="101" parent="100" relname="condition">лишь прекратив использование одноразовых товаров.</segment>
		<segment id="102" parent="191" relname="cause">В окружающую среду должно попадать как можно меньше пластика.</segment>
		<group id="103" type="span" parent="3" relname="purpose"/>
		<group id="104" type="span" parent="105" relname="span"/>
		<group id="105" type="span" />
		<group id="106" type="multinuc" parent="110" relname="span"/>
		<group id="107" type="multinuc" parent="108" relname="same-unit"/>
		<group id="108" type="multinuc" parent="106" relname="contrast"/>
		<group id="109" type="span" parent="110" relname="cause"/>
		<group id="110" type="span" parent="111" relname="span"/>
		<group id="111" type="span" />
		<group id="112" type="multinuc" parent="113" relname="span"/>
		<group id="113" type="span" parent="109" relname="span"/>
		<group id="114" type="multinuc" parent="117" relname="span"/>
		<group id="115" type="multinuc" parent="120" relname="span"/>
		<group id="116" type="span" parent="115" relname="contrast"/>
		<group id="117" type="span" parent="116" relname="span"/>
		<group id="118" type="span" parent="117" relname="cause"/>
		<group id="119" type="span" parent="115" relname="contrast"/>
		<group id="120" type="span" parent="121" relname="span"/>
		<group id="121" type="span" parent="122" relname="contrast"/>
		<group id="122" type="multinuc" />
		<group id="123" type="multinuc" parent="26" relname="elaboration"/>
		<group id="124" type="span" parent="125" relname="span"/>
		<group id="125" type="span" parent="126" relname="same-unit"/>
		<group id="126" type="multinuc" parent="128" relname="sequence"/>
		<group id="127" type="span" parent="126" relname="same-unit"/>
		<group id="128" type="multinuc" parent="131" relname="comparison"/>
		<group id="129" type="multinuc" parent="128" relname="sequence"/>
		<group id="130" type="span" parent="131" relname="comparison"/>
		<group id="131" type="multinuc" parent="132" relname="span"/>
		<group id="132" type="span" parent="133" relname="span"/>
		<group id="133" type="span" />
		<group id="134" type="multinuc" parent="135" relname="contrast"/>
		<group id="135" type="multinuc" parent="38" relname="elaboration"/>
		<group id="136" type="span" parent="137" relname="span"/>
		<group id="137" type="span" parent="37" relname="elaboration"/>
		<group id="138" type="span" parent="131" relname="comparison"/>
		<group id="139" type="span" parent="140" relname="span"/>
		<group id="140" type="span" parent="142" relname="span"/>
		<group id="141" type="span" parent="140" relname="elaboration"/>
		<group id="142" type="span" parent="147" relname="span"/>
		<group id="143" type="multinuc" parent="145" relname="span"/>
		<group id="144" type="span" parent="143" relname="joint"/>
		<group id="145" type="span" parent="146" relname="span"/>
		<group id="146" type="span" parent="142" relname="evaluation"/>
		<group id="147" type="span" />
		<group id="148" type="span" parent="149" relname="span"/>
		<group id="149" type="span" parent="151" relname="span"/>
		<group id="150" type="span" parent="149" relname="evaluation"/>
		<group id="151" type="span" parent="154" relname="span"/>
		<group id="152" type="span" parent="153" relname="span"/>
		<group id="153" type="span" parent="151" relname="elaboration"/>
		<group id="154" type="span" parent="155" relname="span"/>
		<group id="155" type="span" />
		<group id="156" type="span" parent="154" relname="preparation"/>
		<group id="157" type="span" parent="174" relname="span"/>
		<group id="158" type="span" parent="68" relname="cause"/>
		<group id="159" type="span" parent="69" relname="cause"/>
		<group id="160" type="span" parent="163" relname="joint"/>
		<group id="161" type="span" parent="162" relname="span"/>
		<group id="162" type="span" parent="163" relname="joint"/>
		<group id="163" type="multinuc" parent="164" relname="span"/>
		<group id="164" type="span" parent="165" relname="span"/>
		<group id="165" type="span" parent="173" relname="span"/>
		<group id="166" type="multinuc" parent="77" relname="elaboration"/>
		<group id="167" type="span" parent="166" relname="contrast"/>
		<group id="168" type="span" parent="169" relname="contrast"/>
		<group id="169" type="multinuc" parent="170" relname="span"/>
		<group id="170" type="span" parent="171" relname="span"/>
		<group id="171" type="span" parent="172" relname="span"/>
		<group id="172" type="span" parent="177" relname="span"/>
		<group id="173" type="span" />
		<group id="174" type="span" parent="165" relname="preparation"/>
		<group id="177" type="span" />
		<group id="178" type="span" parent="179" relname="same-unit"/>
		<group id="179" type="multinuc" parent="182" relname="attribution"/>
		<group id="180" type="multinuc" parent="181" relname="span"/>
		<group id="181" type="span" parent="182" relname="span"/>
		<group id="182" type="span" parent="183" relname="span"/>
		<group id="183" type="span" parent="185" relname="joint"/>
		<group id="184" type="span" parent="185" relname="joint"/>
		<group id="185" type="multinuc" parent="186" relname="span"/>
		<group id="186" type="span" parent="187" relname="span"/>
		<group id="187" type="span" />
		<group id="188" type="multinuc" parent="193" relname="solutionhood"/>
		<group id="189" type="span" parent="188" relname="contrast"/>
		<group id="190" type="multinuc" parent="193" relname="span"/>
		<group id="191" type="span" parent="192" relname="span"/>
		<group id="192" type="span" parent="190" relname="contrast"/>
		<group id="193" type="span" parent="194" relname="span"/>
		<group id="194" type="span" />
		<group id="195" type="span" parent="86" relname="cause"/>
		<group id="196" type="span" parent="197" relname="same-unit"/>
		<group id="197" type="multinuc" parent="161" relname="cause"/>
		<group id="198" type="span" parent="196" relname="span"/>
		<group id="199" type="span" parent="200" relname="span"/>
		<group id="200" type="span" parent="104" relname="evaluation"/>
		<group id="201" type="span" parent="83" relname="elaboration"/>
		<group id="202" type="span" parent="172" relname="evaluation"/>
	</body>
</rst>